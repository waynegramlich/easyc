#include "Compiler.ez.h"/*cc2*/
/* # Copyright (c) 2004-2010 by Wayne C. Gramlich. */
/* # All rights reserved. */
/* # This is compiler type: */
#include "Easy_C.ez.h"/*D1*/
#include "EZCC.ez.h"/*D1*/
#include "Declaration.ez.h"/*D1*/
#include "Parse.ez.h"/*D1*/
#include "Token.ez.h"/*D1*/
#include "Unix.ez.h"/*D1*/
/* # {Array} routines: */
/* #undef lower case macros */
#undef i386
#undef linux
#undef unix
#undef errno
#undef makedev
#undef major
#undef minor
#undef alloca

void Array__visit(
  Array array,
  String buffer,
  Compiler compiler,
  void (*visit_routine)(void *, String, Compiler))
{
    Unsigned size;
    Unsigned index;
    void *sub_type;
    size = Array__size_get(array);
    index = 0;
    while ((index < size)) {
        sub_type = ((void *)Array__fetch1(array, index));
        (void)visit_routine(sub_type, buffer, compiler);
        index = (index+1);
    }
}

/* # {Collection} routines: */
Collection Collection__create(
  String name,
  Source source)
{
    Array sources;
    Collection collection;
    sources = Array__new();
    (void)Array__append(sources, ((void *)(source)));
    collection = Collection__new();
    collection->name = name;
    collection->sources = sources;
    collection->version_major = 0xffffffff;
    collection->version_minor = 0xffffffff;
    return collection;
}

void Collection__buffer_append(
  Collection collection,
  String buffer)
{
    if (!(0)) {
        System__assert_fail((String)"\14Compiler.ezc", 191);
    }
}

/* # {Compile_Phase} routines: */
String Compile_Phase__f(
  Compile_Phase compile_phase)
{
    String value;
    String text;
    value = Format__field_next();
    (void)String__trim(value, 0);
    text = String__null;
    switch (compile_phase) {
        case Compile_Phase___ezc_read_library_type_find:
            text = ((String)"\032ezc_read_library_type_find");
            break;
        case Compile_Phase___ezc_read:
            text = ((String)"\010ezc_read");
            break;
        case Compile_Phase___ezg_read:
            text = ((String)"\010ezg_read");
            break;
        case Compile_Phase___h_generate:
            text = ((String)"\012h_generate");
            break;
        case Compile_Phase___c_generate:
            text = ((String)"\012c_generate");
            break;
        case Compile_Phase___c_compile:
            text = ((String)"\011c_compile");
            break;
        case Compile_Phase___link:
            text = ((String)"\004link");
            break;
    }
    (void)String__string_append(value, text);
    return value;
}

/* # {Compiler} routines: */
Collection Compiler__collection_register(
  Compiler compiler,
  Collection_Declaration collection_declaration,
  Source source)
{
    String name;
    Collection collection;
    Token float_number;
    String version;
    Unsigned size;
    Unsigned number;
    Unsigned index;
    Character character;
    String t__0;
    name = collection_declaration->name->value;
    collection = ((Collection)Hash_Table__lookup(compiler->collection_table, ((void *)(name))));
    if ((collection == Collection__null)) {
        collection = Collection__create(name, source);
        (void)Array__append(compiler->collections, ((void *)(collection)));
    } else {
        (void)Array__append(collection->sources, ((void *)(source)));
    }
    if (String__equal(name, collection->name)) {
        float_number = collection_declaration->float_number;
        version = float_number->value;
        size = String__size_get(version);
        number = 0;
        index = 0;
        while ((index < size)) {
            character = String__fetch1(version, index);
            if ((character == ((Character)'.'))) {

                collection->version_major = number;
                number = 0;
            } else if (Character__is_decimal_digit(character)) {
                number = ((number*10)+Character__decimal_convert(character));
            } else {
                (void)Compiler__log(compiler, float_number, (t__0 = String__form(((String)"\057Version number (%v%) is not in major.minor form")), String__divide((t__0), String__f(version))));
                break;
            }
            index = (index+1);
        }
        collection->version_minor = number;
    }
    return collection;
}

void Compiler__define_register(
  Compiler compiler,
  Define_Declaration define)
{
    Type define_type;
    String define_name;
    String type_name;
    Hash_Table define_table;
    Define_Declaration previous_define;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Base_Type_Clause base_type;
    Type new_type;
    Simple_Clause simple;
    Type simple_type;
    Simple_Numeric_Clause simple_numeric;
    String t__0;
    define_type = define->type;
    define_name = Type__base_name(define_type);
    type_name = Type__base_name(define_type);
    define_table = compiler->define_table;
    previous_define = ((Define_Declaration)Hash_Table__lookup(define_table, ((void *)(type_name))));
    if ((previous_define == Define_Declaration__null)) {

        if (!(!Hash_Table__insert(define_table, ((void *)(type_name)), ((void *)(define))))) {
            System__assert_fail((String)"\14Compiler.ezc", 289);
        }
        define_clauses = define->define_clauses;
        size = Array__size_get(define_clauses);
        index = 0;
        while ((index < size)) {
            define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
            switch (define_clause->kind) {
                case Define_Clause_Kind___base_type:


                    base_type = ((define_clause->kind == Define_Clause_Kind___base_type) ? define_clause->kind__union.base_type : (Base_Type_Clause)System__variant_object_fail((String)"\14Compiler.ezc", 300));
                    new_type = Type__simple_create(define_name);
                    (void)Compiler__scalar_insert(compiler, define_name, new_type, base_type->end_of_line);
                    break;
                case Define_Clause_Kind___simple:
                    simple = ((define_clause->kind == Define_Clause_Kind___simple) ? define_clause->kind__union.simple : (Simple_Clause)System__variant_object_fail((String)"\14Compiler.ezc", 305));
                    simple_type = simple->type;
                    if (Type__is_scalar(simple_type)) {
                        new_type = Type__simple_create(define_name);
                        (void)Compiler__scalar_insert(compiler, define_name, new_type, simple->end_of_line);
                    }
                    break;
                case Define_Clause_Kind___simple_numeric:
                    simple_numeric = ((define_clause->kind == Define_Clause_Kind___simple_numeric) ? define_clause->kind__union.simple_numeric : (Simple_Numeric_Clause)System__variant_object_fail((String)"\14Compiler.ezc", 312));
                    (void)Compiler__scalar_insert(compiler, define_name, simple_numeric->type, simple_numeric->end_of_line);
                    break;
                case Define_Clause_Kind___end_of_line:
                case Define_Clause_Kind___enumeration:
                case Define_Clause_Kind___enumeration_prefix:
                case Define_Clause_Kind___error:
                case Define_Clause_Kind___external:
                case Define_Clause_Kind___generate:
                case Define_Clause_Kind___note:
                case Define_Clause_Kind___record:
                case Define_Clause_Kind___record_import:
                case Define_Clause_Kind___registers:
                case Define_Clause_Kind___variant:
                    /* do_nothing */
                    break;
            }
            index = (index+1);
        }
    } else {

        (void)Messages__log2(compiler->messages, define->end_of_line, previous_define->end_of_line, (t__0 = String__form(((String)"\045%t% is defined in multiple locations\n")), String__divide((t__0), Type__f(define_type))));
    }
}

/* #routine compile@Compiler */
/* #    takes compiler Compiler */
/* #    takes source_base String */
/* #    takes options Options */
/* #    takes compile_phase Compile_Phase */
/* #    returns Unsigned */
/* # */
/* #    # This routine will compile the code specified by options at phase */
/* #    #, level {phase}. */
/* #    #,  {phase}=1 => .ezg, .ezh, .h generation, */
/* #    #,  {phase}=2 => .c genaration, */
/* #    #,  {phase}=3 => .o generation. */
/* # */
/* #    includes :@= compiler.includes */
/* #    defines_prefixes :@= compiler.defines_prefixes */
/* #    enumeration_prefixes :@= compiler.enumeration_prefixes */
/* #    call trim@(includes, 0) */
/* #    call trim@(defines_prefixes, 0) */
/* #    call trim@(enumeration_prefixes, 0) */
/* # */
/* #    middlefix :@= compiler.middlefix */
/* #    c_suffix :@= new@String() */
/* #    ezg_suffix :@= new@String() */
/* #    ezh_suffix :@= new@String() */
/* #    h_suffix :@= new@String() */
/* #    call string_append@(c_suffix, middlefix) */
/* #    call string_append@(ezg_suffix, middlefix) */
/* #    call string_append@(ezh_suffix, middlefix) */
/* #    call string_append@(h_suffix, middlefix) */
/* # */
/* #    call string_append@(c_suffix, ".c") */
/* #    call string_append@(ezg_suffix, ".ezg") */
/* #    call string_append@(ezh_suffix, ".ezh") */
/* #    call string_append@(h_suffix, ".h") */
/* # */
/* #    temporary :@= compiler.temporary */
/* #    phase_trace :@= options.verbose */
/* #    trace :@= false@Logical */
/* #    #trace := true@Logical */
/* #    if trace */
/* #        call put@(form@("=>compile@Compiler(*, %qv%, *, %d%)\n\") %  */
/* #	  f@(source_base) / f@(0), error@Out_Stream) */
/* # */
/* #    # Get some basic resources: */
/* #    buffer :@= compiler.buffer */
/* #    messages :@= compiler.messages */
/* #    parser :@= compiler.parser */
/* #    result :@= 0 */
/* #    tokenizer :@= compiler.tokenizer */
/* # */
/* #    # Extract options: */
/* #    verbose :@= options.verbose */
/* # */
/* #    switch compile_phase */
/* #      all_cases_required */
/* #      case ezc_read_library_type_find */
/* #	assert false@Logical	 */
/* #      case ezg_read */
/* #	assert false@Logical	 */
/* #      case h_generate */
/* #	assert false@Logical	 */
/* #      case ezc_read */
/* #	if phase_trace */
/* #	    call put@(form@("Phase 1: %qv%\n\") / f@(source_base), */
/* #	      error@Out_Stream) */
/* # */
/* #	ezc_file :@= read@File(source_base, "", ".ezc", compiler) */
/* #	define_datas :@= ezc_file.define_datas */
/* #	compiler.define_datas := define_datas */
/* #	if ezc_file !== null@File */
/* #	    ezc_tokens :@= ezc_file.tokens */
/* #	    root :@= parse@(parser, ezc_tokens) */
/* #	    ezc_file.root := root */
/* # */
/* #	    # Figure out the various prefix commands: */
/* #	    call visit@(root, buffer, compiler, prefix_scan@Phase) */
/* # */
/* #	    zero :@= 0i */
/* #	    defines_size :@= defines_prefixes.size */
/* #	    enumerations_size :@= enumeration_prefixes.size */
/* #	    if defines_size != 0 || enumerations_size != 0 */
/* #		# We've got some work to do: */
/* # */
/* #		#call d@(form@("defines_size=%d%\n\") / f@(defines_size)) */
/* #		#call d@(form@("enumerations_size=%d%\n\") / */
/* #		#  f@(enumerations_size)) */
/* # */
/* #		includes := compiler.includes */
/* #		size :@= includes.size */
/* #		if size = 0 */
/* #		    defines_prefix :@= defines_prefixes[0] */
/* #		    call log@(compiler, defines_prefix.defines_prefix.keyword, */
/* #		      "There are no 'include' declarations to fetch from") */
/* #		else */
/* #		    # Construct an file containing the #includes: */
/* #		    include_stream :@= open@Out_Stream("/tmp/includes.c") */
/* #		    assert include_stream !== null@Out_Stream */
/* #		    index :@= 0 */
/* #		    while index < size */
/* #			include :@= includes[index] */
/* #			call put@(form@("#include \dq\%s%\dq\//C1./\n\") / */
/* #			  f@(string_convert@(include.string)), include_stream) */
/* #			index := index + 1 */
/* #		    call close@(include_stream) */
/* # */
/* #		    compiler_name :@= options.compiler_executable */
/* #		    if compiler_name == null@String */
/* #			compiler_name := "gcc" */
/* #		    command :@= new@String() */
/* #		    call string_append@(command, */
/* #		      form@("%s% -E %s% -I. -dM /tmp/includes.c | sed s,#,,g | sed /[0-9]EE/d | sed /[0-9]D[DLF]/d") % */
/* #		      f@(compiler_name) / f@(compiler.search_options)) */
/* #		    #call d@(form@("Command: %v%\n\") / f@(command)) */
/* # */
/* #		    define_stream :@= pipe_read@In_Stream(command) */
/* #		    define_contents :@= all_read@(define_stream, null@String) */
/* #		    call close@(define_stream) */
/* #		    #call put@(define_contents, error@Out_Stream) */
/* # */
/* #		    define_tokens :@= new@Array[Token]() */
/* #		    indents :@= new@Array[Unsigned]() */
/* #		    call append@(indents, 0) */
/* # */
/* #		    tokenizer.contents := define_contents */
/* #		    tokenizer.tokens := define_tokens */
/* #		    tokenizer.index := 0 */
/* #		    tokenizer.indents := indents */
/* #	 */
/* #		    lexeme :@= at_sign@Lexeme */
/* #		    while lexeme != end_of_file@Lexeme */
/* #			token :@= next@(tokenizer) */
/* #			lexeme := token.lexeme */
/* #			call append@(define_tokens, token) */
/* # */
/* #		    parser := create@Parser(define_tokens, new@Messages()) */
/* #		    define_root :@= parse@Define_Root(parser) */
/* # */
/* #		    # Now output the defines: */
/* #		    defines :@= define_root.defines */
/* #		    define_lines :@= new@Array[Define_Line]() */
/* #		    size := defines.size */
/* #		    index := 0 */
/* #		    while index < size */
/* #			define :@= defines[index] */
/* #			switch define.kind */
/* #			  case define_line */
/* #			    call append@(define_lines, define.define_line) */
/* #			index := index + 1 */
/* # */
/* #		    call sort@(define_lines, compare@Define_Line) */
/* # */
/* #		    size := define_lines.size */
/* #		    lower_case :@= new@String() */
/* #		    index := 0 */
/* #		    while index < size */
/* #			define_line :@= define_lines[index] */
/* #			define_name :@= define_line.name.value */
/* #			define_name_size :@= define_name.size */
/* #			define_value :@= define_line.number.value */
/* # */
/* #			#call put@(form@(define[%d%] %qv% %qv%\n\") % */
/* #			#  f@(index) % f@(define_name) / f@(define_value), */
/* #			#  error@Out_Stream) */
/* # */
/* #			defines_index :@= 0 */
/* #			while defines_index < defines_size */
/* #			    defines_prefix :@= defines_prefixes[defines_index] */
/* #			    prefix :@= defines_prefix.prefix.value */
/* #			    match :@= defines_prefix.match.value */
/* # */
/* #			    #call put@(form@( */
/* #			    #  "    prefix[%d%] %qv% match %qv%\n\") % */
/* #			    #  f@(prefixes_index) % f(prefix) / f@(match), */
/* #			    #  error@Out_Stream) */
/* # */
/* #			    match_size :@= match.size */
/* #			    if define_name_size >= match_size && */
/* #			      range_compare@(define_name, 0, match_size, */
/* #			      match, 0, match_size) = zero */
/* #				# We have a match: */
/* #				#call put@("*************************Match\n\", */
/* #				#  error@Out_Stream) */
/* #				new_name :@= new@String() */
/* #				call string_append@(new_name, prefix) */
/* #				call range_append@(new_name, define_name, */
/* #				  match_size, define_name_size - match_size) */
/* #				call lower_case@(new_name) */
/* # */
/* #				define_data :@= new@Define_Data() */
/* #				define_data.old_name := define_name */
/* #				define_data.new_name := new_name */
/* #				define_data.value := define_value */
/* #				define_data.type_name := */
/* #				  defines_prefix.type_name.value */
/* #				call append@(define_datas, define_data) */
/* #			    defines_index := defines_index + 1 */
/* # */
/* #			enumerations_index :@= 0 */
/* #			while enumerations_index < enumerations_size */
/* #			    enumeration_prefix :@= */
/* #			      enumeration_prefixes[enumerations_index] */
/* #			    prefix :@= enumeration_prefix.prefix.value */
/* #			    match :@= enumeration_prefix.prefix.value */
/* #			    match_size :@= match.size */
/* #			    if define_name_size >= match_size && */
/* #			      range_compare@(define_name, 0, match_size, */
/* #			      match, 0, match_size) = 0i */
/* #				# We have a match: */
/* #				new_name :@= new@String() */
/* #				call string_append@(new_name, define_name) */
/* #				call lower_case@(new_name) */
/* # */
/* #				#call d@(form@("enum_def match:%v%=%v%\n\") % */
/* #				#  f@(define_name) / f@(define_value)) */
/* # */
/* #				if !enumeration_prefix.define_datas_initialized */
/* #				    enumeration_prefix.define_datas := */
/* #				      new@Array[Define_Data]() */
/* #				    enumeration_prefix. */
/* #				      define_datas_initialized := true@Logical */
/* #				define_data :@= new@Define_Data() */
/* #				define_data.old_name := define_name */
/* #				define_data.new_name := new_name */
/* #				define_data.value := define_value */
/* #				define_data.type_name := "" */
/* #				call append@(enumeration_prefix.define_datas, */
/* #				  define_data) */
/* #			    enumerations_index := enumerations_index + 1 */
/* #			index := index + 1 */
/* # */
/* #	    # Generate .ezg file: */
/* #	    call trim@(buffer, 0) */
/* #	    call visit@(root, buffer, compiler, generate_emit@Phase) */
/* #	    ezg_file_name :@= new@String() */
/* #	    call string_append@(ezg_file_name, source_base) */
/* #	    call string_append@(ezg_file_name, ezg_suffix) */
/* #	    ezg_stream :@= open@Out_Stream(ezg_file_name) */
/* #	    assert ezg_stream !== null@Out_Stream */
/* #	    call put@(buffer, ezg_stream) */
/* #	    call close@(ezg_stream) */
/* # */
/* #	    if buffer.size != 0 */
/* #		# There is stuff in the .ezg file that needs to be processed: */
/* #		ezg_file :@= read@File(source_base, */
/* #		  middlefix, ".ezg", compiler) */
/* #		assert ezg_file !== null@File */
/* #		call parse_append@(parser, root, ezg_file.tokens) */
/* # */
/* #	    # Generate the .h file: */
/* #	    upper_source_base :@= new@String() */
/* #	    call upper_case_append@(upper_source_base, source_base) */
/* # */
/* #	    call trim@(buffer, 0) */
/* # */
/* #	    call string_append@(buffer, */
/* #	      form@("#ifndef %s%_INCLUDED\n\") / f@(upper_source_base)) */
/* #	    call string_append@(buffer, */
/* #	      form@("#define %s%_INCLUDED 1\n,n\") / f@(upper_source_base)) */
/* #	    call string_append@(buffer, */
/* #	      "// Declare all enum's and typedef's first: ./\n\") */
/* # */
/* #	    call visit@(root, buffer, compiler, h_typedefs_emit@Phase) */
/* # */
/* #	    simple_typedefs :@= compiler.simple_typedefs */
/* #	    if simple_typedefs.size != 0 */
/* #		#call string_append@(buffer, */
/* #		#  "\n\ Simple typedefs are stuffed into a macro: \n\") */
/* #		call string_append@(buffer, simple_typedefs) */
/* #		call trim@(simple_typedefs, 0) */
/* #		#call string_append@(buffer, "\n\") */
/* #		#call string_append@(buffer, "#ifdef SCALARS___DEFINED\n\") */
/* #		#call string_append@(buffer, "SIMPLE___TYPEDEFS\n\") */
/* #		#call string_append@(buffer, "#endif\n,n\") */
/* # */
/* #	    call string_append@(buffer, */
/* #	      "\n\// Include other libraries exactly once: ./\n\") */
/* # */
/* #	    call visit@Root(root, buffer, compiler, h_includes_emit@Phase) */
/* # */
/* #	    call string_append@(buffer, "\n\// Define the structures: ./\n\") */
/* # */
/* #	    call visit@Root(root, buffer, compiler, h_structs_emit@Phase) */
/* # */
/* #	    call string_append@(buffer, */
/* #	      "\n\// Declare the routine prototypes: ./\n\") */
/* # */
/* #	    call visit@(root, buffer, compiler, h_externs_emit@Phase) */
/* # */
/* #	    size := define_datas.size */
/* #	    if size != 0 */
/* #		call string_append@(buffer, */
/* #		  "\n\// Declare extracted #define values: ./\n\") */
/* # */
/* #		index := 0 */
/* #		while index < size */
/* #		    define_data :@= define_datas[index] */
/* #		    call string_append@(buffer, */
/* #		      read_only_copy@(form@("extern %s% %s%__%s%;\n\") % */
/* #		      f@(define_data.type_name) % f@(define_data.type_name) / */
/* #		      f@(define_data.new_name))) */
/* #		    index := index + 1 */
/* # */
/* #	    call string_append@(buffer, */
/* #	      form@("#endif // %s%_INCLUDED ./\n\") / f@(upper_source_base)) */
/* # */
/* #	    header_file_name :@= new@String() */
/* #	    call string_append@(header_file_name, source_base) */
/* #	    call string_append@(header_file_name, h_suffix) */
/* #	    header_stream :@= open@Out_Stream(header_file_name) */
/* #	    assert header_stream !== null@Out_Stream */
/* #	    call put@(buffer, header_stream) */
/* #	    call close@(header_stream) */
/* # */
/* #	    # Generate .ezh file: */
/* #	    call trim@(buffer, 0) */
/* #	    traverser :@= compiler.traverser */
/* #	    traverser.buffer := buffer */
/* #	    call trim@(traverser.tokens, 0) */
/* #	    call visit@(root, buffer, compiler, ezh_emit@Phase) */
/* # */
/* #	    header_file_name := new@String() */
/* #	    call string_append@(header_file_name, source_base) */
/* #	    call string_append@(header_file_name, ezh_suffix) */
/* #	    header_stream := open@Out_Stream(header_file_name) */
/* #	    assert header_stream !== null@Out_Stream */
/* # */
/* #	    # Output the #define "external" declarations: */
/* #	    size := define_datas.size */
/* #	    if size != 0 */
/* #		call buffer_append@("\n\# Extracted #define externals:\n\", */
/* #		  buffer) */
/* #		index := 0 */
/* #		while index < size */
/* #		    define_data := define_datas[index] */
/* #		    call string_append@(buffer, */
/* #		      form@("external %s%@%s% %s%\t\# =%s%\n\") % */
/* #		      f@(define_data.new_name) % */
/* #		      f@(define_data.type_name) % */
/* #		      f@(define_data.type_name) / */
/* #		      f@(define_data.value)) */
/* #		    index := index + 1 */
/* #		call string_append@(buffer, "\n\") */
/* # */
/* #	    call put@(buffer, header_stream) */
/* #	    call close@(header_stream) */
/* #      case c_generate */
/* #	if phase_trace */
/* #	    call put@(form@("Phase 2: %qv%\n\") / f@(source_base), */
/* #	      error@Out_Stream) */
/* #	ezc_file := read@File(source_base, "", ".ezc", compiler) */
/* #	#ezg_file := read@File(source_base, middlefix, ".ezg", compiler) */
/* # */
/* #	compiler.undefs_generated := false@Logical */
/* #	define_datas := ezc_file.define_datas */
/* #	compiler.define_datas := define_datas */
/* # */
/* #	#root := null@Root */
/* #	#if ezc_file !== null@File */
/* #	#    if ezg_file == null@File */
/* #	#	root := parse@(parser, ezc_file.tokens) */
/* #	#    else */
/* #	#	root := two_parse@(parser, ezc_file.tokens, ezg_file.tokens) */
/* #	#else */
/* #	#    call put@("empty .ezc file\n\", error@Out_Stream) */
/* # */
/* #	root := ezc_file.root */
/* #	if root == null@Root */
/* #	    call put@("Empty root\n\", error@Out_Stream) */
/* #	else */
/* #	    # Scan everything into the symbol table: */
/* #	    call visit@(root, buffer, compiler, ezh_scan@Phase) */
/* # */
/* #	    # Now spit out the .c file: */
/* #	    c_file_name :@= new@String() */
/* #	    call string_append@(c_file_name, source_base) */
/* #	    call string_append@(c_file_name, c_suffix) */
/* # */
/* #	    c_stream :@= open@Out_Stream(c_file_name) */
/* #	    if c_stream == null@Out_Stream */
/* #	        assert false@Logical */
/* #	        result := result + 1 */
/* #	    else */
/* #	        call trim@(buffer, 0) */
/* # */
/* #		# Force "library {source_base}": */
/* #		call string_append@(buffer, */
/* #		  form@("#include \dq\%s%%s%.h\dq\//c2./\n\") % */
/* #		  f@(source_base) / f@(compiler.middlefix)) */
/* #		ezh_file :@= */
/* #		  read@File(source_base, compiler.middlefix, ".ezh", compiler) */
/* #		if ezh_file !== null@File */
/* #		    ezh_tokens :@= ezh_file.tokens */
/* #		    ezh_parser :@= create@Parser(ezh_tokens, messages) */
/* #		    ezh_root :@= parse@Root(ezh_parser) */
/* #		    call visit@(ezh_root, "", compiler, ezh_scan@Phase) */
/* # */
/* #	        call visit@(root, buffer, compiler, c_emit@Phase) */
/* # */
/* #		xsize :@= define_datas.size */
/* #		 */
/* #		if xsize != 0 */
/* #		    call buffer_append@("\n\", buffer) */
/* #		    call buffer_append@("// #define values: ./\n\", buffer) */
/* #		    xindex :@= 0 */
/* #		    while xindex < xsize */
/* #			define_data :@= define_datas[xindex] */
/* #			call string_append@(buffer,  */
/* #			  form@("%s% %s%__%s% = %s%;\t\// =%s% ./\n\") % */
/* #			  f@(define_data.type_name) % */
/* #			  f@(define_data.type_name) % */
/* #			  f@(define_data.new_name) % */
/* #			  f@(define_data.old_name) / */
/* #			  f@(define_data.value)) */
/* #			xindex := xindex + 1 */
/* #		    call buffer_append@("\n\", buffer) */
/* # */
/* #	        call visit@(root, buffer, compiler, c_defines_emit@Phase) */
/* #	        call buffer_append@("\n\", buffer) */
/* #	        call put@(buffer, c_stream) */
/* #	        call close@(c_stream) */
/* #	call dump@(messages, error@Out_Stream) */
/* #      case c_compile */
/* #	command :@= new@String() */
/* #	compiler_executable :@= options.compiler_executable */
/* #	call string_append@(command, compiler_executable) */
/* #	call string_append@(command, " -c ") */
/* #	if options.debug */
/* #	    call string_append@(command, "-g ") */
/* #	if options.profile */
/* #	    call string_append@(command, "-pg ") */
/* #	if options.optimize */
/* #	    call string_append@(command, "-O ") */
/* #	call string_append@(command, compiler.search_options) */
/* #	call string_append@(command, " ") */
/* #	call string_append@(command, source_base) */
/* #	call string_append@(command, compiler.middlefix) */
/* #	call string_append@(command, ".c") */
/* # */
/* #	if phase_trace */
/* #	    call put@(form@("Phase 3:: %v%: %s%\n\") % */
/* #	      f@(source_base) / f@(command), error@Out_Stream) */
/* #	call execute@System(command) */
/* # */
/* #      case link */
/* #	if phase_trace */
/* #	    call put@(form@("Phase 4: %qv%\n\") / f@(source_base), */
/* #	      error@Out_Stream) */
/* # */
/* #	ezc_file := read@File(source_base, "", ".ezc", compiler) */
/* #	ezg_file := read@File(source_base, middlefix, ".ezg", compiler) */
/* # */
/* #	root := null@Root */
/* #	if ezc_file !== null@File */
/* #	    if ezg_file == null@File */
/* #		root := parse@(parser, ezc_file.tokens) */
/* #	    else */
/* #		root := two_parse@(parser, ezc_file.tokens, ezg_file.tokens) */
/* #	else */
/* #	    call put@("empty .ezc file\n\", error@Out_Stream) */
/* # */
/* #	call trim@(buffer, 0) */
/* #	#call visit@(root, buffer, compiler, link_emit@Phase) */
/* #	call visit@(root, buffer, compiler, link_scan@Phase) */
/* # */
/* #    if messages.size != 0 */
/* #	call dump@(messages, error@Out_Stream) */
/* #	return 1 */
/* # */
/* #    if trace */
/* #        call put@(form@("<=compile@Compiler(*, %qv%, *, %d%)=>%d%\n\") % */
/* #	  f@(source_base) % f@(0) / f@(result), error@Out_Stream) */
/* #    return result */
Unsigned Compiler__defines_check(
  Compiler compiler)
{
    Unsigned errors;
    Hash_Table define_table;
    Array defines;
    Unsigned size;
    Unsigned index;
    Define_Declaration define;
    errors = 0;
    define_table = compiler->define_table;
    defines = compiler->defines;
    size = Array__size_get(defines);
    index = 0;
    while ((index < size)) {
        define = ((Define_Declaration)Array__fetch1(defines, index));
        (void)Compiler__define_register(compiler, define);
        index = (index+1);
    }
    return errors;
}

void Compiler__location_push(
  Compiler compiler,
  String kind,
  Token location)
{
    (void)Array__append(compiler->error_kinds, ((void *)(kind)));
    (void)Array__append(compiler->error_tokens, ((void *)(location)));
}

void Compiler__location_pop(
  Compiler compiler)
{
    (void)((String)Array__pop(compiler->error_kinds));
    (void)((Token)Array__pop(compiler->error_tokens));
}

Logical Compiler__messages_dump(
  Compiler compiler)
{
    return Messages__dump(compiler->messages, Out_Stream__error);
}

Logical Compiler__phase(
  Compiler compiler,
  String phase,
  Unsigned (*phase_routine)(Source, Compiler))
{
    Unsigned errors;
    Array sources;
    Unsigned index;
    Source source;
    errors = 0;
    sources = compiler->sources;
    index = 0;
    while ((index < Array__size_get(sources))) {
        source = ((Source)Array__fetch1(sources, index));
        errors = (errors+phase_routine(source, compiler));
        index = (index+1);
    }
    errors = (errors+Messages__size_get(compiler->messages));
    (void)Compiler__messages_dump(compiler);
    return (errors != 0);
}

void Compiler__simple_type_insert(
  Compiler compiler,
  String simple_name,
  Type actual_type)
{
    (void)Hash_Table__insert(compiler->simple_table, ((void *)(simple_name)), ((void *)(actual_type)));
}

Type Compiler__simple_type_lookup(
  Compiler compiler,
  String simple_name)
{
    return ((Type)Hash_Table__lookup(compiler->simple_table, ((void *)(simple_name))));
}

Unsigned Compiler__source_register(
  Compiler compiler,
  String base_name,
  Token token)
{
    Hash_Table source_table;
    Array sources;
    Source source;
    Unsigned errors;
    File ezc;
    Root ezc_root;
    Unsigned parse_errors;
    Source previous_source;
    String t__0;
    base_name = String__read_only_copy(base_name);
    source_table = compiler->source_table;
    sources = compiler->sources;
    source = ((Source)Hash_Table__lookup(source_table, ((void *)(base_name))));
    errors = 0;
    if ((source == Source__null)) {

        source = Source__create(base_name, compiler);
        if (!(!Hash_Table__insert(source_table, ((void *)(base_name)), ((void *)(source))))) {
            System__assert_fail((String)"\14Compiler.ezc", 917);
        }
        (void)Array__append(sources, ((void *)(source)));
        /* # Now read in the .ezc file and parse it: */
        ezc = File__read(source->base_name, ((String)"\000"), ((String)"\004.ezc"), compiler);
        if ((ezc == File__null)) {
            (void)Compiler__log(compiler, token, (t__0 = String__form(((String)"\055Unable to find library/interface/require %v%\n")), String__divide((t__0), String__f(base_name))));
            errors = (errors+1);
        } else {
            source->ezc = ezc;
            ezc_root = Parser__parse(compiler->parser, ezc->tokens);
            ezc->root = ezc_root;
            parse_errors = Array__size_get(compiler->messages->errors);
            errors = (errors+parse_errors);
            if ((parse_errors == 0)) {
                previous_source = compiler->source;
                compiler->source = source;
                (void)Root__visit(ezc_root, ((String)"\013Source Find"), compiler, Phase__source_find);
                compiler->source = previous_source;
            }
        }
    }
    errors = (errors+Messages__size_get(compiler->messages));
    return errors;
}

Typed_Name_Object Compiler__type_name_lookup(
  Compiler compiler,
  String name,
  Type type,
  Token error_location)
{
    Token name_token;
    Typed_Name typed_name;
    Typed_Name_Object result;
    if (!((type != Type__null))) {
        System__assert_fail((String)"\14Compiler.ezc", 959);
    }
    name_token = Token__create(error_location->file, error_location->position, Lexeme__symbol, name);
    typed_name = compiler->typed_name;
    typed_name->name = name_token;
    typed_name->type = type;
    result = Compiler__typed_name_lookup(compiler, typed_name, error_location);
    return result;
}

Typed_Name_Object Compiler__type_name_routine_lookup(
  Compiler compiler,
  String name,
  Type type,
  Token error_location)
{
    Typed_Name_Object typed_name_object;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    if (!((type != Type__null))) {
        System__assert_fail((String)"\14Compiler.ezc", 989);
    }
    typed_name_object = Compiler__type_name_lookup(compiler, name, type, error_location);
    if (((typed_name_object != Typed_Name_Object__null)&&(typed_name_object->kind != Typed_Name_Object_Kind__routine)&&(error_location != Token__null))) {
        (void)Compiler__log(compiler, error_location, (t__0 = String__form(((String)"\026%s%@%t% already exists")), t__1 = String__f(name), String__divide(String__remainder((t__0), t__1), Type__f(type))));
        (void)Compiler__log(compiler, Typed_Name_Object__location_get(typed_name_object), (t__2 = String__form(((String)"\037%s%@%t% previously defined here")), t__3 = String__f(name), String__divide(String__remainder((t__2), t__3), Type__f(type))));
        typed_name_object = Typed_Name_Object__null;
    }
    return typed_name_object;
}

Typed_Name_Object Compiler__typed_name_lookup(
  Compiler compiler,
  Typed_Name typed_name,
  Token error_location)
{
    Typed_Name_Object typed_name_object;
    String t__0;
    typed_name_object = ((Typed_Name_Object)Hash_Table__lookup(compiler->xtyped_name_object_table, ((void *)(typed_name))));
    if (((error_location != Token__null)&&(typed_name_object == Typed_Name_Object__null))) {
        (void)Compiler__log(compiler, error_location, (t__0 = String__form(((String)"\063Routine/global/external/constant %t% does not exist")), String__divide((t__0), Typed_Name__f(typed_name))));
    }
    return typed_name_object;
}

Logical Compiler__typed_name_insert(
  Compiler compiler,
  Typed_Name typed_name,
  Typed_Name_Object typed_name_object,
  Token error_location,
  String from)
{
    Logical trace;
    Logical result;
    Hash_Table table;
    Typed_Name_Object previous_typed_name_object;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    trace = Logical__false;
    if (trace) {
        (void)String__d((t__2 = String__form(((String)"\042=>typed_name_insert@(*, %t%, %v%)\n")), t__3 = Typed_Name__f(typed_name), String__divide(String__remainder((t__2), t__3), String__f(from))));
    }
    if (!((typed_name_object != Typed_Name_Object__null))) {
        System__assert_fail((String)"\14Compiler.ezc", 1046);
    }
    result = Logical__false;
    table = compiler->xtyped_name_object_table;
    previous_typed_name_object = ((Typed_Name_Object)Hash_Table__lookup(table, ((void *)(typed_name))));
    if ((previous_typed_name_object == Typed_Name_Object__null)) {

        (void)Hash_Table__insert(table, ((void *)(typed_name)), ((void *)(typed_name_object)));
    } else {

        if (Typed_Name_Object__equal(typed_name_object, previous_typed_name_object)) {

            /* do_nothing */
        } else {

            (void)Compiler__log(compiler, error_location, (t__4 = String__form(((String)"\066Routine/global/ext/const %t% already exists (from: %s%")), t__5 = Typed_Name__f(typed_name), String__divide(String__remainder((t__4), t__5), String__f(from))));
            (void)Compiler__log(compiler, Typed_Name_Object__location_get(previous_typed_name_object), (t__6 = String__form(((String)"\031Previous %t% defined here")), String__divide((t__6), Typed_Name__f(typed_name))));
        }
    }
    table->trace_level = 0;
    if (trace) {
        (void)String__d((t__10 = String__form(((String)"\051<=typed_name_insert@(*, %t%, %v%) => %l%\n")), t__11 = Typed_Name__f(typed_name), t__12 = String__f(from), String__divide(String__remainder(String__remainder((t__10), t__11), t__12), Logical__f(result))));
    }
    return result;
}

void Compiler__trace(
  Compiler compiler,
  Token location)
{
    File file;
    Unsigned line_number;
    file = location->file;
    line_number = File__line_number(file, location->position);
    compiler->tracing = (line_number == compiler->trace_line);
}

Compiler Compiler__one_and_only(void)
{
    return Compiler__null;
}

Compiler Compiler__create(
  Options options,
  Messages messages)
{
    Compiler compiler;
    Token null;
    compiler = Compiler__one_and_only();
    if (1) {
        compiler->break_labels = Array__new();
        compiler->buffer = String__new();
        compiler->c_indent = 0;
        compiler->cast_suppress = Logical__false;
        compiler->collections = Array__new();
        compiler->collection_table = Hash_Table__create(((void *)(Collection__null)), ((Unsigned (*)(void *))(String__hash)), ((Logical (*)(void *, void *))(String__equal)), ((void (*)(void *, String))(String__buffer_append)), ((void (*)(void *, String))(Collection__buffer_append)));
        compiler->continue_labels = Array__new();
        compiler->current_routine = Routine_Declaration__null;
        compiler->defines_prefixes = Array__new();
        compiler->define_datas = Array__new();
        compiler->define_table = Hash_Table__create(((void *)(Define_Declaration__null)), ((Unsigned (*)(void *))(String__hash)), ((Logical (*)(void *, void *))(String__equal)), ((void (*)(void *, String))(String__buffer_append)), ((void (*)(void *, String))(Define_Declaration__show)));
        compiler->defines = Array__new();
        compiler->error_kinds = Array__new();
        compiler->error_tokens = Array__new();
        compiler->enumeration_prefixes = Array__new();
        compiler->file = File__null;
        compiler->file_table = Hash_Table__create(((void *)(File__null)), ((Unsigned (*)(void *))(String__hash)), ((Logical (*)(void *, void *))(String__equal)), ((void (*)(void *, String))(String__buffer_append)), ((void (*)(void *, String))(File__show)));
        compiler->files = Array__new();
        compiler->includes = Array__new();
        compiler->interface_bases = Array__new();
        compiler->global_libraries = Array__new();
        compiler->label_count = 0xffff0000;
        compiler->level = 0;
        compiler->library_bases = Array__new();
        compiler->loads = Array__new();
        compiler->loop_levels = Array__new();
        compiler->messages = messages;
        compiler->middlefix = options->suffix;
        compiler->other_typedefs = String__new();
        compiler->options = options;
        compiler->parser = Parser__create(Array__new(), messages);
        compiler->phase = Phase__c_emit;
        compiler->scalar_table = Hash_Table__create(((void *)(Type__null)), ((Unsigned (*)(void *))(String__hash)), ((Logical (*)(void *, void *))(String__equal)), ((void (*)(void *, String))(String__buffer_append)), ((void (*)(void *, String))(Type__buffer_append)));
        compiler->scanned_types = Array__new();
        compiler->search_options = options->search_options;
        compiler->searches = options->searches;
        compiler->simple_table = Hash_Table__create(((void *)(Type__null)), ((Unsigned (*)(void *))(String__hash)), ((Logical (*)(void *, void *))(String__equal)), ((void (*)(void *, String))(String__buffer_append)), ((void (*)(void *, String))(Type__buffer_append)));
        compiler->simple_typedefs = String__new();
        compiler->sources = Array__new();
        compiler->source_table = Hash_Table__create(((void *)(Source__null)), ((Unsigned (*)(void *))(String__hash)), ((Logical (*)(void *, void *))(String__equal)), ((void (*)(void *, String))(String__buffer_append)), ((void (*)(void *, String))(Source__buffer_append)));
        compiler->switch_levels = Array__new();
        compiler->temporaries = Array__new();
        compiler->temporary = String__new();
        compiler->temporary2 = String__new();
        compiler->token = Token__create(File__null, 0, Lexeme__symbol, ((String)"\000"));
        compiler->tokenizer = Tokenizer__create(messages);
        compiler->traverser = Traverser__create(compiler->buffer, Array__new());
        compiler->trace_line = options->trace_line;
        compiler->tracing = Logical__false;
        compiler->type_byte = Type__simple_create(((String)"\004Byte"));
        compiler->type_character = Type__simple_create(((String)"\011Character"));
        compiler->type_double = Type__simple_create(((String)"\006Double"));
        compiler->type_easy_c = Type__simple_create(((String)"\006Easy_C"));
        compiler->type_float = Type__simple_create(((String)"\005Float"));
        compiler->type_integer = Type__simple_create(((String)"\007Integer"));
        compiler->type_long_integer = Type__simple_create(((String)"\014Long_Integer"));
        compiler->type_long_unsigned = Type__simple_create(((String)"\015Long_Unsigned"));
        compiler->type_logical = Type__simple_create(((String)"\007Logical"));
        compiler->type_pointer_pointer = Type__simple_create(((String)"\017Pointer_Pointer"));
        compiler->type_quad = Type__simple_create(((String)"\004Quad"));
        compiler->type_short = Type__simple_create(((String)"\005Short"));
        compiler->type_string = Type__simple_create(((String)"\006String"));
        compiler->type_unsigned = Type__simple_create(((String)"\010Unsigned"));
        compiler->typed_name = Typed_Name__new();
        compiler->xtyped_name_object_table = Hash_Table__create(((void *)(Typed_Name_Object__null)), ((Unsigned (*)(void *))(Typed_Name__hash)), ((Logical (*)(void *, void *))(Typed_Name__equal)), ((void (*)(void *, String))(Typed_Name__show)), ((void (*)(void *, String))(Typed_Name_Object__show)));
        compiler->variables = Array__new();
        compiler->variable_table = Hash_Table__create(((void *)(Variable__null)), ((Unsigned (*)(void *))(String__hash)), ((Logical (*)(void *, void *))(String__equal)), ((void (*)(void *, String))(String__buffer_append)), ((void (*)(void *, String))(Variable__show)));
        compiler->undefs_generated = Logical__false;
    }
    null = Token__null;
    (void)Compiler__scalar_insert(compiler, ((String)"\004Byte"), compiler->type_byte, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\011Character"), compiler->type_character, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\006Double"), compiler->type_double, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\005Float"), compiler->type_float, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\007Integer"), compiler->type_integer, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\007Logical"), compiler->type_logical, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\014Long_Integer"), compiler->type_long_integer, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\015Long_Unsigned"), compiler->type_long_unsigned, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\004Quad"), compiler->type_quad, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\005Short"), compiler->type_short, null);
    (void)Compiler__scalar_insert(compiler, ((String)"\010Unsigned"), compiler->type_unsigned, null);
    return compiler;
}

Logical Compiler__enter(
  Compiler compiler,
  String routine_name,
  Logical more)
{
    return Logical__false;
}

Unsigned Compiler__c_pad_get(
  Compiler compiler)
{
    return (compiler->c_indent*4);
}

void Compiler__pad_append(
  Compiler compiler,
  String text)
{
    Unsigned c_indent;
    c_indent = compiler->c_indent;
    while ((c_indent != 0)) {
        (void)String__string_append(text, ((String)"\004    "));
        c_indent = (c_indent-1);
    }
}

Logical Compiler__leave(
  Compiler compiler,
  String routine_name,
  Logical more)
{
    return Logical__false;
}

void Compiler__log(
  Compiler compiler,
  Token location,
  String text)
{
    (void)Messages__log(compiler->messages, location, text);
    if (compiler->tracing) {
        (void)String__put(text, Out_Stream__error);
        (void)String__put(((String)"\001\n"), Out_Stream__error);
    }
}

Type Compiler__type_lookup(
  Compiler compiler,
  String name,
  Token location)
{
    Define_Declaration define;
    Type type;
    String t__0;
    define = ((Define_Declaration)Hash_Table__lookup(compiler->define_table, ((void *)(name))));
    type = define->type;
    if ((define == Define_Declaration__null)) {
        (void)Compiler__log(compiler, location, (t__0 = String__form(((String)"\030Type %qv% is not defined")), String__divide((t__0), String__f(name))));
        type = Type__null;
    }
    return type;
}

void Compiler__level_begin(
  Compiler compiler)
{
    compiler->level = (compiler->level+1);
    compiler->c_indent = (compiler->c_indent+1);
}

void Compiler__level_end(
  Compiler compiler)
{
    Unsigned level;
    Array variables;
    Unsigned size;
    Unsigned index;
    Variable variable;
    level = compiler->level;
    if (!((level != 0))) {
        System__assert_fail((String)"\14Compiler.ezc", 1316);
    }
    if (!((compiler->c_indent != 0))) {
        System__assert_fail((String)"\14Compiler.ezc", 1317);
    }
    variables = compiler->variables;
    size = Array__size_get(variables);
    index = 0;
    while ((index < size)) {
        variable = ((Variable)Array__fetch1(variables, index));
        if ((variable->level == level)) {
            variable->level = 0xffffffff;
        }
        index = (index+1);
    }
    compiler->level = (level-1);
    compiler->c_indent = (compiler->c_indent-1);
}

void Compiler__scalar_insert(
  Compiler compiler,
  String name,
  Type type,
  Token location)
{
    Hash_Table scalar_table;
    Type previous_type;
    scalar_table = compiler->scalar_table;
    previous_type = Compiler__scalar_lookup(compiler, name);
    if ((previous_type == Type__null)) {
        if (!(!Hash_Table__insert(scalar_table, ((void *)(String__read_only_copy(name))), ((void *)(type))))) {
            System__assert_fail((String)"\14Compiler.ezc", 1350);
        }
    } else {
        (void)Compiler__log(compiler, location, ((String)"\042Duplicate scalar %t% being defined"));
    }
}

Type Compiler__scalar_lookup(
  Compiler compiler,
  String name)
{
    return ((Type)Hash_Table__lookup(compiler->scalar_table, ((void *)(name))));
}

void Compiler__undefs_append(
  Compiler compiler,
  String buffer)
{
    if (!compiler->undefs_generated) {
        compiler->undefs_generated = Logical__true;
        (void)String__buffer_append(((String)"\037/* #undef lower case macros */\n"), buffer);
        (void)String__buffer_append(((String)"\014#undef i386\n"), buffer);
        (void)String__buffer_append(((String)"\015#undef linux\n"), buffer);
        (void)String__buffer_append(((String)"\014#undef unix\n"), buffer);
        /* # For now; squish errno here: */
        (void)String__buffer_append(((String)"\015#undef errno\n"), buffer);
        (void)String__buffer_append(((String)"\017#undef makedev\n"), buffer);
        (void)String__buffer_append(((String)"\015#undef major\n"), buffer);
        (void)String__buffer_append(((String)"\015#undef minor\n"), buffer);
        (void)String__buffer_append(((String)"\016#undef alloca\n"), buffer);
        (void)String__buffer_append(((String)"\001\n"), buffer);
    }
}

String Compiler__variable_temporary(
  Compiler compiler,
  Type type)
{
    Array temporaries;
    Unsigned size;
    String name;
    Variable variable;
    String t__0;
    String t__1;
    temporaries = compiler->temporaries;
    size = Array__size_get(temporaries);
    name = String__read_only_copy((t__1 = String__form(((String)"\006t__%d%")), String__divide((t__1), Unsigned__f(size))));
    variable = Variable__create(name, type);
    (void)Array__append(temporaries, ((void *)(variable)));
    return name;
}

Variable Compiler__variable_insert(
  Compiler compiler,
  String name,
  Type type,
  Logical is_argument)
{
    Hash_Table variable_table;
    Variable variable;
    String t__0;
    String t__1;
    variable_table = compiler->variable_table;
    variable = ((Variable)Hash_Table__lookup(variable_table, ((void *)(name))));
    if ((variable != Variable__null)) {
        (void)Compiler__log(compiler, Type__location_get(type), (t__0 = String__form(((String)"\051Variable/argument %vq% is already defined")), String__divide((t__0), String__f(name))));
        (void)Compiler__log(compiler, Type__location_get(variable->type), (t__1 = String__form(((String)"\056Variable/argument %vq% previously defined here")), String__divide((t__1), String__f(name))));
    } else {

        /* #  f@(name) % f@(hash@(name)) / f@(variable_table.mask)) */
        variable = Variable__create(name, type);
        (void)Array__append(compiler->variables, ((void *)(variable)));
        (void)Hash_Table__insert(variable_table, ((void *)(name)), ((void *)(variable)));
        if (is_argument) {
            variable->level = 0;
        }
    }
    return variable;
}

Variable Compiler__variable_lookup(
  Compiler compiler,
  String name)
{
    Variable variable;
    variable = ((Variable)Hash_Table__lookup(compiler->variable_table, ((void *)(name))));
    return variable;
}

void Compiler__variables_clear(
  Compiler compiler)
{
    Hash_Table variable_table;
    Array variables;
    Unsigned size;
    Unsigned index;
    Variable variable;
    String t__0;
    String t__1;
    variable_table = compiler->variable_table;
    variables = compiler->variables;
    size = Array__size_get(variables);
    index = 0;
    while ((index < size)) {
        variable = ((Variable)Array__fetch1(variables, index));
        if (!Hash_Table__delete(variable_table, ((void *)(variable->name)))) {
            (void)String__d((t__1 = String__form(((String)"\036Unable to delete variable %s%\n")), String__divide((t__1), String__f(variable->name))));
        }
        index = (index+1);
    }
}

/* # {Phase} routines: */
String Phase__f(
  Phase phase)
{
    String value;
    value = Format__field_next();
    (void)String__trim(value, 0);
    (void)String__string_append(value, Phase__string_convert(phase));
    return value;
}

void Phase__xxxformat(
  Phase phase,
  String buffer)
{
    String text;
    Unsigned anchor;
    text = Phase__string_convert(phase);
    anchor = String__format_begin(buffer);
    (void)String__string_gap_insert(buffer, text);
    (void)String__format_end(buffer, anchor);
}

/* # {Source} routines: */
/* #routine all_needed_clear@Source */
/* #    takes source Source */
/* #    returns_nothing */
/* # */
/* #    # This routine will unmark all of the {Source} objects in */
/* #    # {source}.{all_needed}: */
/* # */
/* #    all_needed :@= source.all_needed */
/* #    size :@= all_needed.size */
/* #    index :@= 0 */
/* #    while index < size */
/* #	sub_source :@= all_needed[index] */
/* #	sub_source.mark := false@Logical */
/* #	index := index + 1 */
/* #routine all_needed_find@Source */
/* #    takes source Source */
/* #    takes all_needed Array[Source] */
/* #    returns_nothing */
/* # */
/* #    # This routine will recursively iterate over {source} filling in */
/* #    # the {all_needed} array. */
/* # */
/* #    if source.mark */
/* #	# We have been visited before: */
/* #	do_nothing */
/* #    else */
/* #	# We have not been visited before: */
/* #	call append@(all_needed, source) */
/* #	source.mark := true@Logical */
/* # */
/* #	# Scan the children: */
/* #	needed :@= source.needed */
/* #	size :@= needed.size */
/* #	index :@= 0 */
/* #	while index < size */
/* #	    needed_source :@= needed[index] */
/* #	    call all_needed_find@(needed_source, all_needed) */
/* #	    index := index + 1 */
void Source__buffer_append(
  Source source,
  String buffer)
{
    (void)String__string_append(buffer, source->base_name);
}

Unsigned Source__c_compile(
  Source source,
  Compiler compiler)
{
    Unsigned errors;
    String base_name;
    Logical trace;
    String compile_command;
    Options options;
    Logical verbose;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    errors = 0;
    if (Source__should_compile(source, compiler)) {
        base_name = source->base_name;
        trace = Logical__false;
        /* #trace := true@Logical */
        /* #if trace */
        /* #    call d@(form@("=>c_compile@Source(%v%)\n\") / f@(base_name)) */
        compile_command = String__new();
        options = compiler->options;
        verbose = options->verbose;
        (void)String__string_append(compile_command, options->compiler_executable);
        (void)String__string_append(compile_command, ((String)"\003 -c"));
        if (options->debug) {
            (void)String__string_append(compile_command, ((String)"\003 -g"));
        }
        if ((source->collection != Collection__null)) {
            (void)String__string_append(compile_command, ((String)"\006 -fPIC"));
        }
        if (options->optimize) {
            (void)String__string_append(compile_command, ((String)"\004 -O2"));
        }
        if (options->profile) {
            (void)String__string_append(compile_command, ((String)"\004 -pg"));
        }
        (void)String__string_append(compile_command, (t__0 = String__form(((String)"\004 %s%")), String__divide((t__0), String__f(options->search_options))));
        (void)String__string_append(compile_command, (t__1 = String__form(((String)"\011 %s%%s%.c")), t__2 = String__f(base_name), String__divide(String__remainder((t__1), t__2), String__f(compiler->middlefix))));
        (void)String__d((t__4 = String__form(((String)"\004%s%\n")), String__divide((t__4), String__f(compile_command))));
        /* #call d@("*********************************************************\n\") */
        (void)System__execute(compile_command);
        /* #if trace */
        /* #    call d@(form@("=>c_compile@Source(%v%)\n\") / f@(source.base_name)) */
    }
    return errors;
}

Unsigned Source__c_emit(
  Source source,
  Compiler compiler)
{
    String base_name;
    File ezc_file;
    File ezg_file;
    Root ezc_root;
    String buffer;
    Array define_datas;
    Unsigned size;
    Unsigned index;
    Define_Data define_data;
    String file_name;
    Out_Stream c_stream;
    Unsigned errors;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    base_name = source->base_name;
    if (Source__should_compile(source, compiler)) {
        ezc_file = source->ezc;
        ezg_file = source->ezg;
        compiler->undefs_generated = Logical__false;
        /* #define_datas := ezc_file.define_datas */
        /* #compiler.define_datas := define_datas */
        ezc_root = ezc_file->root;
        if ((ezc_root == Root__null)) {

            return 1;
        }
        buffer = compiler->buffer;
        (void)String__trim(buffer, 0);
        /* # Scan everything into the symbol table: */
        /* #call visit@(root, buffer, compiler, ezh_scan@Phase) */
        /* # Force "library {base_name}": */
        (void)String__string_append(buffer, (t__0 = String__form(((String)"\033#include \"%s%%s%.h\"/*cc2*/\n")), t__1 = String__f(base_name), String__divide(String__remainder((t__0), t__1), String__f(compiler->middlefix))));
        /* #if trace */
        /* #    call d@("  c_emit@Source(): 1\n\") */
        (void)Root__visit(ezc_root, buffer, compiler, Phase__c_emit);
        if ((ezg_file != File__null)) {
            (void)Root__visit(ezg_file->root, buffer, compiler, Phase__c_emit);
        }
        /* # Output data defines: */
        define_datas = ezc_file->define_datas;
        size = Array__size_get(define_datas);
        if ((size != 0)) {
            (void)String__buffer_append(((String)"\001\n"), buffer);
            (void)String__buffer_append(((String)"\026/* #define values: */\n"), buffer);
            index = 0;
            while ((index < size)) {
                define_data = ((Define_Data)Array__fetch1(define_datas, index));
                (void)String__string_append(buffer, (t__2 = String__form(((String)"\037%s% %s%__%s% = %s%;\t/* =%s% */\n")), t__3 = String__f(define_data->type_name), t__4 = String__f(define_data->type_name), t__5 = String__f(define_data->new_name), t__6 = String__f(define_data->old_name), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__2), t__3), t__4), t__5), t__6), String__f(define_data->value))));
                index = (index+1);
            }
            (void)String__buffer_append(((String)"\001\n"), buffer);
        }
        /* #if trace */
        /* #	call d@("  c_emit@Source(): 2\n\") */
        (void)Root__visit(ezc_root, buffer, compiler, Phase__c_defines_emit);
        (void)String__buffer_append(((String)"\001\n"), buffer);
        /* # Write out the .c file: */
        file_name = String__read_only_copy((t__9 = String__form(((String)"\010%s%%s%.c")), t__10 = String__f(base_name), String__divide(String__remainder((t__9), t__10), String__f(compiler->middlefix))));
        c_stream = Out_Stream__open(file_name);
        if ((c_stream == Out_Stream__null)) {
            if (!(Logical__false)) {
                System__assert_fail((String)"\14Compiler.ezc", 1674);
            }
        } else {
            (void)String__put(buffer, c_stream);
            (void)Out_Stream__close(c_stream);
        }
        /* #if trace */
        /* #	call d@(form@("<=c_emit@Source(%v%) => %d%\n\") % */
        /* #	  f@(base_name) / f@(errors)) */
    }
    errors = Messages__size_get(compiler->messages);
    (void)Compiler__messages_dump(compiler);
    return errors;
}

Source Source__create(
  String base_name,
  Compiler compiler)
{
    Source source;
    source = Source__new();
    source->base_name = base_name;
    source->collection = Collection__null;
    source->collection_declaration = Collection_Declaration__null;
    source->defines = Array__new();
    source->ezc = File__null;
    source->ezg = File__null;
    source->global_libraries = Array__new();
    source->interfaces = Array__new();
    source->libraries = Array__new();
    source->requires = Array__new();
    return source;
}

/* #routine defines_needed_find@Source */
/* #    takes source Source */
/* #    takes compiler Compiler */
/* #    returns Unsigned */
/* # */
/* #    # This routine will fill in the {needed} list for {source} using {compiler}. */
/* # */
/* #    errors :@= 0 */
/* #    defines :@= source.defines */
/* #    needed :@= source.needed */
/* #    source_table :@= compiler.source_table */
/* # */
/* #    # Step 1: scan across the declarations looking for library, interface, */
/* #    # and define declarations: */
/* #    declarations :@= source.ezc.root.declarations */
/* #    size :@= declarations.size */
/* #    index :@= 0 */
/* #    while index < size */
/* #	declaration :@= declarations[index] */
/* #	name :@= null@Token */
/* #	switch declaration.kind */
/* #	  all_cases_required */
/* #	  case global_library */
/* #	    global_library :@= declaration.global_library */
/* #	    name := global_library.name */
/* #	  case library */
/* #	    library :@= declaration.library */
/* #	    name := library.name */
/* #	  case interface */
/* #	    interface :@= declaration.interface */
/* #	    name := interface.name */
/* #	  case define */
/* #	    define :@= declaration.define */
/* #	    call append@(defines, define) */
/* #	    define_clauses :@= define.define_clauses */
/* #	    define_clauses_size :@= define_clauses.size */
/* #	    define_clauses_index :@= 0 */
/* #	    while define_clauses_index < define_clauses_size */
/* #		define_clause :@= define_clauses[define_clauses_index] */
/* #		switch define_clause.kind */
/* #		  case simple */
/* #		    simple :@= define_clause.simple */
/* #		    call simple_type_insert@(compiler, */
/* #		      base_name@(define.type), simple.type) */
/* #		define_clauses_index := define_clauses_index + 1 */
/* #	  case easy_c, end_of_line, note, routine, defines_prefix, */
/* #	   external_named, external, global, load, include_string, constant, */
/* #	   require, error, collection */
/* #	    do_nothing */
/* #	if name !== null@Token */
/* #	    needed_source :@= lookup@(source_table, name.value) */
/* #	    assert needed_source !== null@Source */
/* #	    call append@(needed, needed_source) */
/* #	index := index + 1 */
/* # */
/* #    # Step 2: Look for duplicates: */
/* # */
/* #    # Step 2a: Mark all {Source} objects in {needed} as {false@Logical}: */
/* #    size := needed.size */
/* #    index := 0 */
/* #    while index < size */
/* #	needed_source :@= needed[index] */
/* #	needed_source.mark := false@Logical */
/* #	index := index + 1 */
/* # */
/* #    # Step 2b: Iterate through {needed} setting mark to {true@Logical}: */
/* #    index := 0 */
/* #    while index < size */
/* #	needed_source :@= needed[index] */
/* #	if needed_source.mark */
/* #	    # We have a duplicate!  Generate a nice error message: */
/* #	    base_name :@= needed_source.base_name */
/* #	    messages :@= compiler.messages */
/* #	    name_token1 :@= null@Token */
/* #	    name_token2 :@= null@Token */
/* #	    declaration2 :@= null@Declaration */
/* #	    declarations_size :@= declarations.size */
/* #	    declarations_index :@= 0 */
/* #	    while declarations_index < declarations_size */
/* #		declaration :@= declarations[declarations_index] */
/* #		name_token :@= null@Token */
/* #		switch declaration.kind */
/* #		  case library */
/* #		    library :@= declaration.library */
/* #		    name_token := library.name */
/* #		  case interface */
/* #		    interface :@= declaration.interface */
/* #		    name_token := interface.name */
/* #		if equal@(name_token.value, base_name) */
/* #		    # We found one that matches {base_name}: */
/* #		    name_token1 := name_token2 */
/* #		    name_token2 := name_token */
/* #		    if name_token1 !== null@Token */
/* #			# We have two that match, let's blast out an error: */
/* #			call log2@(messages, name_token1, name_token2, */
/* #			  form@("Duplicate library/interface request for %v%") / */
/* #			  f@(base_name)) */
/* #		declarations_index := declarations_index + 1 */
/* #	else */
/* #	    needed_source.mark := true@Logical */
/* #	index := index + 1 */
/* # */
/* #    # Step 2c: Clear all of the mark bits: */
/* #    index := 0 */
/* #    while index < size */
/* #	needed_source :@= needed[index] */
/* #	needed_source.mark := false@Logical */
/* #	index := index + 1 */
/* # */
/* #    return errors */
/* #routine ezc_read@Source */
/* #    takes source Source */
/* #    takes compiler Compiler */
/* #    returns Unsigned */
/* # */
/* #    # This routine will read in the .ezc file associated with {source} */
/* #    # using {compiler}.  An error count is returned. */
/* # */
/* #    errors :@= 0 */
/* #    base_name :@= source.base_name */
/* #    file :@= read@File(source.base_name, "", ".ezc", compiler) */
/* #    if file == null@File */
/* #	errors := errors + 1 */
/* #    else */
/* #	source.ezc := file */
/* #    return errors */
/* #routine ezg_defines_find@Source */
/* #    takes source Source */
/* #    takes compiler Compiler */
/* #    returns Unsigned */
/* # */
/* #    # This routine will fill in the {needed} list for {source} using {compiler}. */
/* # */
/* #    defines :@= source.defines */
/* #    needed :@= source.needed */
/* #    source_table :@= compiler.source_table */
/* # */
/* #    # Step 1: scan across the declarations looking for library, interface, */
/* #    # and define declarations: */
/* #    declarations :@= source.ezg.root.declarations */
/* #    size :@= declarations.size */
/* #    index :@= 0 */
/* #    while index < size */
/* #	declaration :@= declarations[index] */
/* #	name :@= null@Token */
/* #	switch declaration.kind */
/* #	  all_cases_required */
/* #	  case define */
/* #	    define :@= declaration.define */
/* #	    call append@(defines, define) */
/* #	  case easy_c, end_of_line, note, routine, defines_prefix, */
/* #	   external_named, external, global, load, include_string, constant, */
/* #	   require, error, library, interface, global_library, collection */
/* #	    do_nothing */
/* #	index := index + 1 */
/* #    return 0 */
Unsigned Source__ezg_generate(
  Source source,
  Compiler compiler)
{
    String base_name;
    Unsigned errors;
    String buffer;
    Array define_datas;
    Unsigned size;
    Unsigned index;
    Define_Data define_data;
    String type_name;
    String file_name;
    Out_Stream out_stream;
    Array ezg_tokens;
    File ezg_file;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    base_name = source->base_name;
    (void)Source__type_arm(source);
    errors = 0;
    buffer = compiler->buffer;
    (void)String__trim(buffer, 0);
    (void)Root__visit(source->ezc->root, buffer, compiler, Phase__generate_emit);
    define_datas = source->ezc->define_datas;
    size = Array__size_get(define_datas);
    index = 0;
    while ((index < size)) {
        define_data = ((Define_Data)Array__fetch1(define_datas, index));
        type_name = define_data->type_name;
        (void)String__string_append(buffer, (t__0 = String__form(((String)"\025external %s%@%s% %s%\n")), t__1 = String__f(define_data->new_name), t__2 = String__f(type_name), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), String__f(type_name))));
        index = (index+1);
    }
    if ((String__size_get(buffer) != 0)) {
        file_name = String__read_only_copy((t__5 = String__form(((String)"\012%s%%s%.ezg")), t__6 = String__f(base_name), String__divide(String__remainder((t__5), t__6), String__f(compiler->middlefix))));
        out_stream = Out_Stream__open(file_name);
        if ((out_stream == Out_Stream__null)) {
            (void)String__d((t__8 = String__form(((String)"\027Can not write %v% file\n")), String__divide((t__8), String__f(file_name))));
            /* #FIXME: we can't write out the .ezg file!!! */
            if (!(Logical__false)) {
                System__assert_fail((String)"\14Compiler.ezc", 1914);
            }
        } else {
            (void)String__put(buffer, out_stream);
            (void)Out_Stream__close(out_stream);
            ezg_tokens = Array__new();
            ezg_file = File__create(file_name, String__read_only_copy(buffer), ezg_tokens);
            source->ezg = ezg_file;
            (void)Tokenizer__tokenize(compiler->tokenizer, ezg_file);
            source->ezg->root = Parser__parse(compiler->parser, ezg_tokens);
            /* #call d@(form@("Generated %v%\n\") / f@(file_name)) */
        }
    }
    (void)Source__type_disarm(source);
    return errors;
}

Unsigned Source__h_emit(
  Source source,
  Compiler compiler)
{
    String base_name;
    Logical trace;
    Unsigned errors;
    String buffer;
    Root ezc_root;
    File ezg_file;
    Root ezg_root;
    String simple_typedefs;
    Array global_libraries;
    Unsigned size;
    Unsigned index;
    Source global_library;
    String global_base_name;
    String other_typedefs;
    Array define_datas;
    Define_Data define_data;
    String file_name;
    Out_Stream out_stream;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    base_name = source->base_name;
    trace = 0;
    if (trace) {
        (void)String__d((t__1 = String__form(((String)"\025=>h_emit@Source(%v%)\n")), String__divide((t__1), String__f(base_name))));
    }
    errors = 0;
    if (Source__should_compile(source, compiler)) {
        if (trace) {
            (void)String__d((t__3 = String__form(((String)"\017  generate %v%\n")), String__divide((t__3), String__f(base_name))));
        }
        (void)Source__type_arm(source);
        buffer = compiler->buffer;
        (void)String__trim(buffer, 0);
        (void)String__string_append(buffer, (t__4 = String__form(((String)"\025#ifndef %u%_INCLUDED\n")), String__divide((t__4), String__f(base_name))));
        (void)String__string_append(buffer, (t__5 = String__form(((String)"\030#define %u%_INCLUDED 1\n\n")), String__divide((t__5), String__f(base_name))));
        (void)String__string_append(buffer, ((String)"\056/* Declare all enum's and typedef's first: */\n"));
        (void)String__string_append(buffer, ((String)"\016/* h_emit1 */\n"));
        ezc_root = source->ezc->root;
        if ((ezc_root == Root__null)) {

            return 1;
        }
        (void)Root__visit(ezc_root, buffer, compiler, Phase__h_typedefs_emit);
        ezg_file = source->ezg;
        ezg_root = Root__null;
        (void)String__string_append(buffer, ((String)"\016/* h_emit2 */\n"));
        if ((ezg_file != File__null)) {
            ezg_root = ezg_file->root;
            (void)Root__visit(ezg_root, buffer, compiler, Phase__h_typedefs_emit);
        }
        (void)String__string_append(buffer, ((String)"\016/* h_emit3 */\n"));
        simple_typedefs = compiler->simple_typedefs;
        if ((String__size_get(simple_typedefs) != 0)) {

            /* #  "\n\ Simple typedefs are stuffed into a macro: \n\") */
            (void)String__string_append(buffer, simple_typedefs);
            (void)String__trim(simple_typedefs, 0);
            /* #call string_append@(buffer, "\n\") */
            /* #call string_append@(buffer, "#ifdef SCALARS___DEFINED\n\") */
            /* #call string_append@(buffer, "SIMPLE___TYPEDEFS\n\") */
            /* #call string_append@(buffer, "#endif\n,n\") */
        }
        (void)String__string_append(buffer, ((String)"\055\n/* Include other libraries exactly once: */\n"));
        global_libraries = compiler->global_libraries;
        size = Array__size_get(global_libraries);
        index = 0;
        while ((index < size)) {
            global_library = ((Source)Array__fetch1(global_libraries, index));
            global_base_name = global_library->base_name;
            (void)String__string_append(buffer, (t__6 = String__form(((String)"\025#ifndef %u%_INCLUDED\n")), String__divide((t__6), String__f(global_base_name))));
            (void)String__string_append(buffer, (t__7 = String__form(((String)"\021#include \"%s%.h\"\n")), String__divide((t__7), String__f(global_base_name))));
            (void)String__string_append(buffer, (t__8 = String__form(((String)"\032#endif /* %u%_INCLUDED */\n")), String__divide((t__8), String__f(global_base_name))));
            index = (index+1);
        }
        (void)Root__visit(ezc_root, buffer, compiler, Phase__h_includes_emit);
        if ((ezg_root != Root__null)) {
            (void)Root__visit(ezg_root, buffer, compiler, Phase__h_includes_emit);
        }
        other_typedefs = compiler->other_typedefs;
        if ((String__size_get(other_typedefs) != 0)) {
            (void)String__string_append(buffer, ((String)"\027\n/* Other typedefs: */\n"));
            (void)String__string_append(buffer, other_typedefs);
            (void)String__trim(other_typedefs, 0);
        }
        (void)String__string_append(buffer, ((String)"\036\n/* Define the structures: */\n"));
        (void)Root__visit(ezc_root, buffer, compiler, Phase__h_structs_emit);
        if ((ezg_root != Root__null)) {
            (void)Root__visit(ezg_root, buffer, compiler, Phase__h_structs_emit);
        }
        (void)String__string_append(buffer, ((String)"\047\n/* Declare the routine prototypes: */\n"));
        (void)Root__visit(ezc_root, buffer, compiler, Phase__h_externs_emit);
        if ((ezg_root != Root__null)) {
            (void)Root__visit(ezg_root, buffer, compiler, Phase__h_externs_emit);
        }
        define_datas = compiler->define_datas;
        size = Array__size_get(define_datas);
        if ((size != 0)) {
            (void)String__string_append(buffer, ((String)"\051\n/* Declare extracted #define values: */\n"));
            index = 0;
            while ((index < size)) {
                define_data = ((Define_Data)Array__fetch1(define_datas, index));
                (void)String__string_append(buffer, String__read_only_copy((t__12 = String__form(((String)"\025extern %s% %s%__%s%;\n")), t__13 = String__f(define_data->type_name), t__14 = String__f(define_data->type_name), String__divide(String__remainder(String__remainder((t__12), t__13), t__14), String__f(define_data->new_name)))));
                index = (index+1);
            }
        }
        (void)String__string_append(buffer, (t__15 = String__form(((String)"\032#endif /* %u%_INCLUDED */\n")), String__divide((t__15), String__f(base_name))));
        /* # Write out the .h file: */
        file_name = String__read_only_copy((t__18 = String__form(((String)"\010%s%%s%.h")), t__19 = String__f(base_name), String__divide(String__remainder((t__18), t__19), String__f(compiler->middlefix))));
        out_stream = Out_Stream__open(file_name);
        if ((out_stream == Out_Stream__null)) {
            if (!(Logical__false)) {
                System__assert_fail((String)"\14Compiler.ezc", 2053);
            }
        } else {
            (void)String__put(buffer, out_stream);
            (void)Out_Stream__close(out_stream);
        }
        (void)Source__type_disarm(source);
    }
    if (trace) {
        (void)String__d((t__22 = String__form(((String)"\034<=h_emit@Source(%v%) => %d%\n")), t__23 = String__f(base_name), String__divide(String__remainder((t__22), t__23), Unsigned__f(errors))));
    }
    return errors;
}

Unsigned Source__link_scan(
  Source source,
  Compiler compiler)
{
    (void)Root__visit(source->ezc->root, compiler->buffer, compiler, Phase__link_scan);
    return 0;
}

Unsigned Source__prefix_scan(
  Source source,
  Compiler compiler)
{
    Unsigned errors;
    String base_name;
    Array includes;
    Array defines_prefixes;
    Array enumeration_prefixes;
    Options options;
    Tokenizer tokenizer;
    File ezc;
    Array define_datas;
    Unsigned defines_size;
    Unsigned enumerations_size;
    Unsigned size;
    Defines_Prefix_Declaration defines_prefix;
    Out_Stream include_stream;
    Unsigned index;
    Include_String_Declaration include;
    String compiler_name;
    String command;
    In_Stream define_stream;
    String define_contents;
    Array define_tokens;
    Array indents;
    Lexeme lexeme;
    Token token;
    Parser parser;
    Define_Root define_root;
    Array defines;
    Array define_lines;
    Define define;
    String lower_case;
    Define_Line define_line;
    String define_name;
    Unsigned define_name_size;
    String define_value;
    Unsigned defines_index;
    String prefix;
    String match;
    Unsigned match_size;
    String new_name;
    Define_Data define_data;
    Unsigned enumerations_index;
    Enumeration_Prefix_Clause enumeration_prefix;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    errors = 0;
    base_name = source->base_name;
    includes = compiler->includes;
    defines_prefixes = compiler->defines_prefixes;
    enumeration_prefixes = compiler->enumeration_prefixes;
    (void)Array__trim(includes, 0);
    (void)Array__trim(defines_prefixes, 0);
    (void)Array__trim(enumeration_prefixes, 0);
    options = compiler->options;
    tokenizer = compiler->tokenizer;
    ezc = source->ezc;
    if ((ezc == File__null)) {

        return 1;
    }
    define_datas = ezc->define_datas;
    compiler->define_datas = define_datas;
    (void)Root__visit(ezc->root, compiler->buffer, compiler, Phase__prefix_scan);
    defines_size = Array__size_get(defines_prefixes);
    enumerations_size = Array__size_get(enumeration_prefixes);
    if (((defines_size != 0)||(enumerations_size != 0))) {


        /* #call d@(form@("defines_size=%d%\n\") / f@(defines_size)) */
        /* #call d@(form@("enumerations_size=%d%\n\") / */
        /* #  f@(enumerations_size)) */
        includes = compiler->includes;
        size = Array__size_get(includes);
        if ((size == 0)) {
            defines_prefix = ((Defines_Prefix_Declaration)Array__fetch1(defines_prefixes, 0));
            (void)Compiler__log(compiler, defines_prefix->defines_prefix->keyword, ((String)"\061There are no 'include' declarations to fetch from"));
        } else {

            /* #if trace */
            /* #	call d@("We have some #includes\n\") */
            include_stream = Out_Stream__open(((String)"\017/tmp/includes.c"));
            if (!((include_stream != Out_Stream__null))) {
                System__assert_fail((String)"\14Compiler.ezc", 2131);
            }
            index = 0;
            while ((index < size)) {
                include = ((Include_String_Declaration)Array__fetch1(includes, index));
                (void)String__put((t__1 = String__form(((String)"\025#include \"%s%\"/*C1*/\n")), String__divide((t__1), String__f(Token__string_convert(include->string)))), include_stream);
                index = (index+1);
            }
            (void)Out_Stream__close(include_stream);
            compiler_name = options->compiler_executable;
            if ((compiler_name == String__null)) {
                compiler_name = ((String)"\003gcc");
            }
            command = String__new();
            (void)String__string_append(command, (t__2 = String__form(((String)"\125%s% -E %s% -I. -dM /tmp/includes.c | sed s,#,,g | sed /[0-9]EE/d | sed /[0-9]D[DLF]/d")), t__3 = String__f(compiler_name), String__divide(String__remainder((t__2), t__3), String__f(compiler->search_options))));
            /* #call d@(form@("Command: %v%\n\") / f@(command)) */
            define_stream = In_Stream__pipe_read(command);
            define_contents = In_Stream__all_read(define_stream, String__null);
            (void)In_Stream__close(define_stream);
            /* #call put@(define_contents, error@Out_Stream) */
            define_tokens = Array__new();
            indents = Array__new();
            (void)Array__append(indents, ((CAST)(0)).xpointer);
            tokenizer->contents = define_contents;
            tokenizer->tokens = define_tokens;
            tokenizer->index = 0;
            tokenizer->indents = indents;
            lexeme = Lexeme__at_sign;
            while ((lexeme != Lexeme__end_of_file)) {
                token = Tokenizer__next(tokenizer);
                lexeme = token->lexeme;
                (void)Array__append(define_tokens, ((void *)(token)));
            }
            parser = Parser__create(define_tokens, Messages__new());
            define_root = Define_Root__parse(parser);
            /* # Now output the defines: */
            defines = define_root->defines;
            define_lines = Array__new();
            size = Array__size_get(defines);
            index = 0;
            while ((index < size)) {
                define = ((Define)Array__fetch1(defines, index));
                switch (define->kind) {
                    case Define_Kind___define_line:
                        (void)Array__append(define_lines, ((void *)(((define->kind == Define_Kind___define_line) ? define->kind__union.define_line : (Define_Line)System__variant_object_fail((String)"\14Compiler.ezc", 2181)))));
                        break;
                }
                index = (index+1);
            }
            (void)Array__sort(define_lines, ((Integer (*)(void *, void *))(Define_Line__compare)));
            size = Array__size_get(define_lines);
            /* #if trace */
            /* #	call d@(form@("We have %d% define lines\n\") / f@(size)) */
            lower_case = String__new();
            index = 0;
            while ((index < size)) {
                define_line = ((Define_Line)Array__fetch1(define_lines, index));
                define_name = define_line->name->value;
                define_name_size = String__size_get(define_name);
                define_value = define_line->number->value;
                /* #call put@(form@(define[%d%] %qv% %qv%\n\") % */
                /* #  f@(index) % f@(define_name) / f@(define_value), */
                /* #  error@Out_Stream) */
                defines_index = 0;
                while ((defines_index < defines_size)) {
                    defines_prefix = ((Defines_Prefix_Declaration)Array__fetch1(defines_prefixes, defines_index));
                    prefix = defines_prefix->prefix->value;
                    match = defines_prefix->match->value;
                    /* #call put@(form@( */
                    /* #  "    prefix[%d%] %qv% match %qv%\n\") % */
                    /* #  f@(prefixes_index) % f(prefix) / f@(match), */
                    /* #  error@Out_Stream) */
                    match_size = String__size_get(match);
                    if (((define_name_size >= match_size)&&(String__range_compare(define_name, 0, match_size, match, 0, match_size) == 0))) {

                        /* #if trace */
                        /* #    call d@("*************************Match\n\") */
                        new_name = String__new();
                        (void)String__string_append(new_name, prefix);
                        (void)String__range_append(new_name, define_name, match_size, (define_name_size-match_size));
                        (void)String__lower_case(new_name);
                        define_data = Define_Data__new();
                        define_data->old_name = define_name;
                        define_data->new_name = new_name;
                        define_data->value = define_value;
                        define_data->type_name = defines_prefix->type_name->value;
                        (void)Array__append(define_datas, ((void *)(define_data)));
                    }
                    defines_index = (defines_index+1);
                }
                enumerations_index = 0;
                while ((enumerations_index < enumerations_size)) {
                    enumeration_prefix = ((Enumeration_Prefix_Clause)Array__fetch1(enumeration_prefixes, enumerations_index));
                    prefix = enumeration_prefix->prefix->value;
                    match = enumeration_prefix->prefix->value;
                    match_size = String__size_get(match);
                    if (((define_name_size >= match_size)&&(String__range_compare(define_name, 0, match_size, match, 0, match_size) == 0))) {

                        new_name = String__new();
                        (void)String__string_append(new_name, define_name);
                        (void)String__lower_case(new_name);
                        /* #call d@(form@("enum_def match:%v%=%v%\n\") % */
                        /* #  f@(define_name) / f@(define_value)) */
                        if (!enumeration_prefix->define_datas_initialized) {
                            enumeration_prefix->define_datas = Array__new();
                            enumeration_prefix->define_datas_initialized = Logical__true;
                        }
                        define_data = Define_Data__new();
                        define_data->old_name = define_name;
                        define_data->new_name = new_name;
                        define_data->value = define_value;
                        define_data->type_name = ((String)"\000");
                        (void)Array__append(enumeration_prefix->define_datas, ((void *)(define_data)));
                    }
                    enumerations_index = (enumerations_index+1);
                }
                index = (index+1);
            }
            /* #if trace */
            /* #	call d@(form@("We have %d% define_datas\n\") / */
            /* #	  f@(define_datas.size)) */
        }
    }
    return errors;
}

/* #routine read_library_find_type@Source */
/* #    takes source Source */
/* #    takes compiler Compiler */
/* #    returns Unsigned */
/* # */
/* #    # This routine will run the {compile_phase} of the compiler on {source} */
/* #    # using {compiler} and return the number of errors. */
/* # */
/* #    base_name :@= source.base_name */
/* #    #trace :@= false@Logical */
/* #    #if trace */
/* #    #	call d@(form@("=>read_library_find_type@Source(v%)\n\") % f@(base_name)) */
/* # */
/* #    errors :@= 0 */
/* #    if ezc_read@(source, compiler) */
/* #	token :@= source.token */
/* #	if token == null@Token */
/* #	    call d@(form@("Unable to find library/interface %v%\n\") / */
/* #	      f@(base_name)) */
/* #	else */
/* #	    call log@(compiler, token, */
/* #	      form@("Unable to find library/interface %v%") / f@(base_name)) */
/* #	errors := errors + 1 */
/* #    else */
/* #	source.ezc.root := parse@(compiler.parser, source.ezc.tokens) */
/* # */
/* #	buffer :@= compiler.buffer */
/* #	call trim@(buffer, 0) */
/* #	compiler.source := source */
/* #	call visit@(source.ezc.root, */
/* #	  buffer, compiler, library_type_find@Phase) */
/* #	call trim@(buffer, 0) */
/* #	compiler.source := null@Source */
/* # */
/* #    #if trace */
/* #    #	call d@(form@("<=read_library_find_type@Source(v%)\n\") % f@(base_name)) */
/* # */
/* #    return errors */
Logical Source__should_compile(
  Source source,
  Compiler compiler)
{
    Source source0;
    Collection source_collection;
    Logical result;
    source0 = ((Source)Array__fetch1(compiler->sources, 0));
    source_collection = source->collection;
    result = 0;
    if ((source_collection == Collection__null)) {

        if ((source0->collection == Collection__null)) {

            result = 1;
        } else {

            /* # so it should not be compiled: */
            result = 0;
        }
    } else {

        if (String__equal(source0->base_name, source_collection->name)) {

            result = 1;
        } else {

            result = 0;
        }
    }
    return result;
}

void Source__show(
  Source source)
{
    Unsigned index;
    Unsigned size;
    Collection collection;
    Array collection_sources;
    Source collection_source;
    Array libraries;
    Array requires;
    Array interfaces;
    Array global_libraries;
    Array defines;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    index = 0;
    size = 0;
    (void)String__d((t__1 = String__form(((String)"\021  Base_Name: %v%\n")), String__divide((t__1), String__f(source->base_name))));
    collection = source->collection;
    if ((collection != Collection__null)) {
        (void)String__d((t__3 = String__form(((String)"\024    Collection: %v%\n")), String__divide((t__3), String__f(collection->name))));
        collection_sources = collection->sources;
        size = Array__size_get(collection_sources);
        index = 0;
        while ((index < size)) {
            collection_source = ((Source)Array__fetch1(collection_sources, index));
            (void)String__d((t__6 = String__form(((String)"\042      Collection_Source[%d%]: %v%\n")), t__7 = Unsigned__f(index), String__divide(String__remainder((t__6), t__7), String__f(collection_source->base_name))));
            index = (index+1);
        }
    }
    libraries = source->libraries;
    size = Array__size_get(libraries);
    index = 0;
    while ((index < size)) {
        (void)String__d((t__10 = String__form(((String)"\026    Library[%d%]: %v%\n")), t__11 = Unsigned__f(index), String__divide(String__remainder((t__10), t__11), String__f(((Library_Declaration)Array__fetch1(libraries, index))->name->value))));
        index = (index+1);
    }
    requires = source->requires;
    size = Array__size_get(requires);
    index = 0;
    while ((index < size)) {
        (void)String__d((t__14 = String__form(((String)"\027    Requires[%d%]: %v%\n")), t__15 = Unsigned__f(index), String__divide(String__remainder((t__14), t__15), String__f(((Require_Declaration)Array__fetch1(requires, index))->name->value))));
        index = (index+1);
    }
    interfaces = source->interfaces;
    size = Array__size_get(interfaces);
    index = 0;
    while ((index < size)) {
        (void)String__d((t__18 = String__form(((String)"\031    Interfaces[%d%]: %v%\n")), t__19 = Unsigned__f(index), String__divide(String__remainder((t__18), t__19), String__f(((Require_Declaration)Array__fetch1(requires, index))->name->value))));
        index = (index+1);
    }
    global_libraries = source->global_libraries;
    size = Array__size_get(global_libraries);
    index = 0;
    while ((index < size)) {
        (void)String__d((t__22 = String__form(((String)"\035    Global_Library[%d%]: %v%\n")), t__23 = Unsigned__f(index), String__divide(String__remainder((t__22), t__23), String__f(((Global_Library_Declaration)Array__fetch1(global_libraries, index))->name->value))));
        index = (index+1);
    }
    defines = source->defines;
    size = Array__size_get(defines);
    while ((index < size)) {
        (void)String__d((t__26 = String__form(((String)"\026    Defines[%d%]: %t%\n")), t__27 = Unsigned__f(index), String__divide(String__remainder((t__26), t__27), Type__f(((Define_Declaration)Array__fetch1(defines, index))->type))));
        index = (index+1);
    }
}

void Source__type_arm(
  Source source)
{
    /* do_nothing */;
}

void Source__type_disarm(
  Source source)
{
    /* do_nothing */;
}

Unsigned Source__typed_name_object_find(
  Source source,
  Compiler compiler)
{
    String base_name;
    Unsigned errors;
    String buffer;
    File ezg;
    base_name = source->base_name;
    (void)Source__type_arm(source);
    errors = 0;
    buffer = compiler->buffer;
    (void)String__trim(buffer, 0);
    (void)Root__visit(source->ezc->root, buffer, compiler, Phase__ezh_scan);
    ezg = source->ezg;
    if ((ezg != File__null)) {

        if (!((ezg->root != Root__null))) {
            System__assert_fail((String)"\14Compiler.ezc", 2462);
        }
        (void)Root__visit(ezg->root, buffer, compiler, Phase__ezh_scan);
    }
    (void)Source__type_disarm(source);
    return errors;
}

/* # {Variable} routines: */
void Variable__show(
  Variable variable,
  String buffer)
{
    if ((variable == Variable__null)) {
        (void)String__buffer_append(((String)"\015null@Variable"), buffer);
    } else {
        (void)String__buffer_append(((String)"\001'"), buffer);
        (void)String__buffer_append(variable->name, buffer);
        (void)String__buffer_append(((String)"\001'"), buffer);
    }
}

Variable Variable__create(
  String name,
  Type type)
{
    Variable variable;
    variable = Variable__new();
    variable->name = name;
    variable->type = type;
    variable->level = 0xffffffff;
    return variable;
}


String Compile_Phase__string_convert(
  Compile_Phase compile_phase)
{
    switch (compile_phase) {
        case Compile_Phase___ezc_read_library_type_find:
            return ((String)"\032ezc_read_library_type_find");
            break;
        case Compile_Phase___ezc_read:
            return ((String)"\010ezc_read");
            break;
        case Compile_Phase___ezg_read:
            return ((String)"\010ezg_read");
            break;
        case Compile_Phase___h_generate:
            return ((String)"\012h_generate");
            break;
        case Compile_Phase___c_generate:
            return ((String)"\012c_generate");
            break;
        case Compile_Phase___c_compile:
            return ((String)"\011c_compile");
            break;
        case Compile_Phase___link:
            return ((String)"\004link");
            break;
    }
    return ((String)"\000");
}



String Phase__string_convert(
  Phase phase)
{
    switch (phase) {
        case Phase___prefix_scan:
            return ((String)"\013prefix_scan");
            break;
        case Phase___ezh_emit:
            return ((String)"\010ezh_emit");
            break;
        case Phase___h_includes_emit:
            return ((String)"\017h_includes_emit");
            break;
        case Phase___h_typedefs_emit:
            return ((String)"\017h_typedefs_emit");
            break;
        case Phase___h_structs_emit:
            return ((String)"\016h_structs_emit");
            break;
        case Phase___h_externs_emit:
            return ((String)"\016h_externs_emit");
            break;
        case Phase___c_emit:
            return ((String)"\006c_emit");
            break;
        case Phase___c_defines_emit:
            return ((String)"\016c_defines_emit");
            break;
        case Phase___link_emit:
            return ((String)"\011link_emit");
            break;
        case Phase___link_scan:
            return ((String)"\011link_scan");
            break;
        case Phase___ezh_scan:
            return ((String)"\010ezh_scan");
            break;
        case Phase___generate_emit:
            return ((String)"\015generate_emit");
            break;
        case Phase___source_find:
            return ((String)"\013source_find");
            break;
    }
    return ((String)"\000");
}




/* {Collection} stuff: */

struct Collection__Struct Collection__Initial = {
    &String__Initial,
    (Array)0,
    0,
    0,
};

Collection Collection__null = &Collection__Initial;
void Collection__erase(
  Collection collection)
{
    collection->name = String__null;
    if (collection->sources == 0) {
	collection->sources = Array__new();
    } else {
	Array__erase(collection->sources);
    }
    collection->version_major = 0;
    collection->version_minor = 0;
}

Collection Collection__new(void)
{
    Collection collection;
    extern void *malloc(unsigned int);

    collection = (Collection)malloc(sizeof(*collection));
    collection->name = String__null;
    collection->sources = Array__new();
    collection->version_major = Unsigned__null;
    collection->version_minor = Unsigned__null;
    return collection;
}

void Collection__Initialize(void)
{
    Collection__erase(Collection__null);
}

/* {Compile_Phase} stuff: */

Compile_Phase Compile_Phase__null = (Compile_Phase)0;
Compile_Phase Compile_Phase__ezc_read_library_type_find = Compile_Phase___ezc_read_library_type_find;
Compile_Phase Compile_Phase__ezc_read = Compile_Phase___ezc_read;
Compile_Phase Compile_Phase__ezg_read = Compile_Phase___ezg_read;
Compile_Phase Compile_Phase__h_generate = Compile_Phase___h_generate;
Compile_Phase Compile_Phase__c_generate = Compile_Phase___c_generate;
Compile_Phase Compile_Phase__c_compile = Compile_Phase___c_compile;
Compile_Phase Compile_Phase__link = Compile_Phase___link;
void Compile_Phase__erase(
  Compile_Phase compile_phase)
{
    /* do nothing */
}

void Compile_Phase__Initialize(void)
{
    Compile_Phase__erase(Compile_Phase__null);
}

/* {Compiler} stuff: */

struct Compiler__Struct Compiler__Initial = {
    (Array)0,
    &String__Initial,
    0,
    (Array)0,
    (Hash_Table)0,
    (Array)0,
    &Routine_Declaration__Initial,
    0,
    (Hash_Table)0,
    (Array)0,
    (Array)0,
    (Array)0,
    (Array)0,
    (Array)0,
    (Array)0,
    &File__Initial,
    (Hash_Table)0,
    (Array)0,
    (Array)0,
    (Array)0,
    (Array)0,
    0,
    0,
    (Array)0,
    (Array)0,
    (Array)0,
    &Messages__Initial,
    &String__Initial,
    &Options__Initial,
    &Parser__Initial,
    (Phase)0,
    (Hash_Table)0,
    (Array)0,
    (Array)0,
    &String__Initial,
    &String__Initial,
    (Hash_Table)0,
    &String__Initial,
    &Source__Initial,
    (Array)0,
    (Hash_Table)0,
    (Array)0,
    (Array)0,
    (Array)0,
    &String__Initial,
    &String__Initial,
    &Token__Initial,
    &Tokenizer__Initial,
    0,
    0,
    &Traverser__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Type__Initial,
    &Typed_Name__Initial,
    (Hash_Table)0,
    (Array)0,
    (Hash_Table)0,
    0,
};

Compiler Compiler__null = &Compiler__Initial;
void Compiler__erase(
  Compiler compiler)
{
    if (compiler->break_labels == 0) {
	compiler->break_labels = Array__new();
    } else {
	Array__erase(compiler->break_labels);
    }
    compiler->buffer = String__null;
    compiler->c_indent = 0;
    if (compiler->collections == 0) {
	compiler->collections = Array__new();
    } else {
	Array__erase(compiler->collections);
    }
    if (compiler->collection_table == 0) {
	compiler->collection_table = Hash_Table__new();
    } else {
	Hash_Table__erase(compiler->collection_table);
    }
    if (compiler->continue_labels == 0) {
	compiler->continue_labels = Array__new();
    } else {
	Array__erase(compiler->continue_labels);
    }
    compiler->current_routine = Routine_Declaration__null;
    compiler->cast_suppress = 0;
    if (compiler->define_table == 0) {
	compiler->define_table = Hash_Table__new();
    } else {
	Hash_Table__erase(compiler->define_table);
    }
    if (compiler->defines == 0) {
	compiler->defines = Array__new();
    } else {
	Array__erase(compiler->defines);
    }
    if (compiler->defines_prefixes == 0) {
	compiler->defines_prefixes = Array__new();
    } else {
	Array__erase(compiler->defines_prefixes);
    }
    if (compiler->define_datas == 0) {
	compiler->define_datas = Array__new();
    } else {
	Array__erase(compiler->define_datas);
    }
    if (compiler->error_kinds == 0) {
	compiler->error_kinds = Array__new();
    } else {
	Array__erase(compiler->error_kinds);
    }
    if (compiler->error_tokens == 0) {
	compiler->error_tokens = Array__new();
    } else {
	Array__erase(compiler->error_tokens);
    }
    if (compiler->enumeration_prefixes == 0) {
	compiler->enumeration_prefixes = Array__new();
    } else {
	Array__erase(compiler->enumeration_prefixes);
    }
    compiler->file = File__null;
    if (compiler->file_table == 0) {
	compiler->file_table = Hash_Table__new();
    } else {
	Hash_Table__erase(compiler->file_table);
    }
    if (compiler->files == 0) {
	compiler->files = Array__new();
    } else {
	Array__erase(compiler->files);
    }
    if (compiler->global_libraries == 0) {
	compiler->global_libraries = Array__new();
    } else {
	Array__erase(compiler->global_libraries);
    }
    if (compiler->includes == 0) {
	compiler->includes = Array__new();
    } else {
	Array__erase(compiler->includes);
    }
    if (compiler->interface_bases == 0) {
	compiler->interface_bases = Array__new();
    } else {
	Array__erase(compiler->interface_bases);
    }
    compiler->label_count = 0;
    compiler->level = 0;
    if (compiler->library_bases == 0) {
	compiler->library_bases = Array__new();
    } else {
	Array__erase(compiler->library_bases);
    }
    if (compiler->loads == 0) {
	compiler->loads = Array__new();
    } else {
	Array__erase(compiler->loads);
    }
    if (compiler->loop_levels == 0) {
	compiler->loop_levels = Array__new();
    } else {
	Array__erase(compiler->loop_levels);
    }
    compiler->messages = Messages__null;
    compiler->middlefix = String__null;
    compiler->options = Options__null;
    compiler->parser = Parser__null;
    compiler->phase = Phase__null;
    if (compiler->scalar_table == 0) {
	compiler->scalar_table = Hash_Table__new();
    } else {
	Hash_Table__erase(compiler->scalar_table);
    }
    if (compiler->scanned_types == 0) {
	compiler->scanned_types = Array__new();
    } else {
	Array__erase(compiler->scanned_types);
    }
    if (compiler->searches == 0) {
	compiler->searches = Array__new();
    } else {
	Array__erase(compiler->searches);
    }
    compiler->search_options = String__null;
    compiler->other_typedefs = String__null;
    if (compiler->simple_table == 0) {
	compiler->simple_table = Hash_Table__new();
    } else {
	Hash_Table__erase(compiler->simple_table);
    }
    compiler->simple_typedefs = String__null;
    compiler->source = Source__null;
    if (compiler->sources == 0) {
	compiler->sources = Array__new();
    } else {
	Array__erase(compiler->sources);
    }
    if (compiler->source_table == 0) {
	compiler->source_table = Hash_Table__new();
    } else {
	Hash_Table__erase(compiler->source_table);
    }
    if (compiler->statements == 0) {
	compiler->statements = Array__new();
    } else {
	Array__erase(compiler->statements);
    }
    if (compiler->switch_levels == 0) {
	compiler->switch_levels = Array__new();
    } else {
	Array__erase(compiler->switch_levels);
    }
    if (compiler->temporaries == 0) {
	compiler->temporaries = Array__new();
    } else {
	Array__erase(compiler->temporaries);
    }
    compiler->temporary = String__null;
    compiler->temporary2 = String__null;
    compiler->token = Token__null;
    compiler->tokenizer = Tokenizer__null;
    compiler->trace_line = 0;
    compiler->tracing = 0;
    compiler->traverser = Traverser__null;
    compiler->type_byte = Type__null;
    compiler->type_character = Type__null;
    compiler->type_double = Type__null;
    compiler->type_easy_c = Type__null;
    compiler->type_float = Type__null;
    compiler->type_integer = Type__null;
    compiler->type_long_integer = Type__null;
    compiler->type_long_unsigned = Type__null;
    compiler->type_logical = Type__null;
    compiler->type_quad = Type__null;
    compiler->type_pointer_pointer = Type__null;
    compiler->type_short = Type__null;
    compiler->type_string = Type__null;
    compiler->type_unsigned = Type__null;
    compiler->typed_name = Typed_Name__null;
    if (compiler->xtyped_name_object_table == 0) {
	compiler->xtyped_name_object_table = Hash_Table__new();
    } else {
	Hash_Table__erase(compiler->xtyped_name_object_table);
    }
    if (compiler->variables == 0) {
	compiler->variables = Array__new();
    } else {
	Array__erase(compiler->variables);
    }
    if (compiler->variable_table == 0) {
	compiler->variable_table = Hash_Table__new();
    } else {
	Hash_Table__erase(compiler->variable_table);
    }
    compiler->undefs_generated = 0;
}

Compiler Compiler__new(void)
{
    Compiler compiler;
    extern void *malloc(unsigned int);

    compiler = (Compiler)malloc(sizeof(*compiler));
    compiler->break_labels = Array__new();
    compiler->buffer = String__null;
    compiler->c_indent = Unsigned__null;
    compiler->collections = Array__new();
    compiler->collection_table = Hash_Table__new();
    compiler->continue_labels = Array__new();
    compiler->current_routine = Routine_Declaration__null;
    compiler->cast_suppress = Logical__null;
    compiler->define_table = Hash_Table__new();
    compiler->defines = Array__new();
    compiler->defines_prefixes = Array__new();
    compiler->define_datas = Array__new();
    compiler->error_kinds = Array__new();
    compiler->error_tokens = Array__new();
    compiler->enumeration_prefixes = Array__new();
    compiler->file = File__null;
    compiler->file_table = Hash_Table__new();
    compiler->files = Array__new();
    compiler->global_libraries = Array__new();
    compiler->includes = Array__new();
    compiler->interface_bases = Array__new();
    compiler->label_count = Unsigned__null;
    compiler->level = Unsigned__null;
    compiler->library_bases = Array__new();
    compiler->loads = Array__new();
    compiler->loop_levels = Array__new();
    compiler->messages = Messages__null;
    compiler->middlefix = String__null;
    compiler->options = Options__null;
    compiler->parser = Parser__null;
    compiler->phase = Phase__null;
    compiler->scalar_table = Hash_Table__new();
    compiler->scanned_types = Array__new();
    compiler->searches = Array__new();
    compiler->search_options = String__null;
    compiler->other_typedefs = String__null;
    compiler->simple_table = Hash_Table__new();
    compiler->simple_typedefs = String__null;
    compiler->source = Source__null;
    compiler->sources = Array__new();
    compiler->source_table = Hash_Table__new();
    compiler->statements = Array__new();
    compiler->switch_levels = Array__new();
    compiler->temporaries = Array__new();
    compiler->temporary = String__null;
    compiler->temporary2 = String__null;
    compiler->token = Token__null;
    compiler->tokenizer = Tokenizer__null;
    compiler->trace_line = Unsigned__null;
    compiler->tracing = Logical__null;
    compiler->traverser = Traverser__null;
    compiler->type_byte = Type__null;
    compiler->type_character = Type__null;
    compiler->type_double = Type__null;
    compiler->type_easy_c = Type__null;
    compiler->type_float = Type__null;
    compiler->type_integer = Type__null;
    compiler->type_long_integer = Type__null;
    compiler->type_long_unsigned = Type__null;
    compiler->type_logical = Type__null;
    compiler->type_quad = Type__null;
    compiler->type_pointer_pointer = Type__null;
    compiler->type_short = Type__null;
    compiler->type_string = Type__null;
    compiler->type_unsigned = Type__null;
    compiler->typed_name = Typed_Name__null;
    compiler->xtyped_name_object_table = Hash_Table__new();
    compiler->variables = Array__new();
    compiler->variable_table = Hash_Table__new();
    compiler->undefs_generated = Logical__null;
    return compiler;
}

void Compiler__Initialize(void)
{
    Compiler__erase(Compiler__null);
}

/* {Phase} stuff: */

Phase Phase__null = (Phase)0;
Phase Phase__prefix_scan = Phase___prefix_scan;
Phase Phase__ezh_emit = Phase___ezh_emit;
Phase Phase__h_includes_emit = Phase___h_includes_emit;
Phase Phase__h_typedefs_emit = Phase___h_typedefs_emit;
Phase Phase__h_structs_emit = Phase___h_structs_emit;
Phase Phase__h_externs_emit = Phase___h_externs_emit;
Phase Phase__c_emit = Phase___c_emit;
Phase Phase__c_defines_emit = Phase___c_defines_emit;
Phase Phase__link_emit = Phase___link_emit;
Phase Phase__link_scan = Phase___link_scan;
Phase Phase__ezh_scan = Phase___ezh_scan;
Phase Phase__generate_emit = Phase___generate_emit;
Phase Phase__source_find = Phase___source_find;
void Phase__erase(
  Phase phase)
{
    /* do nothing */
}

void Phase__Initialize(void)
{
    Phase__erase(Phase__null);
}

/* {Variable} stuff: */

struct Variable__Struct Variable__Initial = {
    &String__Initial,
    &Type__Initial,
    0,
};

Variable Variable__null = &Variable__Initial;
void Variable__erase(
  Variable variable)
{
    variable->name = String__null;
    variable->type = Type__null;
    variable->level = 0;
}

Variable Variable__new(void)
{
    Variable variable;
    extern void *malloc(unsigned int);

    variable = (Variable)malloc(sizeof(*variable));
    variable->name = String__null;
    variable->type = Type__null;
    variable->level = Unsigned__null;
    return variable;
}

void Variable__Initialize(void)
{
    Variable__erase(Variable__null);
}

/* {Source} stuff: */

struct Source__Struct Source__Initial = {
    &String__Initial,
    &Collection__Initial,
    &Collection_Declaration__Initial,
    (Array)0,
    &File__Initial,
    &File__Initial,
    (Array)0,
    (Array)0,
    (Array)0,
    (Array)0,
};

Source Source__null = &Source__Initial;
void Source__erase(
  Source source)
{
    source->base_name = String__null;
    source->collection = Collection__null;
    source->collection_declaration = Collection_Declaration__null;
    if (source->defines == 0) {
	source->defines = Array__new();
    } else {
	Array__erase(source->defines);
    }
    source->ezc = File__null;
    source->ezg = File__null;
    if (source->global_libraries == 0) {
	source->global_libraries = Array__new();
    } else {
	Array__erase(source->global_libraries);
    }
    if (source->interfaces == 0) {
	source->interfaces = Array__new();
    } else {
	Array__erase(source->interfaces);
    }
    if (source->libraries == 0) {
	source->libraries = Array__new();
    } else {
	Array__erase(source->libraries);
    }
    if (source->requires == 0) {
	source->requires = Array__new();
    } else {
	Array__erase(source->requires);
    }
}

Source Source__new(void)
{
    Source source;
    extern void *malloc(unsigned int);

    source = (Source)malloc(sizeof(*source));
    source->base_name = String__null;
    source->collection = Collection__null;
    source->collection_declaration = Collection_Declaration__null;
    source->defines = Array__new();
    source->ezc = File__null;
    source->ezg = File__null;
    source->global_libraries = Array__new();
    source->interfaces = Array__new();
    source->libraries = Array__new();
    source->requires = Array__new();
    return source;
}

void Source__Initialize(void)
{
    Source__erase(Source__null);
}


