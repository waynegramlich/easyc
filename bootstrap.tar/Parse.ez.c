#include "Parse.ez.h"/*cc2*/
/* # Copyright (c) 2007-2009 by Wayne C. Gramlich. */
/* # All rights reserved. */
#include "Compiler.ez.h"/*D1*/
#include "Easy_C.ez.h"/*D1*/
#include "Expression.ez.h"/*D1*/
#include "Token.ez.h"/*D1*/
/* # This is the location where the Easy-C parsing strategy is */
/* # discussed. */
/* # */
/* # The parsing techniques taught in by most computer science */
/* # courses are based on the "Dragon Book" (named after */
/* # the dragon on its cover) "Compilers: Principles, Techniques, */
/* # and Tools" by Aho, Sethi, and Ullman.  The authors of this */
/* # book really push LALR(1) bottom-up parsing using a parser */
/* # generator such as YACC (Yet Another Compiler Compiler.) */
/* # */
/* # Unfortunately, I disagree with their thrust.  I think the */
/* # most important aspects of a parser are 1) correctness and */
/* # 2) quality error messages, 3) ease of understanding the */
/* # code and with 4) performance not being nearly as important. */
/* # Bottom-up parsers are notorious for having insufficient */
/* # information to provide decent error messages.  While it */
/* # is possible to coax a LALR(1) parser into generating some */
/* # reasonable error messages, it is not particularly easy. */
/* # The LALR(1) folks seem to concentrate on 1) and 4) and */
/* # pay little attention to 2) and 3). */
/* # */
/* # The Easy-C parser does not use a LALR(1) bottom-up parser. */
/* # Instead, it uses an easy to understand and reasonably */
/* # efficient recursive decent parser.  Reasonable error */
/* # message generation is quite straight forward using recursive */
/* # decent.   When it comes to expression parsing, a basic */
/* # operator precedence parser is used.  (The "Dragon Book" */
/* # does not even mention operator precedence grammars as such, */
/* # since precedence grammars are kind of built into LALR(1) */
/* # parsers.)  Operator precedence grammars are simple to implement */
/* # and understand whereas LALR(1) parsers are extremely difficult */
/* # to implement and understand.  The long out of print book */
/* # "Compiler Construction for Digital Computers" by David Gries */
/* # discusses both operator precedence grammars and recursive */
/* # decent parsing.  (Warning: the book typography is atrocious.) */
/* # Used copies of the book are available via <http://Amazon.Com/> */
/* # for way less than used copies of the "Dragon Book". */
/* # */
/* # The result of parsing an Easy-C program is a parse tree that is */
/* # stored in a strongly typed recursive data structure that is rooted */
/* # in the {Root} type.  The recursive data structures are defined */
/* # below.  The "magic" is that the Easy-C compiler implements */
/* # special code that generates most of the recursive decent */
/* # "parse" routines automatically; thereby saving a huge amount of */
/* # tedious code writing.  In addition, there is another */
/* # crop of "traverse" routines that are automatically generated */
/* # for visiting all of the nodes in a parse tree. */
/* # */
/* # The text below outlines how the compiler generates both */
/* # the parse and traverse routines.  Be sure to look at the */
/* # generated file Parse.ezg, to see all of these boring routines. */
/* # After you have read a few of them, you will be glad that the */
/* # compiler writes them rather than a human. */
/* # */
/* # The "generate parse" clause causes the compiler to generate */
/* # a parse routine for the type.  The parse routine for a record */
/* # node sequentially calls the parse fields for each field in the */
/* # record.  If any sub-parse fails, by returning Null, the entire */
/* # parse fails and returns Null.  The parse routine for a variant */
/* # node sequentially invokes the parse routine for each sub field */
/* # until the first one returns non-Null.  The last field of each */
/* # variant is "error Error" which always succeeds, but generates */
/* # an error message as a side effect and slurps through the tokens */
/* # until the "line" is at the same indentation level. */
/* # */
/* # The {Token} node is a special case.  If the name of the field */
/* # is a known lexeme, it must match the {Lexeme} name.  Thus */
/* # "end_of_line Token" will only match an {end_of_line} {Token}. */
/* # If the name does not match, a {symbol} token must be matched. */
/* # */
/* # The {Keyword} node is a special case.  It will only match a */
/* # symbol that has the exact spelling of the field name.  Thus, */
/* # "define Keyword" will only match a symbol token containing */
/* # "define". */
/* # */
/* # Parameterized types are a special case.  They must be followed */
/* # by a Token field.  Thus, "statements Array[Statement]" */
/* # followed by "close_indent Token" will match a sequence of */
/* # one or more {Statement} nodes and is terminated when a */
/* # {close_indent} {Token} is encountered. */
/* # */
/* # Lastly, if there is more than one record field, only the */
/* # first one is used for parsing.  The rest are extra fields */
/* # for later use by the compiler. */
/* # */
/* # The "generate traverse" clause causes the compiler to generate */
/* # a traverse routine that will perform an in order tree */
/* # traversal of the parse tree.  The {traverse}@{Token} routine */
/* # is responsible for doing anything interesting with each */
/* # leaf node. */
/* # */
/* # Any special case parsing routines are done by leaving off */
/* # the "generate parse" clause and are hand written. */
/* # Likewise, a special traverse routine can be provided by */
/* # leaving off the "generate traverse" clause and hand writing */
/* # it. */
/* # The following records are used to build up a parse tree: */
/* # Define declaration: */
/* # Other one line declarations: */
/* # Routines go here: */
/* # Statements are listed here: */
/* #FIXME: replace If_Statement data structures!!! */
/* #FIXME: replace Return_Statement data structures!!! */
/* # Expressions are listed here: */
/* # Types are defined here: */
/* # Shared stuff: */
/* # That is it for the parse tree type definitions. */
/* # The remaining types and hand written parse routines are defined here: */
/* # {Array} stuff: */
/* #undef lower case macros */
#undef i386
#undef linux
#undef unix
#undef errno
#undef makedev
#undef major
#undef minor
#undef alloca

Array Array__parse(
  Parser parser,
  void * (*parse_sub_type)(Parser),
  void *null_sub_type,
  Lexeme stop_lexeme)
{
    String temporary;
    Array tokens;
    Unsigned size;
    Array sub_types;
    Unsigned index;
    Token token;
    void *sub_type;
    temporary = String__new();
    tokens = parser->tokens;
    size = Array__size_get(tokens);
    sub_types = Array__new();
    index = parser->index;
    while ((index < size)) {
        token = ((Token)Array__fetch1(parser->tokens, index));
        /* #call put@(form@("parse@Array: [%s%] %t%\n\") % */
        /* #  f@(parser.index) / f@(token), error@Out_Stream) */
        if ((token->lexeme == stop_lexeme)) {
            break;
        }
        sub_type = parse_sub_type(parser);
        if ((sub_type == null_sub_type)) {
            break;
        }
        (void)Array__append(sub_types, ((void *)(sub_type)));
        index = parser->index;
    }
    return sub_types;
}

void Array__traverse(
  Array sub_types,
  Traverser traverser,
  void (*traverse_proc)(void *, Traverser))
{
    Unsigned size;
    Unsigned index;
    void *sub_type;
    size = Array__size_get(sub_types);
    index = 0;
    while ((index < size)) {
        sub_type = ((void *)Array__fetch1(sub_types, index));
        (void)traverse_proc(sub_type, traverser);
        index = (index+1);
    }
}

/* # {Comma_Separated} stuff: */
Integer Comma_Separated__compare(
  Comma_Separated comma_separated1,
  Comma_Separated comma_separated2,
  Integer (*compare_routine)(void *, void *))
{
    Integer zero;
    Integer result;
    Array sub_types1;
    Array sub_types2;
    Unsigned size1;
    Unsigned size2;
    Unsigned size;
    Unsigned index;
    zero = 0;
    result = zero;
    sub_types1 = comma_separated1->sub_types;
    sub_types2 = comma_separated2->sub_types;
    size1 = Array__size_get(sub_types1);
    size2 = Array__size_get(sub_types2);
    size = size1;
    if ((size2 < size1)) {
        size = size2;
    }
    index = 0;
    while (((index < size)&&(result == zero))) {
        result = compare_routine(((void *)Comma_Separated__fetch1(comma_separated1, index)), ((void *)Comma_Separated__fetch1(comma_separated2, index)));
        index = (index+1);
    }
    if ((result == zero)) {
        result = Unsigned__compare(size1, size2);
    }
    return result;
}

void Comma_Separated__copy_to(
  Comma_Separated to,
  Comma_Separated from,
  void * (*copy_routine)(void *))
{
    Array from_sub_types;
    Array to_sub_types;
    Array to_commas;
    Unsigned size;
    Unsigned index;
    from_sub_types = from->sub_types;
    to_sub_types = to->sub_types;
    to_commas = to->commas;
    (void)Array__trim(to_sub_types, 0);
    (void)Array__trim(to_commas, 0);
    (void)Array__array_append(to_commas, from->commas);
    size = Array__size_get(from_sub_types);
    index = 0;
    while ((index < size)) {
        (void)Array__append(to_sub_types, ((void *)(copy_routine(((void *)Array__fetch1(from_sub_types, index))))));
        index = (index+1);
    }
}

Logical Comma_Separated__equal(
  Comma_Separated comma_separated1,
  Comma_Separated comma_separated2,
  Logical (*equal_routine)(void *, void *))
{
    Logical result;
    Array sub_types1;
    Array sub_types2;
    Unsigned size1;
    Unsigned size2;
    Unsigned index;
    result = Logical__false;
    sub_types1 = comma_separated1->sub_types;
    sub_types2 = comma_separated2->sub_types;
    size1 = Array__size_get(sub_types1);
    size2 = Array__size_get(sub_types2);
    if ((size1 == size2)) {
        result = Logical__true;
        index = 0;
        while ((index < size1)) {
            if (!equal_routine(((void *)Comma_Separated__fetch1(comma_separated1, index)), ((void *)Comma_Separated__fetch1(comma_separated2, index)))) {
                result = Logical__false;
                break;
            }
            index = (index+1);
        }
    }
    return result;
}

String Comma_Separated__f(
  Comma_Separated comma_separated,
  String (*f_routine)(void *))
{
    String value;
    String control;
    Array sub_types;
    Unsigned size;
    String prefix;
    Unsigned index;
    void *sub_type;
    String form1;
    String form2;
    value = Format__field_next();
    control = String__read_only_copy(value);
    (void)String__trim(value, 0);
    sub_types = comma_separated->sub_types;
    size = Array__size_get(sub_types);
    prefix = ((String)"\000");
    index = 0;
    while ((index < size)) {
        (void)String__string_append(value, prefix);
        prefix = ((String)"\002, ");
        sub_type = ((void *)Array__fetch1(sub_types, index));
        form1 = String__form(control);
        form2 = f_routine(sub_type);
        (void)String__string_append(value, String__divide(form1, form2));
        index = (index+1);
    }
    return value;
}

void * Comma_Separated__fetch1(
  Comma_Separated comma_separated,
  Unsigned index)
{
    return ((void *)Array__fetch1(comma_separated->sub_types, index));
}

Unsigned Comma_Separated__hash(
  Comma_Separated comma_separated,
  Unsigned (*hash_routine)(void *))
{
    Unsigned hash;
    Array sub_types;
    Unsigned size;
    Unsigned index;
    hash = 0;
    sub_types = comma_separated->sub_types;
    size = Array__size_get(sub_types);
    index = 0;
    while ((index < size)) {
        hash = (hash+hash_routine(((void *)Array__fetch1(sub_types, index))));
        index = (index+1);
    }
    return hash;
}

Comma_Separated Comma_Separated__parse(
  Parser parser,
  void * (*parse_sub_type)(Parser),
  void *null_sub_type,
  Lexeme stop_lexeme)
{
    Array tokens;
    Comma_Separated comma_separated;
    Array commas;
    Array sub_types;
    void *sub_type;
    Token comma;
    tokens = parser->tokens;
    comma_separated = Comma_Separated__new();
    commas = comma_separated->commas;
    sub_types = comma_separated->sub_types;
    sub_type = parse_sub_type(parser);
    if ((sub_type == null_sub_type)) {
        return comma_separated;
    }
    (void)Array__append(sub_types, ((void *)(sub_type)));
    while ((((Token)Array__fetch1(tokens, parser->index))->lexeme != stop_lexeme)) {

        comma = Token__parse(parser, Lexeme__comma);
        if ((comma == Token__null)) {

            (void)Array__trim(sub_types, 0);
            (void)Array__trim(commas, 0);
            break;
        }
        /* # Parse a {Sub_Type}: */
        sub_type = parse_sub_type(parser);
        if ((sub_type == null_sub_type)) {

            (void)Array__trim(sub_types, 0);
            (void)Array__trim(commas, 0);
            break;
        }
        /* # Got them both; add them to {comma_separated}: */
        (void)Array__append(sub_types, ((void *)(sub_type)));
        (void)Array__append(commas, ((void *)(comma)));
    }
    return comma_separated;
}

Unsigned Comma_Separated__size_get(
  Comma_Separated comma_separated)
{
    return Array__size_get(comma_separated->sub_types);
}

void Comma_Separated__store1(
  Comma_Separated comma_separated,
  Unsigned index,
  void *sub_type)
{
    Array__store1(comma_separated->sub_types, index, (void *)(sub_type));
}

void Comma_Separated__string_gap_insert(
  Comma_Separated comma_separated,
  String buffer,
  void (*gap_insert_routine)(void *, String))
{
    Array sub_types;
    Unsigned size;
    Unsigned index;
    sub_types = comma_separated->sub_types;
    size = Array__size_get(sub_types);
    index = 0;
    while ((index < size)) {
        if ((index != 0)) {
            (void)String__string_gap_insert(buffer, ((String)"\002, "));
        }
        (void)gap_insert_routine(((void *)Array__fetch1(sub_types, index)), buffer);
        index = (index+1);
    }
}

void Comma_Separated__traverse(
  Comma_Separated comma_separated,
  Traverser traverser,
  void (*traverse_proc)(void *, Traverser))
{
    Array commas;
    Array sub_types;
    Unsigned size;
    Unsigned index;
    commas = comma_separated->commas;
    sub_types = comma_separated->sub_types;
    size = Array__size_get(sub_types);
    index = 0;
    while ((index < size)) {
        if ((index != 0)) {
            (void)Token__traverse(((Token)Array__fetch1(commas, (index-1))), traverser);
        }
        (void)traverse_proc(((void *)Array__fetch1(sub_types, index)), traverser);
        index = (index+1);
    }
}

/* # {Define_Declaration} stuff: */
Enumeration_Clause Define_Declaration__enumeration_get(
  Define_Declaration define)
{
    Enumeration_Clause enumeration;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    enumeration = Enumeration_Clause__null;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___enumeration:
                enumeration = ((define_clause->kind == Define_Clause_Kind___enumeration) ? define_clause->kind__union.enumeration : (Enumeration_Clause)System__variant_object_fail((String)"\tParse.ezc", 1206));
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return enumeration;
}

Enumeration_Prefix_Clause Define_Declaration__enumeration_prefix_get(
  Define_Declaration define)
{
    Enumeration_Prefix_Clause enumeration_prefix;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    enumeration_prefix = Enumeration_Prefix_Clause__null;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___enumeration_prefix:
                enumeration_prefix = ((define_clause->kind == Define_Clause_Kind___enumeration_prefix) ? define_clause->kind__union.enumeration_prefix : (Enumeration_Prefix_Clause)System__variant_object_fail((String)"\tParse.ezc", 1227));
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return enumeration_prefix;
}

/* # {Enumeration_Clause} stuff: */
Array Enumeration_Clause__item_names(
  Enumeration_Clause enumeration)
{
    Array names;
    Array item_clauses;
    Unsigned size;
    Unsigned index;
    Item_Clause item_clause;
    names = Array__new();
    item_clauses = enumeration->item_clauses;
    size = Array__size_get(item_clauses);
    index = 0;
    while ((index < size)) {
        item_clause = ((Item_Clause)Array__fetch1(item_clauses, index));
        switch (item_clause->kind) {
            case Item_Clause_Kind___item:
                (void)Array__append(names, ((void *)(((item_clause->kind == Item_Clause_Kind___item) ? item_clause->kind__union.item : (Item)System__variant_object_fail((String)"\tParse.ezc", 1250))->name->value)));
                break;
        }
        index = (index+1);
    }
    return names;
}

/* # {Enumeration_Prefix_Clause} stuff: */
Array Enumeration_Prefix_Clause__item_names(
  Enumeration_Prefix_Clause enumeration_prefix)
{
    Array names;
    Array define_datas;
    Unsigned size;
    Unsigned index;
    Define_Data define_data;
    names = Array__new();
    define_datas = enumeration_prefix->define_datas;
    size = Array__size_get(define_datas);
    index = 0;
    while ((index < size)) {
        define_data = ((Define_Data)Array__fetch1(define_datas, index));
        (void)Array__append(names, ((void *)(define_data->new_name)));
        index = (index+1);
    }
    return names;
}

/* # {Error} stuff: */
Error Error__parse(
  Parser parser)
{
    Array parser_tokens;
    Unsigned index;
    Array tokens;
    Token token;
    String temporary;
    Unsigned tokens_size;
    Unsigned tokens_index;
    Unsigned level;
    Error error;
    parser_tokens = parser->tokens;
    index = parser->index;
    tokens = Array__new();
    while (Logical__true) {
        token = ((Token)Array__fetch1(parser_tokens, index));
        switch (token->lexeme) {
            case Lexeme___end_of_line:

                temporary = parser->temporary;
                (void)String__trim(temporary, 0);
                (void)String__buffer_append(((String)"\021Could not parse '"), temporary);
                tokens_size = Array__size_get(tokens);
                tokens_index = 0;
                while ((tokens_index < tokens_size)) {
                    token = ((Token)Array__fetch1(tokens, tokens_index));
                    if ((String__size_get(token->white_space) != 0)) {
                        (void)Character__buffer_append(((Character)' '), temporary);
                    }
                    (void)String__buffer_append(token->value, temporary);
                    tokens_index = (tokens_index+1);
                }
                (void)String__buffer_append(((String)"\001'"), temporary);
                (void)Messages__log(parser->messages, token, temporary);
                /* # Now look for a new indentation level: */
                (void)Array__append(tokens, ((void *)(token)));
                index = (index+1);
                /* # Check for a following indentation level: */
                token = ((Token)Array__fetch1(parser_tokens, index));
                if ((token->lexeme == Lexeme__open_indent)) {
                    (void)Array__append(tokens, ((void *)(token)));
                    index = (index+1);
                    level = 1;
                    while ((level != 0)) {
                        token = ((Token)Array__fetch1(parser_tokens, index));
                        switch (token->lexeme) {
                            case Lexeme___open_indent:
                                level = (level+1);
                                break;
                            case Lexeme___close_indent:
                                level = (level-1);
                                break;
                            case Lexeme___end_of_file:
                                if (!(Logical__false)) {
                                    System__assert_fail((String)"\tParse.ezc", 1321);
                                }
                                break;
                        }
                        (void)Array__append(tokens, ((void *)(token)));
                        index = (index+1);
                    }
                }
                goto break__1;
                break;
            case Lexeme___end_of_file:
                goto break__1;
                break;
            default:
                (void)Array__append(tokens, ((void *)(token)));
                index = (index+1);
                break;
        }
    }
    break__1:;
    parser->index = index;
    error = Error__new();
    error->tokens = tokens;
    return error;
}

void Error__traverse(
  Error error,
  Traverser traverser)
{
    if (!traverser->no_errors) {
        (void)Array__traverse(error->tokens, traverser, ((void (*)(void *, Traverser))(Token__traverse)));
    }
}

String Expression__f(
  Expression expression)
{
    String value;
    Traverser traverser;
    value = Format__field_next();
    (void)String__trim(value, 0);
    traverser = Traverser__create(value, Array__new());
    (void)Expression__traverse(expression, traverser);
    return value;
}

void Expression__format(
  Expression expression,
  String buffer)
{
    Unsigned anchor;
    Unsigned size;
    Unsigned index;
    Character character;
    Traverser traverser;
    anchor = String__format_begin(buffer);
    size = String__size_get(buffer);
    index = (anchor+1);
    character = ((Character)' ');
    while (((index < size)&&(character != ((Character)'%')))) {
        character = String__fetch1(buffer, index);
        index = (index+1);
    }
    traverser = Traverser__create(buffer, Array__new());
    (void)Expression__traverse(expression, traverser);
    (void)String__format_end(buffer, anchor);
}

Expression Expression__leaf_create(
  Token token)
{
    Expression expression;
    expression = Expression__new();
    switch (token->lexeme) {
        case Lexeme___character:
            expression->kind = Expression_Kind___character; expression->kind__union.character = token;
            break;
        case Lexeme___float_number:
            expression->kind = Expression_Kind___float_number; expression->kind__union.float_number = token;
            break;
        case Lexeme___number:
            expression->kind = Expression_Kind___number; expression->kind__union.number = token;
            break;
        case Lexeme___string:
            expression->kind = Expression_Kind___string; expression->kind__union.string = token;
            break;
        case Lexeme___symbol:
            expression->kind = Expression_Kind___symbol; expression->kind__union.symbol = token;
            break;
    }
    return expression;
}

/* # This is where expression parsing occurs.  A "standard" operator */
/* # precedence parser is used to parse expressions.  (The reason */
/* # why "standard" is in quotes is because most computer science classes */
/* # that teach compiler technology do not teach the operator precedence */
/* # parser anymore.  So even though a operator precedence parser is */
/* # quite simple to understand, it can hardly be called "standard" */
/* # anymore.)  An operator precedence parser has an expression stack */
/* # for holding expressions and an operator stack for holding operators. */
/* # While most precedence parsers operate in one pass, this compiler */
/* # uses a two pass strategy -- prescan and shift/reduce.  These two */
/* # passes can be combined into one, but the code is harder to understand */
/* # and the compiler error messages are not nearly as useful; hence, */
/* # two passes. */
/* # */
/* # The prescan pass scans over the entire expression performing two */
/* # basic tasks.  The first task is to transmute some operators */
/* # (e.g. binary operator to unary operator, etc.)  The second task */
/* # is to match up open parenthesises and brackets with their corresponding */
/* # close parenthesises and brackets.  There are three transmutations */
/* # that occur, 1) Binary to Unary, 2) Parentheses Grouping to Function */
/* # Invocation, and 3) Bracket to Type Bracket: */
/* # */
/* #  Binary to Unary: */
/* #    There are 4 unary oparators - '+', '-', '~', and '!'.  The */
/* #    first three are also binary operators.  Since binary operators */
/* #    have a different precedence (and associtivity) than binary */
/* #    operators it is important to distinguish them from one another */
/* #    This is done by the prescanner noticing when an operator is */
/* #    being used in a unary fashion and transmuting the {Token} */
/* #    {Lexeme}.  For example, the {Lexeme} for binary '-' is {minus} */
/* #    and the unary {Lexeme} is {negative}.  The way to identify a */
/* #    unary operator is that they can only occur immediately after */
/* #    another operator, except close parenthesis (')') or close */
/* #    bracket (']').  Some examples: "a := -b", "a := ~-b", and */
/* #    "a := (-b + c) - (-d - e)", where the first and third '-' */
/* #    are unary.  Notationally, 'u+', 'u-', 'u~', and 'u!' are */
/* #    used to represent tokens that have been transmuted to unary. */
/* #    Note that 'u!' and '!' are equivalent, since there is no binary */
/* #    operator '!'. */
/* #  */
/* #  Parenthesis Grouping to Function Invocation: */
/* #    The parenthesis operators can be used to group results */
/* #    (e.g. "(a + b) * c") or to provide function invocation */
/* #    (e.g. "a(b, c)".)  A function invocation occurs immeciately */
/* #    after a symbol, a close parenthesis (')'), or a close */
/* #    bracket (']').  Examples, "a(b)", "a[b](c)", "a(b)(c)". */
/* #    Notationally, 'i(' and 'i)' are used to represent parentheses */
/* #    that have been transmuted into invoke parentheses. */
/* # */
/* #  Bracket to Type Bracket: */
/* #    In order to compatible with ANSI-C syntax, the (...) [...] */
/* #    and dot ('.') operators need to be a the same precedence level. */
/* #    Thus, "a.b[c].d(e)" is grouped as "{{{{a.b} [c]} .d } (e)}". */
/* #    Alas, typed names in Easy-C look as follows:  "a@T[U](b)". */
/* #    Where "T[U]" is a parameterized type.  Using standard */
/* #    ANSI-C rules, it is grouped as follows "{{{a@T} [U]} (b)}" */
/* #    which is not what we want.  Instead, what we want is to */
/* #    group "T[U]" together.  This done by transmuting the '[' */
/* #    after an occurance of an '@' from an {open_bracket}@{Lexeme} */
/* #    to {open_type}@{Lexeme}.  Notationally, 't[' and 't]' */
/* #    are used to represent transmuted type brackets. */
/* # */
/* # In addition, the parenthesis/bracket matcher ensures that */
/* # the (...) and [...] match up.  It also transmute the close */
/* # parenthesis (')') and close bracket (']') into matching */
/* # lexemes.  The matches are always as follows: */
/* # */
/* #    Open                         Close */
/* #   ====================================================== */
/* #    open_parenthesis ('(')       close_parenthesis (')') */
/* #    open_invoke ('(')            close_invoke (')') */
/* #    open_bracket ('[')           close_parenthesis (']') */
/* #    open_type ('[')              close_type (']') */
/* #    type_invoke ('@(')           close_parenthesis (')') */
/* # */
/* # All of this transmutation and parenthesis/bracket matching is */
/* # done using a 5-state state machine.  This machine is drawn */
/* # below: */
/* # */
/* #      Start   +---+ */
/* #        |     |   |! (           leaf = symbol, number, or */
/* #        V     V   |eops-u               charter/string literal */
/* #       *********  | */
/* # +---->*       *--+              eops = Either binary or unary */
/* # |     * Unary *     ! (                OPerationS '+' '-' '~' */
/* # |     *       *<-----------+    eops-u = Transmute to unary */
/* # |     *********    eops-u  |    eops-b = Leave as binary */
/* # |        ^ |               | */
/* # |    *   | |               |    bops = other Binary OPeratorS */
/* # | @( ( [ | | ) leaf        |           excluding '@' */
/* # |        | |               |           For now, * / % & ^ | < = > , . */
/* # |   ] )  | |               |           <= >= != << >> == !== := :@= && || */
/* # |  +---+ | |               |    uops = Unary OPerators only '!' */
/* # |  |   | | |               |    eol = End Of line */
/* # |  |   V | V    eops-b     | */
/* # |  |  *********  bops  ********** */
/* # |  +--*       *------->*        * */
/* # |     * Leaf  *        * Binary * */
/* # |  +->*       *<-------*        * */
/* # |  |  *********  leaf  ********** */
/* # |  |       |   \         ^ */
/* # |  | ] )   |    \leaf    | */
/* # |  |       |     \eof    |bops */
/* # |  |     @ |      \      | */
/* # |  |       |       V     | */
/* # |  |       V      Exit   | */
/* # |  |  *********        ********** */
/* # |  |  *       *        *        * leaf */
/* # |  |  * @Sign *------->* @Leaf  *------->Exit */
/* # |  |  *       *  leaf  *        * eol */
/* # |  |  *********        ********** */
/* # |  |                     |   | */
/* # |  +---------------------+   | * * */
/* # |                            | [ ( @( */
/* # |                            | */
/* # +----------------------------+ */
/* # */
/* # The operators marked with (*) are transmuted to either a unary */
/* # operator or a function invocation open parenthesis or a type */
/* # open bracket.  The conversion from {close_parenthesis} to */
/* # {close_invoke} and from {close_bracket} to {close_type} is done */
/* # by the parenthesis/bracket matcher. */
/* # */
/* # Running through a few examples by hand should help clarify how */
/* # the state machine works: */
/* # */
/* #     1)   -a(-(b+c)*(d+e)) */
/* #     2)   a[-b+c, d](e, f, g) */
/* # */
/* # The shift/reduce phase starts with the expression stack empty */
/* # and a fictitious {start} operator on the operator stack.  The */
/* # expression tokens are scanned from left to right with a fictitious */
/* # {end} operator is processed last to force algorithm finalization. */
/* # */
/* # The mechanics of an operator precedence grammar are simple, but */
/* # understandy why they work is a bit more involved.  We will start */
/* # with explaining the mechanics and then work towards explaining why. */
/* # */
/* # A leaf token is a symbol, number, or string/character literal. */
/* # If a leaf token is encounterd, it is immediatly converted */
/* # into a leaf {Expression} and pushed onto the expression stack. */
/* # */
/* # If an operator is encountered, two precedence functions f(top) and */
/* # g(current) are computed.  f(top) is computed on the top most function */
/* # of the operator stack.  g(current) is computed on the current token. */
/* # If f(top) < g(current), a reduction operation takes place that */
/* # takes one or more operators and one or more expressions, creates */
/* # new expression and pushes that back onto the stack.  This reduction */
/* # process continuses until f(top) > f(current) at which point the */
/* # current token is pushed onto the operator stack and the next */
/* # token is processes.  The trick to making all of this work is the */
/* # f(top) and g(current) functions, and the associated reductions. */
/* # */
/* # The following reductions are possible: */
/* # */
/* #    Unary Reduction */
/* #	A unary redcution combines the top operator and the top */
/* #	expression into a {Unary_Expression} that is pushed back */
/* #	onto the expression stack.  Example: '-' and 'a' => "-a" */
/* # */
/* #    Group Reduction */
/* #	A group redcution combines the top operator, current operator */
/* #	and the top expression into a {Parenthesis_Expression} that */
/* #       is pushed back onto the expression stack.  Example: */
/* #	'(', 'a', ') => "(a)" */
/* # */
/* #    Binary Reduction */
/* #	A binary reduction combines the top operator and the two */
/* #	top expressions into a {Binary_Expression} that is pushed */
/* #	back onto the expression stack.  Example '*', 'a', 'b' => */
/* #	"a+b". */
/* # */
/* #    Bracket Reduction */
/* #	A bracket reduction combines the top operartors, the current */
/* #	operator, and the top two expressions into a */
/* #	{Bracket_Expression} that is pushed back onto the expression */
/* #	stack.  Example: '[', ']', 'a', 'b' => "a[b]". */
/* # */
/* #    List Reduction */
/* #	A list reduction combines the one or more operators of the */
/* #	same precedence on the operator stack with the same number */
/* #	of expressions (plus one) on the expression stack into a */
/* #	{List_Expression} that is pushed back onto the expression */
/* #	stack.  Example: '+', '-', 'a', 'b', 'c' => "a+b-c". */
/* #       There is some extra nonsense required to detect and deal */
/* #	with empty lists (e.g. "a()" or "b[]".)  This done by */
/* #	noticing when the two bracket/parenthesis tokens are */
/* #	next to one another in the token stream. */
/* # */
/* #    Final Reduction */
/* #	A final reduction notices that the last two operators */
/* #	are {start} and {end} and terminates the algorithm. */
/* # */
/* # Of these reductions, the List reduction is rather non-typical */
/* # for a "standard" operator precedence grammars.  In "standard" */
/* # operator precedence grammars, usually everthing is reduced into */
/* # unary and binary expressions.  Alas, for operators at the same */
/* # precedence, this causes grief later on in the compiler.  So, */
/* # the non-standard list reduction is used to keep then all the */
/* # operands at the same precedence level grouped together in one */
/* # big happy {List_Expression} expression. */
/* # */
/* # The table below is what makes the whole grammar "sing". */
/* # Explaining the table will take some doing though. */
/* # */
/* # Prec.  Operator               Assoc.   Reduction S/R  f(top) g(current) */
/* # ========================================================================= */
/* #  16    t[                     left      Bracket   S      15      173 */
/* #  16    t]                     left      Bracket   S     175       13 */
/* #  15    i( @( [                left      Bracket   S      25      163 */
/* #  15    i) ]                   left      Bracket   R     165       23 */
/* #  15    (                      n/a       Group     S      25      163 */
/* #  15    )                      n/a       Group     R     165       23 */
/* #  15    @ .                    left      Binary    R     165      163 */
/* #  14    u- u! u+ u~  (unary)   right     Unary     S     155      158 */
/* #  14    ~                      left      LIst      S     145      148 */
/* #  13    * / %                  left      List      S     135      138 */
/* #  12    + -      (binary)      left      List      S     125      128 */
/* #  11    << >>                  left      List      S     115      118 */
/* #  10    &                      left      List      S     105      108 */
/* #   9    ^                      left      List      S      95       98 */
/* #   8    |                      left      List      S      85       88 */
/* #   7    < > <= >= != = == !==  left      Binary    R      75       73 */
/* #   6    &&                     left      List      S      65       68 */
/* #   5    ||                     left      List      S      55       58 */
/* #   4    ,                      left      List      S      45       48 */
/* #   3    := :@= ;               right     Binary    S      35       38 */
/* #   2    (used by brackets)                                  */
/* #   1    (used by brackets) */
/* #   0    {start}                n/a       Final             5      error */
/* #   0    {end}                  n/a       Final          error       3 */
/* # */
/* # The first column is the operator precedence.  The higher the */
/* # precedence number, the tighter the precedence.  Notice that */
/* # the '(', 'i(', '@(', '[', ')', 'i)', ']', '.', and '@' are all marked */
/* # at the same precedence of 15.  The type square brackets, 't[' */
/* # and 't]', are even higer # at 16.  Precedence 1 and 2 is actually */
/* # used by the bracket/parenthesis operators, so the lowest user visable */
/* # operator is ':=' at precedence 3. */
/* # */
/* # The operators are listed under the operator column.  The */
/* # unary 'u+' and 'u-' are in a separate row from the binary */
/* # '+' and '-'. */
/* # */
/* # Associativity is how operators at the same precedence level */
/* # are grouped.  In general all operators are left associative */
/* # except the unary operators.  Thus, "a+b-c" associates as */
/* # "(a+b)-c".  The unary operators are right associative, */
/* # so "~-a" is "~(-a)". */
/* # */
/* # The next column specifies the reduction that is performed */
/* # on the operator.  There six possible reductions, Final, */
/* # Unary, Binary, Bracket, List, and Group.  These reductions */
/* # are described above. */
/* # */
/* # The next column is S/R which is short for Shift/Reduce. */
/* # This column specifies what to do when the two operators */
/* # at the same precedence are encountered.  An "S" means */
/* # that the current token should be shifted to the operator */
/* # stack.  An "R" means that a reduction should be triggered. */
/* # */
/* # In a "standard" operator precedence grammar, left associative */
/* # operators are "Reduce" and right associative operators are */
/* # "Shift".  Alas, the List reduction does not work that way. */
/* # The List reduction wants all operators at the same precedence */
/* # level on the stack, so it requires a Shift.  The following */
/* # table summarizes what we want to happen based on associativity */
/* # and reduction. */
/* # */
/* #      Reduction   Associativity   S/R */
/* #      ==================================== */
/* #      Group        n/a            Reduce */
/* #      Unary        Right          Shift */
/* #      Binary       Left           Reduce */
/* #      Binary       Right          Shift */
/* #      Bracket      Left           Reduce */
/* #      List         Left           Shift */
/* # */
/* # Once we have decided on the Shift and Reduce requirements for */
/* # a given precedence level, the f(top) and g(current) fucntions */
/* # are mechanically generated using the table: */
/* # */
/* #      S/R         f(top)          g(current) */
/* #      ========================================== */
/* #      Shift       P*10+5          P*10+8 */
/* #      Reduce      P*10+5          P*10+3 */
/* # */
/* # where P is the precedence.  In the algorithm f(top) < g(current) */
/* # causes a shift and f(top) > g(current) causes a reduce. */
/* # For operators at different precedence levels, the f(top) and */
/* # g(current) comparison causes the correct shift and reduce to occur. */
/* # The bracket operators are carefully chosen to cause the correct */
/* # grouping to occur. */
/* # */
/* # Working through a few examples are in order to get the hang */
/* # of what is going on.  First, a few comments on notation are */
/* # in order.  Spaces separate stack entries.  Braces ('{', '}') */
/* # enclose expressions.  We will forgo putting braces around */
/* # symbols (i.e. "a" instead of "{a}"), although in reality  */
/* # they are leaf expressions.  Also, it gets tedious to put */
/* # braces around bracketed expressions, so we will forgo those */
/* # braces as well (i.e. "{({a+b})}" = "(a+b)". */
/* # Unary operators are preceeded by 'u' as in 'u-', and the */
/* # invocation parenthesis as 'i('.  Lastly, the fictitious */
/* # {start} and end operators are represented by 'S' and 'E' */
/* # respectively. */
/* # */
/* # Example 1:  (a+b)*c-d */
/* # */
/* # Step Top:Cur f(t):g(c)  S/R             Exp. Stack           Op Stack */
/* # ===================================================================== */
/* #  1     S (     5 < 153  Shift                                S ( */
/* #  2     ( a      Leaf    Shift           a                    S ( */
/* #  3     ( +    25 < 128  Shift           a                    S ( + */
/* #  4     + b      Leaf    Shift           a b                  S ( + */
/* #  5a    + )   125 > 13   List Reduce     {a+b}                S ( */
/* #  5b    ( )    25 > 23   Bracket Reduce  (a+b)                S */
/* #  6     S *     5 < 138  Shift           (a+b)                S * */
/* #  7     * c      Leaf    Shift           (a+b) c              S * */
/* #  8a    * -   135 > 128  List Reduce     {(a+b)*c}            S */
/* #  8b    S -     5 < 128  Shift           {(a+b)*c}            S -  */
/* #  9     - d      Leaf    Shift           {(a+b)*c} d          S - */
/* # 10a    - E   125 > 3    List Reduce     {{(a+b)*c}-d}        S */
/* # 10b    S E     5 > 3    Final Reduce    {{(a+b)*c}-d} */
/* # */
/* # That was fun: */
/* # */
/* # Example 2: a[-b.c](d,e) */
/* # */
/* # Step Top:Cur f(t):g(c)  S/R             Exp. Stack           Op Stack */
/* # ===================================================================== */
/* #  1     S a      Leaf    Shift           a                    S */
/* #  2     S [     5 < 153  Shift           a                    S [ */
/* #  3     [ u-   25 < 138  Shift           a                    S [ u- */
/* #  4    u- b      Leaf    Shift           a b                  S [ u- */
/* #  5    u- .   145 < 153  Shift           a b                  S [ u- . */
/* #  6     . c      Leaf    Shift           a b c                S [ u- . */
/* #  7a    . ]   155 > 23   Binary Reduce   a {b.c}              S [ u-  */
/* #  7b   u- ]   145 > 23   Unary Reduce    a {-{b.c}}           S [  */
/* #  7c    [ ]    25 > 23   Bracket Reduce  a[-{b.c}]            S */
/* #  8     S (     5 < 153  Shift           a[-{b.c}]            S ( */
/* #  9    i( d      Leaf    Shift           a[-{b.c}] d          S ( */
/* # 10    i( ,    25 < 38   Shift           a[-{b.c}] d          S ( , */
/* # 11     , e      Leaf    Shift           a[-{b.c}] d e        S ( , */
/* # 12     , i)   45 > 23   List Reduce     a[-{b.c}] {d,e}      S ( */
/* # 13    i( i)   25 > 23   Bracket Reduce  a[-{b.c}](d,e)       S */
/* # 14     S E     5 > 3    Final Reduce    a[-{b.c}](d,e) */
/* # */
/* # Example : a@b[c[d,e]](f) */
/* # */
/* # Step Top:Cur f(t):g(c)  S/R             Exp. Stack           Op Stack */
/* # ===================================================================== */
/* #  1     S a      Leaf    Shift           a                    S */
/* #  2     S @     5 < 153  Shift           a                    S @ */
/* #  3     @ b      Leaf    Shift           a b                  S @ */
/* #  4     @ t[  155 < 163  Shift           a b                  S @ t[ */
/* #  5    t[ c      Leaf    Shift           a b c                S @ t[ */
/* #  6    t[ [    15 < 153  Shift           a b c                S @ t[ [ */
/* #  7     [ d      Leaf    Shift           a b c d              S @ t[ [ */
/* #  8     [ ,    15 < 38   Shift           a b c d              S @ t[ [ , */
/* #  9     , e      Leaf    Shift           a b c d e            S @ t[ [ , */
/* # 10a    , ]    45 > 23   List Reduce     a b c {d,e}          S @ t[ [ */
/* # 10b    [ ]    25 > 23   Bracket Reduce  a b {c[d,e]}         S @ t[ */
/* # 11    t[ t]   15 > 13   Bracket Reduce  a {b[c[d,e]]}        S @ */
/* # 12a    @ i(  155 > 153  Binary Reduce   {a@b[c[d,e]]}        S */
/* # 12b    S i(    5 < 153  Shift           {a@b[c[d,e]]}        S i( */
/* # 13    i( f      Leaf    Shift           {a@b[c[d,e]]} f      S i( */
/* # 14    i( i)   25 > 23   Bracket Reduce  {{a@b[c[d,e]]}(f)}   S */
/* # 15     S E     5 > 3    Final Reduce    {{a@b[c[d,e]]}(f)} */
/* # */
/* # OK, that should be enough examples to get the idea how this */
/* # all works. */
/* # */
/* # Just for laughs, the ANSI-C precedence table is listed below: */
/* # */
/* # ANSI-C precedence is: */
/* # */
/* # #  Class                     Assoc.  Operator */
/* # */
/* # 1  Select                     L->R   (...) [...] . -> */
/* # 2  Unary                      R->L   ! ~ ++ -- + - * & (type) sizeof */
/* # 3  Multiply, Divide, Modulus  L->R   * / % */
/* # 4  Add, Subtract              L->R   + - */
/* # 5  Shift Right, Left          L->R   >> << */
/* # 6  Greater, Less Than         L->R   > < <= >= */
/* # 7  Equal, Not Equal           L->R   == != */
/* # 8  Bitwise AND                L->R   & */
/* # 9  Bitwise XOR                L->R   ^ */
/* # 10 Bitwise OR                 L->R   | */
/* # 11 Logical AND                L->R   && */
/* # 12 Logical OR                 L->R   || */
/* # 13 Conditional Expression     R->L   ? : */
/* # 14 Assignment                 R->L   = += -= *= /= &= |= ^= <<= >>= */
/* # 15 Comma                      L->R   , */
Expression Expression__parse(
  Parser parser)
{
    Logical trace;
    Expression expression;
    Unsigned end_index;
    trace = Logical__false;
    expression = Expression__null;
    end_index = Expression__prescan(parser, trace);
    if ((end_index != 0)) {
        expression = Expression__shift_reduce(parser, end_index, trace);
        if ((expression != Expression__null)) {
            parser->index = (end_index+1);
        }
    }
    return expression;
}

Unsigned Expression__prescan(
  Parser parser,
  Logical trace)
{
    String temporary;
    Unsigned index;
    Array tokens;
    Array expressions;
    Array operators;
    Messages messages;
    Compiler compiler;
    Expression_State state;
    Logical error;
    Token token;
    Lexeme lexeme;
    Unsigned end_index;
    Unsigned size;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    temporary = parser->temporary;
    if (trace) {
        (void)String__put(((String)"\027=>prescan@Expression()\n"), Out_Stream__error);
    }
    index = parser->index;
    tokens = parser->tokens;
    expressions = parser->expressions;
    operators = parser->operators;
    messages = parser->messages;
    compiler = Compiler__one_and_only();
    (void)Array__trim(operators, 0);
    (void)Array__trim(expressions, 0);
    state = Expression_State__unary;
    error = Logical__false;
    while (!error) {
        token = ((Token)Array__fetch1(tokens, index));
        lexeme = token->lexeme;
        if (trace) {

            (void)String__put((t__4 = String__form(((String)"\033Prescan[%d%]: %qv% %l% %s%\n")), t__5 = Unsigned__f(index), t__6 = String__f(token->value), t__7 = Lexeme__f(lexeme), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), String__f(Expression_State__string_convert(state)))), Out_Stream__error);
        }
        index = (index+1);
        switch (state) {
            case Expression_State___unary:
                switch (lexeme) {
                    case Lexeme___open_parenthesis:
                    case Lexeme___open_invoke:
                        (void)Array__append(operators, ((void *)(token)));
                        /* # State in {unary} state: */
                        break;
                    case Lexeme___add:
                    case Lexeme___positive:
                    case Lexeme___minus:
                    case Lexeme___negative:
                    case Lexeme___concatenate:
                    case Lexeme___not:
                    case Lexeme___logical_not:
                        token->lexeme = Lexeme__unary_transmute(lexeme);
                        /* # Stay in {unary} state: */
                        break;
                    case Lexeme___character:
                    case Lexeme___float_number:
                    case Lexeme___number:
                    case Lexeme___string:
                    case Lexeme___symbol:

                        state = Expression_State__leaf;
                        break;
                    case Lexeme___close_parenthesis:
                    case Lexeme___close_invoke:
                        error = Expression__bracket_pop(parser, token, trace);
                        state = Expression_State__leaf;
                        break;
                    case Lexeme___end_of_line:
                        (void)Compiler__log(compiler, token, (t__8 = String__form(((String)"\035Missing expression after %qv%")), String__divide((t__8), String__f(((Token)Array__fetch1(tokens, (index-2)))->value))));
                        error = Logical__true;
                        if (trace) {
                            (void)String__put(((String)"\022unary:end_of_line\n"), Out_Stream__error);
                        }
                        break;
                    default:
                        (void)Compiler__log(compiler, token, (t__9 = String__form(((String)"\055Expression error at %qv% (lexeme=%l%) (unary)")), t__10 = String__f(token->value), String__divide(String__remainder((t__9), t__10), Lexeme__f(token->lexeme))));
                        error = Logical__true;
                        if (trace) {
                            (void)String__put(((String)"\016unary:default\n"), Out_Stream__error);
                        }
                        break;
                }
                break;
            case Expression_State___leaf:
                switch (lexeme) {
                    case Lexeme___close_parenthesis:
                    case Lexeme___close_invoke:
                    case Lexeme___close_bracket:
                    case Lexeme___close_type:
                        error = Expression__bracket_pop(parser, token, trace);
                        /* # Stay in {leaf} state: */
                        break;
                    case Lexeme___open_parenthesis:
                    case Lexeme___open_invoke:
                    case Lexeme___type_invoke:
                        token->lexeme = Lexeme__invoke_transmute(lexeme);
                        (void)Array__append(operators, ((void *)(token)));
                        state = Expression_State__unary;
                        break;
                    case Lexeme___open_bracket:
                    case Lexeme___open_type:
                        (void)Array__append(operators, ((void *)(token)));
                        state = Expression_State__unary;
                        break;
                    case Lexeme___at_sign:
                        state = Expression_State__at_sign;
                        break;
                    case Lexeme___add:
                    case Lexeme___minus:
                    case Lexeme___multiply:
                    case Lexeme___divide:
                    case Lexeme___remainder:
                    case Lexeme___and:
                    case Lexeme___xor:
                    case Lexeme___or:
                    case Lexeme___comma:
                    case Lexeme___greater_than:
                    case Lexeme___less_than:
                    case Lexeme___equals:
                    case Lexeme___conditional_and:
                    case Lexeme___conditional_or:
                    case Lexeme___less_than_or_equal:
                    case Lexeme___greater_than_or_equal:
                    case Lexeme___not_equal:
                    case Lexeme___identical:
                    case Lexeme___not_identical:
                    case Lexeme___assign:
                    case Lexeme___dot:
                    case Lexeme___left_shift:
                    case Lexeme___right_shift:
                    case Lexeme___define_assign:

                        state = Expression_State__binary;
                        break;
                    case Lexeme___end_of_line:

                        goto break__1;
                        break;
                    case Lexeme___symbol:

                        (void)Compiler__log(compiler, token, (t__11 = String__form(((String)"\046Expression error at %qv% (leaf symbol)")), String__divide((t__11), String__f(token->value))));
                        error = Logical__true;
                        if (trace) {
                            (void)String__put(((String)"\014leaf:symbol\n"), Out_Stream__error);
                        }
                        break;
                    default:
                        (void)Compiler__log(compiler, token, (t__12 = String__form(((String)"\045Expression error at %qv% (leaf other)")), String__divide((t__12), String__f(token->value))));
                        error = Logical__true;
                        if (trace) {
                            (void)String__put(((String)"\015leaf:default\n"), Out_Stream__error);
                        }
                        break;
                }
                break;
            case Expression_State___binary:
                switch (lexeme) {
                    case Lexeme___character:
                    case Lexeme___float_number:
                    case Lexeme___number:
                    case Lexeme___string:
                    case Lexeme___symbol:

                        state = Expression_State__leaf;
                        break;
                    case Lexeme___open_parenthesis:
                    case Lexeme___open_invoke:

                        (void)Array__append(operators, ((void *)(token)));
                        state = Expression_State__unary;
                        break;
                    case Lexeme___add:
                    case Lexeme___positive:
                    case Lexeme___minus:
                    case Lexeme___negative:
                    case Lexeme___concatenate:
                    case Lexeme___not:
                    case Lexeme___logical_not:
                        token->lexeme = Lexeme__unary_transmute(lexeme);
                        state = Expression_State__unary;
                        break;
                    case Lexeme___end_of_line:
                        (void)Messages__log(messages, token, (t__13 = String__form(((String)"\027Expression ends in %qv%")), String__divide((t__13), String__f(((Token)Array__fetch1(tokens, (index-2)))->value))));
                        error = Logical__true;
                        if (trace) {
                            (void)String__put(((String)"\023binary:end_of_line\n"), Out_Stream__error);
                        }
                        break;
                    default:
                        (void)Compiler__log(compiler, token, (t__14 = String__form(((String)"\041Expression error at %qv% (binary)")), String__divide((t__14), String__f(token->value))));
                        error = Logical__true;
                        if (trace) {
                            (void)String__put(((String)"\017binary:default\n"), Out_Stream__error);
                        }
                        break;
                }
                break;
            case Expression_State___at_sign:
                switch (lexeme) {
                    case Lexeme___symbol:
                        state = Expression_State__at_leaf;
                        break;
                    default:
                        (void)Messages__log(messages, token, (t__15 = String__form(((String)"\042Expression error at %qv% (at_sign)")), String__divide((t__15), String__f(token->value))));
                        error = Logical__true;
                        if (trace) {
                            (void)String__put(((String)"\020at_sign:default\n"), Out_Stream__error);
                        }
                        break;
                }
                break;
            case Expression_State___at_leaf:
                switch (lexeme) {
                    case Lexeme___close_parenthesis:
                    case Lexeme___close_invoke:
                    case Lexeme___close_bracket:
                    case Lexeme___close_type:
                        error = Expression__bracket_pop(parser, token, trace);
                        state = Expression_State__leaf;
                        break;
                    case Lexeme___open_parenthesis:
                    case Lexeme___open_invoke:
                    case Lexeme___type_invoke:
                        token->lexeme = Lexeme__invoke_transmute(lexeme);
                        (void)Array__append(operators, ((void *)(token)));
                        state = Expression_State__unary;
                        break;
                    case Lexeme___open_bracket:
                    case Lexeme___open_type:
                        token->lexeme = Lexeme__type_transmute(lexeme);
                        (void)Array__append(operators, ((void *)(token)));
                        state = Expression_State__unary;
                        break;
                    case Lexeme___add:
                    case Lexeme___and:
                    case Lexeme___assign:
                    case Lexeme___comma:
                    case Lexeme___conditional_and:
                    case Lexeme___conditional_or:
                    case Lexeme___define_assign:
                    case Lexeme___divide:
                    case Lexeme___dot:
                    case Lexeme___equals:
                    case Lexeme___greater_than:
                    case Lexeme___greater_than_or_equal:
                    case Lexeme___identical:
                    case Lexeme___left_shift:
                    case Lexeme___less_than:
                    case Lexeme___less_than_or_equal:
                    case Lexeme___minus:
                    case Lexeme___multiply:
                    case Lexeme___not_equal:
                    case Lexeme___not_identical:
                    case Lexeme___or:
                    case Lexeme___remainder:
                    case Lexeme___right_shift:
                    case Lexeme___xor:

                        state = Expression_State__binary;
                        break;
                    case Lexeme___end_of_line:

                        goto break__1;
                        break;
                    case Lexeme___symbol:

                        (void)Compiler__log(compiler, token, (t__16 = String__form(((String)"\051Expression error at %qv% (at_leaf symbol)")), String__divide((t__16), String__f(token->value))));
                        error = Logical__true;
                        if (trace) {
                            (void)String__put(((String)"\017at_leaf:symbol\n"), Out_Stream__error);
                        }
                        break;
                    default:
                        (void)Compiler__log(compiler, token, (t__17 = String__form(((String)"\050Expression error at %qv% (at leaf other)")), String__divide((t__17), String__f(token->value))));
                        error = Logical__true;
                        if (trace) {
                            (void)String__put(((String)"\020at_leaf:default\n"), Out_Stream__error);
                        }
                        break;
                }
                break;
        }
    }
    break__1:;
    end_index = (index-2);
    if (error) {
        end_index = 0;
    } else {
        size = Array__size_get(operators);
        if ((size != 0)) {
            (void)String__trim(temporary, 0);
            index = 0;
            while ((index < size)) {
                (void)String__string_append(temporary, ((String)"\001 "));
                (void)String__string_append(temporary, Lexeme__string_convert(((Token)Array__fetch1(operators, index))->lexeme));
                index = (index+1);
            }
            (void)Compiler__log(compiler, ((Token)Array__fetch1(tokens, parser->index)), (t__18 = String__form(((String)"\054Unmatched parentheses and/or brackets (%qv%)")), String__divide((t__18), String__f(temporary))));
            end_index = 0;
        }
    }
    if (trace) {
        (void)String__put((t__20 = String__form(((String)"\036<=prescan@Expression() => %d%\n")), String__divide((t__20), Unsigned__f(end_index))), Out_Stream__error);
    }
    return end_index;
}

Expression Expression__shift_reduce(
  Parser parser,
  Unsigned end_index,
  Logical trace)
{
    String temporary;
    Array operators;
    Array expressions;
    Messages messages;
    Array tokens;
    Unsigned index;
    Token token_end;
    Logical error;
    Unsigned current_index;
    Token current_token;
    Lexeme current;
    Expression expression;
    Token top_token;
    Lexeme top;
    Unsigned f_top;
    Unsigned g_current;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    temporary = parser->temporary;
    operators = parser->operators;
    expressions = parser->expressions;
    messages = parser->messages;
    tokens = parser->tokens;
    index = parser->index;
    trace = Logical__false;
    if (trace) {
        (void)String__put(((String)"\034=>shift_reduce@Expression()\n"), Out_Stream__error);
    }
    (void)Array__trim(operators, 0);
    (void)Array__trim(expressions, 0);
    (void)Array__append(operators, ((void *)(parser->token_start)));
    token_end = parser->token_end;
    end_index = (end_index+2);
    error = Logical__false;
    while (((index < end_index)&&!error)) {
        current_index = index;
        current_token = ((Token)Array__fetch1(tokens, index));
        index = (index+1);
        if ((index == end_index)) {

            current_token = token_end;
        }
        current = current_token->lexeme;
        if (trace) {
            (void)String__put((t__3 = String__form(((String)"\023S/R[%d%]: %qv% %l%\n")), t__4 = Unsigned__f(index), t__5 = String__f(current_token->value), String__divide(String__remainder(String__remainder((t__3), t__4), t__5), Lexeme__f(current))), Out_Stream__error);
        }
        /* # Dispatch on leaf or operator tokens: */
        switch (current) {
            case Lexeme___character:
                expression = Expression__new();
                expression->kind = Expression_Kind___character; expression->kind__union.character = current_token;
                (void)Array__append(expressions, ((void *)(expression)));
                break;
            case Lexeme___float_number:
                expression = Expression__new();
                expression->kind = Expression_Kind___float_number; expression->kind__union.float_number = current_token;
                (void)Array__append(expressions, ((void *)(expression)));
                break;
            case Lexeme___number:
                expression = Expression__new();
                expression->kind = Expression_Kind___number; expression->kind__union.number = current_token;
                (void)Array__append(expressions, ((void *)(expression)));
                break;
            case Lexeme___string:
                expression = Expression__new();
                expression->kind = Expression_Kind___string; expression->kind__union.string = current_token;
                (void)Array__append(expressions, ((void *)(expression)));
                break;
            case Lexeme___symbol:
                expression = Expression__new();
                expression->kind = Expression_Kind___symbol; expression->kind__union.symbol = current_token;
                (void)Array__append(expressions, ((void *)(expression)));
                break;
            default:


                /* # Perform as many reductions as possible */
                top_token = ((Token)Array__fetch1(operators, (Array__size_get(operators)-1)));
                top = top_token->lexeme;
                f_top = Lexeme__f_precedence(top);
                g_current = Lexeme__g_precedence(current);
                if (trace) {
                    (void)String__put((t__10 = String__form(((String)"\033f(%l%)=%d%  g(%l%)=%d%  => ")), t__11 = Lexeme__f(top), t__12 = Unsigned__f(f_top), t__13 = Lexeme__f(current), String__divide(String__remainder(String__remainder(String__remainder((t__10), t__11), t__12), t__13), Unsigned__f(g_current))), Out_Stream__error);
                }
                while ((!error&&(current_token != Token__null)&&(f_top > g_current))) {
                    if (trace) {
                        (void)String__put(((String)"\007Reduce "), Out_Stream__error);
                    }
                    /* # Perform reductions based on {top}: */
                    expression = Expression__null;
                    switch (top) {
                        case Lexeme___positive:
                        case Lexeme___negative:
                        case Lexeme___not:
                        case Lexeme___logical_not:

                            error = Expression__unary_reduce(parser);
                            if (trace) {
                                (void)String__put(((String)"\006Unary\n"), Out_Stream__error);
                            }
                            break;
                        case Lexeme___open_parenthesis:
                            error = Expression__group_reduce(parser, current_token, current_index);
                            /* # A group reduction consumes {current_token}: */
                            current_token = Token__null;
                            if (trace) {
                                (void)String__put(((String)"\006Group\n"), Out_Stream__error);
                            }
                            break;
                        case Lexeme___open_invoke:
                        case Lexeme___open_bracket:
                        case Lexeme___open_type:
                        case Lexeme___type_invoke:
                            error = Expression__bracket_reduce(parser, current_token, current_index);
                            /* # A bracket reduction consumes {current_token}: */
                            current_token = Token__null;
                            if (trace) {
                                (void)String__put(((String)"\010Bracket\n"), Out_Stream__error);
                            }
                            break;
                        case Lexeme___dot:
                        case Lexeme___at_sign:
                        case Lexeme___less_than:
                        case Lexeme___greater_than:
                        case Lexeme___equals:
                        case Lexeme___less_than_or_equal:
                        case Lexeme___greater_than_or_equal:
                        case Lexeme___identical:
                        case Lexeme___not_equal:
                        case Lexeme___not_identical:
                        case Lexeme___assign:
                        case Lexeme___define_assign:
                            error = Expression__binary_reduce(parser);
                            if (trace) {
                                (void)String__put(((String)"\007Binary\n"), Out_Stream__error);
                            }
                            break;
                        case Lexeme___multiply:
                        case Lexeme___divide:
                        case Lexeme___remainder:
                        case Lexeme___add:
                        case Lexeme___minus:
                        case Lexeme___and:
                        case Lexeme___xor:
                        case Lexeme___or:
                        case Lexeme___conditional_and:
                        case Lexeme___conditional_or:
                        case Lexeme___comma:
                        case Lexeme___left_shift:
                        case Lexeme___right_shift:
                            error = Expression__list_reduce(parser);
                            if (trace) {
                                (void)String__put(((String)"\005List\n"), Out_Stream__error);
                            }
                            break;
                        case Lexeme___start:

                            current_token = Token__null;
                            if (trace) {
                                (void)String__put(((String)"\006Final\n"), Out_Stream__error);
                            }
                            break;
                        default:
                            (void)String__put(Lexeme__string_convert(top), Out_Stream__error);
                            if (!(Logical__false)) {
                                System__assert_fail((String)"\tParse.ezc", 2154);
                            }
                            break;
                    }
                    if (trace) {
                        (void)Parser__stacks_show(parser, index);
                    }
                    /* # Compute {f_top} and {g_current} for next iteration: */
                    top_token = ((Token)Array__fetch1(operators, (Array__size_get(operators)-1)));
                    top = top_token->lexeme;
                    f_top = Lexeme__f_precedence(top);
                    g_current = Lexeme__g_precedence(current);
                    if (trace) {
                        (void)String__put((t__18 = String__form(((String)"\032f(%l%)=%d%  g(%l%)=%d% => ")), t__19 = Lexeme__f(top), t__20 = Unsigned__f(f_top), t__21 = Lexeme__f(current), String__divide(String__remainder(String__remainder(String__remainder((t__18), t__19), t__20), t__21), Unsigned__f(g_current))), Out_Stream__error);
                    }
                }
                /* # Perform final shift of {current_token}: */
                if ((current_token != Token__null)) {
                    (void)Array__append(operators, ((void *)(current_token)));
                    if (trace) {
                        (void)String__put(((String)"\006Shift\n"), Out_Stream__error);
                    }
                } else {
                    if (trace) {
                        (void)String__put(((String)"\011Absorbed\n"), Out_Stream__error);
                    }
                }
                if (trace) {
                    (void)Parser__stacks_show(parser, index);
                }
                break;
        }
    }
    expression = Expression__null;
    if (!error) {
        if (((Array__size_get(expressions) == 1)&&(index == end_index))) {

            expression = ((Expression)Array__fetch1(expressions, 0));
        } else {
            (void)Messages__log(messages, ((Token)Array__fetch1(tokens, parser->index)), ((String)"\032Unable to parse expression"));
        }
    }
    if (trace) {
        (void)String__put((t__23 = String__form(((String)"\041=>shift_reduce@Expression()=>%e%\n")), String__divide((t__23), Expression__f(expression))), Out_Stream__error);
    }
    return expression;
}

void Parser__stacks_show(
  Parser parser,
  Unsigned index)
{
    String temporary;
    Array expressions;
    Array operators;
    Array tokens;
    Token token;
    Unsigned size;
    Expression expression;
    Token operator;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    temporary = parser->temporary;
    expressions = parser->expressions;
    operators = parser->operators;
    tokens = parser->tokens;
    token = ((Token)Array__fetch1(tokens, index));
    size = Array__size_get(expressions);
    index = 0;
    while ((index < size)) {
        expression = ((Expression)Array__fetch1(expressions, index));
        (void)String__put((t__2 = String__form(((String)"\017 Exp[%d%]=(%e%)")), t__3 = Unsigned__f(index), String__divide(String__remainder((t__2), t__3), Expression__f(expression))), Out_Stream__error);
        index = (index+1);
    }
    (void)String__put(((String)"\001\n"), Out_Stream__error);
    size = Array__size_get(operators);
    index = 0;
    while ((index < size)) {
        operator = ((Token)Array__fetch1(operators, index));
        (void)String__put((t__6 = String__form(((String)"\015 Op[%d%]=%qv%")), t__7 = Unsigned__f(index), String__divide(String__remainder((t__6), t__7), String__f(operator->value))), Out_Stream__error);
        index = (index+1);
    }
    (void)String__put(((String)"\001\n"), Out_Stream__error);
}

Logical Expression__unary_reduce(
  Parser parser)
{
    Logical result;
    Array expressions;
    Array operators;
    Unary_Expression unary;
    Expression expression;
    Array tokens;
    result = Logical__false;
    expressions = parser->expressions;
    operators = parser->operators;
    if (((Array__size_get(expressions) >= 1)&&(Array__size_get(operators) >= 1))) {
        unary = Unary_Expression__new();
        unary->operator = ((Token)Array__pop(operators));
        unary->expression = ((Expression)Array__pop(expressions));
        expression = Expression__new();
        expression->kind = Expression_Kind___unary; expression->kind__union.unary = unary;
        (void)Array__append(expressions, ((void *)(expression)));
    } else {
        tokens = parser->tokens;
        (void)Messages__log(parser->messages, ((Token)Array__fetch1(tokens, parser->index)), ((String)"\054Unable to parse expression (in unary reduce)"));
        result = Logical__true;
    }
    return result;
}

Logical Expression__bracket_reduce(
  Parser parser,
  Token close_bracket,
  Unsigned close_index)
{
    Expression expression;
    Array tokens;
    Logical result;
    Array operators;
    Array expressions;
    Lexeme close_lexeme;
    Token open_bracket;
    Expression expression1;
    Expression expression2;
    List_Expression list;
    Bracket_Expression bracket;
    expression = Expression__null;
    tokens = parser->tokens;
    result = Logical__false;
    operators = parser->operators;
    expressions = parser->expressions;
    if ((Array__size_get(operators) >= 1)) {
        close_lexeme = close_bracket->lexeme;
        open_bracket = ((Token)Array__pop(operators));
        switch (open_bracket->lexeme) {
            case Lexeme___open_bracket:
                if (!((close_lexeme == Lexeme__close_bracket))) {
                    System__assert_fail((String)"\tParse.ezc", 2275);
                }
                break;
            case Lexeme___open_invoke:
            case Lexeme___type_invoke:
                if (!((close_lexeme == Lexeme__close_invoke))) {
                    System__assert_fail((String)"\tParse.ezc", 2277);
                }
                break;
            case Lexeme___open_type:
                if (!((close_lexeme == Lexeme__close_type))) {
                    System__assert_fail((String)"\tParse.ezc", 2279);
                }
                break;
            default:
                if (!(Logical__false)) {
                    System__assert_fail((String)"\tParse.ezc", 2281);
                }
                break;
        }
        expression1 = Expression__null;
        expression2 = Expression__null;
        if ((((Token)Array__fetch1(tokens, (close_index-1))) == open_bracket)) {

            if ((Array__size_get(expressions) >= 1)) {
                list = List_Expression__new();
                list->location = open_bracket;
                expression2 = Expression__new();
                expression2->kind = Expression_Kind___list; expression2->kind__union.list = list;
                expression1 = ((Expression)Array__pop(expressions));
            }
        } else {

            if ((Array__size_get(expressions) >= 2)) {
                expression2 = ((Expression)Array__pop(expressions));
                expression1 = ((Expression)Array__pop(expressions));
            }
        }
        if ((expression1 != Expression__null)) {
            bracket = Bracket_Expression__new();
            bracket->close_bracket = close_bracket;
            bracket->expression2 = expression2;
            bracket->open_bracket = open_bracket;
            bracket->expression1 = expression1;
            expression = Expression__new();
            expression->kind = Expression_Kind___bracket; expression->kind__union.bracket = bracket;
            (void)Array__append(expressions, ((void *)(expression)));
        }
    }
    if ((expression == Expression__null)) {
        (void)Messages__log(parser->messages, ((Token)Array__fetch1(tokens, parser->index)), ((String)"\056Unable to parse expression (in bracket reduce)"));
        result = Logical__true;
    }
    return result;
}

Logical Expression__group_reduce(
  Parser parser,
  Token close_parenthesis,
  Unsigned close_index)
{
    Array tokens;
    Logical result;
    Array operators;
    Expression expression;
    Array expressions;
    Lexeme close_lexeme;
    Token open_parenthesis;
    Parenthesis_Expression parenthesis;
    tokens = parser->tokens;
    result = Logical__false;
    operators = parser->operators;
    expression = Expression__null;
    expressions = parser->expressions;
    if (((Array__size_get(expressions) >= 1)&&(Array__size_get(operators) >= 2))) {
        close_lexeme = close_parenthesis->lexeme;
        open_parenthesis = ((Token)Array__pop(operators));
        switch (open_parenthesis->lexeme) {
            case Lexeme___open_parenthesis:
                if (!((close_lexeme == Lexeme__close_parenthesis))) {
                    System__assert_fail((String)"\tParse.ezc", 2334);
                }
                break;
            default:
                if (!(Logical__false)) {
                    System__assert_fail((String)"\tParse.ezc", 2336);
                }
                break;
        }
        if ((((Token)Array__fetch1(tokens, (close_index-1))) != open_parenthesis)) {
            parenthesis = Parenthesis_Expression__new();
            parenthesis->close_parenthesis = close_parenthesis;
            parenthesis->expression = ((Expression)Array__pop(expressions));
            parenthesis->open_parenthesis = open_parenthesis;
            expression = Expression__new();
            expression->kind = Expression_Kind___parenthesis; expression->kind__union.parenthesis = parenthesis;
            (void)Array__append(expressions, ((void *)(expression)));
        }
        /* #else group is empty and hence illegal => generate error: */
    }
    if ((expression == Expression__null)) {
        (void)Messages__log(parser->messages, ((Token)Array__fetch1(tokens, parser->index)), ((String)"\054Unable to parse expression (in group reduce)"));
        result = Logical__true;
    }
    return result;
}

Logical Expression__binary_reduce(
  Parser parser)
{
    Logical result;
    Array expressions;
    Array operators;
    Binary_Expression binary;
    Expression expression;
    Array tokens;
    result = Logical__false;
    expressions = parser->expressions;
    operators = parser->operators;
    binary = Binary_Expression__new();
    if (((Array__size_get(expressions) >= 2)&&(Array__size_get(operators) >= 1))) {
        binary->right = ((Expression)Array__pop(expressions));
        binary->operator = ((Token)Array__pop(operators));
        binary->left = ((Expression)Array__pop(expressions));
        expression = Expression__new();
        expression->kind = Expression_Kind___binary; expression->kind__union.binary = binary;
        (void)Array__append(expressions, ((void *)(expression)));
    } else {
        tokens = parser->tokens;
        (void)Messages__log(parser->messages, ((Token)Array__fetch1(tokens, parser->index)), ((String)"\056Unable to parse expression (in bracket reduce)"));
        result = Logical__true;
    }
    return result;
}

Logical Expression__list_reduce(
  Parser parser)
{
    Logical result;
    Array expressions;
    Unsigned expressions_size;
    Array operators;
    Unsigned operators_size;
    Expression expression;
    Unsigned first_operator_index;
    Token first_operator;
    Unsigned precedence;
    Unsigned index;
    Token operator;
    Unsigned operators_count;
    Unsigned first_expression_index;
    List_Expression list;
    Array list_operators;
    Array list_expressions;
    Array tokens;
    result = Logical__false;
    expressions = parser->expressions;
    expressions_size = Array__size_get(expressions);
    operators = parser->operators;
    operators_size = Array__size_get(operators);
    expression = Expression__null;
    if (((expressions_size >= 2)&&(operators_size >= 1))) {

        /* # in {operators} that has the same precedence as the last operator */
        /* # in an unbroken sequence: */
        first_operator_index = (operators_size-1);
        first_operator = ((Token)Array__fetch1(operators, first_operator_index));
        precedence = Lexeme__f_precedence(first_operator->lexeme);
        index = first_operator_index;
        while ((index != 0)) {
            index = (index-1);
            operator = ((Token)Array__fetch1(operators, index));
            if ((Lexeme__f_precedence(operator->lexeme) != precedence)) {
                break;
            }
            first_operator = operator;
            first_operator_index = index;
        }
        operators_count = (operators_size-first_operator_index);
        if ((expressions_size >= (operators_count+1))) {

            first_expression_index = (expressions_size-operators_count-1);
            list = List_Expression__new();
            list_operators = list->operators;
            list_expressions = list->expressions;
            /* # Load up {list_operators}: */
            (void)Array__append(list_operators, ((void *)(first_operator)));
            index = first_operator_index;
            while ((index < operators_size)) {
                (void)Array__append(list_operators, ((void *)(((Token)Array__fetch1(operators, index)))));
                index = (index+1);
            }
            (void)Array__trim(operators, first_operator_index);
            /* # Load up {list_expressions}: */
            index = first_expression_index;
            while ((index < expressions_size)) {
                (void)Array__append(list_expressions, ((void *)(((Expression)Array__fetch1(expressions, index)))));
                index = (index+1);
            }
            (void)Array__trim(expressions, first_expression_index);
            /* # Make sure we got it right: */
            if (!((Array__size_get(list_operators) == Array__size_get(list_expressions)))) {
                System__assert_fail((String)"\tParse.ezc", 2431);
            }
            /* # Construct the final {Expression} and push it back: */
            list->location = Expression__location_get(((Expression)Array__fetch1(list_expressions, 0)));
            expression = Expression__new();
            expression->kind = Expression_Kind___list; expression->kind__union.list = list;
            (void)Array__append(expressions, ((void *)(expression)));
        }
    }
    if ((expression == Expression__null)) {
        tokens = parser->tokens;
        (void)Messages__log(parser->messages, ((Token)Array__fetch1(tokens, parser->index)), ((String)"\050Unable to parse expression (list reduce)"));
    }
    return result;
}

Logical Expression__bracket_pop(
  Parser parser,
  Token token,
  Logical trace)
{
    Logical error;
    String temporary;
    Array operators;
    Compiler compiler;
    Unsigned size;
    Lexeme lexeme;
    Token top_token;
    Lexeme top_lexeme;
    String t__0;
    String t__1;
    String t__2;
    error = Logical__true;
    temporary = parser->temporary;
    operators = parser->operators;
    compiler = Compiler__one_and_only();
    size = Array__size_get(operators);
    if ((size == 0)) {
        (void)Messages__log(parser->messages, token, (t__0 = String__form(((String)"\040Extra unmatched %qv% encountered")), String__divide((t__0), String__f(token->value))));
        if (trace) {
            (void)String__put(((String)"\031Mismatched close bracket\n"), Out_Stream__error);
        }
    } else {
        lexeme = token->lexeme;
        top_token = ((Token)Array__pop(operators));
        top_lexeme = top_token->lexeme;
        switch (top_lexeme) {
            case Lexeme___open_parenthesis:
                switch (lexeme) {
                    case Lexeme___close_parenthesis:
                        error = Logical__false;
                        break;
                }
                break;
            case Lexeme___open_invoke:
            case Lexeme___type_invoke:
                switch (lexeme) {
                    case Lexeme___close_parenthesis:
                    case Lexeme___close_invoke:
                        token->lexeme = Lexeme__close_invoke;
                        error = Logical__false;
                        break;
                }
                break;
            case Lexeme___open_bracket:
                switch (lexeme) {
                    case Lexeme___close_bracket:
                        error = Logical__false;
                        break;
                }
                break;
            case Lexeme___open_type:
                switch (lexeme) {
                    case Lexeme___close_bracket:
                    case Lexeme___close_type:
                        token->lexeme = Lexeme__close_type;
                        error = Logical__false;
                        break;
                }
                break;
        }
        if (error) {
            (void)Compiler__log(compiler, token, (t__1 = String__form(((String)"\030%qv% does not match %qv%")), t__2 = String__f(top_token->value), String__divide(String__remainder((t__1), t__2), String__f(token->value))));
            if (trace) {
                (void)String__put(((String)"\027Paren/Bracket Mismatch\n"), Out_Stream__error);
            }
        }
    }
    return error;
}

/* # {Keyword} stuff: */
Keyword Keyword__parse(
  Parser parser,
  String match)
{
    Unsigned index;
    Token token;
    Keyword keyword;
    index = parser->index;
    token = Token__parse(parser, Lexeme__symbol);
    if (((token == Token__null)||!String__equal(token->value, match))) {
        parser->index = index;
        return Keyword__null;
    }
    keyword = Keyword__new();
    keyword->keyword = token;
    return keyword;
}

/* # {Lexeme} stuff: */
Unsigned Lexeme__f_precedence(
  Lexeme lexeme)
{
    Unsigned result;
    result = 0;
    switch (lexeme) {
        case Lexeme___open_type:
            result = 15;
            break;
        case Lexeme___close_type:
            result = 175;
            break;
        case Lexeme___open_bracket:
        case Lexeme___open_parenthesis:
        case Lexeme___open_invoke:
        case Lexeme___type_invoke:
        case Lexeme___open_brace:
            result = 25;
            break;
        case Lexeme___close_bracket:
        case Lexeme___close_parenthesis:
        case Lexeme___close_invoke:
        case Lexeme___close_brace:
            result = 165;
            break;
        case Lexeme___at_sign:
        case Lexeme___dot:
            result = 165;
            break;
        case Lexeme___logical_not:
        case Lexeme___negative:
        case Lexeme___not:
        case Lexeme___positive:
            result = 155;
            break;
        case Lexeme___concatenate:
            result = 145;
            break;
        case Lexeme___divide:
        case Lexeme___multiply:
        case Lexeme___remainder:
            result = 135;
            break;
        case Lexeme___add:
        case Lexeme___minus:
            result = 125;
            break;
        case Lexeme___left_shift:
        case Lexeme___right_shift:
            result = 115;
            break;
        case Lexeme___and:
            result = 105;
            break;
        case Lexeme___xor:
            result = 95;
            break;
        case Lexeme___or:
            result = 85;
            break;
        case Lexeme___equals:
        case Lexeme___identical:
        case Lexeme___less_than:
        case Lexeme___less_than_or_equal:
        case Lexeme___greater_than:
        case Lexeme___greater_than_or_equal:
        case Lexeme___not_equal:
        case Lexeme___not_identical:
            result = 75;
            break;
        case Lexeme___conditional_and:
            result = 65;
            break;
        case Lexeme___conditional_or:
            result = 55;
            break;
        case Lexeme___comma:
            result = 45;
            break;
        case Lexeme___assign:
        case Lexeme___define_assign:
        case Lexeme___semicolon:
            result = 35;
            break;
        case Lexeme___start:
            result = 5;
            break;
        case Lexeme___end:
            if (!(Logical__false)) {
                System__assert_fail((String)"\tParse.ezc", 2567);
            }
            break;
        case Lexeme___close_indent:
        case Lexeme___colon:
        case Lexeme___comment:
        case Lexeme___end_of_file:
        case Lexeme___error:
        case Lexeme___end_of_line:
        case Lexeme___open_indent:
        case Lexeme___question_mark:
        case Lexeme___set:

            if (!(Logical__false)) {
                System__assert_fail((String)"\tParse.ezc", 2571);
            }
            break;
        case Lexeme___character:
        case Lexeme___float_number:
        case Lexeme___number:
        case Lexeme___string:
        case Lexeme___symbol:

            if (!(Logical__false)) {
                System__assert_fail((String)"\tParse.ezc", 2574);
            }
            break;
    }
    return result;
}

Unsigned Lexeme__g_precedence(
  Lexeme lexeme)
{
    Unsigned result;
    String temporary;
    String t__0;
    String t__1;
    result = 0;
    switch (lexeme) {
        case Lexeme___open_type:
            result = 173;
            break;
        case Lexeme___close_type:
            result = 13;
            break;
        case Lexeme___open_bracket:
        case Lexeme___open_parenthesis:
        case Lexeme___open_invoke:
        case Lexeme___type_invoke:
        case Lexeme___open_brace:
            result = 163;
            break;
        case Lexeme___close_bracket:
        case Lexeme___close_parenthesis:
        case Lexeme___close_invoke:
        case Lexeme___close_brace:
            result = 23;
            break;
        case Lexeme___at_sign:
        case Lexeme___dot:
            result = 163;
            break;
        case Lexeme___logical_not:
        case Lexeme___negative:
        case Lexeme___not:
        case Lexeme___positive:
            result = 158;
            break;
        case Lexeme___concatenate:
            result = 148;
            break;
        case Lexeme___divide:
        case Lexeme___multiply:
        case Lexeme___remainder:
            result = 138;
            break;
        case Lexeme___add:
        case Lexeme___minus:
            result = 128;
            break;
        case Lexeme___left_shift:
        case Lexeme___right_shift:
            result = 118;
            break;
        case Lexeme___and:
            result = 108;
            break;
        case Lexeme___xor:
            result = 98;
            break;
        case Lexeme___or:
            result = 88;
            break;
        case Lexeme___equals:
        case Lexeme___identical:
        case Lexeme___less_than:
        case Lexeme___less_than_or_equal:
        case Lexeme___greater_than:
        case Lexeme___greater_than_or_equal:
        case Lexeme___not_equal:
        case Lexeme___not_identical:
            result = 73;
            break;
        case Lexeme___conditional_and:
            result = 68;
            break;
        case Lexeme___conditional_or:
            result = 58;
            break;
        case Lexeme___comma:
            result = 48;
            break;
        case Lexeme___assign:
        case Lexeme___define_assign:
        case Lexeme___semicolon:
            result = 38;
            break;
        case Lexeme___start:
            if (!(Logical__false)) {
                System__assert_fail((String)"\tParse.ezc", 2624);
            }
            break;
        case Lexeme___end:
            result = 3;
            break;
        case Lexeme___close_indent:
        case Lexeme___colon:
        case Lexeme___comment:
        case Lexeme___end_of_file:
        case Lexeme___error:
        case Lexeme___end_of_line:
        case Lexeme___open_indent:
        case Lexeme___question_mark:
        case Lexeme___set:

            temporary = String__new();
            (void)String__put((t__1 = String__form(((String)"\035Unexpected lexeme for g(%l%)\n")), String__divide((t__1), Lexeme__f(lexeme))), Out_Stream__error);
            if (!(Logical__false)) {
                System__assert_fail((String)"\tParse.ezc", 2633);
            }
            break;
        case Lexeme___character:
        case Lexeme___float_number:
        case Lexeme___number:
        case Lexeme___string:
        case Lexeme___symbol:

            if (!(Logical__false)) {
                System__assert_fail((String)"\tParse.ezc", 2636);
            }
            break;
    }
    return result;
}

Lexeme Lexeme__invoke_transmute(
  Lexeme lexeme)
{
    switch (lexeme) {
        case Lexeme___type_invoke:
            lexeme = Lexeme__type_invoke;
            break;
        case Lexeme___open_parenthesis:
            lexeme = Lexeme__open_invoke;
            break;
        case Lexeme___close_parenthesis:
            lexeme = Lexeme__close_invoke;
            break;
    }
    return lexeme;
}

Lexeme Lexeme__type_transmute(
  Lexeme lexeme)
{
    switch (lexeme) {
        case Lexeme___open_bracket:
            lexeme = Lexeme__open_type;
            break;
        case Lexeme___close_bracket:
            lexeme = Lexeme__close_type;
            break;
    }
    return lexeme;
}

Lexeme Lexeme__unary_transmute(
  Lexeme lexeme)
{
    switch (lexeme) {
        case Lexeme___add:
            lexeme = Lexeme__positive;
            break;
        case Lexeme___minus:
            lexeme = Lexeme__negative;
            break;
        case Lexeme___concatenate:
            lexeme = Lexeme__not;
            break;
    }
    return lexeme;
}

/* # {List_Expression} stuff: */
void List_Expression__traverse(
  List_Expression list,
  Traverser traverser)
{
    Array expressions;
    Array operators;
    Unsigned expressions_size;
    Unsigned index;
    expressions = list->expressions;
    operators = list->operators;
    expressions_size = Array__size_get(expressions);
    index = 0;
    while ((index < expressions_size)) {
        if ((index != 0)) {
            (void)Token__traverse(((Token)Array__fetch1(operators, index)), traverser);
        }
        (void)Expression__traverse(((Expression)Array__fetch1(expressions, index)), traverser);
        index = (index+1);
    }
}

/* # {If_Statement} stuff: */
If_Statement If_Statement__parse(
  Parser parser)
{
    Array tokens;
    If_Statement if_statement;
    Array if_clauses;
    Logical have_if;
    Logical have_else;
    Unsigned index;
    Token token;
    String value;
    If_Part if_part;
    If_Clause if_clause;
    Else_If_Part else_if_part;
    Else_Part else_part;
    tokens = parser->tokens;
    if_statement = If_Statement__new();
    if_clauses = if_statement->if_clauses;
    have_if = Logical__false;
    have_else = Logical__false;
    while (Logical__true) {
        index = parser->index;
        token = ((Token)Array__fetch1(tokens, index));
        if ((token->lexeme != Lexeme__symbol)) {
            break;
        }
        value = token->value;
        if (String__equal(value, ((String)"\002if"))) {
            if (have_if) {

                break;
            }
            /* # First if: */
            if_part = If_Part__parse(parser);
            if ((if_part == If_Part__null)) {
                (void)Messages__log(parser->messages, token, ((String)"\034Unable to parse if statement"));
                break;
            }
            if_clause = If_Clause__new();
            if_clause->kind = If_Clause_Kind___if_part; if_clause->kind__union.if_part = if_part;
            (void)Array__append(if_clauses, ((void *)(if_clause)));
            have_if = Logical__true;
        } else if (String__equal(value, ((String)"\007else_if"))) {
            if (!have_if) {
                (void)Messages__log(parser->messages, token, ((String)"\046Lone 'else_if' with no preceeding 'if'"));
                break;
            }
            if (have_else) {
                (void)Messages__log(parser->messages, token, ((String)"\050'else_if' follows 'else' in if statement"));
            }
            else_if_part = Else_If_Part__parse(parser);
            if ((else_if_part == Else_If_Part__null)) {
                (void)Messages__log(parser->messages, token, ((String)"\031Unable to parse 'else_if'"));
                break;
            }
            if_clause = If_Clause__new();
            if_clause->kind = If_Clause_Kind___else_if_part; if_clause->kind__union.else_if_part = else_if_part;
            (void)Array__append(if_clauses, ((void *)(if_clause)));
        } else if (String__equal(value, ((String)"\004else"))) {
            if (!have_if) {
                (void)Messages__log(parser->messages, token, ((String)"\043Lone 'else' with no preceeding 'if'"));
                break;
            }
            if (have_else) {
                (void)Messages__log(parser->messages, token, ((String)"\044More that one 'else' in if statement"));
                break;
            } else {
                else_part = Else_Part__parse(parser);
                if ((else_part == Else_Part__null)) {
                    (void)Messages__log(parser->messages, token, ((String)"\035Unable to parse 'else' clause"));
                    break;
                }
                if_clause = If_Clause__new();
                if_clause->kind = If_Clause_Kind___else_part; if_clause->kind__union.else_part = else_part;
                (void)Array__append(if_clauses, ((void *)(if_clause)));
                have_else = Logical__true;
            }
        } else {
            break;
        }
    }
    if (!have_if) {
        if_statement = If_Statement__null;
    }
    return if_statement;
}

/* # {Parameterized_Type} stuff: */
Parameterized_Type Parameterized_Type__copy(
  Parameterized_Type parameterized)
{
    Parameterized_Type result;
    result = Parameterized_Type__new();
    (void)Parameterized_Type__copy_to(result, parameterized);
    return result;
}

void Parameterized_Type__copy_to(
  Parameterized_Type to,
  Parameterized_Type from)
{
    to->name = from->name;
    to->open_bracket = from->open_bracket;
    (void)Comma_Separated__copy_to(to->sub_types, from->sub_types, ((void * (*)(void *))(Type__copy)));
    to->close_bracket = from->close_bracket;
}

/* # {Parser} stuff: */
Parser Parser__create(
  Array tokens,
  Messages messages)
{
    Parser parser;
    parser = Parser__new();
    parser->c_typedefs = Hash_Table__create(((void *)(String__null)), ((Unsigned (*)(void *))(String__hash)), ((Logical (*)(void *, void *))(String__equal)), ((void (*)(void *, String))(String__buffer_append)), ((void (*)(void *, String))(String__buffer_append)));
    parser->expressions = Array__new();
    parser->index = 0;
    parser->messages = messages;
    parser->operators = Array__new();
    parser->temporary = String__new();
    parser->tokens = tokens;
    parser->token_end = Token__create(File__null, 0, Lexeme__end, ((String)"\000"));
    parser->token_start = Token__create(File__null, 0, Lexeme__start, ((String)"\000"));
    return parser;
}

Root Parser__parse(
  Parser parser,
  Array tokens)
{
    Root root;
    if (!((Array__size_get(tokens) != 0))) {
        System__assert_fail((String)"\tParse.ezc", 2837);
    }
    parser->tokens = tokens;
    parser->index = 0;
    root = Root__parse(parser);
    return root;
}

void Parser__parse_append(
  Parser parser,
  Root root,
  Array tokens)
{
    Root root_append;
    root_append = Parser__parse(parser, tokens);
    (void)Array__array_append(root->declarations, root_append->declarations);
}

Root Parser__two_parse(
  Parser parser,
  Array ezc_tokens,
  Array ezg_tokens)
{
    Root root;
    Array tokens;
    if (!((Array__size_get(ezc_tokens) != 0))) {
        System__assert_fail((String)"\tParse.ezc", 2866);
    }
    if (!((Array__size_get(ezg_tokens) != 0))) {
        System__assert_fail((String)"\tParse.ezc", 2867);
    }
    root = Root__null;
    if ((Array__size_get(ezg_tokens) <= 1)) {

        root = Parser__parse(parser, ezc_tokens);
    } else {

        tokens = Array__new();
        (void)Array__array_append(tokens, ezc_tokens);
        (void)Array__trim(tokens, (Array__size_get(tokens)-1));
        (void)Array__array_append(tokens, ezg_tokens);
        root = Parser__parse(parser, tokens);
        (void)Array__trim(tokens, 0);
    }
    return root;
}

/* # {Routine_Clause} stuff: */
Token Routine_Clause__location_get(
  Routine_Clause routine_clause)
{
    Token location;
    Error error;
    Array tokens;
    Array if_clauses;
    If_Clause if_clause;
    Return_Statement return___k;
    location = Token__null;
    switch (routine_clause->kind) {
        case Routine_Clause_Kind___assert:
            location = ((routine_clause->kind == Routine_Clause_Kind___assert) ? routine_clause->kind__union.assert : (Assert_Statement)System__variant_object_fail((String)"\tParse.ezc", 2896))->assert->keyword;
            break;
        case Routine_Clause_Kind___call:
            location = ((routine_clause->kind == Routine_Clause_Kind___call) ? routine_clause->kind__union.call : (Call_Statement)System__variant_object_fail((String)"\tParse.ezc", 2898))->call->keyword;
            break;
        case Routine_Clause_Kind___do_nothing:
            location = ((routine_clause->kind == Routine_Clause_Kind___do_nothing) ? routine_clause->kind__union.do_nothing : (Do_Nothing_Statement)System__variant_object_fail((String)"\tParse.ezc", 2900))->do_nothing->keyword;
            break;
        case Routine_Clause_Kind___end_of_line:
            location = ((routine_clause->kind == Routine_Clause_Kind___end_of_line) ? routine_clause->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\tParse.ezc", 2902));
            break;
        case Routine_Clause_Kind___error:
            error = ((routine_clause->kind == Routine_Clause_Kind___error) ? routine_clause->kind__union.error : (Error)System__variant_object_fail((String)"\tParse.ezc", 2904));
            tokens = error->tokens;
            if ((Array__size_get(tokens) != 0)) {
                location = ((Token)Array__fetch1(tokens, 0));
            }
            break;
        case Routine_Clause_Kind___if:
            if_clauses = ((routine_clause->kind == Routine_Clause_Kind___if) ? routine_clause->kind__union.if___k : (If_Statement)System__variant_object_fail((String)"\tParse.ezc", 2909))->if_clauses;
            if ((Array__size_get(if_clauses) != 0)) {
                if_clause = ((If_Clause)Array__fetch1(if_clauses, 0));
                switch (if_clause->kind) {
                    case If_Clause_Kind___if_part:
                        location = ((if_clause->kind == If_Clause_Kind___if_part) ? if_clause->kind__union.if_part : (If_Part)System__variant_object_fail((String)"\tParse.ezc", 2915))->if___k->keyword;
                        break;
                    case If_Clause_Kind___else_if_part:
                        location = ((if_clause->kind == If_Clause_Kind___else_if_part) ? if_clause->kind__union.else_if_part : (Else_If_Part)System__variant_object_fail((String)"\tParse.ezc", 2917))->else_if->keyword;
                        break;
                    case If_Clause_Kind___else_part:
                        location = ((if_clause->kind == If_Clause_Kind___else_part) ? if_clause->kind__union.else_part : (Else_Part)System__variant_object_fail((String)"\tParse.ezc", 2919))->else___k->keyword;
                        break;
                }
            }
            break;
        case Routine_Clause_Kind___note:
            location = ((routine_clause->kind == Routine_Clause_Kind___note) ? routine_clause->kind__union.note : (Note)System__variant_object_fail((String)"\tParse.ezc", 2921))->comment;
            break;
        case Routine_Clause_Kind___return:
            return___k = ((routine_clause->kind == Routine_Clause_Kind___return) ? routine_clause->kind__union.return___k : (Return_Statement)System__variant_object_fail((String)"\tParse.ezc", 2923));
            switch (return___k->kind) {
                case Return_Clause_Kind___expression:
                    location = ((return___k->kind == Return_Clause_Kind___expression) ? return___k->kind__union.expression : (Return_Clause_Expression)System__variant_object_fail((String)"\tParse.ezc", 2926))->return___k->keyword;
                    break;
                case Return_Clause_Kind___empty:
                    location = ((return___k->kind == Return_Clause_Kind___empty) ? return___k->kind__union.empty : (Return_Clause_Empty)System__variant_object_fail((String)"\tParse.ezc", 2928))->return___k->keyword;
                    break;
            }
            break;
        case Routine_Clause_Kind___set:
            location = ((routine_clause->kind == Routine_Clause_Kind___set) ? routine_clause->kind__union.set : (Set_Statement)System__variant_object_fail((String)"\tParse.ezc", 2930))->set;
            break;
        case Routine_Clause_Kind___switch:
            location = ((routine_clause->kind == Routine_Clause_Kind___switch) ? routine_clause->kind__union.switch___k : (Switch_Statement)System__variant_object_fail((String)"\tParse.ezc", 2932))->switch___k->keyword;
            break;
        case Routine_Clause_Kind___while:
            location = ((routine_clause->kind == Routine_Clause_Kind___while) ? routine_clause->kind__union.while___k : (While_Statement)System__variant_object_fail((String)"\tParse.ezc", 2934))->while___k->keyword;
            break;
    }
    return location;
}

/* # {Routine_Type} stuff: */
Routine_Type Routine_Type__copy(
  Routine_Type routine)
{
    Routine_Type result;
    result = Routine_Type__new();
    (void)Routine_Type__copy_to(result, routine);
    return result;
}

void Routine_Type__copy_to(
  Routine_Type to_routine,
  Routine_Type from_routine)
{
    to_routine->open_bracket = from_routine->open_bracket;
    (void)Comma_Separated__copy_to(to_routine->return_types, from_routine->return_types, ((void * (*)(void *))(Type__copy)));
    to_routine->less_than_or_equal = from_routine->less_than_or_equal;
    (void)Comma_Separated__copy_to(to_routine->takes_types, from_routine->takes_types, ((void * (*)(void *))(Type__copy)));
    to_routine->close_bracket = from_routine->close_bracket;
}

String Routine_Type__f(
  Routine_Type routine_type)
{
    String value;
    String t__0;
    String t__1;
    value = Format__field_next();
    (void)String__character_append(value, ((Character)'['));
    (void)String__string_append(value, (t__0 = String__form(((String)"\003%t%")), String__divide((t__0), Comma_Separated__f(routine_type->return_types, ((String (*)(void *))(Type__f))))));
    (void)String__string_append(value, ((String)"\004 <= "));
    (void)String__string_append(value, (t__1 = String__form(((String)"\003%t%")), String__divide((t__1), Comma_Separated__f(routine_type->takes_types, ((String (*)(void *))(Type__f))))));
    (void)String__character_append(value, ((Character)']'));
    return value;
}

void Routine_Type__format(
  Routine_Type routine_type,
  String buffer)
{
    Unsigned anchor;
    anchor = String__format_begin(buffer);
    (void)String__string_gap_insert(buffer, ((String)"\001["));
    (void)Comma_Separated__string_gap_insert(routine_type->return_types, buffer, ((void (*)(void *, String))(Type__string_gap_insert)));
    (void)String__string_gap_insert(buffer, ((String)"\004 <= "));
    (void)Comma_Separated__string_gap_insert(routine_type->takes_types, buffer, ((void (*)(void *, String))(Type__string_gap_insert)));
    (void)String__string_gap_insert(buffer, ((String)"\001]"));
    (void)String__format_end(buffer, anchor);
}

Routine_Type Routine_Type__parse(
  Parser parser)
{
    Unsigned index;
    Token open_bracket;
    Comma_Separated return_types;
    Token less_than_or_equal;
    Comma_Separated takes_types;
    Token close_bracket;
    Routine_Type routine_type;
    index = parser->index;
    open_bracket = Token__parse(parser, Lexeme__open_bracket);
    if ((open_bracket == Token__null)) {
        parser->index = index;
        return Routine_Type__null;
    }
    return_types = Comma_Separated__new();
    less_than_or_equal = Token__parse(parser, Lexeme__less_than_or_equal);
    if ((less_than_or_equal == Token__null)) {

        return_types = Comma_Separated__parse(parser, ((void * (*)(Parser))(Type__parse)), ((void *)(Type__null)), Lexeme__less_than_or_equal);
        if ((Comma_Separated__size_get(return_types) == 0)) {
            parser->index = index;
            return Routine_Type__null;
        }
        /* # Now get the following less than or equal: */
        less_than_or_equal = Token__parse(parser, Lexeme__less_than_or_equal);
        if ((less_than_or_equal == Token__null)) {
            parser->index = index;
            return Routine_Type__null;
        }
    }
    takes_types = Comma_Separated__new();
    close_bracket = Token__parse(parser, Lexeme__close_bracket);
    if ((close_bracket == Token__null)) {

        takes_types = Comma_Separated__parse(parser, ((void * (*)(Parser))(Type__parse)), ((void *)(Type__null)), Lexeme__close_bracket);
        if ((Comma_Separated__size_get(takes_types) == 0)) {
            parser->index = index;
            return Routine_Type__null;
        }
        close_bracket = Token__parse(parser, Lexeme__close_bracket);
        if ((close_bracket == Token__null)) {
            parser->index = index;
            return Routine_Type__null;
        }
    }
    routine_type = Routine_Type__new();
    routine_type->open_bracket = open_bracket;
    routine_type->return_types = return_types;
    routine_type->less_than_or_equal = less_than_or_equal;
    routine_type->takes_types = takes_types;
    routine_type->close_bracket = close_bracket;
    return routine_type;
}

/* # {Token} stuff: */
Token Token__parse(
  Parser parser,
  Lexeme lexeme)
{
    Unsigned index;
    Token token;
    index = parser->index;
    token = ((Token)Array__fetch1(parser->tokens, index));
    if ((token->lexeme == lexeme)) {
        parser->index = (index+1);
        return token;
    }
    return Token__null;
}

void Token__traverse(
  Token token,
  Traverser traverser)
{
    String buffer;
    buffer = traverser->buffer;
    if ((buffer != String__null)) {
        (void)String__string_gap_insert(buffer, token->white_space);
        (void)String__string_gap_insert(buffer, token->value);
    }
    (void)Array__append(traverser->tokens, ((void *)(token)));
}

/* # {Traverser} stuff: */
Traverser Traverser__create(
  String buffer,
  Array tokens)
{
    Traverser traverser;
    traverser = Traverser__new();
    traverser->buffer = buffer;
    traverser->tokens = tokens;
    return traverser;
}

/* # {Type} stuff: */
String Type__base_name(
  Type type)
{
    String result;
    result = ((String)"\004NONE");
    switch (type->kind) {
        case Type_Kind___simple:
            result = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3115))->value;
            break;
        case Type_Kind___parameterized:
            result = ((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3117))->name->value;
            break;
        case Type_Kind___routine:
            result = ((String)"\004NONE");
            break;
    }
    return result;
}

String Type__c_base_name(
  Type type)
{
    String result;
    Compiler compiler;
    Type underlying_type;
    if (!((type != Type__null))) {
        System__assert_fail((String)"\tParse.ezc", 3130);
    }
    result = ((String)"\004NONE");
    switch (type->kind) {
        case Type_Kind___simple:
            result = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3134))->value;
            compiler = Compiler__one_and_only();
            underlying_type = Compiler__simple_type_lookup(compiler, result);
            if ((underlying_type != Type__null)) {
                result = Type__c_base_name(underlying_type);
            }
            break;
        case Type_Kind___parameterized:
            result = ((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3140))->name->value;
            break;
        case Type_Kind___routine:
            result = ((String)"\004NONE");
            break;
    }
    return result;
}

void Type__buffer_append(
  Type type,
  String buffer)
{
    String t__0;
    (void)String__string_append(buffer, (t__0 = String__form(((String)"\003%t%")), String__divide((t__0), Type__f(type))));
}

String Type__replaced_c_type(
  Type type,
  String argument_name)
{
    String buffer;
    Routine_Type routine_type;
    Comma_Separated return_types;
    Comma_Separated takes_types;
    Unsigned size;
    Type return_type;
    String c_type;
    String prefix;
    Unsigned index;
    Type argument_type;
    buffer = String__new();
    if ((type == Type__null)) {
        (void)String__buffer_append(((String)"\004void"), buffer);
        if ((argument_name != String__null)) {
            (void)String__buffer_append(((String)"\001 "), buffer);
            (void)String__buffer_append(argument_name, buffer);
        }
    } else {
        switch (type->kind) {
            case Type_Kind___simple:
                if (type->replaced) {
                    (void)String__buffer_append(((String)"\006void *"), buffer);
                } else {
                    (void)String__buffer_append(((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3176))->value, buffer);
                }
                if ((argument_name != String__null)) {
                    (void)String__buffer_append(argument_name, buffer);
                    (void)String__buffer_append(((String)"\001 "), buffer);
                    if (String__is_c_keyword(argument_name)) {
                        (void)String__buffer_append(buffer, ((String)"\004___k"));
                    }
                }
                break;
            case Type_Kind___parameterized:
                (void)String__buffer_append(((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3184))->name->value, buffer);
                if ((argument_name != String__null)) {
                    (void)String__buffer_append(argument_name, buffer);
                    (void)String__buffer_append(((String)"\001 "), buffer);
                    if (String__is_c_keyword(argument_name)) {
                        (void)String__buffer_append(buffer, ((String)"\004___k"));
                    }
                }
                break;
            case Type_Kind___routine:
                routine_type = ((type->kind == Type_Kind___routine) ? type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3192));
                return_types = routine_type->return_types;
                takes_types = routine_type->takes_types;
                size = Comma_Separated__size_get(return_types);
                if ((size == 0)) {
                    (void)String__buffer_append(((String)"\004void"), buffer);
                } else if ((size == 1)) {
                    return_type = ((Type)Comma_Separated__fetch1(return_types, 0));
                    c_type = Type__replaced_c_type(return_type, String__null);
                    (void)String__buffer_append(c_type, buffer);
                } else {
                    if (!(Logical__false)) {
                        System__assert_fail((String)"\tParse.ezc", 3204);
                    }
                }
                (void)String__buffer_append(((String)"\001 "), buffer);
                (void)String__buffer_append(((String)"\002(*"), buffer);
                if ((argument_name != String__null)) {
                    (void)String__buffer_append(argument_name, buffer);
                    if (String__is_c_keyword(argument_name)) {
                        (void)String__buffer_append(((String)"\004___k"), buffer);
                    }
                }
                (void)String__buffer_append(((String)"\001)"), buffer);
                size = Comma_Separated__size_get(takes_types);
                if ((size == 0)) {
                    (void)String__buffer_append(((String)"\006(void)"), buffer);
                } else {
                    (void)String__buffer_append(((String)"\001("), buffer);
                    prefix = ((String)"\000");
                    index = 0;
                    while ((index < size)) {
                        (void)String__buffer_append(prefix, buffer);
                        prefix = ((String)"\002, ");
                        argument_type = ((Type)Comma_Separated__fetch1(takes_types, index));
                        c_type = Type__replaced_c_type(argument_type, String__null);
                        (void)String__buffer_append(c_type, buffer);
                        index = (index+1);
                    }
                    (void)String__buffer_append(((String)"\001)"), buffer);
                }
                break;
        }
    }
    return buffer;
}

String Type__c_type(
  Type type,
  Type parameters_type,
  String argument_name)
{
    String buffer;
    Compiler compiler;
    Type underlying_type;
    String temporary2;
    Token simple;
    String type_name;
    Logical is_pointer;
    Comma_Separated sub_types;
    Unsigned size;
    Unsigned index;
    Routine_Type routine_type;
    Comma_Separated return_types;
    Comma_Separated takes_types;
    Type return_type;
    String c_type;
    String prefix;
    Type argument_type;
    buffer = String__new();
    if ((type == Type__null)) {
        (void)String__buffer_append(((String)"\004void"), buffer);
        if (!String__equal(argument_name, ((String)"\000"))) {
            (void)String__buffer_append(((String)"\001 "), buffer);
            (void)String__buffer_append(argument_name, buffer);
        }
    } else {
        compiler = Compiler__one_and_only();
        underlying_type = Compiler__simple_type_lookup(compiler, Type__base_name(type));
        if ((underlying_type != Type__null)) {
            type = underlying_type;
        }
        if (String__is_c_keyword(argument_name)) {
            temporary2 = String__new();
            (void)String__string_append(temporary2, argument_name);
            (void)String__string_append(temporary2, ((String)"\004___k"));
            argument_name = temporary2;
        }
        switch (type->kind) {
            case Type_Kind___simple:
                simple = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3261));
                type_name = simple->value;
                is_pointer = Logical__false;
                switch (parameters_type->kind) {
                    case Type_Kind___parameterized:
                        sub_types = ((parameters_type->kind == Type_Kind___parameterized) ? parameters_type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3266))->sub_types;
                        size = Comma_Separated__size_get(sub_types);
                        index = 0;
                        while ((index < size)) {
                            if (Type__equal(((Type)Comma_Separated__fetch1(sub_types, index)), type)) {
                                is_pointer = Logical__true;
                                break;
                            }
                            index = (index+1);
                        }
                        break;
                }
                if (is_pointer) {
                    (void)String__buffer_append(((String)"\006void *"), buffer);
                } else {
                    (void)String__buffer_append(type_name, buffer);
                    if (!String__equal(argument_name, ((String)"\000"))) {
                        (void)String__buffer_append(((String)"\001 "), buffer);
                    }
                }
                (void)String__buffer_append(argument_name, buffer);
                break;
            case Type_Kind___parameterized:
                (void)String__buffer_append(((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3282))->name->value, buffer);
                if (!String__equal(argument_name, ((String)"\000"))) {
                    (void)String__buffer_append(((String)"\001 "), buffer);
                    (void)String__buffer_append(argument_name, buffer);
                }
                break;
            case Type_Kind___routine:
                routine_type = ((type->kind == Type_Kind___routine) ? type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3287));
                return_types = routine_type->return_types;
                takes_types = routine_type->takes_types;
                size = Comma_Separated__size_get(return_types);
                if ((size == 0)) {
                    (void)String__buffer_append(((String)"\005void "), buffer);
                } else if ((size == 1)) {
                    return_type = ((Type)Comma_Separated__fetch1(return_types, 0));
                    c_type = Type__c_type(return_type, parameters_type, ((String)"\000"));
                    (void)String__buffer_append(c_type, buffer);
                    (void)String__buffer_append(((String)"\001 "), buffer);
                } else {
                    if (!(Logical__false)) {
                        System__assert_fail((String)"\tParse.ezc", 3300);
                    }
                }
                (void)String__buffer_append(((String)"\002(*"), buffer);
                (void)String__buffer_append(argument_name, buffer);
                (void)String__buffer_append(((String)"\001)"), buffer);
                size = Comma_Separated__size_get(takes_types);
                if ((size == 0)) {
                    (void)String__buffer_append(((String)"\006(void)"), buffer);
                } else {
                    prefix = ((String)"\001(");
                    index = 0;
                    while ((index < size)) {
                        argument_type = ((Type)Comma_Separated__fetch1(takes_types, index));
                        (void)String__buffer_append(prefix, buffer);
                        prefix = ((String)"\002, ");
                        c_type = Type__c_type(argument_type, parameters_type, ((String)"\000"));
                        (void)String__buffer_append(c_type, buffer);
                        index = (index+1);
                    }
                    (void)String__buffer_append(((String)"\001)"), buffer);
                }
                break;
        }
    }
    return buffer;
}

Integer Type__compare(
  Type type1,
  Type type2)
{
    Integer zero;
    Integer one;
    Integer result;
    Parameterized_Type parameterized1;
    Parameterized_Type parameterized2;
    Routine_Type routine1;
    Routine_Type routine2;
    zero = 0;
    one = 1;
    result = zero;
    switch (type1->kind) {
        case Type_Kind___simple:
            switch (type2->kind) {
                case Type_Kind___simple:
                    result = String__compare(((type1->kind == Type_Kind___simple) ? type1->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3340))->value, ((type2->kind == Type_Kind___simple) ? type2->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3340))->value);
                    break;
                case Type_Kind___parameterized:
                case Type_Kind___routine:
                    result = one;
                    break;
            }
            break;
        case Type_Kind___parameterized:
            parameterized1 = ((type1->kind == Type_Kind___parameterized) ? type1->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3344));
            switch (type2->kind) {
                case Type_Kind___simple:
                    result = -one;
                    break;
                case Type_Kind___parameterized:
                    parameterized2 = ((type2->kind == Type_Kind___parameterized) ? type2->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3350));
                    result = String__compare(parameterized1->name->value, parameterized2->name->value);
                    if ((result == zero)) {
                        result = Comma_Separated__compare(parameterized1->sub_types, parameterized2->sub_types, ((Integer (*)(void *, void *))(Type__compare)));
                    }
                    break;
                case Type_Kind___routine:
                    result = one;
                    break;
            }
            break;
        case Type_Kind___routine:
            routine1 = ((type1->kind == Type_Kind___routine) ? type1->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3360));
            switch (type2->kind) {
                case Type_Kind___routine:
                    routine2 = ((type2->kind == Type_Kind___routine) ? type2->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3364));
                    result = Comma_Separated__compare(routine1->return_types, routine2->return_types, ((Integer (*)(void *, void *))(Type__compare)));
                    if ((result == zero)) {
                        result = Comma_Separated__compare(routine1->takes_types, routine2->takes_types, ((Integer (*)(void *, void *))(Type__compare)));
                    }
                    break;
                case Type_Kind___simple:
                case Type_Kind___parameterized:
                    result = -one;
                    break;
            }
            break;
    }
    return result;
}

Type Type__copy(
  Type type)
{
    Type result;
    result = Type__new();
    switch (type->kind) {
        case Type_Kind___simple:
            result->kind = Type_Kind___simple; result->kind__union.simple = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3386));
            break;
        case Type_Kind___parameterized:
            result->kind = Type_Kind___parameterized; result->kind__union.parameterized = Parameterized_Type__copy(((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3388)));
            break;
        case Type_Kind___routine:
            result->kind = Type_Kind___routine; result->kind__union.routine = Routine_Type__copy(((type->kind == Type_Kind___routine) ? type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3390)));
            break;
    }
    return result;
}

Logical Type__equal(
  Type type1,
  Type type2)
{
    return (Type__compare(type1, type2) == 0);
}

String Type__f(
  Type type)
{
    String value;
    Logical c_mode;
    Logical base_name_mode;
    Unsigned size;
    Unsigned index;
    Character mode_character;
    Parameterized_Type parameterized_type;
    Routine_Type routine_type;
    String t__0;
    String t__1;
    String t__2;
    value = Format__field_next();
    c_mode = Logical__false;
    base_name_mode = Logical__false;
    size = String__size_get(value);
    index = 0;
    while ((index < size)) {
        mode_character = String__fetch1(value, index);
        if ((mode_character == ((Character)'c'))) {
            c_mode = Logical__true;
        } else if ((mode_character == ((Character)'b'))) {
            base_name_mode = Logical__true;
        }
        index = (index+1);
    }
    (void)String__trim(value, 0);
    if ((type == Type__null)) {
        (void)String__string_append(value, ((String)"\007NO_TYPE"));
    } else {
        if (type->replaced) {
            (void)String__character_append(value, ((Character)'<'));
        }
        switch (type->kind) {
            case Type_Kind___simple:
                if (c_mode) {
                    (void)String__string_append(value, Type__c_base_name(type));
                } else {
                    (void)String__string_append(value, ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3436))->value);
                }
                break;
            case Type_Kind___parameterized:
                parameterized_type = ((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3438));
                (void)String__string_append(value, parameterized_type->name->value);
                if (!base_name_mode) {
                    (void)String__character_append(value, ((Character)'['));
                    (void)String__string_append(value, (t__0 = String__form(((String)"\003%t%")), String__divide((t__0), Comma_Separated__f(parameterized_type->sub_types, ((String (*)(void *))(Type__f))))));
                    (void)String__character_append(value, ((Character)']'));
                }
                break;
            case Type_Kind___routine:
                routine_type = ((type->kind == Type_Kind___routine) ? type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3446));
                (void)String__character_append(value, ((Character)'['));
                (void)String__string_append(value, (t__1 = String__form(((String)"\003%t%")), String__divide((t__1), Comma_Separated__f(routine_type->return_types, ((String (*)(void *))(Type__f))))));
                (void)String__string_append(value, ((String)"\004 <= "));
                (void)String__string_append(value, (t__2 = String__form(((String)"\003%t%")), String__divide((t__2), Comma_Separated__f(routine_type->takes_types, ((String (*)(void *))(Type__f))))));
                (void)String__character_append(value, ((Character)']'));
                break;
        }
        if (type->replaced) {
            (void)String__character_append(value, ((Character)'>'));
        }
    }
    return value;
}

void Type__format(
  Type type,
  String buffer)
{
    Unsigned anchor;
    anchor = String__format_begin(buffer);
    if ((type == Type__null)) {
        (void)String__string_gap_insert(buffer, ((String)"\007NO_TYPE"));
    } else {
        (void)Type__string_gap_insert(type, buffer);
    }
    (void)String__format_end(buffer, anchor);
}

Unsigned Type__hash(
  Type type)
{
    Unsigned hash;
    Parameterized_Type parameterized_type;
    Routine_Type routine_type;
    Unsigned t__0;
    Unsigned t__1;
    hash = 0;
    switch (type->kind) {
        case Type_Kind___simple:
            hash = Token__hash(((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3483)));
            break;
        case Type_Kind___parameterized:
            parameterized_type = ((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3485));
            hash = (t__0 = Token__hash(parameterized_type->name), (hash+t__0+Comma_Separated__hash(parameterized_type->sub_types, ((Unsigned (*)(void *))(Type__hash)))));
            break;
        case Type_Kind___routine:
            routine_type = ((type->kind == Type_Kind___routine) ? type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3489));
            hash = (t__1 = Comma_Separated__hash(routine_type->return_types, ((Unsigned (*)(void *))(Type__hash))), (t__1+Comma_Separated__hash(routine_type->takes_types, ((Unsigned (*)(void *))(Type__hash)))));
            break;
    }
    return hash;
}

Logical Type__is_parameterized(
  Type type)
{
    Logical result;
    result = Logical__false;
    switch (type->kind) {
        case Type_Kind___parameterized:
            result = Logical__true;
            break;
    }
    return result;
}

Logical Type__is_replaced(
  Type type)
{
    Logical result;
    Comma_Separated sub_types;
    Unsigned size;
    Unsigned index;
    Routine_Type routine_type;
    Comma_Separated takes_types;
    Comma_Separated return_types;
    result = Logical__false;
    switch (type->kind) {
        case Type_Kind___simple:
            result = type->replaced;
            break;
        case Type_Kind___parameterized:
            sub_types = ((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3517))->sub_types;
            size = Comma_Separated__size_get(sub_types);
            index = 0;
            while ((index < size)) {
                result = Type__is_replaced(((Type)Comma_Separated__fetch1(sub_types, index)));
                if (result) {
                    break;
                }
                index = (index+1);
            }
            break;
        case Type_Kind___routine:
            routine_type = ((type->kind == Type_Kind___routine) ? type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3526));
            takes_types = routine_type->takes_types;
            return_types = routine_type->return_types;
            size = Comma_Separated__size_get(takes_types);
            index = 0;
            while ((index < size)) {
                result = Type__is_replaced(((Type)Comma_Separated__fetch1(takes_types, index)));
                if (result) {
                    break;
                }
                index = (index+1);
            }
            if (!result) {
                size = Comma_Separated__size_get(return_types);
                index = 0;
                while ((index < size)) {
                    result = Type__is_replaced(((Type)Comma_Separated__fetch1(return_types, index)));
                    if (result) {
                        break;
                    }
                    index = (index+1);
                }
            }
            break;
    }
    return result;
}

Logical Type__is_routine(
  Type type)
{
    Logical result;
    result = Logical__false;
    switch (type->kind) {
        case Type_Kind___routine:
            result = Logical__true;
            break;
    }
    return result;
}

Logical Type__is_scalar(
  Type type)
{
    Compiler compiler;
    Logical result;
    String name;
    compiler = Compiler__one_and_only();
    result = Logical__false;
    switch (type->kind) {
        case Type_Kind___simple:
            name = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3571))->value;
            result = (Compiler__scalar_lookup(compiler, name) != Type__null);
            break;
    }
    return result;
}

Logical Type__is_float_scalar(
  Type type)
{
    Logical result;
    String name;
    result = Logical__false;
    switch (type->kind) {
        case Type_Kind___simple:
            name = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3586))->value;
            result = (String__equal(name, ((String)"\006Double"))||String__equal(name, ((String)"\005Float"))||String__equal(name, ((String)"\004Quad")));
            break;
    }
    return result;
}

Logical Type__is_number_scalar(
  Type type)
{
    Logical result;
    String name;
    Compiler compiler;
    result = Logical__false;
    switch (type->kind) {
        case Type_Kind___simple:
            name = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3602))->value;
            result = (String__equal(name, ((String)"\004Byte"))||String__equal(name, ((String)"\011Character"))||String__equal(name, ((String)"\006Double"))||String__equal(name, ((String)"\007Integer"))||String__equal(name, ((String)"\014Long_Integer"))||String__equal(name, ((String)"\015Long_Unsigned"))||String__equal(name, ((String)"\005Float"))||String__equal(name, ((String)"\004Quad"))||String__equal(name, ((String)"\005Short"))||String__equal(name, ((String)"\010Unsigned")));
            if (!result) {
                compiler = Compiler__one_and_only();
                result = (Compiler__scalar_lookup(compiler, name) != Type__null);
            }
            break;
    }
    return result;
}

Logical Type__is_logical(
  Type type)
{
    Logical result;
    String name;
    result = Logical__false;
    switch (type->kind) {
        case Type_Kind___simple:
            name = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3629))->value;
            result = String__equal(name, ((String)"\007Logical"));
            break;
    }
    return result;
}

Logical Type__is_non_float_scalar(
  Type type)
{
    Logical result;
    String name;
    result = Logical__false;
    switch (type->kind) {
        case Type_Kind___simple:
            name = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3644))->value;
            result = (String__equal(name, ((String)"\004Byte"))||String__equal(name, ((String)"\011Character"))||String__equal(name, ((String)"\007Integer"))||String__equal(name, ((String)"\005Short"))||String__equal(name, ((String)"\010Unsigned")));
            break;
    }
    return result;
}

Logical Type__is_parameter(
  Type parameter,
  Type type)
{
    Logical result;
    Comma_Separated sub_types;
    Unsigned size;
    Unsigned index;
    result = Logical__false;
    switch (type->kind) {
        case Type_Kind___parameterized:
            sub_types = ((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3665))->sub_types;
            size = Comma_Separated__size_get(sub_types);
            index = 0;
            while ((index < size)) {
                if (Type__equal(((Type)Comma_Separated__fetch1(sub_types, index)), parameter)) {
                    result = Logical__true;
                    break;
                }
                index = (index+1);
            }
            break;
    }
    return result;
}

Token Type__location_get(
  Type type)
{
    Token result;
    result = Token__null;
    switch (type->kind) {
        case Type_Kind___simple:
            result = ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3685));
            break;
        case Type_Kind___parameterized:
            result = ((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3687))->name;
            break;
        case Type_Kind___routine:
            result = ((type->kind == Type_Kind___routine) ? type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3689))->open_bracket;
            break;
    }
    return result;
}

Type Type__replace(
  Type type,
  Type formal_type,
  Type actual_type,
  Token location,
  Unsigned level)
{
    Compiler compiler;
    String temporary;
    Logical tracing;
    Type result;
    Parameterized_Type actual_parameterized_type;
    Comma_Separated actual_types;
    Comma_Separated formal_types;
    Unsigned actual_types_size;
    Unsigned formal_types_size;
    Unsigned size;
    Unsigned index;
    Parameterized_Type parameterized_type;
    Comma_Separated sub_types;
    Routine_Type routine_type;
    Comma_Separated takes_types;
    Comma_Separated return_types;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    compiler = Compiler__one_and_only();
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__4 = String__form(((String)"\047%p%=>replace@Type(t:%t%, f:%t%, a:%t%)\n")), t__5 = Unsigned__f(level), t__6 = Type__f(type), t__7 = Type__f(formal_type), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), Type__f(actual_type))), Out_Stream__error);
    }
    result = type;
    switch (formal_type->kind) {
        case Type_Kind___parameterized:
            switch (actual_type->kind) {
                case Type_Kind___parameterized:
                    actual_parameterized_type = ((actual_type->kind == Type_Kind___parameterized) ? actual_type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3718));
                    actual_types = actual_parameterized_type->sub_types;
                    formal_types = ((formal_type->kind == Type_Kind___parameterized) ? formal_type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3720))->sub_types;
                    actual_types_size = Comma_Separated__size_get(actual_types);
                    formal_types_size = Comma_Separated__size_get(formal_types);
                    if ((actual_types_size == formal_types_size)) {

                        size = actual_types_size;
                        switch (type->kind) {
                            case Type_Kind___simple:
                                index = 0;
                                while ((index < size)) {
                                    if (Type__equal(((Type)Comma_Separated__fetch1(formal_types, index)), type)) {
                                        result = Type__copy(((Type)Comma_Separated__fetch1(actual_types, index)));
                                        result->replaced = Logical__true;
                                        break;
                                    }
                                    index = (index+1);
                                }
                                break;
                            case Type_Kind___parameterized:

                                result = Type__copy(type);
                                parameterized_type = ((result->kind == Type_Kind___parameterized) ? result->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3739));
                                /* # Sweep through the parameters {sub_types}. */
                                sub_types = parameterized_type->sub_types;
                                size = Comma_Separated__size_get(sub_types);
                                index = 0;
                                while ((index < size)) {
                                    Comma_Separated__store1(sub_types, index, (void *)(Type__replace(((Type)Comma_Separated__fetch1(sub_types, index)), formal_type, actual_type, location, (level+1))));
                                    index = (index+1);
                                }
                                break;
                            case Type_Kind___routine:

                                result = Type__copy(type);
                                routine_type = ((result->kind == Type_Kind___routine) ? result->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3753));
                                /* # Sweep through the argument types: */
                                takes_types = routine_type->takes_types;
                                size = Comma_Separated__size_get(takes_types);
                                index = 0;
                                while ((index < size)) {
                                    Comma_Separated__store1(takes_types, index, (void *)(Type__replace(((Type)Comma_Separated__fetch1(takes_types, index)), formal_type, actual_type, location, (level+1))));
                                    index = (index+1);
                                }
                                /* # Sweep through the return types: */
                                return_types = routine_type->return_types;
                                size = Comma_Separated__size_get(return_types);
                                index = 0;
                                while ((index < size)) {
                                    Comma_Separated__store1(return_types, index, (void *)(Type__replace(((Type)Comma_Separated__fetch1(return_types, index)), formal_type, actual_type, location, (level+1))));
                                    index = (index+1);
                                }
                                break;
                        }
                    } else {
                        (void)Compiler__log(compiler, location, (t__8 = String__form(((String)"\057Parameter count mismatch %t% (%d%) != %t% (%d%)")), t__9 = Type__f(formal_type), t__10 = Unsigned__f(formal_types_size), t__11 = Type__f(actual_type), String__divide(String__remainder(String__remainder(String__remainder((t__8), t__9), t__10), t__11), Unsigned__f(actual_types_size))));
                    }
                    break;
                default:
                    (void)Compiler__log(compiler, location, (t__12 = String__form(((String)"\043%t% is Parameterized and %t% is not")), t__13 = Type__f(formal_type), String__divide(String__remainder((t__12), t__13), Type__f(actual_type))));
                    break;
            }
            break;
        default:
            if ((actual_type->kind == Type_Kind__parameterized)) {
                (void)Compiler__log(compiler, location, (t__14 = String__form(((String)"\043%t% is parameterized and %t% is not")), t__15 = Type__f(actual_type), String__divide(String__remainder((t__14), t__15), Type__f(formal_type))));
            }
            break;
    }
    if (tracing) {
        (void)String__put((t__21 = String__form(((String)"\056%p%<=replace@Type(t:%t%, f:%t%, a:%t%) => %t%\n")), t__22 = Unsigned__f(level), t__23 = Type__f(type), t__24 = Type__f(formal_type), t__25 = Type__f(actual_type), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__21), t__22), t__23), t__24), t__25), Type__f(result))), Out_Stream__error);
    }
    return result;
}

Type Type__simple_create(
  String name)
{
    Token simple;
    Type type;
    name = String__read_only_copy(name);
    simple = Token__create(File__null, 0, Lexeme__symbol, name);
    type = Type__new();
    type->kind = Type_Kind___simple; type->kind__union.simple = simple;
    return type;
}

void Type__string_gap_insert(
  Type type,
  String buffer)
{
    Parameterized_Type parameterized_type;
    Routine_Type routine_type;
    if (type->replaced) {
        (void)String__string_gap_insert(buffer, ((String)"\001<"));
    }
    switch (type->kind) {
        case Type_Kind___simple:
            (void)String__string_gap_insert(buffer, ((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\tParse.ezc", 3822))->value);
            break;
        case Type_Kind___parameterized:
            parameterized_type = ((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\tParse.ezc", 3824));
            (void)String__string_gap_insert(buffer, parameterized_type->name->value);
            (void)String__string_gap_insert(buffer, ((String)"\001["));
            (void)Comma_Separated__string_gap_insert(parameterized_type->sub_types, buffer, ((void (*)(void *, String))(Type__string_gap_insert)));
            (void)String__string_gap_insert(buffer, ((String)"\001]"));
            break;
        case Type_Kind___routine:
            routine_type = ((type->kind == Type_Kind___routine) ? type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\tParse.ezc", 3831));
            (void)String__string_gap_insert(buffer, ((String)"\001["));
            (void)Comma_Separated__string_gap_insert(routine_type->return_types, buffer, ((void (*)(void *, String))(Type__string_gap_insert)));
            (void)String__string_gap_insert(buffer, ((String)"\004 <= "));
            (void)Comma_Separated__string_gap_insert(routine_type->takes_types, buffer, ((void (*)(void *, String))(Type__string_gap_insert)));
            (void)String__string_gap_insert(buffer, ((String)"\001]"));
            break;
    }
    if (type->replaced) {
        (void)String__string_gap_insert(buffer, ((String)"\001>"));
    }
}

/* # {Typed_Name} stuff: */
Logical Typed_Name__equal(
  Typed_Name typed_name1,
  Typed_Name typed_name2)
{
    Logical names_equal;
    Logical types_equal;
    Logical result;
    names_equal = String__equal(typed_name1->name->value, typed_name2->name->value);
    types_equal = String__equal(Type__base_name(typed_name1->type), Type__base_name(typed_name2->type));
    result = (names_equal&&types_equal);
    return result;
}

String Typed_Name__f(
  Typed_Name typed_name)
{
    String value;
    String t__0;
    String t__1;
    value = Format__field_next();
    (void)String__trim(value, 0);
    (void)String__string_append(value, (t__0 = String__form(((String)"\007%s%@%t%")), t__1 = String__f(typed_name->name->value), String__divide(String__remainder((t__0), t__1), Type__f(typed_name->type))));
    return value;
}

void Typed_Name__format(
  Typed_Name typed_name,
  String buffer)
{
    Unsigned anchor;
    anchor = String__format_begin(buffer);
    (void)String__string_gap_insert(buffer, typed_name->name->value);
    (void)String__string_gap_insert(buffer, ((String)"\001@"));
    (void)Type__string_gap_insert(typed_name->type, buffer);
    (void)String__format_end(buffer, anchor);
}

Unsigned Typed_Name__hash(
  Typed_Name typed_name)
{
    Unsigned t__0;
    return (t__0 = Token__hash(typed_name->name), (t__0+String__hash(Type__base_name(typed_name->type))));
}

void Typed_Name__show(
  Typed_Name typed_name,
  String buffer)
{
    if ((typed_name == Typed_Name__null)) {
        (void)String__buffer_append(((String)"\021{null@Typed_Name}"), buffer);
    } else {
        (void)String__buffer_append(typed_name->name->value, buffer);
        (void)String__buffer_append(((String)"\001@"), buffer);
        (void)Type__string_gap_insert(typed_name->type, buffer);
    }
}

Root Root__parse(
  Parser parser)
{
    Unsigned index;
    Array declarations;
    Token end_of_file;
    Root root;
    index = parser->index;
    declarations = Array__parse(parser, ((void * (*)(Parser))(Declaration__parse)), ((void *)(Declaration__null)), Lexeme__end_of_file);
    if ((Array__size_get(declarations) == 0)) {
        parser->index = index;
        return Root__null;
    }
    end_of_file = Token__parse(parser, Lexeme__end_of_file);
    if ((end_of_file == Token__null)) {
        parser->index = index;
        return Root__null;
    }
    root = Root__new();
    root->declarations = declarations;
    root->end_of_file = end_of_file;
    return root;
}

void Root__traverse(
  Root root,
  Traverser traverser)
{
    (void)Array__traverse(root->declarations, traverser, ((void (*)(void *, Traverser))(Declaration__traverse)));
    (void)Token__traverse(root->end_of_file, traverser);
}



String Declaration_Kind__string_convert(
  Declaration_Kind declaration_kind)
{
    switch (declaration_kind) {
        case Declaration_Kind___easy_c:
            return ((String)"\006easy_c");
            break;
        case Declaration_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Declaration_Kind___note:
            return ((String)"\004note");
            break;
        case Declaration_Kind___routine:
            return ((String)"\007routine");
            break;
        case Declaration_Kind___define:
            return ((String)"\006define");
            break;
        case Declaration_Kind___defines_prefix:
            return ((String)"\016defines_prefix");
            break;
        case Declaration_Kind___external_named:
            return ((String)"\016external_named");
            break;
        case Declaration_Kind___external:
            return ((String)"\010external");
            break;
        case Declaration_Kind___global:
            return ((String)"\006global");
            break;
        case Declaration_Kind___global_library:
            return ((String)"\016global_library");
            break;
        case Declaration_Kind___library:
            return ((String)"\007library");
            break;
        case Declaration_Kind___interface:
            return ((String)"\011interface");
            break;
        case Declaration_Kind___load:
            return ((String)"\004load");
            break;
        case Declaration_Kind___include_string:
            return ((String)"\016include_string");
            break;
        case Declaration_Kind___constant:
            return ((String)"\010constant");
            break;
        case Declaration_Kind___require:
            return ((String)"\007require");
            break;
        case Declaration_Kind___collection:
            return ((String)"\012collection");
            break;
        case Declaration_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Declaration Declaration__parse(
  Parser parser)
{
    Declaration declaration;
    Easy_C_Declaration easy_c;
    Token end_of_line;
    Note note;
    Routine_Declaration routine;
    Define_Declaration define;
    Defines_Prefix_Declaration defines_prefix;
    External_Named_Declaration external_named;
    External_Declaration external;
    Global_Declaration global;
    Global_Library_Declaration global_library;
    Library_Declaration library;
    Interface_Declaration interface;
    Load_Declaration load;
    Include_String_Declaration include_string;
    Constant_Declaration constant;
    Require_Declaration require;
    Collection_Declaration collection;
    Error error;
    declaration = Declaration__new();
    easy_c = Easy_C_Declaration__parse(parser);
    if ((easy_c != Easy_C_Declaration__null)) {
        declaration->kind = Declaration_Kind___easy_c; declaration->kind__union.easy_c = easy_c;
        return declaration;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        declaration->kind = Declaration_Kind___end_of_line; declaration->kind__union.end_of_line = end_of_line;
        return declaration;
    }
    note = Note__parse(parser);
    if ((note != Note__null)) {
        declaration->kind = Declaration_Kind___note; declaration->kind__union.note = note;
        return declaration;
    }
    routine = Routine_Declaration__parse(parser);
    if ((routine != Routine_Declaration__null)) {
        declaration->kind = Declaration_Kind___routine; declaration->kind__union.routine = routine;
        return declaration;
    }
    define = Define_Declaration__parse(parser);
    if ((define != Define_Declaration__null)) {
        declaration->kind = Declaration_Kind___define; declaration->kind__union.define = define;
        return declaration;
    }
    defines_prefix = Defines_Prefix_Declaration__parse(parser);
    if ((defines_prefix != Defines_Prefix_Declaration__null)) {
        declaration->kind = Declaration_Kind___defines_prefix; declaration->kind__union.defines_prefix = defines_prefix;
        return declaration;
    }
    external_named = External_Named_Declaration__parse(parser);
    if ((external_named != External_Named_Declaration__null)) {
        declaration->kind = Declaration_Kind___external_named; declaration->kind__union.external_named = external_named;
        return declaration;
    }
    external = External_Declaration__parse(parser);
    if ((external != External_Declaration__null)) {
        declaration->kind = Declaration_Kind___external; declaration->kind__union.external = external;
        return declaration;
    }
    global = Global_Declaration__parse(parser);
    if ((global != Global_Declaration__null)) {
        declaration->kind = Declaration_Kind___global; declaration->kind__union.global = global;
        return declaration;
    }
    global_library = Global_Library_Declaration__parse(parser);
    if ((global_library != Global_Library_Declaration__null)) {
        declaration->kind = Declaration_Kind___global_library; declaration->kind__union.global_library = global_library;
        return declaration;
    }
    library = Library_Declaration__parse(parser);
    if ((library != Library_Declaration__null)) {
        declaration->kind = Declaration_Kind___library; declaration->kind__union.library = library;
        return declaration;
    }
    interface = Interface_Declaration__parse(parser);
    if ((interface != Interface_Declaration__null)) {
        declaration->kind = Declaration_Kind___interface; declaration->kind__union.interface = interface;
        return declaration;
    }
    load = Load_Declaration__parse(parser);
    if ((load != Load_Declaration__null)) {
        declaration->kind = Declaration_Kind___load; declaration->kind__union.load = load;
        return declaration;
    }
    include_string = Include_String_Declaration__parse(parser);
    if ((include_string != Include_String_Declaration__null)) {
        declaration->kind = Declaration_Kind___include_string; declaration->kind__union.include_string = include_string;
        return declaration;
    }
    constant = Constant_Declaration__parse(parser);
    if ((constant != Constant_Declaration__null)) {
        declaration->kind = Declaration_Kind___constant; declaration->kind__union.constant = constant;
        return declaration;
    }
    require = Require_Declaration__parse(parser);
    if ((require != Require_Declaration__null)) {
        declaration->kind = Declaration_Kind___require; declaration->kind__union.require = require;
        return declaration;
    }
    collection = Collection_Declaration__parse(parser);
    if ((collection != Collection_Declaration__null)) {
        declaration->kind = Declaration_Kind___collection; declaration->kind__union.collection = collection;
        return declaration;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        declaration->kind = Declaration_Kind___error; declaration->kind__union.error = error;
        return declaration;
    }
    return Declaration__null;
}

void Declaration__traverse(
  Declaration declaration,
  Traverser traverser)
{
    switch (declaration->kind) {
        case Declaration_Kind___easy_c:
            (void)Easy_C_Declaration__traverse(((declaration->kind == Declaration_Kind___easy_c) ? declaration->kind__union.easy_c : (Easy_C_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 227)), traverser);
            break;
        case Declaration_Kind___end_of_line:
            (void)Token__traverse(((declaration->kind == Declaration_Kind___end_of_line) ? declaration->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 229)), traverser);
            break;
        case Declaration_Kind___note:
            (void)Note__traverse(((declaration->kind == Declaration_Kind___note) ? declaration->kind__union.note : (Note)System__variant_object_fail((String)"\14Parse.ez.ezg", 231)), traverser);
            break;
        case Declaration_Kind___routine:
            (void)Routine_Declaration__traverse(((declaration->kind == Declaration_Kind___routine) ? declaration->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 233)), traverser);
            break;
        case Declaration_Kind___define:
            (void)Define_Declaration__traverse(((declaration->kind == Declaration_Kind___define) ? declaration->kind__union.define : (Define_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 235)), traverser);
            break;
        case Declaration_Kind___defines_prefix:
            (void)Defines_Prefix_Declaration__traverse(((declaration->kind == Declaration_Kind___defines_prefix) ? declaration->kind__union.defines_prefix : (Defines_Prefix_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 237)), traverser);
            break;
        case Declaration_Kind___external_named:
            (void)External_Named_Declaration__traverse(((declaration->kind == Declaration_Kind___external_named) ? declaration->kind__union.external_named : (External_Named_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 239)), traverser);
            break;
        case Declaration_Kind___external:
            (void)External_Declaration__traverse(((declaration->kind == Declaration_Kind___external) ? declaration->kind__union.external : (External_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 241)), traverser);
            break;
        case Declaration_Kind___global:
            (void)Global_Declaration__traverse(((declaration->kind == Declaration_Kind___global) ? declaration->kind__union.global : (Global_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 243)), traverser);
            break;
        case Declaration_Kind___global_library:
            (void)Global_Library_Declaration__traverse(((declaration->kind == Declaration_Kind___global_library) ? declaration->kind__union.global_library : (Global_Library_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 245)), traverser);
            break;
        case Declaration_Kind___library:
            (void)Library_Declaration__traverse(((declaration->kind == Declaration_Kind___library) ? declaration->kind__union.library : (Library_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 247)), traverser);
            break;
        case Declaration_Kind___interface:
            (void)Interface_Declaration__traverse(((declaration->kind == Declaration_Kind___interface) ? declaration->kind__union.interface : (Interface_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 249)), traverser);
            break;
        case Declaration_Kind___load:
            (void)Load_Declaration__traverse(((declaration->kind == Declaration_Kind___load) ? declaration->kind__union.load : (Load_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 251)), traverser);
            break;
        case Declaration_Kind___include_string:
            (void)Include_String_Declaration__traverse(((declaration->kind == Declaration_Kind___include_string) ? declaration->kind__union.include_string : (Include_String_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 253)), traverser);
            break;
        case Declaration_Kind___constant:
            (void)Constant_Declaration__traverse(((declaration->kind == Declaration_Kind___constant) ? declaration->kind__union.constant : (Constant_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 255)), traverser);
            break;
        case Declaration_Kind___require:
            (void)Require_Declaration__traverse(((declaration->kind == Declaration_Kind___require) ? declaration->kind__union.require : (Require_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 257)), traverser);
            break;
        case Declaration_Kind___collection:
            (void)Collection_Declaration__traverse(((declaration->kind == Declaration_Kind___collection) ? declaration->kind__union.collection : (Collection_Declaration)System__variant_object_fail((String)"\14Parse.ez.ezg", 259)), traverser);
            break;
        case Declaration_Kind___error:
            (void)Error__traverse(((declaration->kind == Declaration_Kind___error) ? declaration->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 261)), traverser);
            break;
    }
}


Easy_C_Declaration Easy_C_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword easy_c;
    Token float_number;
    Token end_of_line;
    Easy_C_Declaration easy_c_declaration;
    index = parser->index;
    easy_c = Keyword__parse(parser, ((String)"\006easy_c"));
    if ((easy_c == Keyword__null)) {
        parser->index = index;
        return Easy_C_Declaration__null;
    }
    float_number = Token__parse(parser, Lexeme__float_number);
    if ((float_number == Token__null)) {
        parser->index = index;
        return Easy_C_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Easy_C_Declaration__null;
    }
    easy_c_declaration = Easy_C_Declaration__new();
    easy_c_declaration->easy_c = easy_c;
    easy_c_declaration->float_number = float_number;
    easy_c_declaration->end_of_line = end_of_line;
    return easy_c_declaration;
}

void Easy_C_Declaration__traverse(
  Easy_C_Declaration easy_c_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(easy_c_declaration->easy_c, traverser);
    (void)Token__traverse(easy_c_declaration->float_number, traverser);
    (void)Token__traverse(easy_c_declaration->end_of_line, traverser);
}


Define_Declaration Define_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword define;
    Type type;
    Token end_of_line;
    Token open_indent;
    Array define_clauses;
    Token close_indent;
    Define_Declaration define_declaration;
    index = parser->index;
    define = Keyword__parse(parser, ((String)"\006define"));
    if ((define == Keyword__null)) {
        parser->index = index;
        return Define_Declaration__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Define_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Define_Declaration__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Define_Declaration__null;
    }
    define_clauses = Array__parse(parser, ((void * (*)(Parser))(Define_Clause__parse)), ((void *)(Define_Clause__null)), Lexeme__close_indent);
    if ((Array__size_get(define_clauses) == 0)) {
        parser->index = index;
        return Define_Declaration__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Define_Declaration__null;
    }
    define_declaration = Define_Declaration__new();
    define_declaration->define = define;
    define_declaration->type = type;
    define_declaration->end_of_line = end_of_line;
    define_declaration->open_indent = open_indent;
    define_declaration->define_clauses = define_clauses;
    define_declaration->close_indent = close_indent;
    return define_declaration;
}

void Define_Declaration__traverse(
  Define_Declaration define_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(define_declaration->define, traverser);
    (void)Type__traverse(define_declaration->type, traverser);
    (void)Token__traverse(define_declaration->end_of_line, traverser);
    (void)Token__traverse(define_declaration->open_indent, traverser);
    (void)Array__traverse(define_declaration->define_clauses, traverser, ((void (*)(void *, Traverser))(Define_Clause__traverse)));
    (void)Token__traverse(define_declaration->close_indent, traverser);
}



String Define_Clause_Kind__string_convert(
  Define_Clause_Kind define_clause_kind)
{
    switch (define_clause_kind) {
        case Define_Clause_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Define_Clause_Kind___note:
            return ((String)"\004note");
            break;
        case Define_Clause_Kind___enumeration:
            return ((String)"\013enumeration");
            break;
        case Define_Clause_Kind___enumeration_prefix:
            return ((String)"\022enumeration_prefix");
            break;
        case Define_Clause_Kind___record:
            return ((String)"\006record");
            break;
        case Define_Clause_Kind___record_import:
            return ((String)"\015record_import");
            break;
        case Define_Clause_Kind___registers:
            return ((String)"\011registers");
            break;
        case Define_Clause_Kind___variant:
            return ((String)"\007variant");
            break;
        case Define_Clause_Kind___generate:
            return ((String)"\010generate");
            break;
        case Define_Clause_Kind___simple:
            return ((String)"\006simple");
            break;
        case Define_Clause_Kind___simple_numeric:
            return ((String)"\016simple_numeric");
            break;
        case Define_Clause_Kind___external:
            return ((String)"\010external");
            break;
        case Define_Clause_Kind___base_type:
            return ((String)"\011base_type");
            break;
        case Define_Clause_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Define_Clause Define_Clause__parse(
  Parser parser)
{
    Define_Clause define_clause;
    Token end_of_line;
    Note note;
    Enumeration_Clause enumeration;
    Enumeration_Prefix_Clause enumeration_prefix;
    Record_Clause record;
    Record_Import_Clause record_import;
    Registers_Clause registers;
    Variant_Clause variant;
    Generate_Clause generate;
    Simple_Clause simple;
    Simple_Numeric_Clause simple_numeric;
    External_Clause external;
    Base_Type_Clause base_type;
    Error error;
    define_clause = Define_Clause__new();
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        define_clause->kind = Define_Clause_Kind___end_of_line; define_clause->kind__union.end_of_line = end_of_line;
        return define_clause;
    }
    note = Note__parse(parser);
    if ((note != Note__null)) {
        define_clause->kind = Define_Clause_Kind___note; define_clause->kind__union.note = note;
        return define_clause;
    }
    enumeration = Enumeration_Clause__parse(parser);
    if ((enumeration != Enumeration_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___enumeration; define_clause->kind__union.enumeration = enumeration;
        return define_clause;
    }
    enumeration_prefix = Enumeration_Prefix_Clause__parse(parser);
    if ((enumeration_prefix != Enumeration_Prefix_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___enumeration_prefix; define_clause->kind__union.enumeration_prefix = enumeration_prefix;
        return define_clause;
    }
    record = Record_Clause__parse(parser);
    if ((record != Record_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___record; define_clause->kind__union.record = record;
        return define_clause;
    }
    record_import = Record_Import_Clause__parse(parser);
    if ((record_import != Record_Import_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___record_import; define_clause->kind__union.record_import = record_import;
        return define_clause;
    }
    registers = Registers_Clause__parse(parser);
    if ((registers != Registers_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___registers; define_clause->kind__union.registers = registers;
        return define_clause;
    }
    variant = Variant_Clause__parse(parser);
    if ((variant != Variant_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___variant; define_clause->kind__union.variant = variant;
        return define_clause;
    }
    generate = Generate_Clause__parse(parser);
    if ((generate != Generate_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___generate; define_clause->kind__union.generate = generate;
        return define_clause;
    }
    simple = Simple_Clause__parse(parser);
    if ((simple != Simple_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___simple; define_clause->kind__union.simple = simple;
        return define_clause;
    }
    simple_numeric = Simple_Numeric_Clause__parse(parser);
    if ((simple_numeric != Simple_Numeric_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___simple_numeric; define_clause->kind__union.simple_numeric = simple_numeric;
        return define_clause;
    }
    external = External_Clause__parse(parser);
    if ((external != External_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___external; define_clause->kind__union.external = external;
        return define_clause;
    }
    base_type = Base_Type_Clause__parse(parser);
    if ((base_type != Base_Type_Clause__null)) {
        define_clause->kind = Define_Clause_Kind___base_type; define_clause->kind__union.base_type = base_type;
        return define_clause;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        define_clause->kind = Define_Clause_Kind___error; define_clause->kind__union.error = error;
        return define_clause;
    }
    return Define_Clause__null;
}

void Define_Clause__traverse(
  Define_Clause define_clause,
  Traverser traverser)
{
    switch (define_clause->kind) {
        case Define_Clause_Kind___end_of_line:
            (void)Token__traverse(((define_clause->kind == Define_Clause_Kind___end_of_line) ? define_clause->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 532)), traverser);
            break;
        case Define_Clause_Kind___note:
            (void)Note__traverse(((define_clause->kind == Define_Clause_Kind___note) ? define_clause->kind__union.note : (Note)System__variant_object_fail((String)"\14Parse.ez.ezg", 534)), traverser);
            break;
        case Define_Clause_Kind___enumeration:
            (void)Enumeration_Clause__traverse(((define_clause->kind == Define_Clause_Kind___enumeration) ? define_clause->kind__union.enumeration : (Enumeration_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 536)), traverser);
            break;
        case Define_Clause_Kind___enumeration_prefix:
            (void)Enumeration_Prefix_Clause__traverse(((define_clause->kind == Define_Clause_Kind___enumeration_prefix) ? define_clause->kind__union.enumeration_prefix : (Enumeration_Prefix_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 538)), traverser);
            break;
        case Define_Clause_Kind___record:
            (void)Record_Clause__traverse(((define_clause->kind == Define_Clause_Kind___record) ? define_clause->kind__union.record : (Record_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 540)), traverser);
            break;
        case Define_Clause_Kind___record_import:
            (void)Record_Import_Clause__traverse(((define_clause->kind == Define_Clause_Kind___record_import) ? define_clause->kind__union.record_import : (Record_Import_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 542)), traverser);
            break;
        case Define_Clause_Kind___registers:
            (void)Registers_Clause__traverse(((define_clause->kind == Define_Clause_Kind___registers) ? define_clause->kind__union.registers : (Registers_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 544)), traverser);
            break;
        case Define_Clause_Kind___variant:
            (void)Variant_Clause__traverse(((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 546)), traverser);
            break;
        case Define_Clause_Kind___generate:
            (void)Generate_Clause__traverse(((define_clause->kind == Define_Clause_Kind___generate) ? define_clause->kind__union.generate : (Generate_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 548)), traverser);
            break;
        case Define_Clause_Kind___simple:
            (void)Simple_Clause__traverse(((define_clause->kind == Define_Clause_Kind___simple) ? define_clause->kind__union.simple : (Simple_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 550)), traverser);
            break;
        case Define_Clause_Kind___simple_numeric:
            (void)Simple_Numeric_Clause__traverse(((define_clause->kind == Define_Clause_Kind___simple_numeric) ? define_clause->kind__union.simple_numeric : (Simple_Numeric_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 552)), traverser);
            break;
        case Define_Clause_Kind___external:
            (void)External_Clause__traverse(((define_clause->kind == Define_Clause_Kind___external) ? define_clause->kind__union.external : (External_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 554)), traverser);
            break;
        case Define_Clause_Kind___base_type:
            (void)Base_Type_Clause__traverse(((define_clause->kind == Define_Clause_Kind___base_type) ? define_clause->kind__union.base_type : (Base_Type_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 556)), traverser);
            break;
        case Define_Clause_Kind___error:
            (void)Error__traverse(((define_clause->kind == Define_Clause_Kind___error) ? define_clause->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 558)), traverser);
            break;
    }
}


Simple_Numeric_Clause Simple_Numeric_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword simple_numeric;
    Type type;
    Token end_of_line;
    Simple_Numeric_Clause simple_numeric_clause;
    index = parser->index;
    simple_numeric = Keyword__parse(parser, ((String)"\016simple_numeric"));
    if ((simple_numeric == Keyword__null)) {
        parser->index = index;
        return Simple_Numeric_Clause__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Simple_Numeric_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Simple_Numeric_Clause__null;
    }
    simple_numeric_clause = Simple_Numeric_Clause__new();
    simple_numeric_clause->simple_numeric = simple_numeric;
    simple_numeric_clause->type = type;
    simple_numeric_clause->end_of_line = end_of_line;
    return simple_numeric_clause;
}

void Simple_Numeric_Clause__traverse(
  Simple_Numeric_Clause simple_numeric_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(simple_numeric_clause->simple_numeric, traverser);
    (void)Type__traverse(simple_numeric_clause->type, traverser);
    (void)Token__traverse(simple_numeric_clause->end_of_line, traverser);
}


Base_Type_Clause Base_Type_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword base_type;
    Token string;
    Token end_of_line;
    Base_Type_Clause base_type_clause;
    index = parser->index;
    base_type = Keyword__parse(parser, ((String)"\011base_type"));
    if ((base_type == Keyword__null)) {
        parser->index = index;
        return Base_Type_Clause__null;
    }
    string = Token__parse(parser, Lexeme__string);
    if ((string == Token__null)) {
        parser->index = index;
        return Base_Type_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Base_Type_Clause__null;
    }
    base_type_clause = Base_Type_Clause__new();
    base_type_clause->base_type = base_type;
    base_type_clause->string = string;
    base_type_clause->end_of_line = end_of_line;
    return base_type_clause;
}

void Base_Type_Clause__traverse(
  Base_Type_Clause base_type_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(base_type_clause->base_type, traverser);
    (void)Token__traverse(base_type_clause->string, traverser);
    (void)Token__traverse(base_type_clause->end_of_line, traverser);
}


Enumeration_Clause Enumeration_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword enumeration;
    Token end_of_line;
    Token open_indent;
    Array item_clauses;
    Token close_indent;
    Enumeration_Clause enumeration_clause;
    index = parser->index;
    enumeration = Keyword__parse(parser, ((String)"\013enumeration"));
    if ((enumeration == Keyword__null)) {
        parser->index = index;
        return Enumeration_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Enumeration_Clause__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Enumeration_Clause__null;
    }
    item_clauses = Array__parse(parser, ((void * (*)(Parser))(Item_Clause__parse)), ((void *)(Item_Clause__null)), Lexeme__close_indent);
    if ((Array__size_get(item_clauses) == 0)) {
        parser->index = index;
        return Enumeration_Clause__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Enumeration_Clause__null;
    }
    enumeration_clause = Enumeration_Clause__new();
    enumeration_clause->enumeration = enumeration;
    enumeration_clause->end_of_line = end_of_line;
    enumeration_clause->open_indent = open_indent;
    enumeration_clause->item_clauses = item_clauses;
    enumeration_clause->close_indent = close_indent;
    return enumeration_clause;
}

void Enumeration_Clause__traverse(
  Enumeration_Clause enumeration_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(enumeration_clause->enumeration, traverser);
    (void)Token__traverse(enumeration_clause->end_of_line, traverser);
    (void)Token__traverse(enumeration_clause->open_indent, traverser);
    (void)Array__traverse(enumeration_clause->item_clauses, traverser, ((void (*)(void *, Traverser))(Item_Clause__traverse)));
    (void)Token__traverse(enumeration_clause->close_indent, traverser);
}


Enumeration_Prefix_Clause Enumeration_Prefix_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword enumeration_prefix;
    Token prefix;
    Token end_of_line;
    Enumeration_Prefix_Clause enumeration_prefix_clause;
    index = parser->index;
    enumeration_prefix = Keyword__parse(parser, ((String)"\022enumeration_prefix"));
    if ((enumeration_prefix == Keyword__null)) {
        parser->index = index;
        return Enumeration_Prefix_Clause__null;
    }
    prefix = Token__parse(parser, Lexeme__symbol);
    if ((prefix == Token__null)) {
        parser->index = index;
        return Enumeration_Prefix_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Enumeration_Prefix_Clause__null;
    }
    enumeration_prefix_clause = Enumeration_Prefix_Clause__new();
    enumeration_prefix_clause->enumeration_prefix = enumeration_prefix;
    enumeration_prefix_clause->prefix = prefix;
    enumeration_prefix_clause->end_of_line = end_of_line;
    return enumeration_prefix_clause;
}

void Enumeration_Prefix_Clause__traverse(
  Enumeration_Prefix_Clause enumeration_prefix_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(enumeration_prefix_clause->enumeration_prefix, traverser);
    (void)Token__traverse(enumeration_prefix_clause->prefix, traverser);
    (void)Token__traverse(enumeration_prefix_clause->end_of_line, traverser);
}



String Item_Clause_Kind__string_convert(
  Item_Clause_Kind item_clause_kind)
{
    switch (item_clause_kind) {
        case Item_Clause_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Item_Clause_Kind___note:
            return ((String)"\004note");
            break;
        case Item_Clause_Kind___item:
            return ((String)"\004item");
            break;
        case Item_Clause_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Item_Clause Item_Clause__parse(
  Parser parser)
{
    Item_Clause item_clause;
    Token end_of_line;
    Note note;
    Item item;
    Error error;
    item_clause = Item_Clause__new();
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        item_clause->kind = Item_Clause_Kind___end_of_line; item_clause->kind__union.end_of_line = end_of_line;
        return item_clause;
    }
    note = Note__parse(parser);
    if ((note != Note__null)) {
        item_clause->kind = Item_Clause_Kind___note; item_clause->kind__union.note = note;
        return item_clause;
    }
    item = Item__parse(parser);
    if ((item != Item__null)) {
        item_clause->kind = Item_Clause_Kind___item; item_clause->kind__union.item = item;
        return item_clause;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        item_clause->kind = Item_Clause_Kind___error; item_clause->kind__union.error = error;
        return item_clause;
    }
    return Item_Clause__null;
}

void Item_Clause__traverse(
  Item_Clause item_clause,
  Traverser traverser)
{
    switch (item_clause->kind) {
        case Item_Clause_Kind___end_of_line:
            (void)Token__traverse(((item_clause->kind == Item_Clause_Kind___end_of_line) ? item_clause->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 820)), traverser);
            break;
        case Item_Clause_Kind___note:
            (void)Note__traverse(((item_clause->kind == Item_Clause_Kind___note) ? item_clause->kind__union.note : (Note)System__variant_object_fail((String)"\14Parse.ez.ezg", 822)), traverser);
            break;
        case Item_Clause_Kind___item:
            (void)Item__traverse(((item_clause->kind == Item_Clause_Kind___item) ? item_clause->kind__union.item : (Item)System__variant_object_fail((String)"\14Parse.ez.ezg", 824)), traverser);
            break;
        case Item_Clause_Kind___error:
            (void)Error__traverse(((item_clause->kind == Item_Clause_Kind___error) ? item_clause->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 826)), traverser);
            break;
    }
}


Item Item__parse(
  Parser parser)
{
    Unsigned index;
    Token name;
    Token end_of_line;
    Item item;
    index = parser->index;
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Item__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Item__null;
    }
    item = Item__new();
    item->name = name;
    item->end_of_line = end_of_line;
    return item;
}

void Item__traverse(
  Item item,
  Traverser traverser)
{
    (void)Token__traverse(item->name, traverser);
    (void)Token__traverse(item->end_of_line, traverser);
}


Record_Clause Record_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword record;
    Token end_of_line;
    Token open_indent;
    Array field_clauses;
    Token close_indent;
    Record_Clause record_clause;
    index = parser->index;
    record = Keyword__parse(parser, ((String)"\006record"));
    if ((record == Keyword__null)) {
        parser->index = index;
        return Record_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Record_Clause__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Record_Clause__null;
    }
    field_clauses = Array__parse(parser, ((void * (*)(Parser))(Field_Clause__parse)), ((void *)(Field_Clause__null)), Lexeme__close_indent);
    if ((Array__size_get(field_clauses) == 0)) {
        parser->index = index;
        return Record_Clause__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Record_Clause__null;
    }
    record_clause = Record_Clause__new();
    record_clause->record = record;
    record_clause->end_of_line = end_of_line;
    record_clause->open_indent = open_indent;
    record_clause->field_clauses = field_clauses;
    record_clause->close_indent = close_indent;
    return record_clause;
}

void Record_Clause__traverse(
  Record_Clause record_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(record_clause->record, traverser);
    (void)Token__traverse(record_clause->end_of_line, traverser);
    (void)Token__traverse(record_clause->open_indent, traverser);
    (void)Array__traverse(record_clause->field_clauses, traverser, ((void (*)(void *, Traverser))(Field_Clause__traverse)));
    (void)Token__traverse(record_clause->close_indent, traverser);
}


Record_Import_Clause Record_Import_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword record_import;
    Token string;
    Token end_of_line;
    Token open_indent;
    Array import_field_clauses;
    Token close_indent;
    Record_Import_Clause record_import_clause;
    index = parser->index;
    record_import = Keyword__parse(parser, ((String)"\015record_import"));
    if ((record_import == Keyword__null)) {
        parser->index = index;
        return Record_Import_Clause__null;
    }
    string = Token__parse(parser, Lexeme__string);
    if ((string == Token__null)) {
        parser->index = index;
        return Record_Import_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Record_Import_Clause__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Record_Import_Clause__null;
    }
    import_field_clauses = Array__parse(parser, ((void * (*)(Parser))(Import_Field_Clause__parse)), ((void *)(Import_Field_Clause__null)), Lexeme__close_indent);
    if ((Array__size_get(import_field_clauses) == 0)) {
        parser->index = index;
        return Record_Import_Clause__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Record_Import_Clause__null;
    }
    record_import_clause = Record_Import_Clause__new();
    record_import_clause->record_import = record_import;
    record_import_clause->string = string;
    record_import_clause->end_of_line = end_of_line;
    record_import_clause->open_indent = open_indent;
    record_import_clause->import_field_clauses = import_field_clauses;
    record_import_clause->close_indent = close_indent;
    return record_import_clause;
}

void Record_Import_Clause__traverse(
  Record_Import_Clause record_import_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(record_import_clause->record_import, traverser);
    (void)Token__traverse(record_import_clause->string, traverser);
    (void)Token__traverse(record_import_clause->end_of_line, traverser);
    (void)Token__traverse(record_import_clause->open_indent, traverser);
    (void)Array__traverse(record_import_clause->import_field_clauses, traverser, ((void (*)(void *, Traverser))(Import_Field_Clause__traverse)));
    (void)Token__traverse(record_import_clause->close_indent, traverser);
}


Registers_Clause Registers_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword registers;
    Token end_of_line;
    Token open_indent;
    Array register_clauses;
    Token close_indent;
    Registers_Clause registers_clause;
    index = parser->index;
    registers = Keyword__parse(parser, ((String)"\011registers"));
    if ((registers == Keyword__null)) {
        parser->index = index;
        return Registers_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Registers_Clause__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Registers_Clause__null;
    }
    register_clauses = Array__parse(parser, ((void * (*)(Parser))(Register_Clause__parse)), ((void *)(Register_Clause__null)), Lexeme__close_indent);
    if ((Array__size_get(register_clauses) == 0)) {
        parser->index = index;
        return Registers_Clause__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Registers_Clause__null;
    }
    registers_clause = Registers_Clause__new();
    registers_clause->registers = registers;
    registers_clause->end_of_line = end_of_line;
    registers_clause->open_indent = open_indent;
    registers_clause->register_clauses = register_clauses;
    registers_clause->close_indent = close_indent;
    return registers_clause;
}

void Registers_Clause__traverse(
  Registers_Clause registers_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(registers_clause->registers, traverser);
    (void)Token__traverse(registers_clause->end_of_line, traverser);
    (void)Token__traverse(registers_clause->open_indent, traverser);
    (void)Array__traverse(registers_clause->register_clauses, traverser, ((void (*)(void *, Traverser))(Register_Clause__traverse)));
    (void)Token__traverse(registers_clause->close_indent, traverser);
}



String Register_Clause_Kind__string_convert(
  Register_Clause_Kind register_clause_kind)
{
    switch (register_clause_kind) {
        case Register_Clause_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Register_Clause_Kind___note:
            return ((String)"\004note");
            break;
        case Register_Clause_Kind___bit:
            return ((String)"\003bit");
            break;
        case Register_Clause_Kind___byte:
            return ((String)"\004byte");
            break;
        case Register_Clause_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Register_Clause Register_Clause__parse(
  Parser parser)
{
    Register_Clause register_clause;
    Token end_of_line;
    Note note;
    Register_Bit bit;
    Register_Byte byte;
    Error error;
    register_clause = Register_Clause__new();
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        register_clause->kind = Register_Clause_Kind___end_of_line; register_clause->kind__union.end_of_line = end_of_line;
        return register_clause;
    }
    note = Note__parse(parser);
    if ((note != Note__null)) {
        register_clause->kind = Register_Clause_Kind___note; register_clause->kind__union.note = note;
        return register_clause;
    }
    bit = Register_Bit__parse(parser);
    if ((bit != Register_Bit__null)) {
        register_clause->kind = Register_Clause_Kind___bit; register_clause->kind__union.bit = bit;
        return register_clause;
    }
    byte = Register_Byte__parse(parser);
    if ((byte != Register_Byte__null)) {
        register_clause->kind = Register_Clause_Kind___byte; register_clause->kind__union.byte = byte;
        return register_clause;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        register_clause->kind = Register_Clause_Kind___error; register_clause->kind__union.error = error;
        return register_clause;
    }
    return Register_Clause__null;
}

void Register_Clause__traverse(
  Register_Clause register_clause,
  Traverser traverser)
{
    switch (register_clause->kind) {
        case Register_Clause_Kind___end_of_line:
            (void)Token__traverse(((register_clause->kind == Register_Clause_Kind___end_of_line) ? register_clause->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 1125)), traverser);
            break;
        case Register_Clause_Kind___note:
            (void)Note__traverse(((register_clause->kind == Register_Clause_Kind___note) ? register_clause->kind__union.note : (Note)System__variant_object_fail((String)"\14Parse.ez.ezg", 1127)), traverser);
            break;
        case Register_Clause_Kind___bit:
            (void)Register_Bit__traverse(((register_clause->kind == Register_Clause_Kind___bit) ? register_clause->kind__union.bit : (Register_Bit)System__variant_object_fail((String)"\14Parse.ez.ezg", 1129)), traverser);
            break;
        case Register_Clause_Kind___byte:
            (void)Register_Byte__traverse(((register_clause->kind == Register_Clause_Kind___byte) ? register_clause->kind__union.byte : (Register_Byte)System__variant_object_fail((String)"\14Parse.ez.ezg", 1131)), traverser);
            break;
        case Register_Clause_Kind___error:
            (void)Error__traverse(((register_clause->kind == Register_Clause_Kind___error) ? register_clause->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 1133)), traverser);
            break;
    }
}


Register_Bit Register_Bit__parse(
  Parser parser)
{
    Unsigned index;
    Keyword bit;
    Token name;
    Token equals;
    Token string;
    Token end_of_line;
    Register_Bit register_bit;
    index = parser->index;
    bit = Keyword__parse(parser, ((String)"\003bit"));
    if ((bit == Keyword__null)) {
        parser->index = index;
        return Register_Bit__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Register_Bit__null;
    }
    equals = Token__parse(parser, Lexeme__equals);
    if ((equals == Token__null)) {
        parser->index = index;
        return Register_Bit__null;
    }
    string = Token__parse(parser, Lexeme__string);
    if ((string == Token__null)) {
        parser->index = index;
        return Register_Bit__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Register_Bit__null;
    }
    register_bit = Register_Bit__new();
    register_bit->bit = bit;
    register_bit->name = name;
    register_bit->equals = equals;
    register_bit->string = string;
    register_bit->end_of_line = end_of_line;
    return register_bit;
}

void Register_Bit__traverse(
  Register_Bit register_bit,
  Traverser traverser)
{
    (void)Keyword__traverse(register_bit->bit, traverser);
    (void)Token__traverse(register_bit->name, traverser);
    (void)Token__traverse(register_bit->equals, traverser);
    (void)Token__traverse(register_bit->string, traverser);
    (void)Token__traverse(register_bit->end_of_line, traverser);
}


Register_Byte Register_Byte__parse(
  Parser parser)
{
    Unsigned index;
    Keyword byte;
    Token name;
    Token equals;
    Token string;
    Token end_of_line;
    Register_Byte register_byte;
    index = parser->index;
    byte = Keyword__parse(parser, ((String)"\004byte"));
    if ((byte == Keyword__null)) {
        parser->index = index;
        return Register_Byte__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Register_Byte__null;
    }
    equals = Token__parse(parser, Lexeme__equals);
    if ((equals == Token__null)) {
        parser->index = index;
        return Register_Byte__null;
    }
    string = Token__parse(parser, Lexeme__string);
    if ((string == Token__null)) {
        parser->index = index;
        return Register_Byte__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Register_Byte__null;
    }
    register_byte = Register_Byte__new();
    register_byte->byte = byte;
    register_byte->name = name;
    register_byte->equals = equals;
    register_byte->string = string;
    register_byte->end_of_line = end_of_line;
    return register_byte;
}

void Register_Byte__traverse(
  Register_Byte register_byte,
  Traverser traverser)
{
    (void)Keyword__traverse(register_byte->byte, traverser);
    (void)Token__traverse(register_byte->name, traverser);
    (void)Token__traverse(register_byte->equals, traverser);
    (void)Token__traverse(register_byte->string, traverser);
    (void)Token__traverse(register_byte->end_of_line, traverser);
}



String Field_Clause_Kind__string_convert(
  Field_Clause_Kind field_clause_kind)
{
    switch (field_clause_kind) {
        case Field_Clause_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Field_Clause_Kind___note:
            return ((String)"\004note");
            break;
        case Field_Clause_Kind___field:
            return ((String)"\005field");
            break;
        case Field_Clause_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Field_Clause Field_Clause__parse(
  Parser parser)
{
    Field_Clause field_clause;
    Token end_of_line;
    Note note;
    Field field;
    Error error;
    field_clause = Field_Clause__new();
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        field_clause->kind = Field_Clause_Kind___end_of_line; field_clause->kind__union.end_of_line = end_of_line;
        return field_clause;
    }
    note = Note__parse(parser);
    if ((note != Note__null)) {
        field_clause->kind = Field_Clause_Kind___note; field_clause->kind__union.note = note;
        return field_clause;
    }
    field = Field__parse(parser);
    if ((field != Field__null)) {
        field_clause->kind = Field_Clause_Kind___field; field_clause->kind__union.field = field;
        return field_clause;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        field_clause->kind = Field_Clause_Kind___error; field_clause->kind__union.error = error;
        return field_clause;
    }
    return Field_Clause__null;
}

void Field_Clause__traverse(
  Field_Clause field_clause,
  Traverser traverser)
{
    switch (field_clause->kind) {
        case Field_Clause_Kind___end_of_line:
            (void)Token__traverse(((field_clause->kind == Field_Clause_Kind___end_of_line) ? field_clause->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 1321)), traverser);
            break;
        case Field_Clause_Kind___note:
            (void)Note__traverse(((field_clause->kind == Field_Clause_Kind___note) ? field_clause->kind__union.note : (Note)System__variant_object_fail((String)"\14Parse.ez.ezg", 1323)), traverser);
            break;
        case Field_Clause_Kind___field:
            (void)Field__traverse(((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\14Parse.ez.ezg", 1325)), traverser);
            break;
        case Field_Clause_Kind___error:
            (void)Error__traverse(((field_clause->kind == Field_Clause_Kind___error) ? field_clause->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 1327)), traverser);
            break;
    }
}



String Import_Field_Clause_Kind__string_convert(
  Import_Field_Clause_Kind import_field_clause_kind)
{
    switch (import_field_clause_kind) {
        case Import_Field_Clause_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Import_Field_Clause_Kind___note:
            return ((String)"\004note");
            break;
        case Import_Field_Clause_Kind___import_field:
            return ((String)"\014import_field");
            break;
        case Import_Field_Clause_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Import_Field_Clause Import_Field_Clause__parse(
  Parser parser)
{
    Import_Field_Clause import_field_clause;
    Token end_of_line;
    Note note;
    Import_Field import_field;
    Error error;
    import_field_clause = Import_Field_Clause__new();
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        import_field_clause->kind = Import_Field_Clause_Kind___end_of_line; import_field_clause->kind__union.end_of_line = end_of_line;
        return import_field_clause;
    }
    note = Note__parse(parser);
    if ((note != Note__null)) {
        import_field_clause->kind = Import_Field_Clause_Kind___note; import_field_clause->kind__union.note = note;
        return import_field_clause;
    }
    import_field = Import_Field__parse(parser);
    if ((import_field != Import_Field__null)) {
        import_field_clause->kind = Import_Field_Clause_Kind___import_field; import_field_clause->kind__union.import_field = import_field;
        return import_field_clause;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        import_field_clause->kind = Import_Field_Clause_Kind___error; import_field_clause->kind__union.error = error;
        return import_field_clause;
    }
    return Import_Field_Clause__null;
}

void Import_Field_Clause__traverse(
  Import_Field_Clause import_field_clause,
  Traverser traverser)
{
    switch (import_field_clause->kind) {
        case Import_Field_Clause_Kind___end_of_line:
            (void)Token__traverse(((import_field_clause->kind == Import_Field_Clause_Kind___end_of_line) ? import_field_clause->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 1399)), traverser);
            break;
        case Import_Field_Clause_Kind___note:
            (void)Note__traverse(((import_field_clause->kind == Import_Field_Clause_Kind___note) ? import_field_clause->kind__union.note : (Note)System__variant_object_fail((String)"\14Parse.ez.ezg", 1401)), traverser);
            break;
        case Import_Field_Clause_Kind___import_field:
            (void)Import_Field__traverse(((import_field_clause->kind == Import_Field_Clause_Kind___import_field) ? import_field_clause->kind__union.import_field : (Import_Field)System__variant_object_fail((String)"\14Parse.ez.ezg", 1403)), traverser);
            break;
        case Import_Field_Clause_Kind___error:
            (void)Error__traverse(((import_field_clause->kind == Import_Field_Clause_Kind___error) ? import_field_clause->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 1405)), traverser);
            break;
    }
}


Variant_Clause Variant_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword variant;
    Token kind_name;
    Type kind_type;
    Token end_of_line;
    Token open_indent;
    Array field_clauses;
    Token close_indent;
    Variant_Clause variant_clause;
    index = parser->index;
    variant = Keyword__parse(parser, ((String)"\007variant"));
    if ((variant == Keyword__null)) {
        parser->index = index;
        return Variant_Clause__null;
    }
    kind_name = Token__parse(parser, Lexeme__symbol);
    if ((kind_name == Token__null)) {
        parser->index = index;
        return Variant_Clause__null;
    }
    kind_type = Type__parse(parser);
    if ((kind_type == Type__null)) {
        parser->index = index;
        return Variant_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Variant_Clause__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Variant_Clause__null;
    }
    field_clauses = Array__parse(parser, ((void * (*)(Parser))(Field_Clause__parse)), ((void *)(Field_Clause__null)), Lexeme__close_indent);
    if ((Array__size_get(field_clauses) == 0)) {
        parser->index = index;
        return Variant_Clause__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Variant_Clause__null;
    }
    variant_clause = Variant_Clause__new();
    variant_clause->variant = variant;
    variant_clause->kind_name = kind_name;
    variant_clause->kind_type = kind_type;
    variant_clause->end_of_line = end_of_line;
    variant_clause->open_indent = open_indent;
    variant_clause->field_clauses = field_clauses;
    variant_clause->close_indent = close_indent;
    return variant_clause;
}

void Variant_Clause__traverse(
  Variant_Clause variant_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(variant_clause->variant, traverser);
    (void)Token__traverse(variant_clause->kind_name, traverser);
    (void)Type__traverse(variant_clause->kind_type, traverser);
    (void)Token__traverse(variant_clause->end_of_line, traverser);
    (void)Token__traverse(variant_clause->open_indent, traverser);
    (void)Array__traverse(variant_clause->field_clauses, traverser, ((void (*)(void *, Traverser))(Field_Clause__traverse)));
    (void)Token__traverse(variant_clause->close_indent, traverser);
}


Field Field__parse(
  Parser parser)
{
    Unsigned index;
    Token name;
    Type type;
    Token end_of_line;
    Field field;
    index = parser->index;
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Field__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Field__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Field__null;
    }
    field = Field__new();
    field->name = name;
    field->type = type;
    field->end_of_line = end_of_line;
    return field;
}

void Field__traverse(
  Field field,
  Traverser traverser)
{
    (void)Token__traverse(field->name, traverser);
    (void)Type__traverse(field->type, traverser);
    (void)Token__traverse(field->end_of_line, traverser);
}


Import_Field Import_Field__parse(
  Parser parser)
{
    Unsigned index;
    Token c_name;
    Token equals;
    Token name;
    Type type;
    Token end_of_line;
    Import_Field import_field;
    index = parser->index;
    c_name = Token__parse(parser, Lexeme__symbol);
    if ((c_name == Token__null)) {
        parser->index = index;
        return Import_Field__null;
    }
    equals = Token__parse(parser, Lexeme__equals);
    if ((equals == Token__null)) {
        parser->index = index;
        return Import_Field__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Import_Field__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Import_Field__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Import_Field__null;
    }
    import_field = Import_Field__new();
    import_field->c_name = c_name;
    import_field->equals = equals;
    import_field->name = name;
    import_field->type = type;
    import_field->end_of_line = end_of_line;
    return import_field;
}

void Import_Field__traverse(
  Import_Field import_field,
  Traverser traverser)
{
    (void)Token__traverse(import_field->c_name, traverser);
    (void)Token__traverse(import_field->equals, traverser);
    (void)Token__traverse(import_field->name, traverser);
    (void)Type__traverse(import_field->type, traverser);
    (void)Token__traverse(import_field->end_of_line, traverser);
}


Simple_Clause Simple_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword simple;
    Type type;
    Token end_of_line;
    Simple_Clause simple_clause;
    index = parser->index;
    simple = Keyword__parse(parser, ((String)"\006simple"));
    if ((simple == Keyword__null)) {
        parser->index = index;
        return Simple_Clause__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Simple_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Simple_Clause__null;
    }
    simple_clause = Simple_Clause__new();
    simple_clause->simple = simple;
    simple_clause->type = type;
    simple_clause->end_of_line = end_of_line;
    return simple_clause;
}

void Simple_Clause__traverse(
  Simple_Clause simple_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(simple_clause->simple, traverser);
    (void)Type__traverse(simple_clause->type, traverser);
    (void)Token__traverse(simple_clause->end_of_line, traverser);
}


Generate_Clause Generate_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword generate;
    Comma_Separated names;
    Token end_of_line;
    Generate_Clause generate_clause;
    index = parser->index;
    generate = Keyword__parse(parser, ((String)"\010generate"));
    if ((generate == Keyword__null)) {
        parser->index = index;
        return Generate_Clause__null;
    }
    names = Comma_Separated__parse(parser, ((void * (*)(Parser))(Generate_Name__parse)), ((void *)(Generate_Name__null)), Lexeme__end_of_line);
    if ((Comma_Separated__size_get(names) == 0)) {
        parser->index = index;
        return Generate_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Generate_Clause__null;
    }
    generate_clause = Generate_Clause__new();
    generate_clause->generate = generate;
    generate_clause->names = names;
    generate_clause->end_of_line = end_of_line;
    return generate_clause;
}

void Generate_Clause__traverse(
  Generate_Clause generate_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(generate_clause->generate, traverser);
    (void)Comma_Separated__traverse(generate_clause->names, traverser, ((void (*)(void *, Traverser))(Generate_Name__traverse)));
    (void)Token__traverse(generate_clause->end_of_line, traverser);
}


Generate_Name Generate_Name__parse(
  Parser parser)
{
    Unsigned index;
    Token name;
    Generate_Name generate_name;
    index = parser->index;
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Generate_Name__null;
    }
    generate_name = Generate_Name__new();
    generate_name->name = name;
    return generate_name;
}

void Generate_Name__traverse(
  Generate_Name generate_name,
  Traverser traverser)
{
    (void)Token__traverse(generate_name->name, traverser);
}


External_Clause External_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword external;
    Token end_of_line;
    External_Clause external_clause;
    index = parser->index;
    external = Keyword__parse(parser, ((String)"\010external"));
    if ((external == Keyword__null)) {
        parser->index = index;
        return External_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return External_Clause__null;
    }
    external_clause = External_Clause__new();
    external_clause->external = external;
    external_clause->end_of_line = end_of_line;
    return external_clause;
}

void External_Clause__traverse(
  External_Clause external_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(external_clause->external, traverser);
    (void)Token__traverse(external_clause->end_of_line, traverser);
}


External_Declaration External_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword external;
    Typed_Name typed_name;
    Type type;
    Token end_of_line;
    External_Declaration external_declaration;
    index = parser->index;
    external = Keyword__parse(parser, ((String)"\010external"));
    if ((external == Keyword__null)) {
        parser->index = index;
        return External_Declaration__null;
    }
    typed_name = Typed_Name__parse(parser);
    if ((typed_name == Typed_Name__null)) {
        parser->index = index;
        return External_Declaration__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return External_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return External_Declaration__null;
    }
    external_declaration = External_Declaration__new();
    external_declaration->external = external;
    external_declaration->typed_name = typed_name;
    external_declaration->type = type;
    external_declaration->end_of_line = end_of_line;
    return external_declaration;
}

void External_Declaration__traverse(
  External_Declaration external_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(external_declaration->external, traverser);
    (void)Typed_Name__traverse(external_declaration->typed_name, traverser);
    (void)Type__traverse(external_declaration->type, traverser);
    (void)Token__traverse(external_declaration->end_of_line, traverser);
}


External_Named_Declaration External_Named_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword external;
    Typed_Name typed_name;
    Token equals;
    Token string;
    Token end_of_line;
    External_Named_Declaration external_named_declaration;
    index = parser->index;
    external = Keyword__parse(parser, ((String)"\010external"));
    if ((external == Keyword__null)) {
        parser->index = index;
        return External_Named_Declaration__null;
    }
    typed_name = Typed_Name__parse(parser);
    if ((typed_name == Typed_Name__null)) {
        parser->index = index;
        return External_Named_Declaration__null;
    }
    equals = Token__parse(parser, Lexeme__equals);
    if ((equals == Token__null)) {
        parser->index = index;
        return External_Named_Declaration__null;
    }
    string = Token__parse(parser, Lexeme__string);
    if ((string == Token__null)) {
        parser->index = index;
        return External_Named_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return External_Named_Declaration__null;
    }
    external_named_declaration = External_Named_Declaration__new();
    external_named_declaration->external = external;
    external_named_declaration->typed_name = typed_name;
    external_named_declaration->equals = equals;
    external_named_declaration->string = string;
    external_named_declaration->end_of_line = end_of_line;
    return external_named_declaration;
}

void External_Named_Declaration__traverse(
  External_Named_Declaration external_named_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(external_named_declaration->external, traverser);
    (void)Typed_Name__traverse(external_named_declaration->typed_name, traverser);
    (void)Token__traverse(external_named_declaration->equals, traverser);
    (void)Token__traverse(external_named_declaration->string, traverser);
    (void)Token__traverse(external_named_declaration->end_of_line, traverser);
}


Global_Declaration Global_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword global;
    Typed_Name typed_name;
    Type type;
    Token end_of_line;
    Global_Declaration global_declaration;
    index = parser->index;
    global = Keyword__parse(parser, ((String)"\006global"));
    if ((global == Keyword__null)) {
        parser->index = index;
        return Global_Declaration__null;
    }
    typed_name = Typed_Name__parse(parser);
    if ((typed_name == Typed_Name__null)) {
        parser->index = index;
        return Global_Declaration__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Global_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Global_Declaration__null;
    }
    global_declaration = Global_Declaration__new();
    global_declaration->global = global;
    global_declaration->typed_name = typed_name;
    global_declaration->type = type;
    global_declaration->end_of_line = end_of_line;
    return global_declaration;
}

void Global_Declaration__traverse(
  Global_Declaration global_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(global_declaration->global, traverser);
    (void)Typed_Name__traverse(global_declaration->typed_name, traverser);
    (void)Type__traverse(global_declaration->type, traverser);
    (void)Token__traverse(global_declaration->end_of_line, traverser);
}


Include_String_Declaration Include_String_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword include;
    Token string;
    Token end_of_line;
    Include_String_Declaration include_string_declaration;
    index = parser->index;
    include = Keyword__parse(parser, ((String)"\007include"));
    if ((include == Keyword__null)) {
        parser->index = index;
        return Include_String_Declaration__null;
    }
    string = Token__parse(parser, Lexeme__string);
    if ((string == Token__null)) {
        parser->index = index;
        return Include_String_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Include_String_Declaration__null;
    }
    include_string_declaration = Include_String_Declaration__new();
    include_string_declaration->include = include;
    include_string_declaration->string = string;
    include_string_declaration->end_of_line = end_of_line;
    return include_string_declaration;
}

void Include_String_Declaration__traverse(
  Include_String_Declaration include_string_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(include_string_declaration->include, traverser);
    (void)Token__traverse(include_string_declaration->string, traverser);
    (void)Token__traverse(include_string_declaration->end_of_line, traverser);
}


Global_Library_Declaration Global_Library_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword global_library;
    Token name;
    Token end_of_line;
    Global_Library_Declaration global_library_declaration;
    index = parser->index;
    global_library = Keyword__parse(parser, ((String)"\016global_library"));
    if ((global_library == Keyword__null)) {
        parser->index = index;
        return Global_Library_Declaration__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Global_Library_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Global_Library_Declaration__null;
    }
    global_library_declaration = Global_Library_Declaration__new();
    global_library_declaration->global_library = global_library;
    global_library_declaration->name = name;
    global_library_declaration->end_of_line = end_of_line;
    return global_library_declaration;
}

void Global_Library_Declaration__traverse(
  Global_Library_Declaration global_library_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(global_library_declaration->global_library, traverser);
    (void)Token__traverse(global_library_declaration->name, traverser);
    (void)Token__traverse(global_library_declaration->end_of_line, traverser);
}


Library_Declaration Library_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword library;
    Token name;
    Token end_of_line;
    Library_Declaration library_declaration;
    index = parser->index;
    library = Keyword__parse(parser, ((String)"\007library"));
    if ((library == Keyword__null)) {
        parser->index = index;
        return Library_Declaration__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Library_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Library_Declaration__null;
    }
    library_declaration = Library_Declaration__new();
    library_declaration->library = library;
    library_declaration->name = name;
    library_declaration->end_of_line = end_of_line;
    return library_declaration;
}

void Library_Declaration__traverse(
  Library_Declaration library_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(library_declaration->library, traverser);
    (void)Token__traverse(library_declaration->name, traverser);
    (void)Token__traverse(library_declaration->end_of_line, traverser);
}


Interface_Declaration Interface_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword interface;
    Token name;
    Token end_of_line;
    Interface_Declaration interface_declaration;
    index = parser->index;
    interface = Keyword__parse(parser, ((String)"\011interface"));
    if ((interface == Keyword__null)) {
        parser->index = index;
        return Interface_Declaration__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Interface_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Interface_Declaration__null;
    }
    interface_declaration = Interface_Declaration__new();
    interface_declaration->interface = interface;
    interface_declaration->name = name;
    interface_declaration->end_of_line = end_of_line;
    return interface_declaration;
}

void Interface_Declaration__traverse(
  Interface_Declaration interface_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(interface_declaration->interface, traverser);
    (void)Token__traverse(interface_declaration->name, traverser);
    (void)Token__traverse(interface_declaration->end_of_line, traverser);
}


Load_Declaration Load_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword load;
    Token string;
    Token end_of_line;
    Load_Declaration load_declaration;
    index = parser->index;
    load = Keyword__parse(parser, ((String)"\004load"));
    if ((load == Keyword__null)) {
        parser->index = index;
        return Load_Declaration__null;
    }
    string = Token__parse(parser, Lexeme__string);
    if ((string == Token__null)) {
        parser->index = index;
        return Load_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Load_Declaration__null;
    }
    load_declaration = Load_Declaration__new();
    load_declaration->load = load;
    load_declaration->string = string;
    load_declaration->end_of_line = end_of_line;
    return load_declaration;
}

void Load_Declaration__traverse(
  Load_Declaration load_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(load_declaration->load, traverser);
    (void)Token__traverse(load_declaration->string, traverser);
    (void)Token__traverse(load_declaration->end_of_line, traverser);
}


Collection_Declaration Collection_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword collection;
    Token name;
    Token float_number;
    Token end_of_line;
    Collection_Declaration collection_declaration;
    index = parser->index;
    collection = Keyword__parse(parser, ((String)"\012collection"));
    if ((collection == Keyword__null)) {
        parser->index = index;
        return Collection_Declaration__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Collection_Declaration__null;
    }
    float_number = Token__parse(parser, Lexeme__float_number);
    if ((float_number == Token__null)) {
        parser->index = index;
        return Collection_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Collection_Declaration__null;
    }
    collection_declaration = Collection_Declaration__new();
    collection_declaration->collection = collection;
    collection_declaration->name = name;
    collection_declaration->float_number = float_number;
    collection_declaration->end_of_line = end_of_line;
    return collection_declaration;
}

void Collection_Declaration__traverse(
  Collection_Declaration collection_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(collection_declaration->collection, traverser);
    (void)Token__traverse(collection_declaration->name, traverser);
    (void)Token__traverse(collection_declaration->float_number, traverser);
    (void)Token__traverse(collection_declaration->end_of_line, traverser);
}


Require_Declaration Require_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword require;
    Token name;
    Token end_of_line;
    Require_Declaration require_declaration;
    index = parser->index;
    require = Keyword__parse(parser, ((String)"\007require"));
    if ((require == Keyword__null)) {
        parser->index = index;
        return Require_Declaration__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Require_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Require_Declaration__null;
    }
    require_declaration = Require_Declaration__new();
    require_declaration->require = require;
    require_declaration->name = name;
    require_declaration->end_of_line = end_of_line;
    return require_declaration;
}

void Require_Declaration__traverse(
  Require_Declaration require_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(require_declaration->require, traverser);
    (void)Token__traverse(require_declaration->name, traverser);
    (void)Token__traverse(require_declaration->end_of_line, traverser);
}


Constant_Declaration Constant_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword constant;
    Typed_Name typed_name;
    Type type;
    Token equals;
    Expression expression;
    Token end_of_line;
    Constant_Declaration constant_declaration;
    index = parser->index;
    constant = Keyword__parse(parser, ((String)"\010constant"));
    if ((constant == Keyword__null)) {
        parser->index = index;
        return Constant_Declaration__null;
    }
    typed_name = Typed_Name__parse(parser);
    if ((typed_name == Typed_Name__null)) {
        parser->index = index;
        return Constant_Declaration__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Constant_Declaration__null;
    }
    equals = Token__parse(parser, Lexeme__equals);
    if ((equals == Token__null)) {
        parser->index = index;
        return Constant_Declaration__null;
    }
    expression = Expression__parse(parser);
    if ((expression == Expression__null)) {
        parser->index = index;
        return Constant_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Constant_Declaration__null;
    }
    constant_declaration = Constant_Declaration__new();
    constant_declaration->constant = constant;
    constant_declaration->typed_name = typed_name;
    constant_declaration->type = type;
    constant_declaration->equals = equals;
    constant_declaration->expression = expression;
    constant_declaration->end_of_line = end_of_line;
    return constant_declaration;
}

void Constant_Declaration__traverse(
  Constant_Declaration constant_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(constant_declaration->constant, traverser);
    (void)Typed_Name__traverse(constant_declaration->typed_name, traverser);
    (void)Type__traverse(constant_declaration->type, traverser);
    (void)Token__traverse(constant_declaration->equals, traverser);
    (void)Expression__traverse(constant_declaration->expression, traverser);
    (void)Token__traverse(constant_declaration->end_of_line, traverser);
}


Defines_Prefix_Declaration Defines_Prefix_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword defines_prefix;
    Token prefix;
    Token equals;
    Token match;
    Token at_sign;
    Token type_name;
    Token end_of_line;
    Defines_Prefix_Declaration defines_prefix_declaration;
    index = parser->index;
    defines_prefix = Keyword__parse(parser, ((String)"\016defines_prefix"));
    if ((defines_prefix == Keyword__null)) {
        parser->index = index;
        return Defines_Prefix_Declaration__null;
    }
    prefix = Token__parse(parser, Lexeme__symbol);
    if ((prefix == Token__null)) {
        parser->index = index;
        return Defines_Prefix_Declaration__null;
    }
    equals = Token__parse(parser, Lexeme__equals);
    if ((equals == Token__null)) {
        parser->index = index;
        return Defines_Prefix_Declaration__null;
    }
    match = Token__parse(parser, Lexeme__symbol);
    if ((match == Token__null)) {
        parser->index = index;
        return Defines_Prefix_Declaration__null;
    }
    at_sign = Token__parse(parser, Lexeme__at_sign);
    if ((at_sign == Token__null)) {
        parser->index = index;
        return Defines_Prefix_Declaration__null;
    }
    type_name = Token__parse(parser, Lexeme__symbol);
    if ((type_name == Token__null)) {
        parser->index = index;
        return Defines_Prefix_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Defines_Prefix_Declaration__null;
    }
    defines_prefix_declaration = Defines_Prefix_Declaration__new();
    defines_prefix_declaration->defines_prefix = defines_prefix;
    defines_prefix_declaration->prefix = prefix;
    defines_prefix_declaration->equals = equals;
    defines_prefix_declaration->match = match;
    defines_prefix_declaration->at_sign = at_sign;
    defines_prefix_declaration->type_name = type_name;
    defines_prefix_declaration->end_of_line = end_of_line;
    return defines_prefix_declaration;
}

void Defines_Prefix_Declaration__traverse(
  Defines_Prefix_Declaration defines_prefix_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(defines_prefix_declaration->defines_prefix, traverser);
    (void)Token__traverse(defines_prefix_declaration->prefix, traverser);
    (void)Token__traverse(defines_prefix_declaration->equals, traverser);
    (void)Token__traverse(defines_prefix_declaration->match, traverser);
    (void)Token__traverse(defines_prefix_declaration->at_sign, traverser);
    (void)Token__traverse(defines_prefix_declaration->type_name, traverser);
    (void)Token__traverse(defines_prefix_declaration->end_of_line, traverser);
}


Routine_Declaration Routine_Declaration__parse(
  Parser parser)
{
    Unsigned index;
    Keyword routine;
    Typed_Name typed_name;
    Token end_of_line;
    Token open_indent;
    Array routine_clauses;
    Token close_indent;
    Routine_Declaration routine_declaration;
    index = parser->index;
    routine = Keyword__parse(parser, ((String)"\007routine"));
    if ((routine == Keyword__null)) {
        parser->index = index;
        return Routine_Declaration__null;
    }
    typed_name = Typed_Name__parse(parser);
    if ((typed_name == Typed_Name__null)) {
        parser->index = index;
        return Routine_Declaration__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Routine_Declaration__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Routine_Declaration__null;
    }
    routine_clauses = Array__parse(parser, ((void * (*)(Parser))(Routine_Clause__parse)), ((void *)(Routine_Clause__null)), Lexeme__close_indent);
    if ((Array__size_get(routine_clauses) == 0)) {
        parser->index = index;
        return Routine_Declaration__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Routine_Declaration__null;
    }
    routine_declaration = Routine_Declaration__new();
    routine_declaration->routine = routine;
    routine_declaration->typed_name = typed_name;
    routine_declaration->end_of_line = end_of_line;
    routine_declaration->open_indent = open_indent;
    routine_declaration->routine_clauses = routine_clauses;
    routine_declaration->close_indent = close_indent;
    return routine_declaration;
}

void Routine_Declaration__traverse(
  Routine_Declaration routine_declaration,
  Traverser traverser)
{
    (void)Keyword__traverse(routine_declaration->routine, traverser);
    (void)Typed_Name__traverse(routine_declaration->typed_name, traverser);
    (void)Token__traverse(routine_declaration->end_of_line, traverser);
    (void)Token__traverse(routine_declaration->open_indent, traverser);
    (void)Array__traverse(routine_declaration->routine_clauses, traverser, ((void (*)(void *, Traverser))(Routine_Clause__traverse)));
    (void)Token__traverse(routine_declaration->close_indent, traverser);
}



String Routine_Clause_Kind__string_convert(
  Routine_Clause_Kind routine_clause_kind)
{
    switch (routine_clause_kind) {
        case Routine_Clause_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Routine_Clause_Kind___note:
            return ((String)"\004note");
            break;
        case Routine_Clause_Kind___takes_nothing:
            return ((String)"\015takes_nothing");
            break;
        case Routine_Clause_Kind___take_import:
            return ((String)"\013take_import");
            break;
        case Routine_Clause_Kind___take:
            return ((String)"\004take");
            break;
        case Routine_Clause_Kind___interrupt:
            return ((String)"\011interrupt");
            break;
        case Routine_Clause_Kind___returns_nothing:
            return ((String)"\017returns_nothing");
            break;
        case Routine_Clause_Kind___returns:
            return ((String)"\007returns");
            break;
        case Routine_Clause_Kind___external:
            return ((String)"\010external");
            break;
        case Routine_Clause_Kind___c_array_access:
            return ((String)"\016c_array_access");
            break;
        case Routine_Clause_Kind___scalar_cast:
            return ((String)"\013scalar_cast");
            break;
        case Routine_Clause_Kind___local:
            return ((String)"\005local");
            break;
        case Routine_Clause_Kind___assert:
            return ((String)"\006assert");
            break;
        case Routine_Clause_Kind___call:
            return ((String)"\004call");
            break;
        case Routine_Clause_Kind___do_nothing:
            return ((String)"\012do_nothing");
            break;
        case Routine_Clause_Kind___if:
            return ((String)"\002if");
            break;
        case Routine_Clause_Kind___return:
            return ((String)"\006return");
            break;
        case Routine_Clause_Kind___fail:
            return ((String)"\004fail");
            break;
        case Routine_Clause_Kind___set:
            return ((String)"\003set");
            break;
        case Routine_Clause_Kind___switch:
            return ((String)"\006switch");
            break;
        case Routine_Clause_Kind___while:
            return ((String)"\005while");
            break;
        case Routine_Clause_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Routine_Clause Routine_Clause__parse(
  Parser parser)
{
    Routine_Clause routine_clause;
    Token end_of_line;
    Note note;
    Takes_Nothing_Clause takes_nothing;
    Take_Import_Clause take_import;
    Take_Clause take;
    Interrupt_Clause interrupt;
    Returns_Nothing_Clause returns_nothing;
    Returns_Clause returns;
    External_Routine_Clause external;
    C_Array_Access_Clause c_array_access;
    Scalar_Cast_Clause scalar_cast;
    Local_Clause local;
    Assert_Statement assert;
    Call_Statement call;
    Do_Nothing_Statement do_nothing;
    If_Statement if___k;
    Return_Statement return___k;
    Fail_Statement fail;
    Set_Statement set;
    Switch_Statement switch___k;
    While_Statement while___k;
    Error error;
    routine_clause = Routine_Clause__new();
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        routine_clause->kind = Routine_Clause_Kind___end_of_line; routine_clause->kind__union.end_of_line = end_of_line;
        return routine_clause;
    }
    note = Note__parse(parser);
    if ((note != Note__null)) {
        routine_clause->kind = Routine_Clause_Kind___note; routine_clause->kind__union.note = note;
        return routine_clause;
    }
    takes_nothing = Takes_Nothing_Clause__parse(parser);
    if ((takes_nothing != Takes_Nothing_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___takes_nothing; routine_clause->kind__union.takes_nothing = takes_nothing;
        return routine_clause;
    }
    take_import = Take_Import_Clause__parse(parser);
    if ((take_import != Take_Import_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___take_import; routine_clause->kind__union.take_import = take_import;
        return routine_clause;
    }
    take = Take_Clause__parse(parser);
    if ((take != Take_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___take; routine_clause->kind__union.take = take;
        return routine_clause;
    }
    interrupt = Interrupt_Clause__parse(parser);
    if ((interrupt != Interrupt_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___interrupt; routine_clause->kind__union.interrupt = interrupt;
        return routine_clause;
    }
    returns_nothing = Returns_Nothing_Clause__parse(parser);
    if ((returns_nothing != Returns_Nothing_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___returns_nothing; routine_clause->kind__union.returns_nothing = returns_nothing;
        return routine_clause;
    }
    returns = Returns_Clause__parse(parser);
    if ((returns != Returns_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___returns; routine_clause->kind__union.returns = returns;
        return routine_clause;
    }
    external = External_Routine_Clause__parse(parser);
    if ((external != External_Routine_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___external; routine_clause->kind__union.external = external;
        return routine_clause;
    }
    c_array_access = C_Array_Access_Clause__parse(parser);
    if ((c_array_access != C_Array_Access_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___c_array_access; routine_clause->kind__union.c_array_access = c_array_access;
        return routine_clause;
    }
    scalar_cast = Scalar_Cast_Clause__parse(parser);
    if ((scalar_cast != Scalar_Cast_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___scalar_cast; routine_clause->kind__union.scalar_cast = scalar_cast;
        return routine_clause;
    }
    local = Local_Clause__parse(parser);
    if ((local != Local_Clause__null)) {
        routine_clause->kind = Routine_Clause_Kind___local; routine_clause->kind__union.local = local;
        return routine_clause;
    }
    assert = Assert_Statement__parse(parser);
    if ((assert != Assert_Statement__null)) {
        routine_clause->kind = Routine_Clause_Kind___assert; routine_clause->kind__union.assert = assert;
        return routine_clause;
    }
    call = Call_Statement__parse(parser);
    if ((call != Call_Statement__null)) {
        routine_clause->kind = Routine_Clause_Kind___call; routine_clause->kind__union.call = call;
        return routine_clause;
    }
    do_nothing = Do_Nothing_Statement__parse(parser);
    if ((do_nothing != Do_Nothing_Statement__null)) {
        routine_clause->kind = Routine_Clause_Kind___do_nothing; routine_clause->kind__union.do_nothing = do_nothing;
        return routine_clause;
    }
    if___k = If_Statement__parse(parser);
    if ((if___k != If_Statement__null)) {
        routine_clause->kind = Routine_Clause_Kind___if; routine_clause->kind__union.if___k = if___k;
        return routine_clause;
    }
    return___k = Return_Statement__parse(parser);
    if ((return___k != Return_Statement__null)) {
        routine_clause->kind = Routine_Clause_Kind___return; routine_clause->kind__union.return___k = return___k;
        return routine_clause;
    }
    fail = Fail_Statement__parse(parser);
    if ((fail != Fail_Statement__null)) {
        routine_clause->kind = Routine_Clause_Kind___fail; routine_clause->kind__union.fail = fail;
        return routine_clause;
    }
    set = Set_Statement__parse(parser);
    if ((set != Set_Statement__null)) {
        routine_clause->kind = Routine_Clause_Kind___set; routine_clause->kind__union.set = set;
        return routine_clause;
    }
    switch___k = Switch_Statement__parse(parser);
    if ((switch___k != Switch_Statement__null)) {
        routine_clause->kind = Routine_Clause_Kind___switch; routine_clause->kind__union.switch___k = switch___k;
        return routine_clause;
    }
    while___k = While_Statement__parse(parser);
    if ((while___k != While_Statement__null)) {
        routine_clause->kind = Routine_Clause_Kind___while; routine_clause->kind__union.while___k = while___k;
        return routine_clause;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        routine_clause->kind = Routine_Clause_Kind___error; routine_clause->kind__union.error = error;
        return routine_clause;
    }
    return Routine_Clause__null;
}

void Routine_Clause__traverse(
  Routine_Clause routine_clause,
  Traverser traverser)
{
    switch (routine_clause->kind) {
        case Routine_Clause_Kind___end_of_line:
            (void)Token__traverse(((routine_clause->kind == Routine_Clause_Kind___end_of_line) ? routine_clause->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 2645)), traverser);
            break;
        case Routine_Clause_Kind___note:
            (void)Note__traverse(((routine_clause->kind == Routine_Clause_Kind___note) ? routine_clause->kind__union.note : (Note)System__variant_object_fail((String)"\14Parse.ez.ezg", 2647)), traverser);
            break;
        case Routine_Clause_Kind___takes_nothing:
            (void)Takes_Nothing_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___takes_nothing) ? routine_clause->kind__union.takes_nothing : (Takes_Nothing_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2649)), traverser);
            break;
        case Routine_Clause_Kind___take_import:
            (void)Take_Import_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___take_import) ? routine_clause->kind__union.take_import : (Take_Import_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2651)), traverser);
            break;
        case Routine_Clause_Kind___take:
            (void)Take_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___take) ? routine_clause->kind__union.take : (Take_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2653)), traverser);
            break;
        case Routine_Clause_Kind___interrupt:
            (void)Interrupt_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___interrupt) ? routine_clause->kind__union.interrupt : (Interrupt_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2655)), traverser);
            break;
        case Routine_Clause_Kind___returns_nothing:
            (void)Returns_Nothing_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___returns_nothing) ? routine_clause->kind__union.returns_nothing : (Returns_Nothing_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2657)), traverser);
            break;
        case Routine_Clause_Kind___returns:
            (void)Returns_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___returns) ? routine_clause->kind__union.returns : (Returns_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2659)), traverser);
            break;
        case Routine_Clause_Kind___external:
            (void)External_Routine_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___external) ? routine_clause->kind__union.external : (External_Routine_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2661)), traverser);
            break;
        case Routine_Clause_Kind___c_array_access:
            (void)C_Array_Access_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___c_array_access) ? routine_clause->kind__union.c_array_access : (C_Array_Access_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2663)), traverser);
            break;
        case Routine_Clause_Kind___scalar_cast:
            (void)Scalar_Cast_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___scalar_cast) ? routine_clause->kind__union.scalar_cast : (Scalar_Cast_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2665)), traverser);
            break;
        case Routine_Clause_Kind___local:
            (void)Local_Clause__traverse(((routine_clause->kind == Routine_Clause_Kind___local) ? routine_clause->kind__union.local : (Local_Clause)System__variant_object_fail((String)"\14Parse.ez.ezg", 2667)), traverser);
            break;
        case Routine_Clause_Kind___assert:
            (void)Assert_Statement__traverse(((routine_clause->kind == Routine_Clause_Kind___assert) ? routine_clause->kind__union.assert : (Assert_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 2669)), traverser);
            break;
        case Routine_Clause_Kind___call:
            (void)Call_Statement__traverse(((routine_clause->kind == Routine_Clause_Kind___call) ? routine_clause->kind__union.call : (Call_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 2671)), traverser);
            break;
        case Routine_Clause_Kind___do_nothing:
            (void)Do_Nothing_Statement__traverse(((routine_clause->kind == Routine_Clause_Kind___do_nothing) ? routine_clause->kind__union.do_nothing : (Do_Nothing_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 2673)), traverser);
            break;
        case Routine_Clause_Kind___if:
            (void)If_Statement__traverse(((routine_clause->kind == Routine_Clause_Kind___if) ? routine_clause->kind__union.if___k : (If_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 2675)), traverser);
            break;
        case Routine_Clause_Kind___return:
            (void)Return_Statement__traverse(((routine_clause->kind == Routine_Clause_Kind___return) ? routine_clause->kind__union.return___k : (Return_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 2677)), traverser);
            break;
        case Routine_Clause_Kind___fail:
            (void)Fail_Statement__traverse(((routine_clause->kind == Routine_Clause_Kind___fail) ? routine_clause->kind__union.fail : (Fail_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 2679)), traverser);
            break;
        case Routine_Clause_Kind___set:
            (void)Set_Statement__traverse(((routine_clause->kind == Routine_Clause_Kind___set) ? routine_clause->kind__union.set : (Set_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 2681)), traverser);
            break;
        case Routine_Clause_Kind___switch:
            (void)Switch_Statement__traverse(((routine_clause->kind == Routine_Clause_Kind___switch) ? routine_clause->kind__union.switch___k : (Switch_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 2683)), traverser);
            break;
        case Routine_Clause_Kind___while:
            (void)While_Statement__traverse(((routine_clause->kind == Routine_Clause_Kind___while) ? routine_clause->kind__union.while___k : (While_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 2685)), traverser);
            break;
        case Routine_Clause_Kind___error:
            (void)Error__traverse(((routine_clause->kind == Routine_Clause_Kind___error) ? routine_clause->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 2687)), traverser);
            break;
    }
}


Takes_Nothing_Clause Takes_Nothing_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword takes_nothing;
    Token end_of_line;
    Takes_Nothing_Clause takes_nothing_clause;
    index = parser->index;
    takes_nothing = Keyword__parse(parser, ((String)"\015takes_nothing"));
    if ((takes_nothing == Keyword__null)) {
        parser->index = index;
        return Takes_Nothing_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Takes_Nothing_Clause__null;
    }
    takes_nothing_clause = Takes_Nothing_Clause__new();
    takes_nothing_clause->takes_nothing = takes_nothing;
    takes_nothing_clause->end_of_line = end_of_line;
    return takes_nothing_clause;
}

void Takes_Nothing_Clause__traverse(
  Takes_Nothing_Clause takes_nothing_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(takes_nothing_clause->takes_nothing, traverser);
    (void)Token__traverse(takes_nothing_clause->end_of_line, traverser);
}


Take_Clause Take_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword takes;
    Token name;
    Type type;
    Token end_of_line;
    Take_Clause take_clause;
    index = parser->index;
    takes = Keyword__parse(parser, ((String)"\005takes"));
    if ((takes == Keyword__null)) {
        parser->index = index;
        return Take_Clause__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Take_Clause__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Take_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Take_Clause__null;
    }
    take_clause = Take_Clause__new();
    take_clause->takes = takes;
    take_clause->name = name;
    take_clause->type = type;
    take_clause->end_of_line = end_of_line;
    return take_clause;
}

void Take_Clause__traverse(
  Take_Clause take_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(take_clause->takes, traverser);
    (void)Token__traverse(take_clause->name, traverser);
    (void)Type__traverse(take_clause->type, traverser);
    (void)Token__traverse(take_clause->end_of_line, traverser);
}


Take_Import_Clause Take_Import_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword takes_import;
    Token name;
    Type type;
    Token equals;
    Token string;
    Token end_of_line;
    Take_Import_Clause take_import_clause;
    index = parser->index;
    takes_import = Keyword__parse(parser, ((String)"\014takes_import"));
    if ((takes_import == Keyword__null)) {
        parser->index = index;
        return Take_Import_Clause__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Take_Import_Clause__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Take_Import_Clause__null;
    }
    equals = Token__parse(parser, Lexeme__equals);
    if ((equals == Token__null)) {
        parser->index = index;
        return Take_Import_Clause__null;
    }
    string = Token__parse(parser, Lexeme__string);
    if ((string == Token__null)) {
        parser->index = index;
        return Take_Import_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Take_Import_Clause__null;
    }
    take_import_clause = Take_Import_Clause__new();
    take_import_clause->takes_import = takes_import;
    take_import_clause->name = name;
    take_import_clause->type = type;
    take_import_clause->equals = equals;
    take_import_clause->string = string;
    take_import_clause->end_of_line = end_of_line;
    return take_import_clause;
}

void Take_Import_Clause__traverse(
  Take_Import_Clause take_import_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(take_import_clause->takes_import, traverser);
    (void)Token__traverse(take_import_clause->name, traverser);
    (void)Type__traverse(take_import_clause->type, traverser);
    (void)Token__traverse(take_import_clause->equals, traverser);
    (void)Token__traverse(take_import_clause->string, traverser);
    (void)Token__traverse(take_import_clause->end_of_line, traverser);
}


Returns_Nothing_Clause Returns_Nothing_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword returns_nothing;
    Token end_of_line;
    Returns_Nothing_Clause returns_nothing_clause;
    index = parser->index;
    returns_nothing = Keyword__parse(parser, ((String)"\017returns_nothing"));
    if ((returns_nothing == Keyword__null)) {
        parser->index = index;
        return Returns_Nothing_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Returns_Nothing_Clause__null;
    }
    returns_nothing_clause = Returns_Nothing_Clause__new();
    returns_nothing_clause->returns_nothing = returns_nothing;
    returns_nothing_clause->end_of_line = end_of_line;
    return returns_nothing_clause;
}

void Returns_Nothing_Clause__traverse(
  Returns_Nothing_Clause returns_nothing_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(returns_nothing_clause->returns_nothing, traverser);
    (void)Token__traverse(returns_nothing_clause->end_of_line, traverser);
}


Returns_Clause Returns_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword returns;
    Comma_Separated return_types;
    Token end_of_line;
    Returns_Clause returns_clause;
    index = parser->index;
    returns = Keyword__parse(parser, ((String)"\007returns"));
    if ((returns == Keyword__null)) {
        parser->index = index;
        return Returns_Clause__null;
    }
    return_types = Comma_Separated__parse(parser, ((void * (*)(Parser))(Type__parse)), ((void *)(Type__null)), Lexeme__end_of_line);
    if ((Comma_Separated__size_get(return_types) == 0)) {
        parser->index = index;
        return Returns_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Returns_Clause__null;
    }
    returns_clause = Returns_Clause__new();
    returns_clause->returns = returns;
    returns_clause->return_types = return_types;
    returns_clause->end_of_line = end_of_line;
    return returns_clause;
}

void Returns_Clause__traverse(
  Returns_Clause returns_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(returns_clause->returns, traverser);
    (void)Comma_Separated__traverse(returns_clause->return_types, traverser, ((void (*)(void *, Traverser))(Type__traverse)));
    (void)Token__traverse(returns_clause->end_of_line, traverser);
}


External_Routine_Clause External_Routine_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword external;
    Token name;
    Token end_of_line;
    External_Routine_Clause external_routine_clause;
    index = parser->index;
    external = Keyword__parse(parser, ((String)"\010external"));
    if ((external == Keyword__null)) {
        parser->index = index;
        return External_Routine_Clause__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return External_Routine_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return External_Routine_Clause__null;
    }
    external_routine_clause = External_Routine_Clause__new();
    external_routine_clause->external = external;
    external_routine_clause->name = name;
    external_routine_clause->end_of_line = end_of_line;
    return external_routine_clause;
}

void External_Routine_Clause__traverse(
  External_Routine_Clause external_routine_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(external_routine_clause->external, traverser);
    (void)Token__traverse(external_routine_clause->name, traverser);
    (void)Token__traverse(external_routine_clause->end_of_line, traverser);
}


Scalar_Cast_Clause Scalar_Cast_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword scalar_cast;
    Type type;
    Token end_of_line;
    Scalar_Cast_Clause scalar_cast_clause;
    index = parser->index;
    scalar_cast = Keyword__parse(parser, ((String)"\013scalar_cast"));
    if ((scalar_cast == Keyword__null)) {
        parser->index = index;
        return Scalar_Cast_Clause__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Scalar_Cast_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Scalar_Cast_Clause__null;
    }
    scalar_cast_clause = Scalar_Cast_Clause__new();
    scalar_cast_clause->scalar_cast = scalar_cast;
    scalar_cast_clause->type = type;
    scalar_cast_clause->end_of_line = end_of_line;
    return scalar_cast_clause;
}

void Scalar_Cast_Clause__traverse(
  Scalar_Cast_Clause scalar_cast_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(scalar_cast_clause->scalar_cast, traverser);
    (void)Type__traverse(scalar_cast_clause->type, traverser);
    (void)Token__traverse(scalar_cast_clause->end_of_line, traverser);
}


Interrupt_Clause Interrupt_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword interrupt;
    Token name;
    Token end_of_line;
    Interrupt_Clause interrupt_clause;
    index = parser->index;
    interrupt = Keyword__parse(parser, ((String)"\011interrupt"));
    if ((interrupt == Keyword__null)) {
        parser->index = index;
        return Interrupt_Clause__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Interrupt_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Interrupt_Clause__null;
    }
    interrupt_clause = Interrupt_Clause__new();
    interrupt_clause->interrupt = interrupt;
    interrupt_clause->name = name;
    interrupt_clause->end_of_line = end_of_line;
    return interrupt_clause;
}

void Interrupt_Clause__traverse(
  Interrupt_Clause interrupt_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(interrupt_clause->interrupt, traverser);
    (void)Token__traverse(interrupt_clause->name, traverser);
    (void)Token__traverse(interrupt_clause->end_of_line, traverser);
}


C_Array_Access_Clause C_Array_Access_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword c_array_access;
    Token end_of_line;
    C_Array_Access_Clause c_array_access_clause;
    index = parser->index;
    c_array_access = Keyword__parse(parser, ((String)"\016c_array_access"));
    if ((c_array_access == Keyword__null)) {
        parser->index = index;
        return C_Array_Access_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return C_Array_Access_Clause__null;
    }
    c_array_access_clause = C_Array_Access_Clause__new();
    c_array_access_clause->c_array_access = c_array_access;
    c_array_access_clause->end_of_line = end_of_line;
    return c_array_access_clause;
}

void C_Array_Access_Clause__traverse(
  C_Array_Access_Clause c_array_access_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(c_array_access_clause->c_array_access, traverser);
    (void)Token__traverse(c_array_access_clause->end_of_line, traverser);
}


Local_Clause Local_Clause__parse(
  Parser parser)
{
    Unsigned index;
    Keyword local;
    Token name;
    Type type;
    Token end_of_line;
    Local_Clause local_clause;
    index = parser->index;
    local = Keyword__parse(parser, ((String)"\005local"));
    if ((local == Keyword__null)) {
        parser->index = index;
        return Local_Clause__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Local_Clause__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Local_Clause__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Local_Clause__null;
    }
    local_clause = Local_Clause__new();
    local_clause->local = local;
    local_clause->name = name;
    local_clause->type = type;
    local_clause->end_of_line = end_of_line;
    return local_clause;
}

void Local_Clause__traverse(
  Local_Clause local_clause,
  Traverser traverser)
{
    (void)Keyword__traverse(local_clause->local, traverser);
    (void)Token__traverse(local_clause->name, traverser);
    (void)Type__traverse(local_clause->type, traverser);
    (void)Token__traverse(local_clause->end_of_line, traverser);
}



String Statement_Kind__string_convert(
  Statement_Kind statement_kind)
{
    switch (statement_kind) {
        case Statement_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Statement_Kind___note:
            return ((String)"\004note");
            break;
        case Statement_Kind___assert:
            return ((String)"\006assert");
            break;
        case Statement_Kind___break_level:
            return ((String)"\013break_level");
            break;
        case Statement_Kind___break_empty:
            return ((String)"\013break_empty");
            break;
        case Statement_Kind___call:
            return ((String)"\004call");
            break;
        case Statement_Kind___continue_level:
            return ((String)"\016continue_level");
            break;
        case Statement_Kind___continue_empty:
            return ((String)"\016continue_empty");
            break;
        case Statement_Kind___do_nothing:
            return ((String)"\012do_nothing");
            break;
        case Statement_Kind___if:
            return ((String)"\002if");
            break;
        case Statement_Kind___return:
            return ((String)"\006return");
            break;
        case Statement_Kind___set:
            return ((String)"\003set");
            break;
        case Statement_Kind___switch:
            return ((String)"\006switch");
            break;
        case Statement_Kind___while:
            return ((String)"\005while");
            break;
        case Statement_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Statement Statement__parse(
  Parser parser)
{
    Statement statement;
    Token end_of_line;
    Note note;
    Assert_Statement assert;
    Break_Level_Statement break_level;
    Break_Empty_Statement break_empty;
    Call_Statement call;
    Continue_Level_Statement continue_level;
    Continue_Empty_Statement continue_empty;
    Do_Nothing_Statement do_nothing;
    If_Statement if___k;
    Return_Statement return___k;
    Set_Statement set;
    Switch_Statement switch___k;
    While_Statement while___k;
    Error error;
    statement = Statement__new();
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        statement->kind = Statement_Kind___end_of_line; statement->kind__union.end_of_line = end_of_line;
        return statement;
    }
    note = Note__parse(parser);
    if ((note != Note__null)) {
        statement->kind = Statement_Kind___note; statement->kind__union.note = note;
        return statement;
    }
    assert = Assert_Statement__parse(parser);
    if ((assert != Assert_Statement__null)) {
        statement->kind = Statement_Kind___assert; statement->kind__union.assert = assert;
        return statement;
    }
    break_level = Break_Level_Statement__parse(parser);
    if ((break_level != Break_Level_Statement__null)) {
        statement->kind = Statement_Kind___break_level; statement->kind__union.break_level = break_level;
        return statement;
    }
    break_empty = Break_Empty_Statement__parse(parser);
    if ((break_empty != Break_Empty_Statement__null)) {
        statement->kind = Statement_Kind___break_empty; statement->kind__union.break_empty = break_empty;
        return statement;
    }
    call = Call_Statement__parse(parser);
    if ((call != Call_Statement__null)) {
        statement->kind = Statement_Kind___call; statement->kind__union.call = call;
        return statement;
    }
    continue_level = Continue_Level_Statement__parse(parser);
    if ((continue_level != Continue_Level_Statement__null)) {
        statement->kind = Statement_Kind___continue_level; statement->kind__union.continue_level = continue_level;
        return statement;
    }
    continue_empty = Continue_Empty_Statement__parse(parser);
    if ((continue_empty != Continue_Empty_Statement__null)) {
        statement->kind = Statement_Kind___continue_empty; statement->kind__union.continue_empty = continue_empty;
        return statement;
    }
    do_nothing = Do_Nothing_Statement__parse(parser);
    if ((do_nothing != Do_Nothing_Statement__null)) {
        statement->kind = Statement_Kind___do_nothing; statement->kind__union.do_nothing = do_nothing;
        return statement;
    }
    if___k = If_Statement__parse(parser);
    if ((if___k != If_Statement__null)) {
        statement->kind = Statement_Kind___if; statement->kind__union.if___k = if___k;
        return statement;
    }
    return___k = Return_Statement__parse(parser);
    if ((return___k != Return_Statement__null)) {
        statement->kind = Statement_Kind___return; statement->kind__union.return___k = return___k;
        return statement;
    }
    set = Set_Statement__parse(parser);
    if ((set != Set_Statement__null)) {
        statement->kind = Statement_Kind___set; statement->kind__union.set = set;
        return statement;
    }
    switch___k = Switch_Statement__parse(parser);
    if ((switch___k != Switch_Statement__null)) {
        statement->kind = Statement_Kind___switch; statement->kind__union.switch___k = switch___k;
        return statement;
    }
    while___k = While_Statement__parse(parser);
    if ((while___k != While_Statement__null)) {
        statement->kind = Statement_Kind___while; statement->kind__union.while___k = while___k;
        return statement;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        statement->kind = Statement_Kind___error; statement->kind__union.error = error;
        return statement;
    }
    return Statement__null;
}

void Statement__traverse(
  Statement statement,
  Traverser traverser)
{
    switch (statement->kind) {
        case Statement_Kind___end_of_line:
            (void)Token__traverse(((statement->kind == Statement_Kind___end_of_line) ? statement->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 3312)), traverser);
            break;
        case Statement_Kind___note:
            (void)Note__traverse(((statement->kind == Statement_Kind___note) ? statement->kind__union.note : (Note)System__variant_object_fail((String)"\14Parse.ez.ezg", 3314)), traverser);
            break;
        case Statement_Kind___assert:
            (void)Assert_Statement__traverse(((statement->kind == Statement_Kind___assert) ? statement->kind__union.assert : (Assert_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3316)), traverser);
            break;
        case Statement_Kind___break_level:
            (void)Break_Level_Statement__traverse(((statement->kind == Statement_Kind___break_level) ? statement->kind__union.break_level : (Break_Level_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3318)), traverser);
            break;
        case Statement_Kind___break_empty:
            (void)Break_Empty_Statement__traverse(((statement->kind == Statement_Kind___break_empty) ? statement->kind__union.break_empty : (Break_Empty_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3320)), traverser);
            break;
        case Statement_Kind___call:
            (void)Call_Statement__traverse(((statement->kind == Statement_Kind___call) ? statement->kind__union.call : (Call_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3322)), traverser);
            break;
        case Statement_Kind___continue_level:
            (void)Continue_Level_Statement__traverse(((statement->kind == Statement_Kind___continue_level) ? statement->kind__union.continue_level : (Continue_Level_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3324)), traverser);
            break;
        case Statement_Kind___continue_empty:
            (void)Continue_Empty_Statement__traverse(((statement->kind == Statement_Kind___continue_empty) ? statement->kind__union.continue_empty : (Continue_Empty_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3326)), traverser);
            break;
        case Statement_Kind___do_nothing:
            (void)Do_Nothing_Statement__traverse(((statement->kind == Statement_Kind___do_nothing) ? statement->kind__union.do_nothing : (Do_Nothing_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3328)), traverser);
            break;
        case Statement_Kind___if:
            (void)If_Statement__traverse(((statement->kind == Statement_Kind___if) ? statement->kind__union.if___k : (If_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3330)), traverser);
            break;
        case Statement_Kind___return:
            (void)Return_Statement__traverse(((statement->kind == Statement_Kind___return) ? statement->kind__union.return___k : (Return_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3332)), traverser);
            break;
        case Statement_Kind___set:
            (void)Set_Statement__traverse(((statement->kind == Statement_Kind___set) ? statement->kind__union.set : (Set_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3334)), traverser);
            break;
        case Statement_Kind___switch:
            (void)Switch_Statement__traverse(((statement->kind == Statement_Kind___switch) ? statement->kind__union.switch___k : (Switch_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3336)), traverser);
            break;
        case Statement_Kind___while:
            (void)While_Statement__traverse(((statement->kind == Statement_Kind___while) ? statement->kind__union.while___k : (While_Statement)System__variant_object_fail((String)"\14Parse.ez.ezg", 3338)), traverser);
            break;
        case Statement_Kind___error:
            (void)Error__traverse(((statement->kind == Statement_Kind___error) ? statement->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 3340)), traverser);
            break;
    }
}


Assert_Statement Assert_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword assert;
    Expression expression;
    Token end_of_line;
    Assert_Statement assert_statement;
    index = parser->index;
    assert = Keyword__parse(parser, ((String)"\006assert"));
    if ((assert == Keyword__null)) {
        parser->index = index;
        return Assert_Statement__null;
    }
    expression = Expression__parse(parser);
    if ((expression == Expression__null)) {
        parser->index = index;
        return Assert_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Assert_Statement__null;
    }
    assert_statement = Assert_Statement__new();
    assert_statement->assert = assert;
    assert_statement->expression = expression;
    assert_statement->end_of_line = end_of_line;
    return assert_statement;
}

void Assert_Statement__traverse(
  Assert_Statement assert_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(assert_statement->assert, traverser);
    (void)Expression__traverse(assert_statement->expression, traverser);
    (void)Token__traverse(assert_statement->end_of_line, traverser);
}


Break_Empty_Statement Break_Empty_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword break___k;
    Token end_of_line;
    Break_Empty_Statement break_empty_statement;
    index = parser->index;
    break___k = Keyword__parse(parser, ((String)"\005break"));
    if ((break___k == Keyword__null)) {
        parser->index = index;
        return Break_Empty_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Break_Empty_Statement__null;
    }
    break_empty_statement = Break_Empty_Statement__new();
    break_empty_statement->break___k = break___k;
    break_empty_statement->end_of_line = end_of_line;
    return break_empty_statement;
}

void Break_Empty_Statement__traverse(
  Break_Empty_Statement break_empty_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(break_empty_statement->break___k, traverser);
    (void)Token__traverse(break_empty_statement->end_of_line, traverser);
}


Break_Level_Statement Break_Level_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword break___k;
    Token number;
    Token end_of_line;
    Break_Level_Statement break_level_statement;
    index = parser->index;
    break___k = Keyword__parse(parser, ((String)"\005break"));
    if ((break___k == Keyword__null)) {
        parser->index = index;
        return Break_Level_Statement__null;
    }
    number = Token__parse(parser, Lexeme__number);
    if ((number == Token__null)) {
        parser->index = index;
        return Break_Level_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Break_Level_Statement__null;
    }
    break_level_statement = Break_Level_Statement__new();
    break_level_statement->break___k = break___k;
    break_level_statement->number = number;
    break_level_statement->end_of_line = end_of_line;
    return break_level_statement;
}

void Break_Level_Statement__traverse(
  Break_Level_Statement break_level_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(break_level_statement->break___k, traverser);
    (void)Token__traverse(break_level_statement->number, traverser);
    (void)Token__traverse(break_level_statement->end_of_line, traverser);
}


Call_Statement Call_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword call;
    Expression expression;
    Token end_of_line;
    Call_Statement call_statement;
    index = parser->index;
    call = Keyword__parse(parser, ((String)"\004call"));
    if ((call == Keyword__null)) {
        parser->index = index;
        return Call_Statement__null;
    }
    expression = Expression__parse(parser);
    if ((expression == Expression__null)) {
        parser->index = index;
        return Call_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Call_Statement__null;
    }
    call_statement = Call_Statement__new();
    call_statement->call = call;
    call_statement->expression = expression;
    call_statement->end_of_line = end_of_line;
    return call_statement;
}

void Call_Statement__traverse(
  Call_Statement call_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(call_statement->call, traverser);
    (void)Expression__traverse(call_statement->expression, traverser);
    (void)Token__traverse(call_statement->end_of_line, traverser);
}


Continue_Empty_Statement Continue_Empty_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword continue___k;
    Token end_of_line;
    Continue_Empty_Statement continue_empty_statement;
    index = parser->index;
    continue___k = Keyword__parse(parser, ((String)"\010continue"));
    if ((continue___k == Keyword__null)) {
        parser->index = index;
        return Continue_Empty_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Continue_Empty_Statement__null;
    }
    continue_empty_statement = Continue_Empty_Statement__new();
    continue_empty_statement->continue___k = continue___k;
    continue_empty_statement->end_of_line = end_of_line;
    return continue_empty_statement;
}

void Continue_Empty_Statement__traverse(
  Continue_Empty_Statement continue_empty_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(continue_empty_statement->continue___k, traverser);
    (void)Token__traverse(continue_empty_statement->end_of_line, traverser);
}


Continue_Level_Statement Continue_Level_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword continue___k;
    Token number;
    Token end_of_line;
    Continue_Level_Statement continue_level_statement;
    index = parser->index;
    continue___k = Keyword__parse(parser, ((String)"\010continue"));
    if ((continue___k == Keyword__null)) {
        parser->index = index;
        return Continue_Level_Statement__null;
    }
    number = Token__parse(parser, Lexeme__number);
    if ((number == Token__null)) {
        parser->index = index;
        return Continue_Level_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Continue_Level_Statement__null;
    }
    continue_level_statement = Continue_Level_Statement__new();
    continue_level_statement->continue___k = continue___k;
    continue_level_statement->number = number;
    continue_level_statement->end_of_line = end_of_line;
    return continue_level_statement;
}

void Continue_Level_Statement__traverse(
  Continue_Level_Statement continue_level_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(continue_level_statement->continue___k, traverser);
    (void)Token__traverse(continue_level_statement->number, traverser);
    (void)Token__traverse(continue_level_statement->end_of_line, traverser);
}


Do_Nothing_Statement Do_Nothing_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword do_nothing;
    Token end_of_line;
    Do_Nothing_Statement do_nothing_statement;
    index = parser->index;
    do_nothing = Keyword__parse(parser, ((String)"\012do_nothing"));
    if ((do_nothing == Keyword__null)) {
        parser->index = index;
        return Do_Nothing_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Do_Nothing_Statement__null;
    }
    do_nothing_statement = Do_Nothing_Statement__new();
    do_nothing_statement->do_nothing = do_nothing;
    do_nothing_statement->end_of_line = end_of_line;
    return do_nothing_statement;
}

void Do_Nothing_Statement__traverse(
  Do_Nothing_Statement do_nothing_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(do_nothing_statement->do_nothing, traverser);
    (void)Token__traverse(do_nothing_statement->end_of_line, traverser);
}


Fail_Statement Fail_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword fail;
    Token string;
    Token end_of_line;
    Fail_Statement fail_statement;
    index = parser->index;
    fail = Keyword__parse(parser, ((String)"\004fail"));
    if ((fail == Keyword__null)) {
        parser->index = index;
        return Fail_Statement__null;
    }
    string = Token__parse(parser, Lexeme__string);
    if ((string == Token__null)) {
        parser->index = index;
        return Fail_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Fail_Statement__null;
    }
    fail_statement = Fail_Statement__new();
    fail_statement->fail = fail;
    fail_statement->string = string;
    fail_statement->end_of_line = end_of_line;
    return fail_statement;
}

void Fail_Statement__traverse(
  Fail_Statement fail_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(fail_statement->fail, traverser);
    (void)Token__traverse(fail_statement->string, traverser);
    (void)Token__traverse(fail_statement->end_of_line, traverser);
}


void If_Statement__traverse(
  If_Statement if_statement,
  Traverser traverser)
{
    (void)Array__traverse(if_statement->if_clauses, traverser, ((void (*)(void *, Traverser))(If_Clause__traverse)));
}



String If_Clause_Kind__string_convert(
  If_Clause_Kind if_clause_kind)
{
    switch (if_clause_kind) {
        case If_Clause_Kind___if_part:
            return ((String)"\007if_part");
            break;
        case If_Clause_Kind___else_if_part:
            return ((String)"\014else_if_part");
            break;
        case If_Clause_Kind___else_part:
            return ((String)"\011else_part");
            break;
    }
    return ((String)"\000");
}

void If_Clause__traverse(
  If_Clause if_clause,
  Traverser traverser)
{
    switch (if_clause->kind) {
        case If_Clause_Kind___if_part:
            (void)If_Part__traverse(((if_clause->kind == If_Clause_Kind___if_part) ? if_clause->kind__union.if_part : (If_Part)System__variant_object_fail((String)"\14Parse.ez.ezg", 3726)), traverser);
            break;
        case If_Clause_Kind___else_if_part:
            (void)Else_If_Part__traverse(((if_clause->kind == If_Clause_Kind___else_if_part) ? if_clause->kind__union.else_if_part : (Else_If_Part)System__variant_object_fail((String)"\14Parse.ez.ezg", 3728)), traverser);
            break;
        case If_Clause_Kind___else_part:
            (void)Else_Part__traverse(((if_clause->kind == If_Clause_Kind___else_part) ? if_clause->kind__union.else_part : (Else_Part)System__variant_object_fail((String)"\14Parse.ez.ezg", 3730)), traverser);
            break;
    }
}


If_Part If_Part__parse(
  Parser parser)
{
    Unsigned index;
    Keyword if___k;
    Expression expression;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
    If_Part if_part;
    index = parser->index;
    if___k = Keyword__parse(parser, ((String)"\002if"));
    if ((if___k == Keyword__null)) {
        parser->index = index;
        return If_Part__null;
    }
    expression = Expression__parse(parser);
    if ((expression == Expression__null)) {
        parser->index = index;
        return If_Part__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return If_Part__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return If_Part__null;
    }
    statements = Array__parse(parser, ((void * (*)(Parser))(Statement__parse)), ((void *)(Statement__null)), Lexeme__close_indent);
    if ((Array__size_get(statements) == 0)) {
        parser->index = index;
        return If_Part__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return If_Part__null;
    }
    if_part = If_Part__new();
    if_part->if___k = if___k;
    if_part->expression = expression;
    if_part->end_of_line = end_of_line;
    if_part->open_indent = open_indent;
    if_part->statements = statements;
    if_part->close_indent = close_indent;
    return if_part;
}

void If_Part__traverse(
  If_Part if_part,
  Traverser traverser)
{
    (void)Keyword__traverse(if_part->if___k, traverser);
    (void)Expression__traverse(if_part->expression, traverser);
    (void)Token__traverse(if_part->end_of_line, traverser);
    (void)Token__traverse(if_part->open_indent, traverser);
    (void)Array__traverse(if_part->statements, traverser, ((void (*)(void *, Traverser))(Statement__traverse)));
    (void)Token__traverse(if_part->close_indent, traverser);
}


Else_If_Part Else_If_Part__parse(
  Parser parser)
{
    Unsigned index;
    Keyword else_if;
    Expression expression;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
    Else_If_Part else_if_part;
    index = parser->index;
    else_if = Keyword__parse(parser, ((String)"\007else_if"));
    if ((else_if == Keyword__null)) {
        parser->index = index;
        return Else_If_Part__null;
    }
    expression = Expression__parse(parser);
    if ((expression == Expression__null)) {
        parser->index = index;
        return Else_If_Part__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Else_If_Part__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Else_If_Part__null;
    }
    statements = Array__parse(parser, ((void * (*)(Parser))(Statement__parse)), ((void *)(Statement__null)), Lexeme__close_indent);
    if ((Array__size_get(statements) == 0)) {
        parser->index = index;
        return Else_If_Part__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Else_If_Part__null;
    }
    else_if_part = Else_If_Part__new();
    else_if_part->else_if = else_if;
    else_if_part->expression = expression;
    else_if_part->end_of_line = end_of_line;
    else_if_part->open_indent = open_indent;
    else_if_part->statements = statements;
    else_if_part->close_indent = close_indent;
    return else_if_part;
}

void Else_If_Part__traverse(
  Else_If_Part else_if_part,
  Traverser traverser)
{
    (void)Keyword__traverse(else_if_part->else_if, traverser);
    (void)Expression__traverse(else_if_part->expression, traverser);
    (void)Token__traverse(else_if_part->end_of_line, traverser);
    (void)Token__traverse(else_if_part->open_indent, traverser);
    (void)Array__traverse(else_if_part->statements, traverser, ((void (*)(void *, Traverser))(Statement__traverse)));
    (void)Token__traverse(else_if_part->close_indent, traverser);
}


Else_Part Else_Part__parse(
  Parser parser)
{
    Unsigned index;
    Keyword else___k;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
    Else_Part else_part;
    index = parser->index;
    else___k = Keyword__parse(parser, ((String)"\004else"));
    if ((else___k == Keyword__null)) {
        parser->index = index;
        return Else_Part__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Else_Part__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Else_Part__null;
    }
    statements = Array__parse(parser, ((void * (*)(Parser))(Statement__parse)), ((void *)(Statement__null)), Lexeme__close_indent);
    if ((Array__size_get(statements) == 0)) {
        parser->index = index;
        return Else_Part__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Else_Part__null;
    }
    else_part = Else_Part__new();
    else_part->else___k = else___k;
    else_part->end_of_line = end_of_line;
    else_part->open_indent = open_indent;
    else_part->statements = statements;
    else_part->close_indent = close_indent;
    return else_part;
}

void Else_Part__traverse(
  Else_Part else_part,
  Traverser traverser)
{
    (void)Keyword__traverse(else_part->else___k, traverser);
    (void)Token__traverse(else_part->end_of_line, traverser);
    (void)Token__traverse(else_part->open_indent, traverser);
    (void)Array__traverse(else_part->statements, traverser, ((void (*)(void *, Traverser))(Statement__traverse)));
    (void)Token__traverse(else_part->close_indent, traverser);
}



String Return_Clause_Kind__string_convert(
  Return_Clause_Kind return_clause_kind)
{
    switch (return_clause_kind) {
        case Return_Clause_Kind___expression:
            return ((String)"\012expression");
            break;
        case Return_Clause_Kind___empty:
            return ((String)"\005empty");
            break;
    }
    return ((String)"\000");
}

Return_Statement Return_Statement__parse(
  Parser parser)
{
    Return_Statement return_statement;
    Return_Clause_Expression expression;
    Return_Clause_Empty empty;
    return_statement = Return_Statement__new();
    expression = Return_Clause_Expression__parse(parser);
    if ((expression != Return_Clause_Expression__null)) {
        return_statement->kind = Return_Clause_Kind___expression; return_statement->kind__union.expression = expression;
        return return_statement;
    }
    empty = Return_Clause_Empty__parse(parser);
    if ((empty != Return_Clause_Empty__null)) {
        return_statement->kind = Return_Clause_Kind___empty; return_statement->kind__union.empty = empty;
        return return_statement;
    }
    return Return_Statement__null;
}

void Return_Statement__traverse(
  Return_Statement return_statement,
  Traverser traverser)
{
    switch (return_statement->kind) {
        case Return_Clause_Kind___expression:
            (void)Return_Clause_Expression__traverse(((return_statement->kind == Return_Clause_Kind___expression) ? return_statement->kind__union.expression : (Return_Clause_Expression)System__variant_object_fail((String)"\14Parse.ez.ezg", 3972)), traverser);
            break;
        case Return_Clause_Kind___empty:
            (void)Return_Clause_Empty__traverse(((return_statement->kind == Return_Clause_Kind___empty) ? return_statement->kind__union.empty : (Return_Clause_Empty)System__variant_object_fail((String)"\14Parse.ez.ezg", 3974)), traverser);
            break;
    }
}


Return_Clause_Expression Return_Clause_Expression__parse(
  Parser parser)
{
    Unsigned index;
    Keyword return___k;
    Expression expression;
    Token end_of_line;
    Return_Clause_Expression return_clause_expression;
    index = parser->index;
    return___k = Keyword__parse(parser, ((String)"\006return"));
    if ((return___k == Keyword__null)) {
        parser->index = index;
        return Return_Clause_Expression__null;
    }
    expression = Expression__parse(parser);
    if ((expression == Expression__null)) {
        parser->index = index;
        return Return_Clause_Expression__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Return_Clause_Expression__null;
    }
    return_clause_expression = Return_Clause_Expression__new();
    return_clause_expression->return___k = return___k;
    return_clause_expression->expression = expression;
    return_clause_expression->end_of_line = end_of_line;
    return return_clause_expression;
}

void Return_Clause_Expression__traverse(
  Return_Clause_Expression return_clause_expression,
  Traverser traverser)
{
    (void)Keyword__traverse(return_clause_expression->return___k, traverser);
    (void)Expression__traverse(return_clause_expression->expression, traverser);
    (void)Token__traverse(return_clause_expression->end_of_line, traverser);
}


Return_Clause_Empty Return_Clause_Empty__parse(
  Parser parser)
{
    Unsigned index;
    Keyword return___k;
    Token end_of_line;
    Return_Clause_Empty return_clause_empty;
    index = parser->index;
    return___k = Keyword__parse(parser, ((String)"\006return"));
    if ((return___k == Keyword__null)) {
        parser->index = index;
        return Return_Clause_Empty__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Return_Clause_Empty__null;
    }
    return_clause_empty = Return_Clause_Empty__new();
    return_clause_empty->return___k = return___k;
    return_clause_empty->end_of_line = end_of_line;
    return return_clause_empty;
}

void Return_Clause_Empty__traverse(
  Return_Clause_Empty return_clause_empty,
  Traverser traverser)
{
    (void)Keyword__traverse(return_clause_empty->return___k, traverser);
    (void)Token__traverse(return_clause_empty->end_of_line, traverser);
}


Set_Statement Set_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Token set;
    Expression expression;
    Token end_of_line;
    Set_Statement set_statement;
    index = parser->index;
    set = Token__parse(parser, Lexeme__set);
    if ((set == Token__null)) {
        parser->index = index;
        return Set_Statement__null;
    }
    expression = Expression__parse(parser);
    if ((expression == Expression__null)) {
        parser->index = index;
        return Set_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Set_Statement__null;
    }
    set_statement = Set_Statement__new();
    set_statement->set = set;
    set_statement->expression = expression;
    set_statement->end_of_line = end_of_line;
    return set_statement;
}

void Set_Statement__traverse(
  Set_Statement set_statement,
  Traverser traverser)
{
    (void)Token__traverse(set_statement->set, traverser);
    (void)Expression__traverse(set_statement->expression, traverser);
    (void)Token__traverse(set_statement->end_of_line, traverser);
}


Switch_Statement Switch_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword switch___k;
    Expression expression;
    Token end_of_line;
    Token open_indent;
    Array switch_clauses;
    Token close_indent;
    Switch_Statement switch_statement;
    index = parser->index;
    switch___k = Keyword__parse(parser, ((String)"\006switch"));
    if ((switch___k == Keyword__null)) {
        parser->index = index;
        return Switch_Statement__null;
    }
    expression = Expression__parse(parser);
    if ((expression == Expression__null)) {
        parser->index = index;
        return Switch_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Switch_Statement__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Switch_Statement__null;
    }
    switch_clauses = Array__parse(parser, ((void * (*)(Parser))(Switch_Clause__parse)), ((void *)(Switch_Clause__null)), Lexeme__close_indent);
    if ((Array__size_get(switch_clauses) == 0)) {
        parser->index = index;
        return Switch_Statement__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Switch_Statement__null;
    }
    switch_statement = Switch_Statement__new();
    switch_statement->switch___k = switch___k;
    switch_statement->expression = expression;
    switch_statement->end_of_line = end_of_line;
    switch_statement->open_indent = open_indent;
    switch_statement->switch_clauses = switch_clauses;
    switch_statement->close_indent = close_indent;
    return switch_statement;
}

void Switch_Statement__traverse(
  Switch_Statement switch_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(switch_statement->switch___k, traverser);
    (void)Expression__traverse(switch_statement->expression, traverser);
    (void)Token__traverse(switch_statement->end_of_line, traverser);
    (void)Token__traverse(switch_statement->open_indent, traverser);
    (void)Array__traverse(switch_statement->switch_clauses, traverser, ((void (*)(void *, Traverser))(Switch_Clause__traverse)));
    (void)Token__traverse(switch_statement->close_indent, traverser);
}



String Switch_Clause_Kind__string_convert(
  Switch_Clause_Kind switch_clause_kind)
{
    switch (switch_clause_kind) {
        case Switch_Clause_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Switch_Clause_Kind___note:
            return ((String)"\004note");
            break;
        case Switch_Clause_Kind___case:
            return ((String)"\004case");
            break;
        case Switch_Clause_Kind___default:
            return ((String)"\007default");
            break;
        case Switch_Clause_Kind___all_cases_required:
            return ((String)"\022all_cases_required");
            break;
        case Switch_Clause_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Switch_Clause Switch_Clause__parse(
  Parser parser)
{
    Switch_Clause switch_clause;
    Token end_of_line;
    Note note;
    Switch_Case case___k;
    Switch_Default default___k;
    Switch_All_Cases_Required all_cases_required;
    Error error;
    switch_clause = Switch_Clause__new();
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        switch_clause->kind = Switch_Clause_Kind___end_of_line; switch_clause->kind__union.end_of_line = end_of_line;
        return switch_clause;
    }
    note = Note__parse(parser);
    if ((note != Note__null)) {
        switch_clause->kind = Switch_Clause_Kind___note; switch_clause->kind__union.note = note;
        return switch_clause;
    }
    case___k = Switch_Case__parse(parser);
    if ((case___k != Switch_Case__null)) {
        switch_clause->kind = Switch_Clause_Kind___case; switch_clause->kind__union.case___k = case___k;
        return switch_clause;
    }
    default___k = Switch_Default__parse(parser);
    if ((default___k != Switch_Default__null)) {
        switch_clause->kind = Switch_Clause_Kind___default; switch_clause->kind__union.default___k = default___k;
        return switch_clause;
    }
    all_cases_required = Switch_All_Cases_Required__parse(parser);
    if ((all_cases_required != Switch_All_Cases_Required__null)) {
        switch_clause->kind = Switch_Clause_Kind___all_cases_required; switch_clause->kind__union.all_cases_required = all_cases_required;
        return switch_clause;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        switch_clause->kind = Switch_Clause_Kind___error; switch_clause->kind__union.error = error;
        return switch_clause;
    }
    return Switch_Clause__null;
}

void Switch_Clause__traverse(
  Switch_Clause switch_clause,
  Traverser traverser)
{
    switch (switch_clause->kind) {
        case Switch_Clause_Kind___end_of_line:
            (void)Token__traverse(((switch_clause->kind == Switch_Clause_Kind___end_of_line) ? switch_clause->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 4254)), traverser);
            break;
        case Switch_Clause_Kind___note:
            (void)Note__traverse(((switch_clause->kind == Switch_Clause_Kind___note) ? switch_clause->kind__union.note : (Note)System__variant_object_fail((String)"\14Parse.ez.ezg", 4256)), traverser);
            break;
        case Switch_Clause_Kind___case:
            (void)Switch_Case__traverse(((switch_clause->kind == Switch_Clause_Kind___case) ? switch_clause->kind__union.case___k : (Switch_Case)System__variant_object_fail((String)"\14Parse.ez.ezg", 4258)), traverser);
            break;
        case Switch_Clause_Kind___default:
            (void)Switch_Default__traverse(((switch_clause->kind == Switch_Clause_Kind___default) ? switch_clause->kind__union.default___k : (Switch_Default)System__variant_object_fail((String)"\14Parse.ez.ezg", 4260)), traverser);
            break;
        case Switch_Clause_Kind___all_cases_required:
            (void)Switch_All_Cases_Required__traverse(((switch_clause->kind == Switch_Clause_Kind___all_cases_required) ? switch_clause->kind__union.all_cases_required : (Switch_All_Cases_Required)System__variant_object_fail((String)"\14Parse.ez.ezg", 4262)), traverser);
            break;
        case Switch_Clause_Kind___error:
            (void)Error__traverse(((switch_clause->kind == Switch_Clause_Kind___error) ? switch_clause->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 4264)), traverser);
            break;
    }
}


Switch_Case Switch_Case__parse(
  Parser parser)
{
    Unsigned index;
    Keyword case___k;
    Expression cases;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
    Switch_Case switch_case;
    index = parser->index;
    case___k = Keyword__parse(parser, ((String)"\004case"));
    if ((case___k == Keyword__null)) {
        parser->index = index;
        return Switch_Case__null;
    }
    cases = Expression__parse(parser);
    if ((cases == Expression__null)) {
        parser->index = index;
        return Switch_Case__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Switch_Case__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Switch_Case__null;
    }
    statements = Array__parse(parser, ((void * (*)(Parser))(Statement__parse)), ((void *)(Statement__null)), Lexeme__close_indent);
    if ((Array__size_get(statements) == 0)) {
        parser->index = index;
        return Switch_Case__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Switch_Case__null;
    }
    switch_case = Switch_Case__new();
    switch_case->case___k = case___k;
    switch_case->cases = cases;
    switch_case->end_of_line = end_of_line;
    switch_case->open_indent = open_indent;
    switch_case->statements = statements;
    switch_case->close_indent = close_indent;
    return switch_case;
}

void Switch_Case__traverse(
  Switch_Case switch_case,
  Traverser traverser)
{
    (void)Keyword__traverse(switch_case->case___k, traverser);
    (void)Expression__traverse(switch_case->cases, traverser);
    (void)Token__traverse(switch_case->end_of_line, traverser);
    (void)Token__traverse(switch_case->open_indent, traverser);
    (void)Array__traverse(switch_case->statements, traverser, ((void (*)(void *, Traverser))(Statement__traverse)));
    (void)Token__traverse(switch_case->close_indent, traverser);
}


Switch_Default Switch_Default__parse(
  Parser parser)
{
    Unsigned index;
    Keyword default___k;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
    Switch_Default switch_default;
    index = parser->index;
    default___k = Keyword__parse(parser, ((String)"\007default"));
    if ((default___k == Keyword__null)) {
        parser->index = index;
        return Switch_Default__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Switch_Default__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return Switch_Default__null;
    }
    statements = Array__parse(parser, ((void * (*)(Parser))(Statement__parse)), ((void *)(Statement__null)), Lexeme__close_indent);
    if ((Array__size_get(statements) == 0)) {
        parser->index = index;
        return Switch_Default__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return Switch_Default__null;
    }
    switch_default = Switch_Default__new();
    switch_default->default___k = default___k;
    switch_default->end_of_line = end_of_line;
    switch_default->open_indent = open_indent;
    switch_default->statements = statements;
    switch_default->close_indent = close_indent;
    return switch_default;
}

void Switch_Default__traverse(
  Switch_Default switch_default,
  Traverser traverser)
{
    (void)Keyword__traverse(switch_default->default___k, traverser);
    (void)Token__traverse(switch_default->end_of_line, traverser);
    (void)Token__traverse(switch_default->open_indent, traverser);
    (void)Array__traverse(switch_default->statements, traverser, ((void (*)(void *, Traverser))(Statement__traverse)));
    (void)Token__traverse(switch_default->close_indent, traverser);
}


Switch_All_Cases_Required Switch_All_Cases_Required__parse(
  Parser parser)
{
    Unsigned index;
    Keyword all_cases_required;
    Token end_of_line;
    Switch_All_Cases_Required switch_all_cases_required;
    index = parser->index;
    all_cases_required = Keyword__parse(parser, ((String)"\022all_cases_required"));
    if ((all_cases_required == Keyword__null)) {
        parser->index = index;
        return Switch_All_Cases_Required__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Switch_All_Cases_Required__null;
    }
    switch_all_cases_required = Switch_All_Cases_Required__new();
    switch_all_cases_required->all_cases_required = all_cases_required;
    switch_all_cases_required->end_of_line = end_of_line;
    return switch_all_cases_required;
}

void Switch_All_Cases_Required__traverse(
  Switch_All_Cases_Required switch_all_cases_required,
  Traverser traverser)
{
    (void)Keyword__traverse(switch_all_cases_required->all_cases_required, traverser);
    (void)Token__traverse(switch_all_cases_required->end_of_line, traverser);
}


Case_Name Case_Name__parse(
  Parser parser)
{
    Unsigned index;
    Token name;
    Case_Name case_name;
    index = parser->index;
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Case_Name__null;
    }
    case_name = Case_Name__new();
    case_name->name = name;
    return case_name;
}

void Case_Name__traverse(
  Case_Name case_name,
  Traverser traverser)
{
    (void)Token__traverse(case_name->name, traverser);
}


While_Statement While_Statement__parse(
  Parser parser)
{
    Unsigned index;
    Keyword while___k;
    Expression expression;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
    While_Statement while_statement;
    index = parser->index;
    while___k = Keyword__parse(parser, ((String)"\005while"));
    if ((while___k == Keyword__null)) {
        parser->index = index;
        return While_Statement__null;
    }
    expression = Expression__parse(parser);
    if ((expression == Expression__null)) {
        parser->index = index;
        return While_Statement__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return While_Statement__null;
    }
    open_indent = Token__parse(parser, Lexeme__open_indent);
    if ((open_indent == Token__null)) {
        parser->index = index;
        return While_Statement__null;
    }
    statements = Array__parse(parser, ((void * (*)(Parser))(Statement__parse)), ((void *)(Statement__null)), Lexeme__close_indent);
    if ((Array__size_get(statements) == 0)) {
        parser->index = index;
        return While_Statement__null;
    }
    close_indent = Token__parse(parser, Lexeme__close_indent);
    if ((close_indent == Token__null)) {
        parser->index = index;
        return While_Statement__null;
    }
    while_statement = While_Statement__new();
    while_statement->while___k = while___k;
    while_statement->expression = expression;
    while_statement->end_of_line = end_of_line;
    while_statement->open_indent = open_indent;
    while_statement->statements = statements;
    while_statement->close_indent = close_indent;
    return while_statement;
}

void While_Statement__traverse(
  While_Statement while_statement,
  Traverser traverser)
{
    (void)Keyword__traverse(while_statement->while___k, traverser);
    (void)Expression__traverse(while_statement->expression, traverser);
    (void)Token__traverse(while_statement->end_of_line, traverser);
    (void)Token__traverse(while_statement->open_indent, traverser);
    (void)Array__traverse(while_statement->statements, traverser, ((void (*)(void *, Traverser))(Statement__traverse)));
    (void)Token__traverse(while_statement->close_indent, traverser);
}



String Expression_Kind__string_convert(
  Expression_Kind expression_kind)
{
    switch (expression_kind) {
        case Expression_Kind___binary:
            return ((String)"\006binary");
            break;
        case Expression_Kind___bracket:
            return ((String)"\007bracket");
            break;
        case Expression_Kind___character:
            return ((String)"\011character");
            break;
        case Expression_Kind___float_number:
            return ((String)"\014float_number");
            break;
        case Expression_Kind___list:
            return ((String)"\004list");
            break;
        case Expression_Kind___number:
            return ((String)"\006number");
            break;
        case Expression_Kind___parenthesis:
            return ((String)"\013parenthesis");
            break;
        case Expression_Kind___string:
            return ((String)"\006string");
            break;
        case Expression_Kind___symbol:
            return ((String)"\006symbol");
            break;
        case Expression_Kind___unary:
            return ((String)"\005unary");
            break;
        case Expression_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

void Expression__traverse(
  Expression expression,
  Traverser traverser)
{
    switch (expression->kind) {
        case Expression_Kind___binary:
            (void)Binary_Expression__traverse(((expression->kind == Expression_Kind___binary) ? expression->kind__union.binary : (Binary_Expression)System__variant_object_fail((String)"\14Parse.ez.ezg", 4591)), traverser);
            break;
        case Expression_Kind___bracket:
            (void)Bracket_Expression__traverse(((expression->kind == Expression_Kind___bracket) ? expression->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\14Parse.ez.ezg", 4593)), traverser);
            break;
        case Expression_Kind___character:
            (void)Token__traverse(((expression->kind == Expression_Kind___character) ? expression->kind__union.character : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 4595)), traverser);
            break;
        case Expression_Kind___float_number:
            (void)Token__traverse(((expression->kind == Expression_Kind___float_number) ? expression->kind__union.float_number : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 4597)), traverser);
            break;
        case Expression_Kind___list:
            (void)List_Expression__traverse(((expression->kind == Expression_Kind___list) ? expression->kind__union.list : (List_Expression)System__variant_object_fail((String)"\14Parse.ez.ezg", 4599)), traverser);
            break;
        case Expression_Kind___number:
            (void)Token__traverse(((expression->kind == Expression_Kind___number) ? expression->kind__union.number : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 4601)), traverser);
            break;
        case Expression_Kind___parenthesis:
            (void)Parenthesis_Expression__traverse(((expression->kind == Expression_Kind___parenthesis) ? expression->kind__union.parenthesis : (Parenthesis_Expression)System__variant_object_fail((String)"\14Parse.ez.ezg", 4603)), traverser);
            break;
        case Expression_Kind___string:
            (void)Token__traverse(((expression->kind == Expression_Kind___string) ? expression->kind__union.string : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 4605)), traverser);
            break;
        case Expression_Kind___symbol:
            (void)Token__traverse(((expression->kind == Expression_Kind___symbol) ? expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 4607)), traverser);
            break;
        case Expression_Kind___unary:
            (void)Unary_Expression__traverse(((expression->kind == Expression_Kind___unary) ? expression->kind__union.unary : (Unary_Expression)System__variant_object_fail((String)"\14Parse.ez.ezg", 4609)), traverser);
            break;
        case Expression_Kind___error:
            (void)Error__traverse(((expression->kind == Expression_Kind___error) ? expression->kind__union.error : (Error)System__variant_object_fail((String)"\14Parse.ez.ezg", 4611)), traverser);
            break;
    }
}


void Binary_Expression__traverse(
  Binary_Expression binary_expression,
  Traverser traverser)
{
    (void)Expression__traverse(binary_expression->left, traverser);
    (void)Token__traverse(binary_expression->operator, traverser);
    (void)Expression__traverse(binary_expression->right, traverser);
}


void Bracket_Expression__traverse(
  Bracket_Expression bracket_expression,
  Traverser traverser)
{
    (void)Expression__traverse(bracket_expression->expression1, traverser);
    (void)Token__traverse(bracket_expression->open_bracket, traverser);
    (void)Expression__traverse(bracket_expression->expression2, traverser);
    (void)Token__traverse(bracket_expression->close_bracket, traverser);
}



void Parenthesis_Expression__traverse(
  Parenthesis_Expression parenthesis_expression,
  Traverser traverser)
{
    (void)Token__traverse(parenthesis_expression->open_parenthesis, traverser);
    (void)Expression__traverse(parenthesis_expression->expression, traverser);
    (void)Token__traverse(parenthesis_expression->close_parenthesis, traverser);
}


void Unary_Expression__traverse(
  Unary_Expression unary_expression,
  Traverser traverser)
{
    (void)Token__traverse(unary_expression->operator, traverser);
    (void)Expression__traverse(unary_expression->expression, traverser);
}


Typed_Name Typed_Name__parse(
  Parser parser)
{
    Unsigned index;
    Token name;
    Token at_sign;
    Type type;
    Typed_Name typed_name;
    index = parser->index;
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Typed_Name__null;
    }
    at_sign = Token__parse(parser, Lexeme__at_sign);
    if ((at_sign == Token__null)) {
        parser->index = index;
        return Typed_Name__null;
    }
    type = Type__parse(parser);
    if ((type == Type__null)) {
        parser->index = index;
        return Typed_Name__null;
    }
    typed_name = Typed_Name__new();
    typed_name->name = name;
    typed_name->at_sign = at_sign;
    typed_name->type = type;
    return typed_name;
}

void Typed_Name__traverse(
  Typed_Name typed_name,
  Traverser traverser)
{
    (void)Token__traverse(typed_name->name, traverser);
    (void)Token__traverse(typed_name->at_sign, traverser);
    (void)Type__traverse(typed_name->type, traverser);
}



String Type_Kind__string_convert(
  Type_Kind type_kind)
{
    switch (type_kind) {
        case Type_Kind___parameterized:
            return ((String)"\015parameterized");
            break;
        case Type_Kind___simple:
            return ((String)"\006simple");
            break;
        case Type_Kind___routine:
            return ((String)"\007routine");
            break;
    }
    return ((String)"\000");
}

Type Type__parse(
  Parser parser)
{
    Type type;
    Parameterized_Type parameterized;
    Token simple;
    Routine_Type routine;
    type = Type__new();
    parameterized = Parameterized_Type__parse(parser);
    if ((parameterized != Parameterized_Type__null)) {
        type->kind = Type_Kind___parameterized; type->kind__union.parameterized = parameterized;
        return type;
    }
    simple = Token__parse(parser, Lexeme__symbol);
    if ((simple != Token__null)) {
        type->kind = Type_Kind___simple; type->kind__union.simple = simple;
        return type;
    }
    routine = Routine_Type__parse(parser);
    if ((routine != Routine_Type__null)) {
        type->kind = Type_Kind___routine; type->kind__union.routine = routine;
        return type;
    }
    return Type__null;
}

void Type__traverse(
  Type type,
  Traverser traverser)
{
    switch (type->kind) {
        case Type_Kind___parameterized:
            (void)Parameterized_Type__traverse(((type->kind == Type_Kind___parameterized) ? type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\14Parse.ez.ezg", 4793)), traverser);
            break;
        case Type_Kind___simple:
            (void)Token__traverse(((type->kind == Type_Kind___simple) ? type->kind__union.simple : (Token)System__variant_object_fail((String)"\14Parse.ez.ezg", 4795)), traverser);
            break;
        case Type_Kind___routine:
            (void)Routine_Type__traverse(((type->kind == Type_Kind___routine) ? type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\14Parse.ez.ezg", 4797)), traverser);
            break;
    }
}


Parameterized_Type Parameterized_Type__parse(
  Parser parser)
{
    Unsigned index;
    Token name;
    Token open_bracket;
    Comma_Separated sub_types;
    Token close_bracket;
    Parameterized_Type parameterized_type;
    index = parser->index;
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Parameterized_Type__null;
    }
    open_bracket = Token__parse(parser, Lexeme__open_bracket);
    if ((open_bracket == Token__null)) {
        parser->index = index;
        return Parameterized_Type__null;
    }
    sub_types = Comma_Separated__parse(parser, ((void * (*)(Parser))(Type__parse)), ((void *)(Type__null)), Lexeme__close_bracket);
    if ((Comma_Separated__size_get(sub_types) == 0)) {
        parser->index = index;
        return Parameterized_Type__null;
    }
    close_bracket = Token__parse(parser, Lexeme__close_bracket);
    if ((close_bracket == Token__null)) {
        parser->index = index;
        return Parameterized_Type__null;
    }
    parameterized_type = Parameterized_Type__new();
    parameterized_type->name = name;
    parameterized_type->open_bracket = open_bracket;
    parameterized_type->sub_types = sub_types;
    parameterized_type->close_bracket = close_bracket;
    return parameterized_type;
}

void Parameterized_Type__traverse(
  Parameterized_Type parameterized_type,
  Traverser traverser)
{
    (void)Token__traverse(parameterized_type->name, traverser);
    (void)Token__traverse(parameterized_type->open_bracket, traverser);
    (void)Comma_Separated__traverse(parameterized_type->sub_types, traverser, ((void (*)(void *, Traverser))(Type__traverse)));
    (void)Token__traverse(parameterized_type->close_bracket, traverser);
}


void Routine_Type__traverse(
  Routine_Type routine_type,
  Traverser traverser)
{
    (void)Token__traverse(routine_type->open_bracket, traverser);
    (void)Comma_Separated__traverse(routine_type->return_types, traverser, ((void (*)(void *, Traverser))(Type__traverse)));
    (void)Token__traverse(routine_type->less_than_or_equal, traverser);
    (void)Comma_Separated__traverse(routine_type->takes_types, traverser, ((void (*)(void *, Traverser))(Type__traverse)));
    (void)Token__traverse(routine_type->close_bracket, traverser);
}


Note Note__parse(
  Parser parser)
{
    Unsigned index;
    Token comment;
    Token end_of_line;
    Note note;
    index = parser->index;
    comment = Token__parse(parser, Lexeme__comment);
    if ((comment == Token__null)) {
        parser->index = index;
        return Note__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Note__null;
    }
    note = Note__new();
    note->comment = comment;
    note->end_of_line = end_of_line;
    return note;
}

void Note__traverse(
  Note note,
  Traverser traverser)
{
    (void)Token__traverse(note->comment, traverser);
    (void)Token__traverse(note->end_of_line, traverser);
}



void Keyword__traverse(
  Keyword keyword,
  Traverser traverser)
{
    (void)Token__traverse(keyword->keyword, traverser);
}





String Expression_State__string_convert(
  Expression_State expression_state)
{
    switch (expression_state) {
        case Expression_State___unary:
            return ((String)"\005unary");
            break;
        case Expression_State___leaf:
            return ((String)"\004leaf");
            break;
        case Expression_State___binary:
            return ((String)"\006binary");
            break;
        case Expression_State___at_sign:
            return ((String)"\007at_sign");
            break;
        case Expression_State___at_leaf:
            return ((String)"\007at_leaf");
            break;
    }
    return ((String)"\000");
}


/* {Root} stuff: */

struct Root__Struct Root__Initial = {
    (Array)0,
    &Token__Initial,
};

Root Root__null = &Root__Initial;
void Root__erase(
  Root root)
{
    if (root->declarations == 0) {
	root->declarations = Array__new();
    } else {
	Array__erase(root->declarations);
    }
    root->end_of_file = Token__null;
}

Root Root__new(void)
{
    Root root;
    extern void *malloc(unsigned int);

    root = (Root)malloc(sizeof(*root));
    root->declarations = Array__new();
    root->end_of_file = Token__null;
    return root;
}

void Root__Initialize(void)
{
    Root__erase(Root__null);
}

/* {Declaration} stuff: */

Declaration_Kind Declaration_Kind__easy_c = Declaration_Kind___easy_c;
Declaration_Kind Declaration_Kind__end_of_line = Declaration_Kind___end_of_line;
Declaration_Kind Declaration_Kind__note = Declaration_Kind___note;
Declaration_Kind Declaration_Kind__routine = Declaration_Kind___routine;
Declaration_Kind Declaration_Kind__define = Declaration_Kind___define;
Declaration_Kind Declaration_Kind__defines_prefix = Declaration_Kind___defines_prefix;
Declaration_Kind Declaration_Kind__external_named = Declaration_Kind___external_named;
Declaration_Kind Declaration_Kind__external = Declaration_Kind___external;
Declaration_Kind Declaration_Kind__global = Declaration_Kind___global;
Declaration_Kind Declaration_Kind__global_library = Declaration_Kind___global_library;
Declaration_Kind Declaration_Kind__library = Declaration_Kind___library;
Declaration_Kind Declaration_Kind__interface = Declaration_Kind___interface;
Declaration_Kind Declaration_Kind__load = Declaration_Kind___load;
Declaration_Kind Declaration_Kind__include_string = Declaration_Kind___include_string;
Declaration_Kind Declaration_Kind__constant = Declaration_Kind___constant;
Declaration_Kind Declaration_Kind__require = Declaration_Kind___require;
Declaration_Kind Declaration_Kind__collection = Declaration_Kind___collection;
Declaration_Kind Declaration_Kind__error = Declaration_Kind___error;
struct Declaration__Struct Declaration__Initial = {
};

Declaration Declaration__null = &Declaration__Initial;
void Declaration__erase(
  Declaration declaration)
{
}

Declaration Declaration__new(void)
{
    Declaration declaration;
    extern void *malloc(unsigned int);

    declaration = (Declaration)malloc(sizeof(*declaration));
    return declaration;
}

void Declaration__Initialize(void)
{
    Declaration__erase(Declaration__null);
}

/* {Easy_C_Declaration} stuff: */

struct Easy_C_Declaration__Struct Easy_C_Declaration__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Easy_C_Declaration Easy_C_Declaration__null = &Easy_C_Declaration__Initial;
void Easy_C_Declaration__erase(
  Easy_C_Declaration easy_c_declaration)
{
    easy_c_declaration->easy_c = Keyword__null;
    easy_c_declaration->float_number = Token__null;
    easy_c_declaration->end_of_line = Token__null;
}

Easy_C_Declaration Easy_C_Declaration__new(void)
{
    Easy_C_Declaration easy_c_declaration;
    extern void *malloc(unsigned int);

    easy_c_declaration = (Easy_C_Declaration)malloc(sizeof(*easy_c_declaration));
    easy_c_declaration->easy_c = Keyword__null;
    easy_c_declaration->float_number = Token__null;
    easy_c_declaration->end_of_line = Token__null;
    return easy_c_declaration;
}

void Easy_C_Declaration__Initialize(void)
{
    Easy_C_Declaration__erase(Easy_C_Declaration__null);
}

/* {Define_Declaration} stuff: */

struct Define_Declaration__Struct Define_Declaration__Initial = {
    &Keyword__Initial,
    &Type__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Define_Declaration Define_Declaration__null = &Define_Declaration__Initial;
void Define_Declaration__erase(
  Define_Declaration define_declaration)
{
    define_declaration->define = Keyword__null;
    define_declaration->type = Type__null;
    define_declaration->end_of_line = Token__null;
    define_declaration->open_indent = Token__null;
    if (define_declaration->define_clauses == 0) {
	define_declaration->define_clauses = Array__new();
    } else {
	Array__erase(define_declaration->define_clauses);
    }
    define_declaration->close_indent = Token__null;
}

Define_Declaration Define_Declaration__new(void)
{
    Define_Declaration define_declaration;
    extern void *malloc(unsigned int);

    define_declaration = (Define_Declaration)malloc(sizeof(*define_declaration));
    define_declaration->define = Keyword__null;
    define_declaration->type = Type__null;
    define_declaration->end_of_line = Token__null;
    define_declaration->open_indent = Token__null;
    define_declaration->define_clauses = Array__new();
    define_declaration->close_indent = Token__null;
    return define_declaration;
}

void Define_Declaration__Initialize(void)
{
    Define_Declaration__erase(Define_Declaration__null);
}

/* {Define_Clause} stuff: */

Define_Clause_Kind Define_Clause_Kind__end_of_line = Define_Clause_Kind___end_of_line;
Define_Clause_Kind Define_Clause_Kind__note = Define_Clause_Kind___note;
Define_Clause_Kind Define_Clause_Kind__enumeration = Define_Clause_Kind___enumeration;
Define_Clause_Kind Define_Clause_Kind__enumeration_prefix = Define_Clause_Kind___enumeration_prefix;
Define_Clause_Kind Define_Clause_Kind__record = Define_Clause_Kind___record;
Define_Clause_Kind Define_Clause_Kind__record_import = Define_Clause_Kind___record_import;
Define_Clause_Kind Define_Clause_Kind__registers = Define_Clause_Kind___registers;
Define_Clause_Kind Define_Clause_Kind__variant = Define_Clause_Kind___variant;
Define_Clause_Kind Define_Clause_Kind__generate = Define_Clause_Kind___generate;
Define_Clause_Kind Define_Clause_Kind__simple = Define_Clause_Kind___simple;
Define_Clause_Kind Define_Clause_Kind__simple_numeric = Define_Clause_Kind___simple_numeric;
Define_Clause_Kind Define_Clause_Kind__external = Define_Clause_Kind___external;
Define_Clause_Kind Define_Clause_Kind__base_type = Define_Clause_Kind___base_type;
Define_Clause_Kind Define_Clause_Kind__error = Define_Clause_Kind___error;
struct Define_Clause__Struct Define_Clause__Initial = {
};

Define_Clause Define_Clause__null = &Define_Clause__Initial;
void Define_Clause__erase(
  Define_Clause define_clause)
{
}

Define_Clause Define_Clause__new(void)
{
    Define_Clause define_clause;
    extern void *malloc(unsigned int);

    define_clause = (Define_Clause)malloc(sizeof(*define_clause));
    return define_clause;
}

void Define_Clause__Initialize(void)
{
    Define_Clause__erase(Define_Clause__null);
}

/* {Simple_Numeric_Clause} stuff: */

struct Simple_Numeric_Clause__Struct Simple_Numeric_Clause__Initial = {
    &Keyword__Initial,
    &Type__Initial,
    &Token__Initial,
};

Simple_Numeric_Clause Simple_Numeric_Clause__null = &Simple_Numeric_Clause__Initial;
void Simple_Numeric_Clause__erase(
  Simple_Numeric_Clause simple_numeric_clause)
{
    simple_numeric_clause->simple_numeric = Keyword__null;
    simple_numeric_clause->type = Type__null;
    simple_numeric_clause->end_of_line = Token__null;
}

Simple_Numeric_Clause Simple_Numeric_Clause__new(void)
{
    Simple_Numeric_Clause simple_numeric_clause;
    extern void *malloc(unsigned int);

    simple_numeric_clause = (Simple_Numeric_Clause)malloc(sizeof(*simple_numeric_clause));
    simple_numeric_clause->simple_numeric = Keyword__null;
    simple_numeric_clause->type = Type__null;
    simple_numeric_clause->end_of_line = Token__null;
    return simple_numeric_clause;
}

void Simple_Numeric_Clause__Initialize(void)
{
    Simple_Numeric_Clause__erase(Simple_Numeric_Clause__null);
}

/* {Base_Type_Clause} stuff: */

struct Base_Type_Clause__Struct Base_Type_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Base_Type_Clause Base_Type_Clause__null = &Base_Type_Clause__Initial;
void Base_Type_Clause__erase(
  Base_Type_Clause base_type_clause)
{
    base_type_clause->base_type = Keyword__null;
    base_type_clause->string = Token__null;
    base_type_clause->end_of_line = Token__null;
}

Base_Type_Clause Base_Type_Clause__new(void)
{
    Base_Type_Clause base_type_clause;
    extern void *malloc(unsigned int);

    base_type_clause = (Base_Type_Clause)malloc(sizeof(*base_type_clause));
    base_type_clause->base_type = Keyword__null;
    base_type_clause->string = Token__null;
    base_type_clause->end_of_line = Token__null;
    return base_type_clause;
}

void Base_Type_Clause__Initialize(void)
{
    Base_Type_Clause__erase(Base_Type_Clause__null);
}

/* {Enumeration_Clause} stuff: */

struct Enumeration_Clause__Struct Enumeration_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Enumeration_Clause Enumeration_Clause__null = &Enumeration_Clause__Initial;
void Enumeration_Clause__erase(
  Enumeration_Clause enumeration_clause)
{
    enumeration_clause->enumeration = Keyword__null;
    enumeration_clause->end_of_line = Token__null;
    enumeration_clause->open_indent = Token__null;
    if (enumeration_clause->item_clauses == 0) {
	enumeration_clause->item_clauses = Array__new();
    } else {
	Array__erase(enumeration_clause->item_clauses);
    }
    enumeration_clause->close_indent = Token__null;
}

Enumeration_Clause Enumeration_Clause__new(void)
{
    Enumeration_Clause enumeration_clause;
    extern void *malloc(unsigned int);

    enumeration_clause = (Enumeration_Clause)malloc(sizeof(*enumeration_clause));
    enumeration_clause->enumeration = Keyword__null;
    enumeration_clause->end_of_line = Token__null;
    enumeration_clause->open_indent = Token__null;
    enumeration_clause->item_clauses = Array__new();
    enumeration_clause->close_indent = Token__null;
    return enumeration_clause;
}

void Enumeration_Clause__Initialize(void)
{
    Enumeration_Clause__erase(Enumeration_Clause__null);
}

/* {Enumeration_Prefix_Clause} stuff: */

struct Enumeration_Prefix_Clause__Struct Enumeration_Prefix_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    0,
};

Enumeration_Prefix_Clause Enumeration_Prefix_Clause__null = &Enumeration_Prefix_Clause__Initial;
void Enumeration_Prefix_Clause__erase(
  Enumeration_Prefix_Clause enumeration_prefix_clause)
{
    enumeration_prefix_clause->enumeration_prefix = Keyword__null;
    enumeration_prefix_clause->prefix = Token__null;
    enumeration_prefix_clause->end_of_line = Token__null;
    if (enumeration_prefix_clause->define_datas == 0) {
	enumeration_prefix_clause->define_datas = Array__new();
    } else {
	Array__erase(enumeration_prefix_clause->define_datas);
    }
    enumeration_prefix_clause->define_datas_initialized = 0;
}

Enumeration_Prefix_Clause Enumeration_Prefix_Clause__new(void)
{
    Enumeration_Prefix_Clause enumeration_prefix_clause;
    extern void *malloc(unsigned int);

    enumeration_prefix_clause = (Enumeration_Prefix_Clause)malloc(sizeof(*enumeration_prefix_clause));
    enumeration_prefix_clause->enumeration_prefix = Keyword__null;
    enumeration_prefix_clause->prefix = Token__null;
    enumeration_prefix_clause->end_of_line = Token__null;
    enumeration_prefix_clause->define_datas = Array__new();
    enumeration_prefix_clause->define_datas_initialized = Logical__null;
    return enumeration_prefix_clause;
}

void Enumeration_Prefix_Clause__Initialize(void)
{
    Enumeration_Prefix_Clause__erase(Enumeration_Prefix_Clause__null);
}

/* {Item_Clause} stuff: */

Item_Clause_Kind Item_Clause_Kind__end_of_line = Item_Clause_Kind___end_of_line;
Item_Clause_Kind Item_Clause_Kind__note = Item_Clause_Kind___note;
Item_Clause_Kind Item_Clause_Kind__item = Item_Clause_Kind___item;
Item_Clause_Kind Item_Clause_Kind__error = Item_Clause_Kind___error;
struct Item_Clause__Struct Item_Clause__Initial = {
};

Item_Clause Item_Clause__null = &Item_Clause__Initial;
void Item_Clause__erase(
  Item_Clause item_clause)
{
}

Item_Clause Item_Clause__new(void)
{
    Item_Clause item_clause;
    extern void *malloc(unsigned int);

    item_clause = (Item_Clause)malloc(sizeof(*item_clause));
    return item_clause;
}

void Item_Clause__Initialize(void)
{
    Item_Clause__erase(Item_Clause__null);
}

/* {Item} stuff: */

struct Item__Struct Item__Initial = {
    &Token__Initial,
    &Token__Initial,
};

Item Item__null = &Item__Initial;
void Item__erase(
  Item item)
{
    item->name = Token__null;
    item->end_of_line = Token__null;
}

Item Item__new(void)
{
    Item item;
    extern void *malloc(unsigned int);

    item = (Item)malloc(sizeof(*item));
    item->name = Token__null;
    item->end_of_line = Token__null;
    return item;
}

void Item__Initialize(void)
{
    Item__erase(Item__null);
}

/* {Record_Clause} stuff: */

struct Record_Clause__Struct Record_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Record_Clause Record_Clause__null = &Record_Clause__Initial;
void Record_Clause__erase(
  Record_Clause record_clause)
{
    record_clause->record = Keyword__null;
    record_clause->end_of_line = Token__null;
    record_clause->open_indent = Token__null;
    if (record_clause->field_clauses == 0) {
	record_clause->field_clauses = Array__new();
    } else {
	Array__erase(record_clause->field_clauses);
    }
    record_clause->close_indent = Token__null;
}

Record_Clause Record_Clause__new(void)
{
    Record_Clause record_clause;
    extern void *malloc(unsigned int);

    record_clause = (Record_Clause)malloc(sizeof(*record_clause));
    record_clause->record = Keyword__null;
    record_clause->end_of_line = Token__null;
    record_clause->open_indent = Token__null;
    record_clause->field_clauses = Array__new();
    record_clause->close_indent = Token__null;
    return record_clause;
}

void Record_Clause__Initialize(void)
{
    Record_Clause__erase(Record_Clause__null);
}

/* {Record_Import_Clause} stuff: */

struct Record_Import_Clause__Struct Record_Import_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Record_Import_Clause Record_Import_Clause__null = &Record_Import_Clause__Initial;
void Record_Import_Clause__erase(
  Record_Import_Clause record_import_clause)
{
    record_import_clause->record_import = Keyword__null;
    record_import_clause->string = Token__null;
    record_import_clause->end_of_line = Token__null;
    record_import_clause->open_indent = Token__null;
    if (record_import_clause->import_field_clauses == 0) {
	record_import_clause->import_field_clauses = Array__new();
    } else {
	Array__erase(record_import_clause->import_field_clauses);
    }
    record_import_clause->close_indent = Token__null;
}

Record_Import_Clause Record_Import_Clause__new(void)
{
    Record_Import_Clause record_import_clause;
    extern void *malloc(unsigned int);

    record_import_clause = (Record_Import_Clause)malloc(sizeof(*record_import_clause));
    record_import_clause->record_import = Keyword__null;
    record_import_clause->string = Token__null;
    record_import_clause->end_of_line = Token__null;
    record_import_clause->open_indent = Token__null;
    record_import_clause->import_field_clauses = Array__new();
    record_import_clause->close_indent = Token__null;
    return record_import_clause;
}

void Record_Import_Clause__Initialize(void)
{
    Record_Import_Clause__erase(Record_Import_Clause__null);
}

/* {Registers_Clause} stuff: */

struct Registers_Clause__Struct Registers_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Registers_Clause Registers_Clause__null = &Registers_Clause__Initial;
void Registers_Clause__erase(
  Registers_Clause registers_clause)
{
    registers_clause->registers = Keyword__null;
    registers_clause->end_of_line = Token__null;
    registers_clause->open_indent = Token__null;
    if (registers_clause->register_clauses == 0) {
	registers_clause->register_clauses = Array__new();
    } else {
	Array__erase(registers_clause->register_clauses);
    }
    registers_clause->close_indent = Token__null;
}

Registers_Clause Registers_Clause__new(void)
{
    Registers_Clause registers_clause;
    extern void *malloc(unsigned int);

    registers_clause = (Registers_Clause)malloc(sizeof(*registers_clause));
    registers_clause->registers = Keyword__null;
    registers_clause->end_of_line = Token__null;
    registers_clause->open_indent = Token__null;
    registers_clause->register_clauses = Array__new();
    registers_clause->close_indent = Token__null;
    return registers_clause;
}

void Registers_Clause__Initialize(void)
{
    Registers_Clause__erase(Registers_Clause__null);
}

/* {Register_Clause} stuff: */

Register_Clause_Kind Register_Clause_Kind__end_of_line = Register_Clause_Kind___end_of_line;
Register_Clause_Kind Register_Clause_Kind__note = Register_Clause_Kind___note;
Register_Clause_Kind Register_Clause_Kind__bit = Register_Clause_Kind___bit;
Register_Clause_Kind Register_Clause_Kind__byte = Register_Clause_Kind___byte;
Register_Clause_Kind Register_Clause_Kind__error = Register_Clause_Kind___error;
struct Register_Clause__Struct Register_Clause__Initial = {
};

Register_Clause Register_Clause__null = &Register_Clause__Initial;
void Register_Clause__erase(
  Register_Clause register_clause)
{
}

Register_Clause Register_Clause__new(void)
{
    Register_Clause register_clause;
    extern void *malloc(unsigned int);

    register_clause = (Register_Clause)malloc(sizeof(*register_clause));
    return register_clause;
}

void Register_Clause__Initialize(void)
{
    Register_Clause__erase(Register_Clause__null);
}

/* {Register_Bit} stuff: */

struct Register_Bit__Struct Register_Bit__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
};

Register_Bit Register_Bit__null = &Register_Bit__Initial;
void Register_Bit__erase(
  Register_Bit register_bit)
{
    register_bit->bit = Keyword__null;
    register_bit->name = Token__null;
    register_bit->equals = Token__null;
    register_bit->string = Token__null;
    register_bit->end_of_line = Token__null;
}

Register_Bit Register_Bit__new(void)
{
    Register_Bit register_bit;
    extern void *malloc(unsigned int);

    register_bit = (Register_Bit)malloc(sizeof(*register_bit));
    register_bit->bit = Keyword__null;
    register_bit->name = Token__null;
    register_bit->equals = Token__null;
    register_bit->string = Token__null;
    register_bit->end_of_line = Token__null;
    return register_bit;
}

void Register_Bit__Initialize(void)
{
    Register_Bit__erase(Register_Bit__null);
}

/* {Register_Byte} stuff: */

struct Register_Byte__Struct Register_Byte__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
};

Register_Byte Register_Byte__null = &Register_Byte__Initial;
void Register_Byte__erase(
  Register_Byte register_byte)
{
    register_byte->byte = Keyword__null;
    register_byte->name = Token__null;
    register_byte->equals = Token__null;
    register_byte->string = Token__null;
    register_byte->end_of_line = Token__null;
}

Register_Byte Register_Byte__new(void)
{
    Register_Byte register_byte;
    extern void *malloc(unsigned int);

    register_byte = (Register_Byte)malloc(sizeof(*register_byte));
    register_byte->byte = Keyword__null;
    register_byte->name = Token__null;
    register_byte->equals = Token__null;
    register_byte->string = Token__null;
    register_byte->end_of_line = Token__null;
    return register_byte;
}

void Register_Byte__Initialize(void)
{
    Register_Byte__erase(Register_Byte__null);
}

/* {Field_Clause} stuff: */

Field_Clause_Kind Field_Clause_Kind__end_of_line = Field_Clause_Kind___end_of_line;
Field_Clause_Kind Field_Clause_Kind__note = Field_Clause_Kind___note;
Field_Clause_Kind Field_Clause_Kind__field = Field_Clause_Kind___field;
Field_Clause_Kind Field_Clause_Kind__error = Field_Clause_Kind___error;
struct Field_Clause__Struct Field_Clause__Initial = {
};

Field_Clause Field_Clause__null = &Field_Clause__Initial;
void Field_Clause__erase(
  Field_Clause field_clause)
{
}

Field_Clause Field_Clause__new(void)
{
    Field_Clause field_clause;
    extern void *malloc(unsigned int);

    field_clause = (Field_Clause)malloc(sizeof(*field_clause));
    return field_clause;
}

void Field_Clause__Initialize(void)
{
    Field_Clause__erase(Field_Clause__null);
}

/* {Import_Field_Clause} stuff: */

Import_Field_Clause_Kind Import_Field_Clause_Kind__end_of_line = Import_Field_Clause_Kind___end_of_line;
Import_Field_Clause_Kind Import_Field_Clause_Kind__note = Import_Field_Clause_Kind___note;
Import_Field_Clause_Kind Import_Field_Clause_Kind__import_field = Import_Field_Clause_Kind___import_field;
Import_Field_Clause_Kind Import_Field_Clause_Kind__error = Import_Field_Clause_Kind___error;
struct Import_Field_Clause__Struct Import_Field_Clause__Initial = {
};

Import_Field_Clause Import_Field_Clause__null = &Import_Field_Clause__Initial;
void Import_Field_Clause__erase(
  Import_Field_Clause import_field_clause)
{
}

Import_Field_Clause Import_Field_Clause__new(void)
{
    Import_Field_Clause import_field_clause;
    extern void *malloc(unsigned int);

    import_field_clause = (Import_Field_Clause)malloc(sizeof(*import_field_clause));
    return import_field_clause;
}

void Import_Field_Clause__Initialize(void)
{
    Import_Field_Clause__erase(Import_Field_Clause__null);
}

/* {Variant_Clause} stuff: */

struct Variant_Clause__Struct Variant_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Type__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Variant_Clause Variant_Clause__null = &Variant_Clause__Initial;
void Variant_Clause__erase(
  Variant_Clause variant_clause)
{
    variant_clause->variant = Keyword__null;
    variant_clause->kind_name = Token__null;
    variant_clause->kind_type = Type__null;
    variant_clause->end_of_line = Token__null;
    variant_clause->open_indent = Token__null;
    if (variant_clause->field_clauses == 0) {
	variant_clause->field_clauses = Array__new();
    } else {
	Array__erase(variant_clause->field_clauses);
    }
    variant_clause->close_indent = Token__null;
}

Variant_Clause Variant_Clause__new(void)
{
    Variant_Clause variant_clause;
    extern void *malloc(unsigned int);

    variant_clause = (Variant_Clause)malloc(sizeof(*variant_clause));
    variant_clause->variant = Keyword__null;
    variant_clause->kind_name = Token__null;
    variant_clause->kind_type = Type__null;
    variant_clause->end_of_line = Token__null;
    variant_clause->open_indent = Token__null;
    variant_clause->field_clauses = Array__new();
    variant_clause->close_indent = Token__null;
    return variant_clause;
}

void Variant_Clause__Initialize(void)
{
    Variant_Clause__erase(Variant_Clause__null);
}

/* {Field} stuff: */

struct Field__Struct Field__Initial = {
    &Token__Initial,
    &Type__Initial,
    &Token__Initial,
};

Field Field__null = &Field__Initial;
void Field__erase(
  Field field)
{
    field->name = Token__null;
    field->type = Type__null;
    field->end_of_line = Token__null;
}

Field Field__new(void)
{
    Field field;
    extern void *malloc(unsigned int);

    field = (Field)malloc(sizeof(*field));
    field->name = Token__null;
    field->type = Type__null;
    field->end_of_line = Token__null;
    return field;
}

void Field__Initialize(void)
{
    Field__erase(Field__null);
}

/* {Import_Field} stuff: */

struct Import_Field__Struct Import_Field__Initial = {
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
    &Type__Initial,
    &Token__Initial,
};

Import_Field Import_Field__null = &Import_Field__Initial;
void Import_Field__erase(
  Import_Field import_field)
{
    import_field->c_name = Token__null;
    import_field->equals = Token__null;
    import_field->name = Token__null;
    import_field->type = Type__null;
    import_field->end_of_line = Token__null;
}

Import_Field Import_Field__new(void)
{
    Import_Field import_field;
    extern void *malloc(unsigned int);

    import_field = (Import_Field)malloc(sizeof(*import_field));
    import_field->c_name = Token__null;
    import_field->equals = Token__null;
    import_field->name = Token__null;
    import_field->type = Type__null;
    import_field->end_of_line = Token__null;
    return import_field;
}

void Import_Field__Initialize(void)
{
    Import_Field__erase(Import_Field__null);
}

/* {Simple_Clause} stuff: */

struct Simple_Clause__Struct Simple_Clause__Initial = {
    &Keyword__Initial,
    &Type__Initial,
    &Token__Initial,
};

Simple_Clause Simple_Clause__null = &Simple_Clause__Initial;
void Simple_Clause__erase(
  Simple_Clause simple_clause)
{
    simple_clause->simple = Keyword__null;
    simple_clause->type = Type__null;
    simple_clause->end_of_line = Token__null;
}

Simple_Clause Simple_Clause__new(void)
{
    Simple_Clause simple_clause;
    extern void *malloc(unsigned int);

    simple_clause = (Simple_Clause)malloc(sizeof(*simple_clause));
    simple_clause->simple = Keyword__null;
    simple_clause->type = Type__null;
    simple_clause->end_of_line = Token__null;
    return simple_clause;
}

void Simple_Clause__Initialize(void)
{
    Simple_Clause__erase(Simple_Clause__null);
}

/* {Generate_Clause} stuff: */

struct Generate_Clause__Struct Generate_Clause__Initial = {
    &Keyword__Initial,
    (Comma_Separated)0,
    &Token__Initial,
};

Generate_Clause Generate_Clause__null = &Generate_Clause__Initial;
void Generate_Clause__erase(
  Generate_Clause generate_clause)
{
    generate_clause->generate = Keyword__null;
    if (generate_clause->names == 0) {
	generate_clause->names = Comma_Separated__new();
    } else {
	Comma_Separated__erase(generate_clause->names);
    }
    generate_clause->end_of_line = Token__null;
}

Generate_Clause Generate_Clause__new(void)
{
    Generate_Clause generate_clause;
    extern void *malloc(unsigned int);

    generate_clause = (Generate_Clause)malloc(sizeof(*generate_clause));
    generate_clause->generate = Keyword__null;
    generate_clause->names = Comma_Separated__new();
    generate_clause->end_of_line = Token__null;
    return generate_clause;
}

void Generate_Clause__Initialize(void)
{
    Generate_Clause__erase(Generate_Clause__null);
}

/* {Generate_Name} stuff: */

struct Generate_Name__Struct Generate_Name__Initial = {
    &Token__Initial,
};

Generate_Name Generate_Name__null = &Generate_Name__Initial;
void Generate_Name__erase(
  Generate_Name generate_name)
{
    generate_name->name = Token__null;
}

Generate_Name Generate_Name__new(void)
{
    Generate_Name generate_name;
    extern void *malloc(unsigned int);

    generate_name = (Generate_Name)malloc(sizeof(*generate_name));
    generate_name->name = Token__null;
    return generate_name;
}

void Generate_Name__Initialize(void)
{
    Generate_Name__erase(Generate_Name__null);
}

/* {External_Clause} stuff: */

struct External_Clause__Struct External_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
};

External_Clause External_Clause__null = &External_Clause__Initial;
void External_Clause__erase(
  External_Clause external_clause)
{
    external_clause->external = Keyword__null;
    external_clause->end_of_line = Token__null;
}

External_Clause External_Clause__new(void)
{
    External_Clause external_clause;
    extern void *malloc(unsigned int);

    external_clause = (External_Clause)malloc(sizeof(*external_clause));
    external_clause->external = Keyword__null;
    external_clause->end_of_line = Token__null;
    return external_clause;
}

void External_Clause__Initialize(void)
{
    External_Clause__erase(External_Clause__null);
}

/* {External_Declaration} stuff: */

struct External_Declaration__Struct External_Declaration__Initial = {
    &Keyword__Initial,
    &Typed_Name__Initial,
    &Type__Initial,
    &Token__Initial,
};

External_Declaration External_Declaration__null = &External_Declaration__Initial;
void External_Declaration__erase(
  External_Declaration external_declaration)
{
    external_declaration->external = Keyword__null;
    external_declaration->typed_name = Typed_Name__null;
    external_declaration->type = Type__null;
    external_declaration->end_of_line = Token__null;
}

External_Declaration External_Declaration__new(void)
{
    External_Declaration external_declaration;
    extern void *malloc(unsigned int);

    external_declaration = (External_Declaration)malloc(sizeof(*external_declaration));
    external_declaration->external = Keyword__null;
    external_declaration->typed_name = Typed_Name__null;
    external_declaration->type = Type__null;
    external_declaration->end_of_line = Token__null;
    return external_declaration;
}

void External_Declaration__Initialize(void)
{
    External_Declaration__erase(External_Declaration__null);
}

/* {External_Named_Declaration} stuff: */

struct External_Named_Declaration__Struct External_Named_Declaration__Initial = {
    &Keyword__Initial,
    &Typed_Name__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
};

External_Named_Declaration External_Named_Declaration__null = &External_Named_Declaration__Initial;
void External_Named_Declaration__erase(
  External_Named_Declaration external_named_declaration)
{
    external_named_declaration->external = Keyword__null;
    external_named_declaration->typed_name = Typed_Name__null;
    external_named_declaration->equals = Token__null;
    external_named_declaration->string = Token__null;
    external_named_declaration->end_of_line = Token__null;
}

External_Named_Declaration External_Named_Declaration__new(void)
{
    External_Named_Declaration external_named_declaration;
    extern void *malloc(unsigned int);

    external_named_declaration = (External_Named_Declaration)malloc(sizeof(*external_named_declaration));
    external_named_declaration->external = Keyword__null;
    external_named_declaration->typed_name = Typed_Name__null;
    external_named_declaration->equals = Token__null;
    external_named_declaration->string = Token__null;
    external_named_declaration->end_of_line = Token__null;
    return external_named_declaration;
}

void External_Named_Declaration__Initialize(void)
{
    External_Named_Declaration__erase(External_Named_Declaration__null);
}

/* {Global_Declaration} stuff: */

struct Global_Declaration__Struct Global_Declaration__Initial = {
    &Keyword__Initial,
    &Typed_Name__Initial,
    &Type__Initial,
    &Token__Initial,
};

Global_Declaration Global_Declaration__null = &Global_Declaration__Initial;
void Global_Declaration__erase(
  Global_Declaration global_declaration)
{
    global_declaration->global = Keyword__null;
    global_declaration->typed_name = Typed_Name__null;
    global_declaration->type = Type__null;
    global_declaration->end_of_line = Token__null;
}

Global_Declaration Global_Declaration__new(void)
{
    Global_Declaration global_declaration;
    extern void *malloc(unsigned int);

    global_declaration = (Global_Declaration)malloc(sizeof(*global_declaration));
    global_declaration->global = Keyword__null;
    global_declaration->typed_name = Typed_Name__null;
    global_declaration->type = Type__null;
    global_declaration->end_of_line = Token__null;
    return global_declaration;
}

void Global_Declaration__Initialize(void)
{
    Global_Declaration__erase(Global_Declaration__null);
}

/* {Include_String_Declaration} stuff: */

struct Include_String_Declaration__Struct Include_String_Declaration__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Include_String_Declaration Include_String_Declaration__null = &Include_String_Declaration__Initial;
void Include_String_Declaration__erase(
  Include_String_Declaration include_string_declaration)
{
    include_string_declaration->include = Keyword__null;
    include_string_declaration->string = Token__null;
    include_string_declaration->end_of_line = Token__null;
}

Include_String_Declaration Include_String_Declaration__new(void)
{
    Include_String_Declaration include_string_declaration;
    extern void *malloc(unsigned int);

    include_string_declaration = (Include_String_Declaration)malloc(sizeof(*include_string_declaration));
    include_string_declaration->include = Keyword__null;
    include_string_declaration->string = Token__null;
    include_string_declaration->end_of_line = Token__null;
    return include_string_declaration;
}

void Include_String_Declaration__Initialize(void)
{
    Include_String_Declaration__erase(Include_String_Declaration__null);
}

/* {Global_Library_Declaration} stuff: */

struct Global_Library_Declaration__Struct Global_Library_Declaration__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Global_Library_Declaration Global_Library_Declaration__null = &Global_Library_Declaration__Initial;
void Global_Library_Declaration__erase(
  Global_Library_Declaration global_library_declaration)
{
    global_library_declaration->global_library = Keyword__null;
    global_library_declaration->name = Token__null;
    global_library_declaration->end_of_line = Token__null;
}

Global_Library_Declaration Global_Library_Declaration__new(void)
{
    Global_Library_Declaration global_library_declaration;
    extern void *malloc(unsigned int);

    global_library_declaration = (Global_Library_Declaration)malloc(sizeof(*global_library_declaration));
    global_library_declaration->global_library = Keyword__null;
    global_library_declaration->name = Token__null;
    global_library_declaration->end_of_line = Token__null;
    return global_library_declaration;
}

void Global_Library_Declaration__Initialize(void)
{
    Global_Library_Declaration__erase(Global_Library_Declaration__null);
}

/* {Library_Declaration} stuff: */

struct Library_Declaration__Struct Library_Declaration__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Library_Declaration Library_Declaration__null = &Library_Declaration__Initial;
void Library_Declaration__erase(
  Library_Declaration library_declaration)
{
    library_declaration->library = Keyword__null;
    library_declaration->name = Token__null;
    library_declaration->end_of_line = Token__null;
}

Library_Declaration Library_Declaration__new(void)
{
    Library_Declaration library_declaration;
    extern void *malloc(unsigned int);

    library_declaration = (Library_Declaration)malloc(sizeof(*library_declaration));
    library_declaration->library = Keyword__null;
    library_declaration->name = Token__null;
    library_declaration->end_of_line = Token__null;
    return library_declaration;
}

void Library_Declaration__Initialize(void)
{
    Library_Declaration__erase(Library_Declaration__null);
}

/* {Interface_Declaration} stuff: */

struct Interface_Declaration__Struct Interface_Declaration__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Interface_Declaration Interface_Declaration__null = &Interface_Declaration__Initial;
void Interface_Declaration__erase(
  Interface_Declaration interface_declaration)
{
    interface_declaration->interface = Keyword__null;
    interface_declaration->name = Token__null;
    interface_declaration->end_of_line = Token__null;
}

Interface_Declaration Interface_Declaration__new(void)
{
    Interface_Declaration interface_declaration;
    extern void *malloc(unsigned int);

    interface_declaration = (Interface_Declaration)malloc(sizeof(*interface_declaration));
    interface_declaration->interface = Keyword__null;
    interface_declaration->name = Token__null;
    interface_declaration->end_of_line = Token__null;
    return interface_declaration;
}

void Interface_Declaration__Initialize(void)
{
    Interface_Declaration__erase(Interface_Declaration__null);
}

/* {Load_Declaration} stuff: */

struct Load_Declaration__Struct Load_Declaration__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Load_Declaration Load_Declaration__null = &Load_Declaration__Initial;
void Load_Declaration__erase(
  Load_Declaration load_declaration)
{
    load_declaration->load = Keyword__null;
    load_declaration->string = Token__null;
    load_declaration->end_of_line = Token__null;
}

Load_Declaration Load_Declaration__new(void)
{
    Load_Declaration load_declaration;
    extern void *malloc(unsigned int);

    load_declaration = (Load_Declaration)malloc(sizeof(*load_declaration));
    load_declaration->load = Keyword__null;
    load_declaration->string = Token__null;
    load_declaration->end_of_line = Token__null;
    return load_declaration;
}

void Load_Declaration__Initialize(void)
{
    Load_Declaration__erase(Load_Declaration__null);
}

/* {Collection_Declaration} stuff: */

struct Collection_Declaration__Struct Collection_Declaration__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
};

Collection_Declaration Collection_Declaration__null = &Collection_Declaration__Initial;
void Collection_Declaration__erase(
  Collection_Declaration collection_declaration)
{
    collection_declaration->collection = Keyword__null;
    collection_declaration->name = Token__null;
    collection_declaration->float_number = Token__null;
    collection_declaration->end_of_line = Token__null;
}

Collection_Declaration Collection_Declaration__new(void)
{
    Collection_Declaration collection_declaration;
    extern void *malloc(unsigned int);

    collection_declaration = (Collection_Declaration)malloc(sizeof(*collection_declaration));
    collection_declaration->collection = Keyword__null;
    collection_declaration->name = Token__null;
    collection_declaration->float_number = Token__null;
    collection_declaration->end_of_line = Token__null;
    return collection_declaration;
}

void Collection_Declaration__Initialize(void)
{
    Collection_Declaration__erase(Collection_Declaration__null);
}

/* {Require_Declaration} stuff: */

struct Require_Declaration__Struct Require_Declaration__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Require_Declaration Require_Declaration__null = &Require_Declaration__Initial;
void Require_Declaration__erase(
  Require_Declaration require_declaration)
{
    require_declaration->require = Keyword__null;
    require_declaration->name = Token__null;
    require_declaration->end_of_line = Token__null;
}

Require_Declaration Require_Declaration__new(void)
{
    Require_Declaration require_declaration;
    extern void *malloc(unsigned int);

    require_declaration = (Require_Declaration)malloc(sizeof(*require_declaration));
    require_declaration->require = Keyword__null;
    require_declaration->name = Token__null;
    require_declaration->end_of_line = Token__null;
    return require_declaration;
}

void Require_Declaration__Initialize(void)
{
    Require_Declaration__erase(Require_Declaration__null);
}

/* {Constant_Declaration} stuff: */

struct Constant_Declaration__Struct Constant_Declaration__Initial = {
    &Keyword__Initial,
    &Typed_Name__Initial,
    &Type__Initial,
    &Token__Initial,
    &Expression__Initial,
    &Token__Initial,
};

Constant_Declaration Constant_Declaration__null = &Constant_Declaration__Initial;
void Constant_Declaration__erase(
  Constant_Declaration constant_declaration)
{
    constant_declaration->constant = Keyword__null;
    constant_declaration->typed_name = Typed_Name__null;
    constant_declaration->type = Type__null;
    constant_declaration->equals = Token__null;
    constant_declaration->expression = Expression__null;
    constant_declaration->end_of_line = Token__null;
}

Constant_Declaration Constant_Declaration__new(void)
{
    Constant_Declaration constant_declaration;
    extern void *malloc(unsigned int);

    constant_declaration = (Constant_Declaration)malloc(sizeof(*constant_declaration));
    constant_declaration->constant = Keyword__null;
    constant_declaration->typed_name = Typed_Name__null;
    constant_declaration->type = Type__null;
    constant_declaration->equals = Token__null;
    constant_declaration->expression = Expression__null;
    constant_declaration->end_of_line = Token__null;
    return constant_declaration;
}

void Constant_Declaration__Initialize(void)
{
    Constant_Declaration__erase(Constant_Declaration__null);
}

/* {Defines_Prefix_Declaration} stuff: */

struct Defines_Prefix_Declaration__Struct Defines_Prefix_Declaration__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
};

Defines_Prefix_Declaration Defines_Prefix_Declaration__null = &Defines_Prefix_Declaration__Initial;
void Defines_Prefix_Declaration__erase(
  Defines_Prefix_Declaration defines_prefix_declaration)
{
    defines_prefix_declaration->defines_prefix = Keyword__null;
    defines_prefix_declaration->prefix = Token__null;
    defines_prefix_declaration->equals = Token__null;
    defines_prefix_declaration->match = Token__null;
    defines_prefix_declaration->at_sign = Token__null;
    defines_prefix_declaration->type_name = Token__null;
    defines_prefix_declaration->end_of_line = Token__null;
}

Defines_Prefix_Declaration Defines_Prefix_Declaration__new(void)
{
    Defines_Prefix_Declaration defines_prefix_declaration;
    extern void *malloc(unsigned int);

    defines_prefix_declaration = (Defines_Prefix_Declaration)malloc(sizeof(*defines_prefix_declaration));
    defines_prefix_declaration->defines_prefix = Keyword__null;
    defines_prefix_declaration->prefix = Token__null;
    defines_prefix_declaration->equals = Token__null;
    defines_prefix_declaration->match = Token__null;
    defines_prefix_declaration->at_sign = Token__null;
    defines_prefix_declaration->type_name = Token__null;
    defines_prefix_declaration->end_of_line = Token__null;
    return defines_prefix_declaration;
}

void Defines_Prefix_Declaration__Initialize(void)
{
    Defines_Prefix_Declaration__erase(Defines_Prefix_Declaration__null);
}

/* {Routine_Declaration} stuff: */

struct Routine_Declaration__Struct Routine_Declaration__Initial = {
    &Keyword__Initial,
    &Typed_Name__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Routine_Declaration Routine_Declaration__null = &Routine_Declaration__Initial;
void Routine_Declaration__erase(
  Routine_Declaration routine_declaration)
{
    routine_declaration->routine = Keyword__null;
    routine_declaration->typed_name = Typed_Name__null;
    routine_declaration->end_of_line = Token__null;
    routine_declaration->open_indent = Token__null;
    if (routine_declaration->routine_clauses == 0) {
	routine_declaration->routine_clauses = Array__new();
    } else {
	Array__erase(routine_declaration->routine_clauses);
    }
    routine_declaration->close_indent = Token__null;
}

Routine_Declaration Routine_Declaration__new(void)
{
    Routine_Declaration routine_declaration;
    extern void *malloc(unsigned int);

    routine_declaration = (Routine_Declaration)malloc(sizeof(*routine_declaration));
    routine_declaration->routine = Keyword__null;
    routine_declaration->typed_name = Typed_Name__null;
    routine_declaration->end_of_line = Token__null;
    routine_declaration->open_indent = Token__null;
    routine_declaration->routine_clauses = Array__new();
    routine_declaration->close_indent = Token__null;
    return routine_declaration;
}

void Routine_Declaration__Initialize(void)
{
    Routine_Declaration__erase(Routine_Declaration__null);
}

/* {Routine_Clause} stuff: */

Routine_Clause_Kind Routine_Clause_Kind__end_of_line = Routine_Clause_Kind___end_of_line;
Routine_Clause_Kind Routine_Clause_Kind__note = Routine_Clause_Kind___note;
Routine_Clause_Kind Routine_Clause_Kind__takes_nothing = Routine_Clause_Kind___takes_nothing;
Routine_Clause_Kind Routine_Clause_Kind__take_import = Routine_Clause_Kind___take_import;
Routine_Clause_Kind Routine_Clause_Kind__take = Routine_Clause_Kind___take;
Routine_Clause_Kind Routine_Clause_Kind__interrupt = Routine_Clause_Kind___interrupt;
Routine_Clause_Kind Routine_Clause_Kind__returns_nothing = Routine_Clause_Kind___returns_nothing;
Routine_Clause_Kind Routine_Clause_Kind__returns = Routine_Clause_Kind___returns;
Routine_Clause_Kind Routine_Clause_Kind__external = Routine_Clause_Kind___external;
Routine_Clause_Kind Routine_Clause_Kind__c_array_access = Routine_Clause_Kind___c_array_access;
Routine_Clause_Kind Routine_Clause_Kind__scalar_cast = Routine_Clause_Kind___scalar_cast;
Routine_Clause_Kind Routine_Clause_Kind__local = Routine_Clause_Kind___local;
Routine_Clause_Kind Routine_Clause_Kind__assert = Routine_Clause_Kind___assert;
Routine_Clause_Kind Routine_Clause_Kind__call = Routine_Clause_Kind___call;
Routine_Clause_Kind Routine_Clause_Kind__do_nothing = Routine_Clause_Kind___do_nothing;
Routine_Clause_Kind Routine_Clause_Kind__if = Routine_Clause_Kind___if;
Routine_Clause_Kind Routine_Clause_Kind__return = Routine_Clause_Kind___return;
Routine_Clause_Kind Routine_Clause_Kind__fail = Routine_Clause_Kind___fail;
Routine_Clause_Kind Routine_Clause_Kind__set = Routine_Clause_Kind___set;
Routine_Clause_Kind Routine_Clause_Kind__switch = Routine_Clause_Kind___switch;
Routine_Clause_Kind Routine_Clause_Kind__while = Routine_Clause_Kind___while;
Routine_Clause_Kind Routine_Clause_Kind__error = Routine_Clause_Kind___error;
struct Routine_Clause__Struct Routine_Clause__Initial = {
};

Routine_Clause Routine_Clause__null = &Routine_Clause__Initial;
void Routine_Clause__erase(
  Routine_Clause routine_clause)
{
}

Routine_Clause Routine_Clause__new(void)
{
    Routine_Clause routine_clause;
    extern void *malloc(unsigned int);

    routine_clause = (Routine_Clause)malloc(sizeof(*routine_clause));
    return routine_clause;
}

void Routine_Clause__Initialize(void)
{
    Routine_Clause__erase(Routine_Clause__null);
}

/* {Takes_Nothing_Clause} stuff: */

struct Takes_Nothing_Clause__Struct Takes_Nothing_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
};

Takes_Nothing_Clause Takes_Nothing_Clause__null = &Takes_Nothing_Clause__Initial;
void Takes_Nothing_Clause__erase(
  Takes_Nothing_Clause takes_nothing_clause)
{
    takes_nothing_clause->takes_nothing = Keyword__null;
    takes_nothing_clause->end_of_line = Token__null;
}

Takes_Nothing_Clause Takes_Nothing_Clause__new(void)
{
    Takes_Nothing_Clause takes_nothing_clause;
    extern void *malloc(unsigned int);

    takes_nothing_clause = (Takes_Nothing_Clause)malloc(sizeof(*takes_nothing_clause));
    takes_nothing_clause->takes_nothing = Keyword__null;
    takes_nothing_clause->end_of_line = Token__null;
    return takes_nothing_clause;
}

void Takes_Nothing_Clause__Initialize(void)
{
    Takes_Nothing_Clause__erase(Takes_Nothing_Clause__null);
}

/* {Take_Clause} stuff: */

struct Take_Clause__Struct Take_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Type__Initial,
    &Token__Initial,
};

Take_Clause Take_Clause__null = &Take_Clause__Initial;
void Take_Clause__erase(
  Take_Clause take_clause)
{
    take_clause->takes = Keyword__null;
    take_clause->name = Token__null;
    take_clause->type = Type__null;
    take_clause->end_of_line = Token__null;
}

Take_Clause Take_Clause__new(void)
{
    Take_Clause take_clause;
    extern void *malloc(unsigned int);

    take_clause = (Take_Clause)malloc(sizeof(*take_clause));
    take_clause->takes = Keyword__null;
    take_clause->name = Token__null;
    take_clause->type = Type__null;
    take_clause->end_of_line = Token__null;
    return take_clause;
}

void Take_Clause__Initialize(void)
{
    Take_Clause__erase(Take_Clause__null);
}

/* {Take_Import_Clause} stuff: */

struct Take_Import_Clause__Struct Take_Import_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Type__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
};

Take_Import_Clause Take_Import_Clause__null = &Take_Import_Clause__Initial;
void Take_Import_Clause__erase(
  Take_Import_Clause take_import_clause)
{
    take_import_clause->takes_import = Keyword__null;
    take_import_clause->name = Token__null;
    take_import_clause->type = Type__null;
    take_import_clause->equals = Token__null;
    take_import_clause->string = Token__null;
    take_import_clause->end_of_line = Token__null;
}

Take_Import_Clause Take_Import_Clause__new(void)
{
    Take_Import_Clause take_import_clause;
    extern void *malloc(unsigned int);

    take_import_clause = (Take_Import_Clause)malloc(sizeof(*take_import_clause));
    take_import_clause->takes_import = Keyword__null;
    take_import_clause->name = Token__null;
    take_import_clause->type = Type__null;
    take_import_clause->equals = Token__null;
    take_import_clause->string = Token__null;
    take_import_clause->end_of_line = Token__null;
    return take_import_clause;
}

void Take_Import_Clause__Initialize(void)
{
    Take_Import_Clause__erase(Take_Import_Clause__null);
}

/* {Returns_Nothing_Clause} stuff: */

struct Returns_Nothing_Clause__Struct Returns_Nothing_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
};

Returns_Nothing_Clause Returns_Nothing_Clause__null = &Returns_Nothing_Clause__Initial;
void Returns_Nothing_Clause__erase(
  Returns_Nothing_Clause returns_nothing_clause)
{
    returns_nothing_clause->returns_nothing = Keyword__null;
    returns_nothing_clause->end_of_line = Token__null;
}

Returns_Nothing_Clause Returns_Nothing_Clause__new(void)
{
    Returns_Nothing_Clause returns_nothing_clause;
    extern void *malloc(unsigned int);

    returns_nothing_clause = (Returns_Nothing_Clause)malloc(sizeof(*returns_nothing_clause));
    returns_nothing_clause->returns_nothing = Keyword__null;
    returns_nothing_clause->end_of_line = Token__null;
    return returns_nothing_clause;
}

void Returns_Nothing_Clause__Initialize(void)
{
    Returns_Nothing_Clause__erase(Returns_Nothing_Clause__null);
}

/* {Returns_Clause} stuff: */

struct Returns_Clause__Struct Returns_Clause__Initial = {
    &Keyword__Initial,
    (Comma_Separated)0,
    &Token__Initial,
};

Returns_Clause Returns_Clause__null = &Returns_Clause__Initial;
void Returns_Clause__erase(
  Returns_Clause returns_clause)
{
    returns_clause->returns = Keyword__null;
    if (returns_clause->return_types == 0) {
	returns_clause->return_types = Comma_Separated__new();
    } else {
	Comma_Separated__erase(returns_clause->return_types);
    }
    returns_clause->end_of_line = Token__null;
}

Returns_Clause Returns_Clause__new(void)
{
    Returns_Clause returns_clause;
    extern void *malloc(unsigned int);

    returns_clause = (Returns_Clause)malloc(sizeof(*returns_clause));
    returns_clause->returns = Keyword__null;
    returns_clause->return_types = Comma_Separated__new();
    returns_clause->end_of_line = Token__null;
    return returns_clause;
}

void Returns_Clause__Initialize(void)
{
    Returns_Clause__erase(Returns_Clause__null);
}

/* {External_Routine_Clause} stuff: */

struct External_Routine_Clause__Struct External_Routine_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

External_Routine_Clause External_Routine_Clause__null = &External_Routine_Clause__Initial;
void External_Routine_Clause__erase(
  External_Routine_Clause external_routine_clause)
{
    external_routine_clause->external = Keyword__null;
    external_routine_clause->name = Token__null;
    external_routine_clause->end_of_line = Token__null;
}

External_Routine_Clause External_Routine_Clause__new(void)
{
    External_Routine_Clause external_routine_clause;
    extern void *malloc(unsigned int);

    external_routine_clause = (External_Routine_Clause)malloc(sizeof(*external_routine_clause));
    external_routine_clause->external = Keyword__null;
    external_routine_clause->name = Token__null;
    external_routine_clause->end_of_line = Token__null;
    return external_routine_clause;
}

void External_Routine_Clause__Initialize(void)
{
    External_Routine_Clause__erase(External_Routine_Clause__null);
}

/* {Scalar_Cast_Clause} stuff: */

struct Scalar_Cast_Clause__Struct Scalar_Cast_Clause__Initial = {
    &Keyword__Initial,
    &Type__Initial,
    &Token__Initial,
};

Scalar_Cast_Clause Scalar_Cast_Clause__null = &Scalar_Cast_Clause__Initial;
void Scalar_Cast_Clause__erase(
  Scalar_Cast_Clause scalar_cast_clause)
{
    scalar_cast_clause->scalar_cast = Keyword__null;
    scalar_cast_clause->type = Type__null;
    scalar_cast_clause->end_of_line = Token__null;
}

Scalar_Cast_Clause Scalar_Cast_Clause__new(void)
{
    Scalar_Cast_Clause scalar_cast_clause;
    extern void *malloc(unsigned int);

    scalar_cast_clause = (Scalar_Cast_Clause)malloc(sizeof(*scalar_cast_clause));
    scalar_cast_clause->scalar_cast = Keyword__null;
    scalar_cast_clause->type = Type__null;
    scalar_cast_clause->end_of_line = Token__null;
    return scalar_cast_clause;
}

void Scalar_Cast_Clause__Initialize(void)
{
    Scalar_Cast_Clause__erase(Scalar_Cast_Clause__null);
}

/* {Interrupt_Clause} stuff: */

struct Interrupt_Clause__Struct Interrupt_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Interrupt_Clause Interrupt_Clause__null = &Interrupt_Clause__Initial;
void Interrupt_Clause__erase(
  Interrupt_Clause interrupt_clause)
{
    interrupt_clause->interrupt = Keyword__null;
    interrupt_clause->name = Token__null;
    interrupt_clause->end_of_line = Token__null;
}

Interrupt_Clause Interrupt_Clause__new(void)
{
    Interrupt_Clause interrupt_clause;
    extern void *malloc(unsigned int);

    interrupt_clause = (Interrupt_Clause)malloc(sizeof(*interrupt_clause));
    interrupt_clause->interrupt = Keyword__null;
    interrupt_clause->name = Token__null;
    interrupt_clause->end_of_line = Token__null;
    return interrupt_clause;
}

void Interrupt_Clause__Initialize(void)
{
    Interrupt_Clause__erase(Interrupt_Clause__null);
}

/* {C_Array_Access_Clause} stuff: */

struct C_Array_Access_Clause__Struct C_Array_Access_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
};

C_Array_Access_Clause C_Array_Access_Clause__null = &C_Array_Access_Clause__Initial;
void C_Array_Access_Clause__erase(
  C_Array_Access_Clause c_array_access_clause)
{
    c_array_access_clause->c_array_access = Keyword__null;
    c_array_access_clause->end_of_line = Token__null;
}

C_Array_Access_Clause C_Array_Access_Clause__new(void)
{
    C_Array_Access_Clause c_array_access_clause;
    extern void *malloc(unsigned int);

    c_array_access_clause = (C_Array_Access_Clause)malloc(sizeof(*c_array_access_clause));
    c_array_access_clause->c_array_access = Keyword__null;
    c_array_access_clause->end_of_line = Token__null;
    return c_array_access_clause;
}

void C_Array_Access_Clause__Initialize(void)
{
    C_Array_Access_Clause__erase(C_Array_Access_Clause__null);
}

/* {Local_Clause} stuff: */

struct Local_Clause__Struct Local_Clause__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Type__Initial,
    &Token__Initial,
};

Local_Clause Local_Clause__null = &Local_Clause__Initial;
void Local_Clause__erase(
  Local_Clause local_clause)
{
    local_clause->local = Keyword__null;
    local_clause->name = Token__null;
    local_clause->type = Type__null;
    local_clause->end_of_line = Token__null;
}

Local_Clause Local_Clause__new(void)
{
    Local_Clause local_clause;
    extern void *malloc(unsigned int);

    local_clause = (Local_Clause)malloc(sizeof(*local_clause));
    local_clause->local = Keyword__null;
    local_clause->name = Token__null;
    local_clause->type = Type__null;
    local_clause->end_of_line = Token__null;
    return local_clause;
}

void Local_Clause__Initialize(void)
{
    Local_Clause__erase(Local_Clause__null);
}

/* {Statement} stuff: */

Statement_Kind Statement_Kind__end_of_line = Statement_Kind___end_of_line;
Statement_Kind Statement_Kind__note = Statement_Kind___note;
Statement_Kind Statement_Kind__assert = Statement_Kind___assert;
Statement_Kind Statement_Kind__break_level = Statement_Kind___break_level;
Statement_Kind Statement_Kind__break_empty = Statement_Kind___break_empty;
Statement_Kind Statement_Kind__call = Statement_Kind___call;
Statement_Kind Statement_Kind__continue_level = Statement_Kind___continue_level;
Statement_Kind Statement_Kind__continue_empty = Statement_Kind___continue_empty;
Statement_Kind Statement_Kind__do_nothing = Statement_Kind___do_nothing;
Statement_Kind Statement_Kind__if = Statement_Kind___if;
Statement_Kind Statement_Kind__return = Statement_Kind___return;
Statement_Kind Statement_Kind__set = Statement_Kind___set;
Statement_Kind Statement_Kind__switch = Statement_Kind___switch;
Statement_Kind Statement_Kind__while = Statement_Kind___while;
Statement_Kind Statement_Kind__error = Statement_Kind___error;
struct Statement__Struct Statement__Initial = {
};

Statement Statement__null = &Statement__Initial;
void Statement__erase(
  Statement statement)
{
}

Statement Statement__new(void)
{
    Statement statement;
    extern void *malloc(unsigned int);

    statement = (Statement)malloc(sizeof(*statement));
    return statement;
}

void Statement__Initialize(void)
{
    Statement__erase(Statement__null);
}

/* {Assert_Statement} stuff: */

struct Assert_Statement__Struct Assert_Statement__Initial = {
    &Keyword__Initial,
    &Expression__Initial,
    &Token__Initial,
};

Assert_Statement Assert_Statement__null = &Assert_Statement__Initial;
void Assert_Statement__erase(
  Assert_Statement assert_statement)
{
    assert_statement->assert = Keyword__null;
    assert_statement->expression = Expression__null;
    assert_statement->end_of_line = Token__null;
}

Assert_Statement Assert_Statement__new(void)
{
    Assert_Statement assert_statement;
    extern void *malloc(unsigned int);

    assert_statement = (Assert_Statement)malloc(sizeof(*assert_statement));
    assert_statement->assert = Keyword__null;
    assert_statement->expression = Expression__null;
    assert_statement->end_of_line = Token__null;
    return assert_statement;
}

void Assert_Statement__Initialize(void)
{
    Assert_Statement__erase(Assert_Statement__null);
}

/* {Break_Empty_Statement} stuff: */

struct Break_Empty_Statement__Struct Break_Empty_Statement__Initial = {
    &Keyword__Initial,
    &Token__Initial,
};

Break_Empty_Statement Break_Empty_Statement__null = &Break_Empty_Statement__Initial;
void Break_Empty_Statement__erase(
  Break_Empty_Statement break_empty_statement)
{
    break_empty_statement->break___k = Keyword__null;
    break_empty_statement->end_of_line = Token__null;
}

Break_Empty_Statement Break_Empty_Statement__new(void)
{
    Break_Empty_Statement break_empty_statement;
    extern void *malloc(unsigned int);

    break_empty_statement = (Break_Empty_Statement)malloc(sizeof(*break_empty_statement));
    break_empty_statement->break___k = Keyword__null;
    break_empty_statement->end_of_line = Token__null;
    return break_empty_statement;
}

void Break_Empty_Statement__Initialize(void)
{
    Break_Empty_Statement__erase(Break_Empty_Statement__null);
}

/* {Break_Level_Statement} stuff: */

struct Break_Level_Statement__Struct Break_Level_Statement__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Break_Level_Statement Break_Level_Statement__null = &Break_Level_Statement__Initial;
void Break_Level_Statement__erase(
  Break_Level_Statement break_level_statement)
{
    break_level_statement->break___k = Keyword__null;
    break_level_statement->number = Token__null;
    break_level_statement->end_of_line = Token__null;
}

Break_Level_Statement Break_Level_Statement__new(void)
{
    Break_Level_Statement break_level_statement;
    extern void *malloc(unsigned int);

    break_level_statement = (Break_Level_Statement)malloc(sizeof(*break_level_statement));
    break_level_statement->break___k = Keyword__null;
    break_level_statement->number = Token__null;
    break_level_statement->end_of_line = Token__null;
    return break_level_statement;
}

void Break_Level_Statement__Initialize(void)
{
    Break_Level_Statement__erase(Break_Level_Statement__null);
}

/* {Call_Statement} stuff: */

struct Call_Statement__Struct Call_Statement__Initial = {
    &Keyword__Initial,
    &Expression__Initial,
    &Token__Initial,
};

Call_Statement Call_Statement__null = &Call_Statement__Initial;
void Call_Statement__erase(
  Call_Statement call_statement)
{
    call_statement->call = Keyword__null;
    call_statement->expression = Expression__null;
    call_statement->end_of_line = Token__null;
}

Call_Statement Call_Statement__new(void)
{
    Call_Statement call_statement;
    extern void *malloc(unsigned int);

    call_statement = (Call_Statement)malloc(sizeof(*call_statement));
    call_statement->call = Keyword__null;
    call_statement->expression = Expression__null;
    call_statement->end_of_line = Token__null;
    return call_statement;
}

void Call_Statement__Initialize(void)
{
    Call_Statement__erase(Call_Statement__null);
}

/* {Continue_Empty_Statement} stuff: */

struct Continue_Empty_Statement__Struct Continue_Empty_Statement__Initial = {
    &Keyword__Initial,
    &Token__Initial,
};

Continue_Empty_Statement Continue_Empty_Statement__null = &Continue_Empty_Statement__Initial;
void Continue_Empty_Statement__erase(
  Continue_Empty_Statement continue_empty_statement)
{
    continue_empty_statement->continue___k = Keyword__null;
    continue_empty_statement->end_of_line = Token__null;
}

Continue_Empty_Statement Continue_Empty_Statement__new(void)
{
    Continue_Empty_Statement continue_empty_statement;
    extern void *malloc(unsigned int);

    continue_empty_statement = (Continue_Empty_Statement)malloc(sizeof(*continue_empty_statement));
    continue_empty_statement->continue___k = Keyword__null;
    continue_empty_statement->end_of_line = Token__null;
    return continue_empty_statement;
}

void Continue_Empty_Statement__Initialize(void)
{
    Continue_Empty_Statement__erase(Continue_Empty_Statement__null);
}

/* {Continue_Level_Statement} stuff: */

struct Continue_Level_Statement__Struct Continue_Level_Statement__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Continue_Level_Statement Continue_Level_Statement__null = &Continue_Level_Statement__Initial;
void Continue_Level_Statement__erase(
  Continue_Level_Statement continue_level_statement)
{
    continue_level_statement->continue___k = Keyword__null;
    continue_level_statement->number = Token__null;
    continue_level_statement->end_of_line = Token__null;
}

Continue_Level_Statement Continue_Level_Statement__new(void)
{
    Continue_Level_Statement continue_level_statement;
    extern void *malloc(unsigned int);

    continue_level_statement = (Continue_Level_Statement)malloc(sizeof(*continue_level_statement));
    continue_level_statement->continue___k = Keyword__null;
    continue_level_statement->number = Token__null;
    continue_level_statement->end_of_line = Token__null;
    return continue_level_statement;
}

void Continue_Level_Statement__Initialize(void)
{
    Continue_Level_Statement__erase(Continue_Level_Statement__null);
}

/* {Do_Nothing_Statement} stuff: */

struct Do_Nothing_Statement__Struct Do_Nothing_Statement__Initial = {
    &Keyword__Initial,
    &Token__Initial,
};

Do_Nothing_Statement Do_Nothing_Statement__null = &Do_Nothing_Statement__Initial;
void Do_Nothing_Statement__erase(
  Do_Nothing_Statement do_nothing_statement)
{
    do_nothing_statement->do_nothing = Keyword__null;
    do_nothing_statement->end_of_line = Token__null;
}

Do_Nothing_Statement Do_Nothing_Statement__new(void)
{
    Do_Nothing_Statement do_nothing_statement;
    extern void *malloc(unsigned int);

    do_nothing_statement = (Do_Nothing_Statement)malloc(sizeof(*do_nothing_statement));
    do_nothing_statement->do_nothing = Keyword__null;
    do_nothing_statement->end_of_line = Token__null;
    return do_nothing_statement;
}

void Do_Nothing_Statement__Initialize(void)
{
    Do_Nothing_Statement__erase(Do_Nothing_Statement__null);
}

/* {Fail_Statement} stuff: */

struct Fail_Statement__Struct Fail_Statement__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
};

Fail_Statement Fail_Statement__null = &Fail_Statement__Initial;
void Fail_Statement__erase(
  Fail_Statement fail_statement)
{
    fail_statement->fail = Keyword__null;
    fail_statement->string = Token__null;
    fail_statement->end_of_line = Token__null;
}

Fail_Statement Fail_Statement__new(void)
{
    Fail_Statement fail_statement;
    extern void *malloc(unsigned int);

    fail_statement = (Fail_Statement)malloc(sizeof(*fail_statement));
    fail_statement->fail = Keyword__null;
    fail_statement->string = Token__null;
    fail_statement->end_of_line = Token__null;
    return fail_statement;
}

void Fail_Statement__Initialize(void)
{
    Fail_Statement__erase(Fail_Statement__null);
}

/* {If_Statement} stuff: */

struct If_Statement__Struct If_Statement__Initial = {
    (Array)0,
};

If_Statement If_Statement__null = &If_Statement__Initial;
void If_Statement__erase(
  If_Statement if_statement)
{
    if (if_statement->if_clauses == 0) {
	if_statement->if_clauses = Array__new();
    } else {
	Array__erase(if_statement->if_clauses);
    }
}

If_Statement If_Statement__new(void)
{
    If_Statement if_statement;
    extern void *malloc(unsigned int);

    if_statement = (If_Statement)malloc(sizeof(*if_statement));
    if_statement->if_clauses = Array__new();
    return if_statement;
}

void If_Statement__Initialize(void)
{
    If_Statement__erase(If_Statement__null);
}

/* {If_Clause} stuff: */

If_Clause_Kind If_Clause_Kind__if_part = If_Clause_Kind___if_part;
If_Clause_Kind If_Clause_Kind__else_if_part = If_Clause_Kind___else_if_part;
If_Clause_Kind If_Clause_Kind__else_part = If_Clause_Kind___else_part;
struct If_Clause__Struct If_Clause__Initial = {
};

If_Clause If_Clause__null = &If_Clause__Initial;
void If_Clause__erase(
  If_Clause if_clause)
{
}

If_Clause If_Clause__new(void)
{
    If_Clause if_clause;
    extern void *malloc(unsigned int);

    if_clause = (If_Clause)malloc(sizeof(*if_clause));
    return if_clause;
}

void If_Clause__Initialize(void)
{
    If_Clause__erase(If_Clause__null);
}

/* {If_Part} stuff: */

struct If_Part__Struct If_Part__Initial = {
    &Keyword__Initial,
    &Expression__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

If_Part If_Part__null = &If_Part__Initial;
void If_Part__erase(
  If_Part if_part)
{
    if_part->if___k = Keyword__null;
    if_part->expression = Expression__null;
    if_part->end_of_line = Token__null;
    if_part->open_indent = Token__null;
    if (if_part->statements == 0) {
	if_part->statements = Array__new();
    } else {
	Array__erase(if_part->statements);
    }
    if_part->close_indent = Token__null;
}

If_Part If_Part__new(void)
{
    If_Part if_part;
    extern void *malloc(unsigned int);

    if_part = (If_Part)malloc(sizeof(*if_part));
    if_part->if___k = Keyword__null;
    if_part->expression = Expression__null;
    if_part->end_of_line = Token__null;
    if_part->open_indent = Token__null;
    if_part->statements = Array__new();
    if_part->close_indent = Token__null;
    return if_part;
}

void If_Part__Initialize(void)
{
    If_Part__erase(If_Part__null);
}

/* {Else_If_Part} stuff: */

struct Else_If_Part__Struct Else_If_Part__Initial = {
    &Keyword__Initial,
    &Expression__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Else_If_Part Else_If_Part__null = &Else_If_Part__Initial;
void Else_If_Part__erase(
  Else_If_Part else_if_part)
{
    else_if_part->else_if = Keyword__null;
    else_if_part->expression = Expression__null;
    else_if_part->end_of_line = Token__null;
    else_if_part->open_indent = Token__null;
    if (else_if_part->statements == 0) {
	else_if_part->statements = Array__new();
    } else {
	Array__erase(else_if_part->statements);
    }
    else_if_part->close_indent = Token__null;
}

Else_If_Part Else_If_Part__new(void)
{
    Else_If_Part else_if_part;
    extern void *malloc(unsigned int);

    else_if_part = (Else_If_Part)malloc(sizeof(*else_if_part));
    else_if_part->else_if = Keyword__null;
    else_if_part->expression = Expression__null;
    else_if_part->end_of_line = Token__null;
    else_if_part->open_indent = Token__null;
    else_if_part->statements = Array__new();
    else_if_part->close_indent = Token__null;
    return else_if_part;
}

void Else_If_Part__Initialize(void)
{
    Else_If_Part__erase(Else_If_Part__null);
}

/* {Else_Part} stuff: */

struct Else_Part__Struct Else_Part__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Else_Part Else_Part__null = &Else_Part__Initial;
void Else_Part__erase(
  Else_Part else_part)
{
    else_part->else___k = Keyword__null;
    else_part->end_of_line = Token__null;
    else_part->open_indent = Token__null;
    if (else_part->statements == 0) {
	else_part->statements = Array__new();
    } else {
	Array__erase(else_part->statements);
    }
    else_part->close_indent = Token__null;
}

Else_Part Else_Part__new(void)
{
    Else_Part else_part;
    extern void *malloc(unsigned int);

    else_part = (Else_Part)malloc(sizeof(*else_part));
    else_part->else___k = Keyword__null;
    else_part->end_of_line = Token__null;
    else_part->open_indent = Token__null;
    else_part->statements = Array__new();
    else_part->close_indent = Token__null;
    return else_part;
}

void Else_Part__Initialize(void)
{
    Else_Part__erase(Else_Part__null);
}

/* {Return_Statement} stuff: */

Return_Clause_Kind Return_Clause_Kind__expression = Return_Clause_Kind___expression;
Return_Clause_Kind Return_Clause_Kind__empty = Return_Clause_Kind___empty;
struct Return_Statement__Struct Return_Statement__Initial = {
};

Return_Statement Return_Statement__null = &Return_Statement__Initial;
void Return_Statement__erase(
  Return_Statement return_statement)
{
}

Return_Statement Return_Statement__new(void)
{
    Return_Statement return_statement;
    extern void *malloc(unsigned int);

    return_statement = (Return_Statement)malloc(sizeof(*return_statement));
    return return_statement;
}

void Return_Statement__Initialize(void)
{
    Return_Statement__erase(Return_Statement__null);
}

/* {Return_Clause_Expression} stuff: */

struct Return_Clause_Expression__Struct Return_Clause_Expression__Initial = {
    &Keyword__Initial,
    &Expression__Initial,
    &Token__Initial,
};

Return_Clause_Expression Return_Clause_Expression__null = &Return_Clause_Expression__Initial;
void Return_Clause_Expression__erase(
  Return_Clause_Expression return_clause_expression)
{
    return_clause_expression->return___k = Keyword__null;
    return_clause_expression->expression = Expression__null;
    return_clause_expression->end_of_line = Token__null;
}

Return_Clause_Expression Return_Clause_Expression__new(void)
{
    Return_Clause_Expression return_clause_expression;
    extern void *malloc(unsigned int);

    return_clause_expression = (Return_Clause_Expression)malloc(sizeof(*return_clause_expression));
    return_clause_expression->return___k = Keyword__null;
    return_clause_expression->expression = Expression__null;
    return_clause_expression->end_of_line = Token__null;
    return return_clause_expression;
}

void Return_Clause_Expression__Initialize(void)
{
    Return_Clause_Expression__erase(Return_Clause_Expression__null);
}

/* {Return_Clause_Empty} stuff: */

struct Return_Clause_Empty__Struct Return_Clause_Empty__Initial = {
    &Keyword__Initial,
    &Token__Initial,
};

Return_Clause_Empty Return_Clause_Empty__null = &Return_Clause_Empty__Initial;
void Return_Clause_Empty__erase(
  Return_Clause_Empty return_clause_empty)
{
    return_clause_empty->return___k = Keyword__null;
    return_clause_empty->end_of_line = Token__null;
}

Return_Clause_Empty Return_Clause_Empty__new(void)
{
    Return_Clause_Empty return_clause_empty;
    extern void *malloc(unsigned int);

    return_clause_empty = (Return_Clause_Empty)malloc(sizeof(*return_clause_empty));
    return_clause_empty->return___k = Keyword__null;
    return_clause_empty->end_of_line = Token__null;
    return return_clause_empty;
}

void Return_Clause_Empty__Initialize(void)
{
    Return_Clause_Empty__erase(Return_Clause_Empty__null);
}

/* {Set_Statement} stuff: */

struct Set_Statement__Struct Set_Statement__Initial = {
    &Token__Initial,
    &Expression__Initial,
    &Token__Initial,
};

Set_Statement Set_Statement__null = &Set_Statement__Initial;
void Set_Statement__erase(
  Set_Statement set_statement)
{
    set_statement->set = Token__null;
    set_statement->expression = Expression__null;
    set_statement->end_of_line = Token__null;
}

Set_Statement Set_Statement__new(void)
{
    Set_Statement set_statement;
    extern void *malloc(unsigned int);

    set_statement = (Set_Statement)malloc(sizeof(*set_statement));
    set_statement->set = Token__null;
    set_statement->expression = Expression__null;
    set_statement->end_of_line = Token__null;
    return set_statement;
}

void Set_Statement__Initialize(void)
{
    Set_Statement__erase(Set_Statement__null);
}

/* {Switch_Statement} stuff: */

struct Switch_Statement__Struct Switch_Statement__Initial = {
    &Keyword__Initial,
    &Expression__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Switch_Statement Switch_Statement__null = &Switch_Statement__Initial;
void Switch_Statement__erase(
  Switch_Statement switch_statement)
{
    switch_statement->switch___k = Keyword__null;
    switch_statement->expression = Expression__null;
    switch_statement->end_of_line = Token__null;
    switch_statement->open_indent = Token__null;
    if (switch_statement->switch_clauses == 0) {
	switch_statement->switch_clauses = Array__new();
    } else {
	Array__erase(switch_statement->switch_clauses);
    }
    switch_statement->close_indent = Token__null;
}

Switch_Statement Switch_Statement__new(void)
{
    Switch_Statement switch_statement;
    extern void *malloc(unsigned int);

    switch_statement = (Switch_Statement)malloc(sizeof(*switch_statement));
    switch_statement->switch___k = Keyword__null;
    switch_statement->expression = Expression__null;
    switch_statement->end_of_line = Token__null;
    switch_statement->open_indent = Token__null;
    switch_statement->switch_clauses = Array__new();
    switch_statement->close_indent = Token__null;
    return switch_statement;
}

void Switch_Statement__Initialize(void)
{
    Switch_Statement__erase(Switch_Statement__null);
}

/* {Switch_Clause} stuff: */

Switch_Clause_Kind Switch_Clause_Kind__end_of_line = Switch_Clause_Kind___end_of_line;
Switch_Clause_Kind Switch_Clause_Kind__note = Switch_Clause_Kind___note;
Switch_Clause_Kind Switch_Clause_Kind__case = Switch_Clause_Kind___case;
Switch_Clause_Kind Switch_Clause_Kind__default = Switch_Clause_Kind___default;
Switch_Clause_Kind Switch_Clause_Kind__all_cases_required = Switch_Clause_Kind___all_cases_required;
Switch_Clause_Kind Switch_Clause_Kind__error = Switch_Clause_Kind___error;
struct Switch_Clause__Struct Switch_Clause__Initial = {
};

Switch_Clause Switch_Clause__null = &Switch_Clause__Initial;
void Switch_Clause__erase(
  Switch_Clause switch_clause)
{
}

Switch_Clause Switch_Clause__new(void)
{
    Switch_Clause switch_clause;
    extern void *malloc(unsigned int);

    switch_clause = (Switch_Clause)malloc(sizeof(*switch_clause));
    return switch_clause;
}

void Switch_Clause__Initialize(void)
{
    Switch_Clause__erase(Switch_Clause__null);
}

/* {Switch_Case} stuff: */

struct Switch_Case__Struct Switch_Case__Initial = {
    &Keyword__Initial,
    &Expression__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Switch_Case Switch_Case__null = &Switch_Case__Initial;
void Switch_Case__erase(
  Switch_Case switch_case)
{
    switch_case->case___k = Keyword__null;
    switch_case->cases = Expression__null;
    switch_case->end_of_line = Token__null;
    switch_case->open_indent = Token__null;
    if (switch_case->statements == 0) {
	switch_case->statements = Array__new();
    } else {
	Array__erase(switch_case->statements);
    }
    switch_case->close_indent = Token__null;
}

Switch_Case Switch_Case__new(void)
{
    Switch_Case switch_case;
    extern void *malloc(unsigned int);

    switch_case = (Switch_Case)malloc(sizeof(*switch_case));
    switch_case->case___k = Keyword__null;
    switch_case->cases = Expression__null;
    switch_case->end_of_line = Token__null;
    switch_case->open_indent = Token__null;
    switch_case->statements = Array__new();
    switch_case->close_indent = Token__null;
    return switch_case;
}

void Switch_Case__Initialize(void)
{
    Switch_Case__erase(Switch_Case__null);
}

/* {Switch_Default} stuff: */

struct Switch_Default__Struct Switch_Default__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

Switch_Default Switch_Default__null = &Switch_Default__Initial;
void Switch_Default__erase(
  Switch_Default switch_default)
{
    switch_default->default___k = Keyword__null;
    switch_default->end_of_line = Token__null;
    switch_default->open_indent = Token__null;
    if (switch_default->statements == 0) {
	switch_default->statements = Array__new();
    } else {
	Array__erase(switch_default->statements);
    }
    switch_default->close_indent = Token__null;
}

Switch_Default Switch_Default__new(void)
{
    Switch_Default switch_default;
    extern void *malloc(unsigned int);

    switch_default = (Switch_Default)malloc(sizeof(*switch_default));
    switch_default->default___k = Keyword__null;
    switch_default->end_of_line = Token__null;
    switch_default->open_indent = Token__null;
    switch_default->statements = Array__new();
    switch_default->close_indent = Token__null;
    return switch_default;
}

void Switch_Default__Initialize(void)
{
    Switch_Default__erase(Switch_Default__null);
}

/* {Switch_All_Cases_Required} stuff: */

struct Switch_All_Cases_Required__Struct Switch_All_Cases_Required__Initial = {
    &Keyword__Initial,
    &Token__Initial,
};

Switch_All_Cases_Required Switch_All_Cases_Required__null = &Switch_All_Cases_Required__Initial;
void Switch_All_Cases_Required__erase(
  Switch_All_Cases_Required switch_all_cases_required)
{
    switch_all_cases_required->all_cases_required = Keyword__null;
    switch_all_cases_required->end_of_line = Token__null;
}

Switch_All_Cases_Required Switch_All_Cases_Required__new(void)
{
    Switch_All_Cases_Required switch_all_cases_required;
    extern void *malloc(unsigned int);

    switch_all_cases_required = (Switch_All_Cases_Required)malloc(sizeof(*switch_all_cases_required));
    switch_all_cases_required->all_cases_required = Keyword__null;
    switch_all_cases_required->end_of_line = Token__null;
    return switch_all_cases_required;
}

void Switch_All_Cases_Required__Initialize(void)
{
    Switch_All_Cases_Required__erase(Switch_All_Cases_Required__null);
}

/* {Case_Name} stuff: */

struct Case_Name__Struct Case_Name__Initial = {
    &Token__Initial,
};

Case_Name Case_Name__null = &Case_Name__Initial;
void Case_Name__erase(
  Case_Name case_name)
{
    case_name->name = Token__null;
}

Case_Name Case_Name__new(void)
{
    Case_Name case_name;
    extern void *malloc(unsigned int);

    case_name = (Case_Name)malloc(sizeof(*case_name));
    case_name->name = Token__null;
    return case_name;
}

void Case_Name__Initialize(void)
{
    Case_Name__erase(Case_Name__null);
}

/* {While_Statement} stuff: */

struct While_Statement__Struct While_Statement__Initial = {
    &Keyword__Initial,
    &Expression__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
};

While_Statement While_Statement__null = &While_Statement__Initial;
void While_Statement__erase(
  While_Statement while_statement)
{
    while_statement->while___k = Keyword__null;
    while_statement->expression = Expression__null;
    while_statement->end_of_line = Token__null;
    while_statement->open_indent = Token__null;
    if (while_statement->statements == 0) {
	while_statement->statements = Array__new();
    } else {
	Array__erase(while_statement->statements);
    }
    while_statement->close_indent = Token__null;
}

While_Statement While_Statement__new(void)
{
    While_Statement while_statement;
    extern void *malloc(unsigned int);

    while_statement = (While_Statement)malloc(sizeof(*while_statement));
    while_statement->while___k = Keyword__null;
    while_statement->expression = Expression__null;
    while_statement->end_of_line = Token__null;
    while_statement->open_indent = Token__null;
    while_statement->statements = Array__new();
    while_statement->close_indent = Token__null;
    return while_statement;
}

void While_Statement__Initialize(void)
{
    While_Statement__erase(While_Statement__null);
}

/* {Expression} stuff: */

Expression_Kind Expression_Kind__binary = Expression_Kind___binary;
Expression_Kind Expression_Kind__bracket = Expression_Kind___bracket;
Expression_Kind Expression_Kind__character = Expression_Kind___character;
Expression_Kind Expression_Kind__float_number = Expression_Kind___float_number;
Expression_Kind Expression_Kind__list = Expression_Kind___list;
Expression_Kind Expression_Kind__number = Expression_Kind___number;
Expression_Kind Expression_Kind__parenthesis = Expression_Kind___parenthesis;
Expression_Kind Expression_Kind__string = Expression_Kind___string;
Expression_Kind Expression_Kind__symbol = Expression_Kind___symbol;
Expression_Kind Expression_Kind__unary = Expression_Kind___unary;
Expression_Kind Expression_Kind__error = Expression_Kind___error;
struct Expression__Struct Expression__Initial = {
};

Expression Expression__null = &Expression__Initial;
void Expression__erase(
  Expression expression)
{
}

Expression Expression__new(void)
{
    Expression expression;
    extern void *malloc(unsigned int);

    expression = (Expression)malloc(sizeof(*expression));
    return expression;
}

void Expression__Initialize(void)
{
    Expression__erase(Expression__null);
}

/* {Binary_Expression} stuff: */

struct Binary_Expression__Struct Binary_Expression__Initial = {
    &Expression__Initial,
    &Token__Initial,
    &Expression__Initial,
};

Binary_Expression Binary_Expression__null = &Binary_Expression__Initial;
void Binary_Expression__erase(
  Binary_Expression binary_expression)
{
    binary_expression->left = Expression__null;
    binary_expression->operator = Token__null;
    binary_expression->right = Expression__null;
}

Binary_Expression Binary_Expression__new(void)
{
    Binary_Expression binary_expression;
    extern void *malloc(unsigned int);

    binary_expression = (Binary_Expression)malloc(sizeof(*binary_expression));
    binary_expression->left = Expression__null;
    binary_expression->operator = Token__null;
    binary_expression->right = Expression__null;
    return binary_expression;
}

void Binary_Expression__Initialize(void)
{
    Binary_Expression__erase(Binary_Expression__null);
}

/* {Bracket_Expression} stuff: */

struct Bracket_Expression__Struct Bracket_Expression__Initial = {
    &Expression__Initial,
    &Token__Initial,
    &Expression__Initial,
    &Token__Initial,
};

Bracket_Expression Bracket_Expression__null = &Bracket_Expression__Initial;
void Bracket_Expression__erase(
  Bracket_Expression bracket_expression)
{
    bracket_expression->expression1 = Expression__null;
    bracket_expression->open_bracket = Token__null;
    bracket_expression->expression2 = Expression__null;
    bracket_expression->close_bracket = Token__null;
}

Bracket_Expression Bracket_Expression__new(void)
{
    Bracket_Expression bracket_expression;
    extern void *malloc(unsigned int);

    bracket_expression = (Bracket_Expression)malloc(sizeof(*bracket_expression));
    bracket_expression->expression1 = Expression__null;
    bracket_expression->open_bracket = Token__null;
    bracket_expression->expression2 = Expression__null;
    bracket_expression->close_bracket = Token__null;
    return bracket_expression;
}

void Bracket_Expression__Initialize(void)
{
    Bracket_Expression__erase(Bracket_Expression__null);
}

/* {List_Expression} stuff: */

struct List_Expression__Struct List_Expression__Initial = {
    (Array)0,
    (Array)0,
    &Token__Initial,
};

List_Expression List_Expression__null = &List_Expression__Initial;
void List_Expression__erase(
  List_Expression list_expression)
{
    if (list_expression->operators == 0) {
	list_expression->operators = Array__new();
    } else {
	Array__erase(list_expression->operators);
    }
    if (list_expression->expressions == 0) {
	list_expression->expressions = Array__new();
    } else {
	Array__erase(list_expression->expressions);
    }
    list_expression->location = Token__null;
}

List_Expression List_Expression__new(void)
{
    List_Expression list_expression;
    extern void *malloc(unsigned int);

    list_expression = (List_Expression)malloc(sizeof(*list_expression));
    list_expression->operators = Array__new();
    list_expression->expressions = Array__new();
    list_expression->location = Token__null;
    return list_expression;
}

void List_Expression__Initialize(void)
{
    List_Expression__erase(List_Expression__null);
}

/* {Parenthesis_Expression} stuff: */

struct Parenthesis_Expression__Struct Parenthesis_Expression__Initial = {
    &Token__Initial,
    &Expression__Initial,
    &Token__Initial,
};

Parenthesis_Expression Parenthesis_Expression__null = &Parenthesis_Expression__Initial;
void Parenthesis_Expression__erase(
  Parenthesis_Expression parenthesis_expression)
{
    parenthesis_expression->open_parenthesis = Token__null;
    parenthesis_expression->expression = Expression__null;
    parenthesis_expression->close_parenthesis = Token__null;
}

Parenthesis_Expression Parenthesis_Expression__new(void)
{
    Parenthesis_Expression parenthesis_expression;
    extern void *malloc(unsigned int);

    parenthesis_expression = (Parenthesis_Expression)malloc(sizeof(*parenthesis_expression));
    parenthesis_expression->open_parenthesis = Token__null;
    parenthesis_expression->expression = Expression__null;
    parenthesis_expression->close_parenthesis = Token__null;
    return parenthesis_expression;
}

void Parenthesis_Expression__Initialize(void)
{
    Parenthesis_Expression__erase(Parenthesis_Expression__null);
}

/* {Unary_Expression} stuff: */

struct Unary_Expression__Struct Unary_Expression__Initial = {
    &Token__Initial,
    &Expression__Initial,
};

Unary_Expression Unary_Expression__null = &Unary_Expression__Initial;
void Unary_Expression__erase(
  Unary_Expression unary_expression)
{
    unary_expression->operator = Token__null;
    unary_expression->expression = Expression__null;
}

Unary_Expression Unary_Expression__new(void)
{
    Unary_Expression unary_expression;
    extern void *malloc(unsigned int);

    unary_expression = (Unary_Expression)malloc(sizeof(*unary_expression));
    unary_expression->operator = Token__null;
    unary_expression->expression = Expression__null;
    return unary_expression;
}

void Unary_Expression__Initialize(void)
{
    Unary_Expression__erase(Unary_Expression__null);
}

/* {Typed_Name} stuff: */

struct Typed_Name__Struct Typed_Name__Initial = {
    &Token__Initial,
    &Token__Initial,
    &Type__Initial,
};

Typed_Name Typed_Name__null = &Typed_Name__Initial;
void Typed_Name__erase(
  Typed_Name typed_name)
{
    typed_name->name = Token__null;
    typed_name->at_sign = Token__null;
    typed_name->type = Type__null;
}

Typed_Name Typed_Name__new(void)
{
    Typed_Name typed_name;
    extern void *malloc(unsigned int);

    typed_name = (Typed_Name)malloc(sizeof(*typed_name));
    typed_name->name = Token__null;
    typed_name->at_sign = Token__null;
    typed_name->type = Type__null;
    return typed_name;
}

void Typed_Name__Initialize(void)
{
    Typed_Name__erase(Typed_Name__null);
}

/* {Type} stuff: */

Type_Kind Type_Kind__parameterized = Type_Kind___parameterized;
Type_Kind Type_Kind__simple = Type_Kind___simple;
Type_Kind Type_Kind__routine = Type_Kind___routine;
struct Type__Struct Type__Initial = {
    0,
};

Type Type__null = &Type__Initial;
void Type__erase(
  Type type)
{
    type->replaced = 0;
}

Type Type__new(void)
{
    Type type;
    extern void *malloc(unsigned int);

    type = (Type)malloc(sizeof(*type));
    type->replaced = Logical__null;
    return type;
}

void Type__Initialize(void)
{
    Type__erase(Type__null);
}

/* {Parameterized_Type} stuff: */

struct Parameterized_Type__Struct Parameterized_Type__Initial = {
    &Token__Initial,
    &Token__Initial,
    (Comma_Separated)0,
    &Token__Initial,
};

Parameterized_Type Parameterized_Type__null = &Parameterized_Type__Initial;
void Parameterized_Type__erase(
  Parameterized_Type parameterized_type)
{
    parameterized_type->name = Token__null;
    parameterized_type->open_bracket = Token__null;
    if (parameterized_type->sub_types == 0) {
	parameterized_type->sub_types = Comma_Separated__new();
    } else {
	Comma_Separated__erase(parameterized_type->sub_types);
    }
    parameterized_type->close_bracket = Token__null;
}

Parameterized_Type Parameterized_Type__new(void)
{
    Parameterized_Type parameterized_type;
    extern void *malloc(unsigned int);

    parameterized_type = (Parameterized_Type)malloc(sizeof(*parameterized_type));
    parameterized_type->name = Token__null;
    parameterized_type->open_bracket = Token__null;
    parameterized_type->sub_types = Comma_Separated__new();
    parameterized_type->close_bracket = Token__null;
    return parameterized_type;
}

void Parameterized_Type__Initialize(void)
{
    Parameterized_Type__erase(Parameterized_Type__null);
}

/* {Routine_Type} stuff: */

struct Routine_Type__Struct Routine_Type__Initial = {
    &Token__Initial,
    (Comma_Separated)0,
    &Token__Initial,
    (Comma_Separated)0,
    &Token__Initial,
};

Routine_Type Routine_Type__null = &Routine_Type__Initial;
void Routine_Type__erase(
  Routine_Type routine_type)
{
    routine_type->open_bracket = Token__null;
    if (routine_type->return_types == 0) {
	routine_type->return_types = Comma_Separated__new();
    } else {
	Comma_Separated__erase(routine_type->return_types);
    }
    routine_type->less_than_or_equal = Token__null;
    if (routine_type->takes_types == 0) {
	routine_type->takes_types = Comma_Separated__new();
    } else {
	Comma_Separated__erase(routine_type->takes_types);
    }
    routine_type->close_bracket = Token__null;
}

Routine_Type Routine_Type__new(void)
{
    Routine_Type routine_type;
    extern void *malloc(unsigned int);

    routine_type = (Routine_Type)malloc(sizeof(*routine_type));
    routine_type->open_bracket = Token__null;
    routine_type->return_types = Comma_Separated__new();
    routine_type->less_than_or_equal = Token__null;
    routine_type->takes_types = Comma_Separated__new();
    routine_type->close_bracket = Token__null;
    return routine_type;
}

void Routine_Type__Initialize(void)
{
    Routine_Type__erase(Routine_Type__null);
}

/* {Note} stuff: */

struct Note__Struct Note__Initial = {
    &Token__Initial,
    &Token__Initial,
};

Note Note__null = &Note__Initial;
void Note__erase(
  Note note)
{
    note->comment = Token__null;
    note->end_of_line = Token__null;
}

Note Note__new(void)
{
    Note note;
    extern void *malloc(unsigned int);

    note = (Note)malloc(sizeof(*note));
    note->comment = Token__null;
    note->end_of_line = Token__null;
    return note;
}

void Note__Initialize(void)
{
    Note__erase(Note__null);
}

/* {Error} stuff: */

struct Error__Struct Error__Initial = {
    (Array)0,
};

Error Error__null = &Error__Initial;
void Error__erase(
  Error error)
{
    if (error->tokens == 0) {
	error->tokens = Array__new();
    } else {
	Array__erase(error->tokens);
    }
}

Error Error__new(void)
{
    Error error;
    extern void *malloc(unsigned int);

    error = (Error)malloc(sizeof(*error));
    error->tokens = Array__new();
    return error;
}

void Error__Initialize(void)
{
    Error__erase(Error__null);
}

/* {Keyword} stuff: */

struct Keyword__Struct Keyword__Initial = {
    &Token__Initial,
};

Keyword Keyword__null = &Keyword__Initial;
void Keyword__erase(
  Keyword keyword)
{
    keyword->keyword = Token__null;
}

Keyword Keyword__new(void)
{
    Keyword keyword;
    extern void *malloc(unsigned int);

    keyword = (Keyword)malloc(sizeof(*keyword));
    keyword->keyword = Token__null;
    return keyword;
}

void Keyword__Initialize(void)
{
    Keyword__erase(Keyword__null);
}

/* {Comma_Separated} stuff: */

struct Comma_Separated__Struct Comma_Separated__Initial = {
    (Array)0,
    (Array)0,
};

Comma_Separated Comma_Separated__null = &Comma_Separated__Initial;
void Comma_Separated__erase(
  Comma_Separated comma_separated)
{
    if (comma_separated->commas == 0) {
	comma_separated->commas = Array__new();
    } else {
	Array__erase(comma_separated->commas);
    }
    if (comma_separated->sub_types == 0) {
	comma_separated->sub_types = Array__new();
    } else {
	Array__erase(comma_separated->sub_types);
    }
}

Comma_Separated Comma_Separated__new(void)
{
    Comma_Separated comma_separated;
    extern void *malloc(unsigned int);

    comma_separated = (Comma_Separated)malloc(sizeof(*comma_separated));
    comma_separated->commas = Array__new();
    comma_separated->sub_types = Array__new();
    return comma_separated;
}

void Comma_Separated__Initialize(void)
{
    Comma_Separated__erase(Comma_Separated__null);
}

/* {Parser} stuff: */

struct Parser__Struct Parser__Initial = {
    (Hash_Table)0,
    (Array)0,
    0,
    &Messages__Initial,
    (Array)0,
    &String__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
};

Parser Parser__null = &Parser__Initial;
void Parser__erase(
  Parser parser)
{
    if (parser->c_typedefs == 0) {
	parser->c_typedefs = Hash_Table__new();
    } else {
	Hash_Table__erase(parser->c_typedefs);
    }
    if (parser->expressions == 0) {
	parser->expressions = Array__new();
    } else {
	Array__erase(parser->expressions);
    }
    parser->index = 0;
    parser->messages = Messages__null;
    if (parser->operators == 0) {
	parser->operators = Array__new();
    } else {
	Array__erase(parser->operators);
    }
    parser->temporary = String__null;
    parser->token_end = Token__null;
    parser->token_start = Token__null;
    if (parser->tokens == 0) {
	parser->tokens = Array__new();
    } else {
	Array__erase(parser->tokens);
    }
}

Parser Parser__new(void)
{
    Parser parser;
    extern void *malloc(unsigned int);

    parser = (Parser)malloc(sizeof(*parser));
    parser->c_typedefs = Hash_Table__new();
    parser->expressions = Array__new();
    parser->index = Unsigned__null;
    parser->messages = Messages__null;
    parser->operators = Array__new();
    parser->temporary = String__null;
    parser->token_end = Token__null;
    parser->token_start = Token__null;
    parser->tokens = Array__new();
    return parser;
}

void Parser__Initialize(void)
{
    Parser__erase(Parser__null);
}

/* {Traverser} stuff: */

struct Traverser__Struct Traverser__Initial = {
    &String__Initial,
    0,
    (Array)0,
};

Traverser Traverser__null = &Traverser__Initial;
void Traverser__erase(
  Traverser traverser)
{
    traverser->buffer = String__null;
    traverser->no_errors = 0;
    if (traverser->tokens == 0) {
	traverser->tokens = Array__new();
    } else {
	Array__erase(traverser->tokens);
    }
}

Traverser Traverser__new(void)
{
    Traverser traverser;
    extern void *malloc(unsigned int);

    traverser = (Traverser)malloc(sizeof(*traverser));
    traverser->buffer = String__null;
    traverser->no_errors = Logical__null;
    traverser->tokens = Array__new();
    return traverser;
}

void Traverser__Initialize(void)
{
    Traverser__erase(Traverser__null);
}

/* {Expression_State} stuff: */

Expression_State Expression_State__null = (Expression_State)0;
Expression_State Expression_State__unary = Expression_State___unary;
Expression_State Expression_State__leaf = Expression_State___leaf;
Expression_State Expression_State__binary = Expression_State___binary;
Expression_State Expression_State__at_sign = Expression_State___at_sign;
Expression_State Expression_State__at_leaf = Expression_State___at_leaf;
void Expression_State__erase(
  Expression_State expression_state)
{
    /* do nothing */
}

void Expression_State__Initialize(void)
{
    Expression_State__erase(Expression_State__null);
}


