#include "Token.ez.h"/*cc2*/
/* # Copyright (c) 2004-2010 by Wayne C. Gramlich. */
/* # All rights reserved. */
#include "Easy_C.ez.h"/*D1*/
#include "Compiler.ez.h"/*D1*/
#include "Parse.ez.h"/*D1*/
/* # {Array} stuff: */
/* #undef lower case macros */
#undef i386
#undef linux
#undef unix
#undef errno
#undef makedev
#undef major
#undef minor
#undef alloca

void Array__buffer_append(
  Array array,
  String buffer,
  void (*buffer_append_routine)(void *, String))
{
    Unsigned size;
    Unsigned index;
    size = Array__size_get(array);
    index = 0;
    while ((index < size)) {
        (void)buffer_append_routine(((void *)Array__fetch1(array, index)), buffer);
        index = (index+1);
    }
}

/* # {Dispatch} stuff: */
String Dispatch__f(
  Dispatch dispatch)
{
    String value;
    value = Format__field_next();
    (void)String__trim(value, 0);
    (void)String__string_append(value, Dispatch__string_convert(dispatch));
    return value;
}

/* # {File} stuff: */
Logical File__check(
  File file,
  Array tokens)
{
    Logical trace;
    Logical result;
    String contents;
    Unsigned contents_size;
    Compiler compiler;
    Unsigned contents_index;
    Unsigned size;
    Unsigned index;
    Token token;
    String white_space;
    Unsigned white_space_size;
    String value;
    Unsigned value_size;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    trace = Logical__false;
    if (trace) {
        (void)String__d((t__1 = String__form(((String)"\026=>check@File(%qv%, *)\n")), String__divide((t__1), String__f(file->name))));
    }
    result = Logical__false;
    contents = file->contents;
    contents_size = String__size_get(contents);
    compiler = Compiler__one_and_only();
    contents_index = 0;
    size = Array__size_get(tokens);
    index = 0;
    while ((index < size)) {
        token = ((Token)Array__fetch1(tokens, index));
        white_space = token->white_space;
        white_space_size = String__size_get(white_space);
        if (!String__range_equal(contents, contents_index, white_space_size, white_space, 0, white_space_size)) {
            (void)Compiler__log(compiler, token, (t__2 = String__form(((String)"\030White space mismatch %v%")), String__divide((t__2), String__f(white_space))));
            break;
        }
        contents_index = (contents_index+white_space_size);
        value = token->value;
        value_size = String__size_get(value);
        if (!String__range_equal(contents, contents_index, value_size, value, 0, value_size)) {
            (void)Compiler__log(compiler, token, (t__3 = String__form(((String)"\030Value space mismatch %v%")), String__divide((t__3), String__f(value))));
            break;
        }
        contents_index = (contents_index+value_size);
        index = (index+1);
    }
    if ((contents_index != contents_size)) {
        (void)Compiler__log(compiler, ((Token)Array__fetch1(tokens, (size-1))), ((String)"\017Left over stuff"));
    }
    if (trace) {
        (void)String__d((t__6 = String__form(((String)"\033=>check@File(%qv%, *)=>%l%\n")), t__7 = String__f(file->name), String__divide(String__remainder((t__6), t__7), Logical__f(result))));
    }
    return result;
}

File File__create(
  String file_name,
  String contents,
  Array tokens)
{
    Array positions;
    Unsigned size;
    Unsigned index;
    File file;
    positions = Array__new();
    size = String__size_get(contents);
    index = 0;
    while ((index < size)) {
        if ((String__fetch1(contents, index) == ((Character)'\012'))) {
            (void)Array__append(positions, ((CAST)(index)).xpointer);
        }
        index = (index+1);
    }
    file = File__new();
    file->contents = contents;
    file->directory = String__null;
    file->name = String__read_only_copy(file_name);
    file->positions = positions;
    file->tokens = tokens;
    file->root = Root__null;
    return file;
}

Unsigned File__line_number(
  File file,
  Unsigned position)
{
    Array positions;
    Unsigned size;
    Unsigned index;
    Unsigned left_index;
    Unsigned right_index;
    Unsigned bottom;
    Unsigned top;
    Pointer_Pointer t__0;
    Pointer_Pointer t__1;
    Pointer_Pointer t__2;
    positions = file->positions;
    size = Array__size_get(positions);
    index = 0;
    if (((size == 0)||(position > (t__0 = (Pointer_Pointer)(Array__fetch1(positions, (size-1))), *(Unsigned *)(&t__0))))) {
        index = 0xffffffff;
    } else {
        left_index = 0;
        right_index = size;
        while (Logical__true) {
            index = (((left_index+right_index))>>1);
            /* #call d@(form@("left_index=%d% index=%d% bottom_index=%d%\n\") % */
            /* #  f@(left_index) %f@(index) / f@(right_index)) */
            bottom = 0;
            if ((index != 0)) {
                bottom = ((t__1 = (Pointer_Pointer)(Array__fetch1(positions, (index-1))), *(Unsigned *)(&t__1))+1);
            }
            top = 0xffffffff;
            if ((index < size)) {
                top = (t__2 = (Pointer_Pointer)(Array__fetch1(positions, index)), *(Unsigned *)(&t__2));
            }
            if (((bottom <= position)&&(position <= top))) {
                index = (index+1);
                break;
            }
            if ((position < bottom)) {
                right_index = index;
            } else if ((position > top)) {
                left_index = index;
            }
        }
        if (!((left_index <= right_index))) {
            System__assert_fail((String)"\tToken.ezc", 313);
        }
    }
    return index;
}

Logical Lexeme__is_lexeme_string(
  String name)
{
    return (String__equal(name, ((String)"\007at_sign"))||String__equal(name, ((String)"\011character"))||String__equal(name, ((String)"\013close_brace"))||String__equal(name, ((String)"\015close_bracket"))||String__equal(name, ((String)"\014close_indent"))||String__equal(name, ((String)"\021close_parenthesis"))||String__equal(name, ((String)"\005comma"))||String__equal(name, ((String)"\007comment"))||String__equal(name, ((String)"\013end_of_file"))||String__equal(name, ((String)"\013end_of_line"))||String__equal(name, ((String)"\006equals"))||String__equal(name, ((String)"\014float_number"))||String__equal(name, ((String)"\022less_than_or_equal"))||String__equal(name, ((String)"\010multiply"))||String__equal(name, ((String)"\006number"))||String__equal(name, ((String)"\012open_brace"))||String__equal(name, ((String)"\014open_bracket"))||String__equal(name, ((String)"\013open_indent"))||String__equal(name, ((String)"\020open_parenthesis"))||String__equal(name, ((String)"\011semicolon"))||String__equal(name, ((String)"\003set"))||String__equal(name, ((String)"\006string")));
}

File File__read(
  String base_name,
  String middlefix,
  String suffix,
  Compiler compiler)
{
    String temporary;
    Logical trace;
    String directory_separator;
    String source_name;
    Hash_Table file_table;
    File file;
    String contents;
    String buffer;
    Array searches;
    Unsigned size;
    Unsigned match_index;
    String match_directory;
    String match_contents;
    Unsigned index;
    String search;
    In_Stream in_stream;
    Unsigned contents_size;
    Array tokens;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    temporary = compiler->temporary;
    trace = Logical__false;
    if (trace) {
        (void)String__d((t__3 = String__form(((String)"\041=>read@file(%qv%, %qv%, %qv%, *)\n")), t__4 = String__f(base_name), t__5 = String__f(middlefix), String__divide(String__remainder(String__remainder((t__3), t__4), t__5), String__f(suffix))));
    }
    directory_separator = ((String)"\001/");
    temporary = compiler->temporary;
    (void)String__trim(temporary, 0);
    (void)String__buffer_append(base_name, temporary);
    (void)String__buffer_append(middlefix, temporary);
    (void)String__buffer_append(suffix, temporary);
    source_name = String__read_only_copy(temporary);
    file_table = compiler->file_table;
    file = ((File)Hash_Table__lookup(file_table, ((void *)(source_name))));
    if ((file == File__null)) {

        if (trace) {
            (void)String__d(((String)"\015Reading file\n"));
        }
        contents = String__null;
        /* #buffer := compiler.buffer */
        buffer = String__new();
        searches = compiler->searches;
        size = Array__size_get(searches);
        if (!((size != 0))) {
            System__assert_fail((String)"\tToken.ezc", 390);
        }
        match_index = 0xffffffff;
        match_directory = ((String)"\000");
        match_contents = ((String)"\000");
        index = 0;
        while ((index < size)) {
            search = ((String)Array__fetch1(searches, index));
            (void)String__trim(buffer, 0);
            (void)String__string_append(buffer, search);
            (void)String__string_append(buffer, directory_separator);
            (void)String__string_append(buffer, source_name);
            in_stream = In_Stream__open(buffer);
            if ((in_stream != In_Stream__null)) {
                contents = String__new();
                (void)In_Stream__all_read(in_stream, contents);
                (void)In_Stream__close(in_stream);
                contents_size = String__size_get(contents);
                if (((contents_size == 0)||(String__fetch1(contents, (contents_size-1)) != ((Character)'\012')))) {
                    (void)String__character_append(contents, ((Character)'\012'));
                }
                if ((match_index != 0xffffffff)) {
                    if (!String__equal(match_contents, contents)) {
                        temporary = String__new();
                        (void)String__d((t__10 = String__form(((String)"\047File %s%/%s% is different from %s%/%s%\n")), t__11 = String__f(match_directory), t__12 = String__f(source_name), t__13 = String__f(search), String__divide(String__remainder(String__remainder(String__remainder((t__10), t__11), t__12), t__13), String__f(source_name))));
                        /* #return null@File */
                    }
                }
                match_contents = contents;
                match_index = index;
                match_directory = search;
            }
            index = (index+1);
        }
        if ((match_index == 0xffffffff)) {

            file = File__null;
        } else {

            tokens = Array__new();
            file = File__create(source_name, match_contents, tokens);
            file->directory = ((String)Array__fetch1(searches, match_index));
            if ((String__equal(suffix, ((String)"\004.ezc"))||String__equal(suffix, ((String)"\004.ezg")))) {


                /* #call d@(form@("tokenize file %v% contents.size=%d%\n\") % */
                /* #  f@(file.name) / f@(contents.size)) */
                (void)Tokenizer__tokenize(compiler->tokenizer, file);
                if (!((Array__size_get(tokens) != 0))) {
                    System__assert_fail((String)"\tToken.ezc", 441);
                }
            }
            /* # Update file table and list: */
            file_table = compiler->file_table;
            (void)Hash_Table__insert(file_table, ((void *)(source_name)), ((void *)(file)));
        }
    } else {
        if (trace) {
            (void)String__d(((String)"\037Returning previous File object\n"));
        }
    }
    if (trace) {
        (void)String__d((t__17 = String__form(((String)"\041<=read@file(%qv%, %qv%, %qv%, *)\n")), t__18 = String__f(base_name), t__19 = String__f(middlefix), String__divide(String__remainder(String__remainder((t__17), t__18), t__19), String__f(suffix))));
    }
    return file;
}

void File__show(
  File file,
  String buffer)
{
    (void)String__buffer_append(((String)"\006<File:"), buffer);
    if ((file == File__null)) {
        (void)String__buffer_append(((String)"\011null@File"), buffer);
    } else {
        (void)String__buffer_append(((String)"\001'"), buffer);
        (void)String__buffer_append(file->name, buffer);
        (void)String__buffer_append(((String)"\001'"), buffer);
    }
    (void)String__buffer_append(((String)"\001>"), buffer);
}

/* # {Lexeme} stuff: */
String Lexeme__f(
  Lexeme lexeme)
{
    String value;
    value = Format__field_next();
    (void)String__string_append(value, Lexeme__string_convert(lexeme));
    return value;
}

void Lexeme__format(
  Lexeme lexeme,
  String buffer)
{
    Unsigned anchor;
    String text;
    anchor = String__format_begin(buffer);
    text = Lexeme__string_convert(lexeme);
    (void)String__string_gap_insert(buffer, text);
    (void)String__format_end(buffer, anchor);
}

Logical Lexeme__is_continuation(
  Lexeme lexeme)
{
    Logical result;
    result = Logical__false;
    switch (lexeme) {
        case Lexeme___add:
        case Lexeme___and:
        case Lexeme___assign:
        case Lexeme___at_sign:
        case Lexeme___comma:
        case Lexeme___conditional_and:
        case Lexeme___conditional_or:
        case Lexeme___divide:
        case Lexeme___dot:
        case Lexeme___equals:
        case Lexeme___greater_than:
        case Lexeme___greater_than_or_equal:
        case Lexeme___identical:
        case Lexeme___left_shift:
        case Lexeme___less_than:
        case Lexeme___less_than_or_equal:
        case Lexeme___logical_not:
        case Lexeme___minus:
        case Lexeme___multiply:
        case Lexeme___negative:
        case Lexeme___not:
        case Lexeme___not_equal:
        case Lexeme___not_identical:
        case Lexeme___open_bracket:
        case Lexeme___open_invoke:
        case Lexeme___open_parenthesis:
        case Lexeme___open_type:
        case Lexeme___or:
        case Lexeme___positive:
        case Lexeme___remainder:
        case Lexeme___right_shift:
        case Lexeme___xor:
        case Lexeme___define_assign:
        case Lexeme___type_invoke:
            result = Logical__true;
            break;
    }
    return result;
}

/* # {Message} stuff: */
void Message__buffer_append(
  Message message,
  String buffer)
{
    Token location;
    File file;
    Unsigned line_number;
    String t__0;
    String t__1;
    String t__2;
    location = message->location;
    file = location->file;
    line_number = File__line_number(file, location->position);
    (void)String__trim(buffer, 0);
    (void)String__string_append(buffer, (t__0 = String__form(((String)"\026file:%v% line:%d% %s%\n")), t__1 = String__f(file->name), t__2 = Unsigned__f(line_number), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), String__f(message->text))));
}

Integer Message__compare(
  Message message1,
  Message message2)
{
    Token location1;
    Token location2;
    File file1;
    File file2;
    Integer zero;
    Integer result;
    Unsigned line_number1;
    Unsigned line_number2;
    location1 = message1->location;
    location2 = message1->location;
    file1 = location1->file;
    file2 = location2->file;
    zero = 0;
    result = String__compare(file1->name, file2->name);
    if ((result == zero)) {
        line_number1 = File__line_number(file1, location1->position);
        line_number2 = File__line_number(file2, location2->position);
        result = Unsigned__compare(line_number1, line_number2);
        if ((result == zero)) {
            result = Unsigned__compare(message1->sequence, message2->sequence);
        }
    }
    return result;
}

Message Message__create(
  Token location,
  String text,
  Unsigned sequence)
{
    Message message;
    message = Message__new();
    message->location = location;
    message->text = String__read_only_copy(text);
    message->sequence = sequence;
    return message;
}

/* # {Messages} stuff: */
Messages Messages__create(
  Out_Stream immediate_stream)
{
    Messages messages;
    messages = Messages__new();
    messages->errors = Array__new();
    return messages;
}

Logical Messages__dump(
  Messages messages,
  Out_Stream out_stream)
{
    Array errors;
    Unsigned size;
    Unsigned index;
    Message message;
    Token location;
    File file;
    Unsigned line_number;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    errors = messages->errors;
    (void)Array__sort(errors, ((Integer (*)(void *, void *))(Message__compare)));
    size = Array__size_get(errors);
    index = 0;
    while ((index < size)) {
        message = ((Message)Array__fetch1(errors, index));
        location = message->location;
        file = location->file;
        line_number = File__line_number(file, location->position);
        (void)String__put((t__3 = String__form(((String)"\015%s%:%d%: %s%\n")), t__4 = String__f(file->name), t__5 = Unsigned__f(line_number), String__divide(String__remainder(String__remainder((t__3), t__4), t__5), String__f(message->text))), out_stream);
        index = (index+1);
    }
    (void)Array__trim(errors, 0);
    if ((size != 0)) {
        return 1;
    }
    return (size != 0);
}

void Messages__log(
  Messages messages,
  Token location,
  String text)
{
    Array errors;
    Message message;
    Compiler compiler;
    String xbuffer;
    errors = messages->errors;
    message = Message__create(location, text, Array__size_get(errors));
    (void)Array__append(errors, ((void *)(message)));
    compiler = Compiler__one_and_only();
    if (compiler->tracing) {
        xbuffer = String__new();
        (void)Message__buffer_append(message, xbuffer);
        (void)String__d(xbuffer);
    }
}

void Messages__log2(
  Messages messages,
  Token location1,
  Token location2,
  String text)
{
    File file2;
    Unsigned line_number2;
    String t__0;
    String t__1;
    String t__2;
    file2 = location2->file;
    line_number2 = File__line_number(file2, location2->position);
    (void)Messages__log(messages, location1, (t__0 = String__form(((String)"\026file:%v% line:%d%: %s%")), t__1 = String__f(file2->name), t__2 = Unsigned__f(line_number2), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), String__f(text))));
}

Unsigned Messages__size_get(
  Messages messages)
{
    return Array__size_get(messages->errors);
}

/* # {Token} stuff: */
void Token__buffer_append(
  Token token,
  String buffer)
{
    (void)String__buffer_append(token->white_space, buffer);
    (void)String__buffer_append(token->value, buffer);
}

Token Token__create(
  File file,
  Unsigned position,
  Lexeme lexeme,
  String value)
{
    Token token;
    token = Token__new();
    token->file = file;
    token->lexeme = lexeme;
    token->value = value;
    token->white_space = ((String)"\000");
    return token;
}

Integer Token__compare(
  Token token1,
  Token token2)
{
    return String__compare(token1->value, token2->value);
}

Logical Token__equal(
  Token token1,
  Token token2)
{
    return String__equal(token1->value, token2->value);
}

Unsigned Token__hash(
  Token token)
{
    return String__hash(token->value);
}

String Token__f(
  Token token)
{
    String value;
    String t__0;
    String t__1;
    String t__2;
    value = Format__field_next();
    (void)String__trim(value, 0);
    (void)String__string_append(value, (t__0 = String__form(((String)"\047[Token: space=%v% value=%v% lexeme=%s%]")), t__1 = String__f(token->white_space), t__2 = String__f(token->value), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), Lexeme__f(token->lexeme))));
    return value;
}

Unsigned Token__line_number_get(
  Token token)
{
    File file;
    Unsigned line_number;
    file = token->file;
    line_number = 1;
    if ((token != Token__null)) {
        line_number = File__line_number(file, token->position);
    }
    return line_number;
}

String Token__source_name_get(
  Token token)
{
    return token->file->name;
}

String Token__string_convert(
  Token token)
{
    Compiler compiler;
    Logical tracing;
    String temporary;
    Lexeme lexeme;
    String result;
    String text;
    Unsigned size;
    Unsigned index;
    Character character;
    Logical done;
    Unsigned number;
    Unsigned radix;
    String symbol;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    compiler = Compiler__one_and_only();
    tracing = compiler->tracing;
    temporary = compiler->temporary;
    lexeme = token->lexeme;
    if (!(((lexeme == Lexeme__character)||(lexeme == Lexeme__string)))) {
        System__assert_fail((String)"\tToken.ezc", 772);
    }
    result = String__new();
    text = token->value;
    size = (String__size_get(text)-1);
    index = 1;
    while ((index < size)) {
        character = String__fetch1(text, index);
        if ((character == ((Character)'\134'))) {


            index = (index+1);
            done = Logical__false;
            while ((!done&&(index < size))) {

                character = String__fetch1(text, index);
                if (Character__is_decimal_digit(character)) {

                    number = 0;
                    radix = 10;
                    while ((index < size)) {
                        character = String__fetch1(text, index);
                        if (Character__is_hex_digit(character)) {
                            number = ((number*radix)+Character__hexadecimal_convert(character));
                            if (tracing) {
                                (void)String__d((t__1 = String__form(((String)"\010num:%d%\n")), String__divide((t__1), Unsigned__f(number))));
                            }
                            index = (index+1);
                        } else if (((character == ((Character)','))||(character == ((Character)'\134')))) {
                            break;
                        } else if (((character == ((Character)'x'))||(character == ((Character)'X')))) {
                            radix = 16;
                            index = (index+1);
                        } else {
                            (void)Compiler__log(compiler, token, (t__2 = String__form(((String)"\043Illegal character %v% in number %v%")), t__3 = Character__f(character), String__divide(String__remainder((t__2), t__3), String__f(text))));
                            break;
                        }
                    }
                    (void)String__character_append(result, ((Character)(number)));
                } else {

                    symbol = String__new();
                    while ((index < size)) {
                        character = String__fetch1(text, index);
                        if (((character == ((Character)','))||(character == ((Character)'\134')))) {
                            break;
                        }
                        (void)String__character_append(symbol, character);
                        index = (index+1);
                    }
                    character = ((Character)'!');
                    if (String__equal(symbol, ((String)"\003bsl"))) {
                        character = ((Character)'\134');
                    } else if (String__equal(symbol, ((String)"\002dq"))) {
                        character = ((Character)'"');
                    } else if (String__equal(symbol, ((String)"\002sq"))) {
                        character = ((Character)'\047');
                    } else if (String__equal(symbol, ((String)"\001t"))) {
                        character = ((Character)'\011');
                    } else if (String__equal(symbol, ((String)"\001n"))) {
                        character = ((Character)'\012');
                    } else if (String__equal(symbol, ((String)"\002bs"))) {
                        character = ((Character)'\010');
                    } else if (String__equal(symbol, ((String)"\002cr"))) {
                        character = ((Character)'\015');
                    }
                    if ((character == ((Character)'!'))) {
                        (void)Compiler__log(compiler, token, (t__4 = String__form(((String)"\042Unrecognized character code '%qv%'")), String__divide((t__4), String__f(symbol))));
                    } else {
                        (void)String__character_append(result, character);
                    }
                }
                /* # Figure out whether to escape backslash mode: */
                character = String__fetch1(text, index);
                if ((character == ((Character)'\134'))) {
                    done = Logical__true;
                } else {
                    index = (index+1);
                }
            }
        } else {
            (void)String__character_append(result, character);
        }
        index = (index+1);
    }
    result = String__read_only_copy(result);
    return result;
}

void Token__string_gap_insert(
  Token token,
  String buffer)
{
    (void)String__string_gap_insert(buffer, token->value);
}

/* # {Tokenizer} stuff: */
Tokenizer Tokenizer__create(
  Messages messages)
{
    Array dispatch_table;
    Unsigned count;
    Tokenizer tokenizer;
    dispatch_table = Array__new();
    count = 256;
    while ((count != 0)) {
        (void)Array__append(dispatch_table, ((void *)(Dispatch__illegal)));
        count = (count-1);
    }
    tokenizer = Tokenizer__new();
    tokenizer->dispatch_table = dispatch_table;
    tokenizer->messages = messages;
    (void)Tokenizer__dispatch_range(tokenizer, ((Character)'G'), ((Character)'Z'), Dispatch__letter);
    (void)Tokenizer__dispatch_range(tokenizer, ((Character)'A'), ((Character)'F'), Dispatch__hex_letter);
    (void)Tokenizer__dispatch_range(tokenizer, ((Character)'g'), ((Character)'z'), Dispatch__letter);
    (void)Tokenizer__dispatch_range(tokenizer, ((Character)'a'), ((Character)'f'), Dispatch__hex_letter);
    (void)Tokenizer__dispatch_range(tokenizer, ((Character)'1'), ((Character)'7'), Dispatch__octal_digit);
    (void)Tokenizer__dispatch_range(tokenizer, ((Character)'8'), ((Character)'9'), Dispatch__decimal_digit);
    (void)Tokenizer__dispatch_range(tokenizer, ((Character)188), ((Character)190), Dispatch__latin9);
    (void)Tokenizer__dispatch_range(tokenizer, ((Character)192), ((Character)255), Dispatch__latin9);
    Tokenizer__store1(tokenizer, ((Character)166), Dispatch__latin9);
    Tokenizer__store1(tokenizer, ((Character)168), Dispatch__latin9);
    Tokenizer__store1(tokenizer, ((Character)180), Dispatch__latin9);
    Tokenizer__store1(tokenizer, ((Character)184), Dispatch__latin9);
    Tokenizer__store1(tokenizer, ((Character)173), Dispatch__hyphen);
    Tokenizer__store1(tokenizer, ((Character)160), Dispatch__space);
    Tokenizer__store1(tokenizer, ((Character)'e'), Dispatch__e);
    Tokenizer__store1(tokenizer, ((Character)'E'), Dispatch__e);
    Tokenizer__store1(tokenizer, ((Character)'x'), Dispatch__x);
    Tokenizer__store1(tokenizer, ((Character)'X'), Dispatch__x);
    Tokenizer__store1(tokenizer, ((Character)'\047'), Dispatch__apostrophe);
    Tokenizer__store1(tokenizer, ((Character)'&'), Dispatch__amphersand);
    Tokenizer__store1(tokenizer, ((Character)'*'), Dispatch__asterisk);
    Tokenizer__store1(tokenizer, ((Character)'@'), Dispatch__at_sign);
    Tokenizer__store1(tokenizer, ((Character)'\134'), Dispatch__back_slash);
    Tokenizer__store1(tokenizer, ((Character)'^'), Dispatch__caret);
    Tokenizer__store1(tokenizer, ((Character)'\015'), Dispatch__carriage_return);
    Tokenizer__store1(tokenizer, ((Character)'}'), Dispatch__close_brace);
    Tokenizer__store1(tokenizer, ((Character)']'), Dispatch__close_bracket);
    Tokenizer__store1(tokenizer, ((Character)')'), Dispatch__close_parenthesis);
    Tokenizer__store1(tokenizer, ((Character)':'), Dispatch__colon);
    Tokenizer__store1(tokenizer, ((Character)','), Dispatch__comma);
    Tokenizer__store1(tokenizer, ((Character)'"'), Dispatch__double_quote);
    Tokenizer__store1(tokenizer, ((Character)'$'), Dispatch__dollar);
    Tokenizer__store1(tokenizer, ((Character)'='), Dispatch__equals);
    Tokenizer__store1(tokenizer, ((Character)'!'), Dispatch__exclamation_point);
    Tokenizer__store1(tokenizer, ((Character)'/'), Dispatch__forward_slash);
    Tokenizer__store1(tokenizer, ((Character)'`'), Dispatch__grave_accent);
    Tokenizer__store1(tokenizer, ((Character)'>'), Dispatch__greater_than);
    Tokenizer__store1(tokenizer, ((Character)'#'), Dispatch__hash);
    Tokenizer__store1(tokenizer, ((Character)'-'), Dispatch__hyphen);
    Tokenizer__store1(tokenizer, ((Character)'<'), Dispatch__less_than);
    Tokenizer__store1(tokenizer, ((Character)'\012'), Dispatch__line_feed);
    Tokenizer__store1(tokenizer, ((Character)'{'), Dispatch__open_brace);
    Tokenizer__store1(tokenizer, ((Character)'['), Dispatch__open_bracket);
    Tokenizer__store1(tokenizer, ((Character)'('), Dispatch__open_parenthesis);
    Tokenizer__store1(tokenizer, ((Character)'%'), Dispatch__percent);
    Tokenizer__store1(tokenizer, ((Character)'.'), Dispatch__period);
    Tokenizer__store1(tokenizer, ((Character)'+'), Dispatch__plus_sign);
    Tokenizer__store1(tokenizer, ((Character)'?'), Dispatch__question_mark);
    Tokenizer__store1(tokenizer, ((Character)';'), Dispatch__semicolon);
    Tokenizer__store1(tokenizer, ((Character)' '), Dispatch__space);
    Tokenizer__store1(tokenizer, ((Character)'\011'), Dispatch__tab);
    Tokenizer__store1(tokenizer, ((Character)'~'), Dispatch__tilde);
    Tokenizer__store1(tokenizer, ((Character)'_'), Dispatch__underscore);
    Tokenizer__store1(tokenizer, ((Character)'|'), Dispatch__vertical_bar);
    Tokenizer__store1(tokenizer, ((Character)'0'), Dispatch__zero);
    tokenizer->tokens = Array__new();
    tokenizer->white_space = String__new();
    tokenizer->white_spaces = Array__new();
    return tokenizer;
}

void Tokenizer__dispatch_range(
  Tokenizer tokenizer,
  Character low_character,
  Character high_character,
  Dispatch dispatch)
{
    Array dispatch_table;
    Unsigned low;
    Unsigned high;
    Unsigned index;
    dispatch_table = tokenizer->dispatch_table;
    low = ((Unsigned)(low_character));
    high = ((Unsigned)(high_character));
    index = low;
    while ((index <= high)) {
        Array__store1(dispatch_table, index, (void *)(dispatch));
        index = (index+1);
    }
}

void Tokenizer__finish(
  Tokenizer tokenizer)
{
    /* do_nothing */;
}

Token Tokenizer__next(
  Tokenizer tokenizer)
{
    String buffer;
    String contents;
    Unsigned size;
    Messages messages;
    Array dispatch_table;
    Unsigned index;
    Lexeme lexeme;
    Compiler compiler;
    Unsigned anchor;
    Unsigned indent;
    String white_space;
    Array white_spaces;
    Logical pure_white_space;
    Logical done;
    Logical indent_check;
    Character character;
    Dispatch dispatch;
    Token previous_token;
    Unsigned line_feed_index;
    Unsigned ahead_index;
    Character ahead_character;
    Lexeme previous_lexeme;
    Array indents;
    Unsigned indents_size;
    Unsigned current_indent;
    String read_only_white_space;
    Token token;
    String value;
    Character quote;
    Character next_character;
    Dispatch next_dispatch;
    Logical is_hex;
    Logical have_digit;
    Logical have_sign;
    Character character2;
    Pointer_Pointer t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    buffer = tokenizer->buffer;
    contents = tokenizer->contents;
    size = String__size_get(contents);
    messages = tokenizer->messages;
    dispatch_table = tokenizer->dispatch_table;
    index = tokenizer->index;
    lexeme = Lexeme__error;
    compiler = Compiler__one_and_only();
    anchor = index;
    indent = 0;
    white_space = tokenizer->white_space;
    white_spaces = tokenizer->white_spaces;
    pure_white_space = Logical__true;
    (void)String__trim(white_space, 0);
    done = Logical__false;
    while (!done) {
        pure_white_space = Logical__true;
        if ((index < size)) {
            indent_check = Logical__false;
            character = String__fetch1(contents, index);
            dispatch = ((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(character))));
            switch (dispatch) {
                case Dispatch___carriage_return:
                    (void)String__character_append(white_space, character);
                    index = (index+1);
                    pure_white_space = Logical__false;
                    break;
                case Dispatch___space:
                    (void)String__character_append(white_space, character);
                    index = (index+1);
                    indent = (indent+1);
                    break;
                case Dispatch___tab:
                    (void)String__character_append(white_space, character);
                    index = (index+1);
                    indent = (((indent|7))+1);
                    break;
                case Dispatch___hash:
                    previous_token = tokenizer->previous;
                    switch (previous_token->lexeme) {
                        case Lexeme___close_indent:
                        case Lexeme___end_of_line:

                            done = Logical__true;
                            indent_check = Logical__true;
                            break;
                        default:

                            pure_white_space = Logical__false;
                            while (!done) {
                                if ((index < size)) {

                                    character = String__fetch1(contents, index);
                                    if ((character == ((Character)'\012'))) {

                                        done = Logical__true;
                                    } else {

                                        (void)String__character_append(white_space, character);
                                        index = (index+1);
                                    }
                                } else {

                                    done = Logical__true;
                                }
                            }
                            break;
                    }
                    break;
                case Dispatch___line_feed:

                    previous_token = tokenizer->previous;
                    if (Lexeme__is_continuation(previous_token->lexeme)) {

                        (void)String__character_append(white_space, character);
                        index = (index+1);
                        pure_white_space = Logical__false;
                    } else {

                        line_feed_index = index;
                        ahead_index = (index+1);
                        while ((ahead_index < size)) {
                            ahead_character = String__fetch1(contents, ahead_index);
                            switch (((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(ahead_character))))) {
                                case Dispatch___space:
                                case Dispatch___tab:
                                    ahead_index = (ahead_index+1);
                                    break;
                                case Dispatch___line_feed:
                                    line_feed_index = ahead_index;
                                    ahead_index = (ahead_index+1);
                                    break;
                                default:
                                    goto break__1;
                                    break;
                            }
                        }
                        break__1:;
                        if ((index < line_feed_index)) {

                            pure_white_space = 0;
                            while ((index < line_feed_index)) {
                                (void)String__character_append(white_space, String__fetch1(contents, index));
                                index = (index+1);
                            }
                            if (!((index == line_feed_index))) {
                                System__assert_fail((String)"\tToken.ezc", 1076);
                            }
                        }
                        /* # Process in a normal fashion: */
                        done = Logical__true;
                    }
                    break;
                default:

                    indent_check = Logical__true;
                    break;
            }
            if (indent_check) {
                previous_token = tokenizer->previous;
                previous_lexeme = previous_token->lexeme;
                if (((previous_lexeme == Lexeme__end_of_line)||(previous_lexeme == Lexeme__close_indent))) {
                    indents = tokenizer->indents;
                    indents_size = Array__size_get(indents);
                    current_indent = (t__0 = (Pointer_Pointer)(Array__fetch1(indents, (indents_size-1))), *(Unsigned *)(&t__0));
                    /* #call d@(form@( */
                    /* #  "indent:%d% indents_size:%d% current_indent:%d%\n\") % */
                    /* #  f@(indent) % f@(indents_size) / f@(current_indent)) */
                    if ((indent > current_indent)) {

                        index = anchor;
                        lexeme = Lexeme__open_indent;
                        (void)String__trim(white_space, 0);
                        (void)Array__append(indents, ((CAST)(indent)).xpointer);
                    } else if ((indent < current_indent)) {

                        index = anchor;
                        lexeme = Lexeme__close_indent;
                        (void)Array__trim(indents, (indents_size-1));
                    }
                }
                done = Logical__true;
            }
        } else {

            done = Logical__true;
        }
    }
    read_only_white_space = ((String)"\000");
    if (pure_white_space) {
        white_spaces = tokenizer->white_spaces;
        while ((Array__size_get(white_spaces) <= indent)) {
            (void)Array__append(white_spaces, ((void *)(((String)"\000"))));
        }
        read_only_white_space = ((String)Array__fetch1(white_spaces, indent));
        if (!String__equal(white_space, read_only_white_space)) {
            read_only_white_space = String__read_only_copy(white_space);
            Array__store1(white_spaces, indent, (void *)(read_only_white_space));
        }
    } else {
        read_only_white_space = String__read_only_copy(white_space);
    }
    token = Token__new();
    token->white_space = read_only_white_space;
    token->file = tokenizer->file;
    token->position = index;
    token->lexeme = Lexeme__error;
    token->value = ((String)"\000");
    value = ((String)"\000");
    if (((lexeme == Lexeme__open_indent)||(lexeme == Lexeme__close_indent))) {
        token->white_space = ((String)"\000");
        token->value = ((String)"\000");
        token->lexeme = lexeme;
    } else if ((index < size)) {
        character = String__fetch1(contents, index);
        dispatch = ((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(character))));
        switch (dispatch) {
            case Dispatch___amphersand:
                if ((((index+1) < size)&&(String__fetch1(contents, (index+1)) == ((Character)'&')))) {
                    value = ((String)"\002&&");
                    index = (index+2);
                    lexeme = Lexeme__conditional_and;
                } else {
                    value = ((String)"\001&");
                    index = (index+1);
                    lexeme = Lexeme__and;
                }
                break;
            case Dispatch___asterisk:
                value = ((String)"\001*");
                index = (index+1);
                lexeme = Lexeme__multiply;
                break;
            case Dispatch___at_sign:
                value = ((String)"\001@");
                index = (index+1);
                lexeme = Lexeme__at_sign;
                if (((index < size)&&(String__fetch1(contents, index) == ((Character)'(')))) {
                    value = ((String)"\002@(");
                    lexeme = Lexeme__type_invoke;
                    index = (index+1);
                }
                break;
            case Dispatch___apostrophe:
            case Dispatch___double_quote:
                quote = character;
                value = String__new();
                (void)String__character_append(value, quote);
                index = (index+1);
                lexeme = Lexeme__error;
                while ((index < size)) {
                    character = String__fetch1(contents, index);
                    dispatch = ((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(character))));
                    switch (dispatch) {
                        case Dispatch___apostrophe:
                        case Dispatch___double_quote:
                            (void)String__character_append(value, character);
                            index = (index+1);
                            if ((character == quote)) {

                                if ((character == ((Character)'\047'))) {
                                    lexeme = Lexeme__character;
                                } else {
                                    lexeme = Lexeme__string;
                                }
                                goto break__2;
                            }
                            break;
                        case Dispatch___line_feed:
                        case Dispatch___carriage_return:
                        case Dispatch___illegal:

                            (void)Compiler__log(compiler, token, (t__1 = String__form(((String)"\047Unterminated string/character %c%...%c%")), t__2 = Character__f(quote), String__divide(String__remainder((t__1), t__2), Character__f(quote))));
                            goto break__2;
                            break;
                        default:
                            (void)String__character_append(value, character);
                            index = (index+1);
                            break;
                    }
                }
                break__2:;
                break;
            case Dispatch___caret:
                value = ((String)"\001^");
                index = (index+1);
                lexeme = Lexeme__remainder;
                break;
            case Dispatch___close_brace:
                value = ((String)"\001}");
                index = (index+1);
                lexeme = Lexeme__close_brace;
                break;
            case Dispatch___close_bracket:
                value = ((String)"\001]");
                index = (index+1);
                lexeme = Lexeme__close_bracket;
                break;
            case Dispatch___close_parenthesis:
                value = ((String)"\001)");
                index = (index+1);
                lexeme = Lexeme__close_parenthesis;
                break;
            case Dispatch___colon:
                if ((((index+1) < size)&&(String__fetch1(contents, (index+1)) == ((Character)'=')))) {
                    value = ((String)"\002:=");
                    index = (index+2);
                    lexeme = Lexeme__assign;
                } else if ((((index+2) < size)&&(String__fetch1(contents, (index+1)) == ((Character)'@'))&&(String__fetch1(contents, (index+2)) == ((Character)'=')))) {
                    value = ((String)"\003:@=");
                    index = (index+3);
                    lexeme = Lexeme__define_assign;
                } else {
                    value = ((String)"\001:");
                    index = (index+1);
                    lexeme = Lexeme__colon;
                }
                break;
            case Dispatch___comma:
                value = ((String)"\001,");
                index = (index+1);
                lexeme = Lexeme__comma;
                break;
            case Dispatch___decimal_digit:
            case Dispatch___octal_digit:
            case Dispatch___period:
            case Dispatch___zero:

                next_character = ((Character)' ');
                next_dispatch = Dispatch__space;
                if (((index+1) < size)) {
                    next_character = String__fetch1(contents, (index+1));
                    next_dispatch = ((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(next_character))));
                }
                /* # Figure out if this is a {number} or a {dot}. */
                is_hex = Logical__false;
                switch (dispatch) {
                    case Dispatch___period:
                        switch (next_dispatch) {
                            case Dispatch___decimal_digit:
                            case Dispatch___octal_digit:
                            case Dispatch___zero:

                                value = String__new();
                                (void)String__character_append(value, ((Character)'.'));
                                lexeme = Lexeme__float_number;
                                break;
                            default:

                                value = ((String)"\001.");
                                lexeme = Lexeme__dot;
                                break;
                        }
                        index = (index+1);
                        break;
                    case Dispatch___decimal_digit:
                    case Dispatch___octal_digit:
                        value = String__new();
                        lexeme = Lexeme__number;
                        break;
                    case Dispatch___zero:
                        value = String__new();
                        lexeme = Lexeme__number;
                        switch (next_dispatch) {
                            case Dispatch___x:
                                index = (index+2);
                                lexeme = Lexeme__number;
                                (void)String__string_append(value, ((String)"\0020x"));
                                is_hex = Logical__true;
                                break;
                        }
                        break;
                }
                switch (lexeme) {
                    case Lexeme___number:
                    case Lexeme___float_number:

                        while ((index < size)) {
                            character = String__fetch1(contents, index);
                            dispatch = ((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(character))));
                            switch (dispatch) {
                                case Dispatch___period:
                                    switch (lexeme) {
                                        case Lexeme___float_number:
                                            (void)String__character_append(value, ((Character)'.'));
                                            (void)Compiler__log(compiler, token, (t__3 = String__form(((String)"\047Multiple decimal points in number (%v%)")), String__divide((t__3), String__f(value))));
                                            lexeme = Lexeme__error;
                                            goto break__3;
                                            break;
                                        case Lexeme___number:
                                            (void)String__character_append(value, ((Character)'.'));
                                            index = (index+1);
                                            lexeme = Lexeme__float_number;
                                            break;
                                        default:
                                            if (!(Logical__false)) {
                                                System__assert_fail((String)"\tToken.ezc", 1285);
                                            }
                                            break;
                                    }
                                    break;
                                case Dispatch___zero:
                                case Dispatch___octal_digit:
                                case Dispatch___decimal_digit:
                                    (void)String__character_append(value, character);
                                    index = (index+1);
                                    break;
                                case Dispatch___e:

                                    (void)String__character_append(value, character);
                                    index = (index+1);
                                    if ((lexeme == Lexeme__float_number)) {

                                        have_digit = Logical__false;
                                        have_sign = Logical__false;
                                        while ((index < size)) {
                                            character = String__fetch1(contents, index);
                                            dispatch = ((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(character))));
                                            switch (dispatch) {
                                                case Dispatch___hyphen:
                                                case Dispatch___plus_sign:
                                                    if (have_digit) {

                                                        goto break__4;
                                                    }
                                                    if (have_sign) {

                                                        (void)Compiler__log(compiler, token, ((String)"\026Multple exponent signs"));
                                                        goto break__4;
                                                    } else {

                                                        (void)String__character_append(value, character);
                                                        have_sign = Logical__true;
                                                    }
                                                    break;
                                                case Dispatch___zero:
                                                case Dispatch___decimal_digit:
                                                case Dispatch___octal_digit:
                                                    (void)String__character_append(value, character);
                                                    have_digit = Logical__true;
                                                    break;
                                                default:
                                                    goto break__4;
                                                    break;
                                            }
                                            index = (index+1);
                                        }
                                        break__4:;
                                        if (!have_digit) {
                                            (void)Compiler__log(compiler, token, (t__4 = String__form(((String)"\040No floating point exponent (%v%)")), String__divide((t__4), String__f(value))));
                                        }
                                        /* #call d@(form@("float=%v%\n\") / f@(value)) */
                                        goto break__3;
                                    } else if (!is_hex) {
                                        (void)String__character_append(value, character);
                                        (void)Compiler__log(compiler, token, (t__5 = String__form(((String)"\045Decimal number with hex digit ((%v%))")), String__divide((t__5), String__f(value))));
                                        goto break__3;
                                    }
                                    break;
                                case Dispatch___hex_letter:
                                    (void)String__character_append(value, character);
                                    index = (index+1);
                                    if ((!is_hex&&(character != ((Character)'f'))&&(character != ((Character)'F'))&&(character != ((Character)'b'))&&(character != ((Character)'B')))) {
                                        (void)String__character_append(value, character);
                                        (void)Compiler__log(compiler, token, (t__6 = String__form(((String)"\043Decimal number with hex digit (%v%)")), String__divide((t__6), String__f(value))));
                                        goto break__3;
                                    }
                                    break;
                                default:
                                    goto break__3;
                                    break;
                            }
                        }
                        break__3:;
                        switch (lexeme) {
                            case Lexeme___number:
                                character = String__fetch1(contents, index);
                                if (((character == ((Character)'b'))||(character == ((Character)'B'))||(character == ((Character)'f'))||(character == ((Character)'F'))||(character == ((Character)'i'))||(character == ((Character)'I'))||(character == ((Character)'i'))||(character == ((Character)'I'))||(character == ((Character)'s'))||(character == ((Character)'S'))||(character == ((Character)'t'))||(character == ((Character)'T'))||(character == ((Character)'u'))||(character == ((Character)'U')))) {
                                    (void)String__character_append(value, character);
                                    index = (index+1);
                                } else if (((character == ((Character)'l'))||(character == ((Character)'L')))) {
                                    if (((index+1) < size)) {
                                        character2 = String__fetch1(contents, (index+1));
                                        if (((character2 == ((Character)'i'))||(character2 == ((Character)'I'))||(character2 == ((Character)'u'))||(character2 == ((Character)'U')))) {
                                            (void)String__character_append(value, character);
                                            (void)String__character_append(value, character2);
                                            index = (index+2);
                                        }
                                    }
                                }
                                break;
                            case Lexeme___float_number:
                                character = String__fetch1(contents, index);
                                if (((character == ((Character)'f'))||(character == ((Character)'F'))||(character == ((Character)'d'))||(character == ((Character)'D'))||(character == ((Character)'q'))||(character == ((Character)'Q')))) {
                                    (void)String__character_append(value, character);
                                    index = (index+1);
                                }
                                break;
                        }
                        break;
                }
                break;
            case Dispatch___e:
            case Dispatch___hex_letter:
            case Dispatch___letter:
            case Dispatch___x:
            case Dispatch___underscore:

                value = String__new();
                done = Logical__false;
                while (!done) {
                    character = String__fetch1(contents, index);
                    dispatch = ((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(character))));
                    switch (dispatch) {
                        case Dispatch___decimal_digit:
                        case Dispatch___e:
                        case Dispatch___hex_letter:
                        case Dispatch___letter:
                        case Dispatch___octal_digit:
                        case Dispatch___x:
                        case Dispatch___underscore:
                        case Dispatch___zero:
                            (void)String__character_append(value, character);
                            index = (index+1);
                            break;
                        default:

                            /* #  f@(character) / f@(dispatch)) */
                            done = Logical__true;
                            break;
                    }
                }
                lexeme = Lexeme__symbol;
                break;
            case Dispatch___equals:

                if ((((index+1) < size)&&(String__fetch1(contents, (index+1)) == ((Character)'=')))) {
                    value = ((String)"\002==");
                    index = (index+2);
                    lexeme = Lexeme__identical;
                } else {
                    value = ((String)"\001=");
                    index = (index+1);
                    lexeme = Lexeme__equals;
                }
                break;
            case Dispatch___exclamation_point:

                if ((((index+1) < size)&&(String__fetch1(contents, (index+1)) == ((Character)'=')))) {
                    if ((((index+2) < size)&&(String__fetch1(contents, (index+2)) == ((Character)'=')))) {
                        value = ((String)"\003!==");
                        index = (index+3);
                        lexeme = Lexeme__not_identical;
                    } else {
                        value = ((String)"\002!=");
                        index = (index+2);
                        lexeme = Lexeme__not_equal;
                    }
                } else {
                    value = ((String)"\001!");
                    index = (index+1);
                    lexeme = Lexeme__logical_not;
                }
                break;
            case Dispatch___forward_slash:

                value = ((String)"\001/");
                index = (index+1);
                lexeme = Lexeme__divide;
                break;
            case Dispatch___greater_than:
                value = ((String)"\001>");
                index = (index+1);
                lexeme = Lexeme__greater_than;
                if ((index < size)) {
                    next_character = String__fetch1(contents, index);
                    next_dispatch = ((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(next_character))));
                    switch (next_dispatch) {
                        case Dispatch___equals:
                            value = ((String)"\002>=");
                            index = (index+1);
                            lexeme = Lexeme__greater_than_or_equal;
                            break;
                        case Dispatch___greater_than:
                            value = ((String)"\002>>");
                            index = (index+1);
                            lexeme = Lexeme__right_shift;
                            break;
                    }
                }
                break;
            case Dispatch___hash:

                value = String__new();
                done = Logical__false;
                while (!done) {
                    if ((index < size)) {
                        character = String__fetch1(contents, index);
                        if ((character == ((Character)'\012'))) {
                            done = Logical__true;
                        } else {
                            (void)String__character_append(value, character);
                            index = (index+1);
                        }
                    } else {
                        done = Logical__true;
                    }
                }
                lexeme = Lexeme__comment;
                break;
            case Dispatch___hyphen:

                value = ((String)"\001-");
                index = (index+1);
                lexeme = Lexeme__minus;
                break;
            case Dispatch___illegal:

                value = String__new();
                (void)String__character_append(value, character);
                index = (index+1);
                lexeme = Lexeme__error;
                break;
            case Dispatch___less_than:

                value = ((String)"\001<");
                index = (index+1);
                lexeme = Lexeme__less_than;
                if ((index < size)) {
                    next_character = String__fetch1(contents, index);
                    next_dispatch = ((Dispatch)Array__fetch1(dispatch_table, ((Unsigned)(next_character))));
                    switch (next_dispatch) {
                        case Dispatch___equals:
                            value = ((String)"\002<=");
                            index = (index+1);
                            lexeme = Lexeme__less_than_or_equal;
                            break;
                        case Dispatch___less_than:
                            value = ((String)"\002<<");
                            index = (index+1);
                            lexeme = Lexeme__left_shift;
                            break;
                    }
                }
                break;
            case Dispatch___line_feed:
                value = ((String)"\001\n");
                index = (index+1);
                lexeme = Lexeme__end_of_line;
                break;
            case Dispatch___open_brace:
                value = ((String)"\001{");
                index = (index+1);
                lexeme = Lexeme__open_brace;
                break;
            case Dispatch___open_bracket:
                value = ((String)"\001[");
                index = (index+1);
                lexeme = Lexeme__open_bracket;
                break;
            case Dispatch___open_parenthesis:
                value = ((String)"\001(");
                index = (index+1);
                lexeme = Lexeme__open_parenthesis;
                break;
            case Dispatch___percent:
                value = ((String)"\001%");
                index = (index+1);
                lexeme = Lexeme__remainder;
                break;
            case Dispatch___plus_sign:
                value = ((String)"\001+");
                index = (index+1);
                lexeme = Lexeme__add;
                break;
            case Dispatch___question_mark:
                value = ((String)"\001?");
                index = (index+1);
                lexeme = Lexeme__question_mark;
                break;
            case Dispatch___semicolon:
                value = ((String)"\001;");
                index = (index+1);
                lexeme = Lexeme__semicolon;
                break;
            case Dispatch___tilde:
                value = ((String)"\001~");
                index = (index+1);
                lexeme = Lexeme__not;
                break;
            case Dispatch___vertical_bar:
                if ((((index+1) < size)&&(String__fetch1(contents, (index+1)) == ((Character)'|')))) {
                    value = ((String)"\002||");
                    index = (index+2);
                    lexeme = Lexeme__conditional_or;
                } else {
                    value = ((String)"\001|");
                    index = (index+1);
                    lexeme = Lexeme__or;
                }
                break;
            default:
                (void)Compiler__log(compiler, token, (t__7 = String__form(((String)"\033Illegal character %v% (%d%)")), t__8 = Character__f(character), String__divide(String__remainder((t__7), t__8), Dispatch__f(dispatch))));
                index = (index+1);
                break;
        }
        token->value = String__read_only_copy(value);
        token->lexeme = lexeme;
    } else {

        indents = tokenizer->indents;
        indents_size = Array__size_get(indents);
        /* #call d@(form@("indents_size=%d%\n\") / f@(indents_size)) */
        if ((Array__size_get(indents) > 1)) {
            token->white_space = ((String)"\000");
            token->value = ((String)"\000");
            token->lexeme = Lexeme__close_indent;
            (void)Array__trim(indents, (indents_size-1));
        } else {
            token->value = ((String)"\000");
            token->lexeme = Lexeme__end_of_file;
        }
    }
    tokenizer->previous = token;
    tokenizer->index = index;
    return token;
}

void Tokenizer__start(
  Tokenizer tokenizer,
  File file)
{
    Token token;
    Array indents;
    token = Token__new();
    token->lexeme = Lexeme__end_of_line;
    token->value = ((String)"\001\n");
    token->white_space = ((String)"\000");
    indents = Array__new();
    (void)Array__append(indents, ((CAST)(0)).xpointer);
    tokenizer->buffer = String__new();
    tokenizer->contents = file->contents;
    tokenizer->file = file;
    tokenizer->index = 0;
    tokenizer->indents = indents;
    tokenizer->previous = token;
    tokenizer->tokens = file->tokens;
}

void Tokenizer__store1(
  Tokenizer tokenizer,
  Character character,
  Dispatch dispatch)
{
    Unsigned index;
    index = ((Unsigned)(character));
    Array__store1(tokenizer->dispatch_table, index, (void *)(dispatch));
}

void Tokenizer__tokenize(
  Tokenizer tokenizer,
  File file)
{
    Unsigned anchor_index;
    Array tokens;
    Token token;
    Token anchor_token;
    Token set_token;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    (void)Tokenizer__start(tokenizer, file);
    anchor_index = 0;
    tokens = tokenizer->tokens;
    if (!((Array__size_get(tokens) == 0))) {
        System__assert_fail((String)"\tToken.ezc", 1601);
    }
    while (Logical__true) {
        token = Tokenizer__next(tokenizer);
        if (Logical__false) {

            (void)String__d((t__2 = String__form(((String)"\020Tokens[%d%]:%t%\n")), t__3 = Unsigned__f(Array__size_get(tokens)), String__divide(String__remainder((t__2), t__3), Token__f(token))));
        }
        switch (token->lexeme) {
            case Lexeme___end_of_line:
            case Lexeme___close_indent:
            case Lexeme___open_indent:
                anchor_index = (Array__size_get(tokens)+1);
                break;
            case Lexeme___end_of_file:
                (void)Array__append(tokens, ((void *)(token)));
                goto break__1;
                break;
            case Lexeme___assign:
            case Lexeme___define_assign:

                anchor_token = ((Token)Array__fetch1(tokens, anchor_index));
                set_token = Token__new();
                set_token->file = anchor_token->file;
                set_token->lexeme = Lexeme__set;
                set_token->position = anchor_token->position;
                set_token->value = ((String)"\000");
                set_token->white_space = anchor_token->white_space;
                anchor_token->white_space = ((String)"\000");
                (void)Array__insert(tokens, anchor_index, ((void *)(set_token)));
                break;
        }
        (void)Array__append(tokens, ((void *)(token)));
    }
    break__1:;
    (void)Tokenizer__finish(tokenizer);
    if (!((Array__size_get(tokens) != 0))) {
        System__assert_fail((String)"\tToken.ezc", 1631);
    }
}


String Dispatch__string_convert(
  Dispatch dispatch)
{
    switch (dispatch) {
        case Dispatch___apostrophe:
            return ((String)"\012apostrophe");
            break;
        case Dispatch___amphersand:
            return ((String)"\012amphersand");
            break;
        case Dispatch___ascii:
            return ((String)"\005ascii");
            break;
        case Dispatch___asterisk:
            return ((String)"\010asterisk");
            break;
        case Dispatch___at_sign:
            return ((String)"\007at_sign");
            break;
        case Dispatch___back_slash:
            return ((String)"\012back_slash");
            break;
        case Dispatch___caret:
            return ((String)"\005caret");
            break;
        case Dispatch___carriage_return:
            return ((String)"\017carriage_return");
            break;
        case Dispatch___close_brace:
            return ((String)"\013close_brace");
            break;
        case Dispatch___close_bracket:
            return ((String)"\015close_bracket");
            break;
        case Dispatch___close_parenthesis:
            return ((String)"\021close_parenthesis");
            break;
        case Dispatch___colon:
            return ((String)"\005colon");
            break;
        case Dispatch___comma:
            return ((String)"\005comma");
            break;
        case Dispatch___decimal_digit:
            return ((String)"\015decimal_digit");
            break;
        case Dispatch___double_quote:
            return ((String)"\014double_quote");
            break;
        case Dispatch___dollar:
            return ((String)"\006dollar");
            break;
        case Dispatch___e:
            return ((String)"\001e");
            break;
        case Dispatch___equals:
            return ((String)"\006equals");
            break;
        case Dispatch___exclamation_point:
            return ((String)"\021exclamation_point");
            break;
        case Dispatch___forward_slash:
            return ((String)"\015forward_slash");
            break;
        case Dispatch___grave_accent:
            return ((String)"\014grave_accent");
            break;
        case Dispatch___greater_than:
            return ((String)"\014greater_than");
            break;
        case Dispatch___hash:
            return ((String)"\004hash");
            break;
        case Dispatch___hex_letter:
            return ((String)"\012hex_letter");
            break;
        case Dispatch___hyphen:
            return ((String)"\006hyphen");
            break;
        case Dispatch___illegal:
            return ((String)"\007illegal");
            break;
        case Dispatch___latin9:
            return ((String)"\006latin9");
            break;
        case Dispatch___less_than:
            return ((String)"\011less_than");
            break;
        case Dispatch___letter:
            return ((String)"\006letter");
            break;
        case Dispatch___line_feed:
            return ((String)"\011line_feed");
            break;
        case Dispatch___open_brace:
            return ((String)"\012open_brace");
            break;
        case Dispatch___open_bracket:
            return ((String)"\014open_bracket");
            break;
        case Dispatch___open_parenthesis:
            return ((String)"\020open_parenthesis");
            break;
        case Dispatch___octal_digit:
            return ((String)"\013octal_digit");
            break;
        case Dispatch___percent:
            return ((String)"\007percent");
            break;
        case Dispatch___period:
            return ((String)"\006period");
            break;
        case Dispatch___plus_sign:
            return ((String)"\011plus_sign");
            break;
        case Dispatch___question_mark:
            return ((String)"\015question_mark");
            break;
        case Dispatch___semicolon:
            return ((String)"\011semicolon");
            break;
        case Dispatch___space:
            return ((String)"\005space");
            break;
        case Dispatch___tab:
            return ((String)"\003tab");
            break;
        case Dispatch___tilde:
            return ((String)"\005tilde");
            break;
        case Dispatch___underscore:
            return ((String)"\012underscore");
            break;
        case Dispatch___vertical_bar:
            return ((String)"\014vertical_bar");
            break;
        case Dispatch___x:
            return ((String)"\001x");
            break;
        case Dispatch___zero:
            return ((String)"\004zero");
            break;
    }
    return ((String)"\000");
}




String Lexeme__string_convert(
  Lexeme lexeme)
{
    switch (lexeme) {
        case Lexeme___add:
            return ((String)"\003add");
            break;
        case Lexeme___and:
            return ((String)"\003and");
            break;
        case Lexeme___assign:
            return ((String)"\006assign");
            break;
        case Lexeme___at_sign:
            return ((String)"\007at_sign");
            break;
        case Lexeme___character:
            return ((String)"\011character");
            break;
        case Lexeme___close_brace:
            return ((String)"\013close_brace");
            break;
        case Lexeme___close_bracket:
            return ((String)"\015close_bracket");
            break;
        case Lexeme___close_indent:
            return ((String)"\014close_indent");
            break;
        case Lexeme___close_invoke:
            return ((String)"\014close_invoke");
            break;
        case Lexeme___close_parenthesis:
            return ((String)"\021close_parenthesis");
            break;
        case Lexeme___close_type:
            return ((String)"\012close_type");
            break;
        case Lexeme___colon:
            return ((String)"\005colon");
            break;
        case Lexeme___comma:
            return ((String)"\005comma");
            break;
        case Lexeme___comment:
            return ((String)"\007comment");
            break;
        case Lexeme___concatenate:
            return ((String)"\013concatenate");
            break;
        case Lexeme___conditional_and:
            return ((String)"\017conditional_and");
            break;
        case Lexeme___conditional_or:
            return ((String)"\016conditional_or");
            break;
        case Lexeme___define_assign:
            return ((String)"\015define_assign");
            break;
        case Lexeme___divide:
            return ((String)"\006divide");
            break;
        case Lexeme___dot:
            return ((String)"\003dot");
            break;
        case Lexeme___end:
            return ((String)"\003end");
            break;
        case Lexeme___end_of_file:
            return ((String)"\013end_of_file");
            break;
        case Lexeme___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Lexeme___equals:
            return ((String)"\006equals");
            break;
        case Lexeme___error:
            return ((String)"\005error");
            break;
        case Lexeme___float_number:
            return ((String)"\014float_number");
            break;
        case Lexeme___greater_than:
            return ((String)"\014greater_than");
            break;
        case Lexeme___greater_than_or_equal:
            return ((String)"\025greater_than_or_equal");
            break;
        case Lexeme___identical:
            return ((String)"\011identical");
            break;
        case Lexeme___left_shift:
            return ((String)"\012left_shift");
            break;
        case Lexeme___less_than:
            return ((String)"\011less_than");
            break;
        case Lexeme___less_than_or_equal:
            return ((String)"\022less_than_or_equal");
            break;
        case Lexeme___logical_not:
            return ((String)"\013logical_not");
            break;
        case Lexeme___number:
            return ((String)"\006number");
            break;
        case Lexeme___minus:
            return ((String)"\005minus");
            break;
        case Lexeme___multiply:
            return ((String)"\010multiply");
            break;
        case Lexeme___negative:
            return ((String)"\010negative");
            break;
        case Lexeme___not:
            return ((String)"\003not");
            break;
        case Lexeme___not_equal:
            return ((String)"\011not_equal");
            break;
        case Lexeme___not_identical:
            return ((String)"\015not_identical");
            break;
        case Lexeme___open_brace:
            return ((String)"\012open_brace");
            break;
        case Lexeme___open_bracket:
            return ((String)"\014open_bracket");
            break;
        case Lexeme___open_indent:
            return ((String)"\013open_indent");
            break;
        case Lexeme___open_invoke:
            return ((String)"\013open_invoke");
            break;
        case Lexeme___open_parenthesis:
            return ((String)"\020open_parenthesis");
            break;
        case Lexeme___open_type:
            return ((String)"\011open_type");
            break;
        case Lexeme___or:
            return ((String)"\002or");
            break;
        case Lexeme___positive:
            return ((String)"\010positive");
            break;
        case Lexeme___question_mark:
            return ((String)"\015question_mark");
            break;
        case Lexeme___remainder:
            return ((String)"\011remainder");
            break;
        case Lexeme___right_shift:
            return ((String)"\013right_shift");
            break;
        case Lexeme___semicolon:
            return ((String)"\011semicolon");
            break;
        case Lexeme___set:
            return ((String)"\003set");
            break;
        case Lexeme___start:
            return ((String)"\005start");
            break;
        case Lexeme___string:
            return ((String)"\006string");
            break;
        case Lexeme___symbol:
            return ((String)"\006symbol");
            break;
        case Lexeme___type_invoke:
            return ((String)"\013type_invoke");
            break;
        case Lexeme___xor:
            return ((String)"\003xor");
            break;
    }
    return ((String)"\000");
}





/* {Tokenizer} stuff: */

struct Tokenizer__Struct Tokenizer__Initial = {
    &String__Initial,
    &String__Initial,
    (Array)0,
    &File__Initial,
    0,
    (Array)0,
    &Messages__Initial,
    &Token__Initial,
    (Array)0,
    &String__Initial,
    (Array)0,
};

Tokenizer Tokenizer__null = &Tokenizer__Initial;
void Tokenizer__erase(
  Tokenizer tokenizer)
{
    tokenizer->buffer = String__null;
    tokenizer->contents = String__null;
    if (tokenizer->dispatch_table == 0) {
	tokenizer->dispatch_table = Array__new();
    } else {
	Array__erase(tokenizer->dispatch_table);
    }
    tokenizer->file = File__null;
    tokenizer->index = 0;
    if (tokenizer->indents == 0) {
	tokenizer->indents = Array__new();
    } else {
	Array__erase(tokenizer->indents);
    }
    tokenizer->messages = Messages__null;
    tokenizer->previous = Token__null;
    if (tokenizer->tokens == 0) {
	tokenizer->tokens = Array__new();
    } else {
	Array__erase(tokenizer->tokens);
    }
    tokenizer->white_space = String__null;
    if (tokenizer->white_spaces == 0) {
	tokenizer->white_spaces = Array__new();
    } else {
	Array__erase(tokenizer->white_spaces);
    }
}

Tokenizer Tokenizer__new(void)
{
    Tokenizer tokenizer;
    extern void *malloc(size_t);

    tokenizer = (Tokenizer)malloc(sizeof(*tokenizer));
    tokenizer->buffer = String__null;
    tokenizer->contents = String__null;
    tokenizer->dispatch_table = Array__new();
    tokenizer->file = File__null;
    tokenizer->index = Unsigned__null;
    tokenizer->indents = Array__new();
    tokenizer->messages = Messages__null;
    tokenizer->previous = Token__null;
    tokenizer->tokens = Array__new();
    tokenizer->white_space = String__null;
    tokenizer->white_spaces = Array__new();
    return tokenizer;
}

void Tokenizer__Initialize(void)
{
    Tokenizer__erase(Tokenizer__null);
}

/* {Dispatch} stuff: */

Dispatch Dispatch__null = (Dispatch)0;
Dispatch Dispatch__apostrophe = Dispatch___apostrophe;
Dispatch Dispatch__amphersand = Dispatch___amphersand;
Dispatch Dispatch__ascii = Dispatch___ascii;
Dispatch Dispatch__asterisk = Dispatch___asterisk;
Dispatch Dispatch__at_sign = Dispatch___at_sign;
Dispatch Dispatch__back_slash = Dispatch___back_slash;
Dispatch Dispatch__caret = Dispatch___caret;
Dispatch Dispatch__carriage_return = Dispatch___carriage_return;
Dispatch Dispatch__close_brace = Dispatch___close_brace;
Dispatch Dispatch__close_bracket = Dispatch___close_bracket;
Dispatch Dispatch__close_parenthesis = Dispatch___close_parenthesis;
Dispatch Dispatch__colon = Dispatch___colon;
Dispatch Dispatch__comma = Dispatch___comma;
Dispatch Dispatch__decimal_digit = Dispatch___decimal_digit;
Dispatch Dispatch__double_quote = Dispatch___double_quote;
Dispatch Dispatch__dollar = Dispatch___dollar;
Dispatch Dispatch__e = Dispatch___e;
Dispatch Dispatch__equals = Dispatch___equals;
Dispatch Dispatch__exclamation_point = Dispatch___exclamation_point;
Dispatch Dispatch__forward_slash = Dispatch___forward_slash;
Dispatch Dispatch__grave_accent = Dispatch___grave_accent;
Dispatch Dispatch__greater_than = Dispatch___greater_than;
Dispatch Dispatch__hash = Dispatch___hash;
Dispatch Dispatch__hex_letter = Dispatch___hex_letter;
Dispatch Dispatch__hyphen = Dispatch___hyphen;
Dispatch Dispatch__illegal = Dispatch___illegal;
Dispatch Dispatch__latin9 = Dispatch___latin9;
Dispatch Dispatch__less_than = Dispatch___less_than;
Dispatch Dispatch__letter = Dispatch___letter;
Dispatch Dispatch__line_feed = Dispatch___line_feed;
Dispatch Dispatch__open_brace = Dispatch___open_brace;
Dispatch Dispatch__open_bracket = Dispatch___open_bracket;
Dispatch Dispatch__open_parenthesis = Dispatch___open_parenthesis;
Dispatch Dispatch__octal_digit = Dispatch___octal_digit;
Dispatch Dispatch__percent = Dispatch___percent;
Dispatch Dispatch__period = Dispatch___period;
Dispatch Dispatch__plus_sign = Dispatch___plus_sign;
Dispatch Dispatch__question_mark = Dispatch___question_mark;
Dispatch Dispatch__semicolon = Dispatch___semicolon;
Dispatch Dispatch__space = Dispatch___space;
Dispatch Dispatch__tab = Dispatch___tab;
Dispatch Dispatch__tilde = Dispatch___tilde;
Dispatch Dispatch__underscore = Dispatch___underscore;
Dispatch Dispatch__vertical_bar = Dispatch___vertical_bar;
Dispatch Dispatch__x = Dispatch___x;
Dispatch Dispatch__zero = Dispatch___zero;
void Dispatch__erase(
  Dispatch dispatch)
{
    /* do nothing */
}

void Dispatch__Initialize(void)
{
    Dispatch__erase(Dispatch__null);
}

/* {Define_Data} stuff: */

struct Define_Data__Struct Define_Data__Initial = {
    &String__Initial,
    &String__Initial,
    &String__Initial,
    &String__Initial,
};

Define_Data Define_Data__null = &Define_Data__Initial;
void Define_Data__erase(
  Define_Data define_data)
{
    define_data->old_name = String__null;
    define_data->new_name = String__null;
    define_data->value = String__null;
    define_data->type_name = String__null;
}

Define_Data Define_Data__new(void)
{
    Define_Data define_data;
    extern void *malloc(size_t);

    define_data = (Define_Data)malloc(sizeof(*define_data));
    define_data->old_name = String__null;
    define_data->new_name = String__null;
    define_data->value = String__null;
    define_data->type_name = String__null;
    return define_data;
}

void Define_Data__Initialize(void)
{
    Define_Data__erase(Define_Data__null);
}

/* {File} stuff: */

struct File__Struct File__Initial = {
    (Array)0,
    &String__Initial,
    &String__Initial,
    &String__Initial,
    (Array)0,
    (Array)0,
    &Root__Initial,
};

File File__null = &File__Initial;
void File__erase(
  File file)
{
    if (file->define_datas == 0) {
	file->define_datas = Array__new();
    } else {
	Array__erase(file->define_datas);
    }
    file->contents = String__null;
    file->directory = String__null;
    file->name = String__null;
    if (file->positions == 0) {
	file->positions = Array__new();
    } else {
	Array__erase(file->positions);
    }
    if (file->tokens == 0) {
	file->tokens = Array__new();
    } else {
	Array__erase(file->tokens);
    }
    file->root = Root__null;
}

File File__new(void)
{
    File file;
    extern void *malloc(size_t);

    file = (File)malloc(sizeof(*file));
    file->define_datas = Array__new();
    file->contents = String__null;
    file->directory = String__null;
    file->name = String__null;
    file->positions = Array__new();
    file->tokens = Array__new();
    file->root = Root__null;
    return file;
}

void File__Initialize(void)
{
    File__erase(File__null);
}

/* {Lexeme} stuff: */

Lexeme Lexeme__null = (Lexeme)0;
Lexeme Lexeme__add = Lexeme___add;
Lexeme Lexeme__and = Lexeme___and;
Lexeme Lexeme__assign = Lexeme___assign;
Lexeme Lexeme__at_sign = Lexeme___at_sign;
Lexeme Lexeme__character = Lexeme___character;
Lexeme Lexeme__close_brace = Lexeme___close_brace;
Lexeme Lexeme__close_bracket = Lexeme___close_bracket;
Lexeme Lexeme__close_indent = Lexeme___close_indent;
Lexeme Lexeme__close_invoke = Lexeme___close_invoke;
Lexeme Lexeme__close_parenthesis = Lexeme___close_parenthesis;
Lexeme Lexeme__close_type = Lexeme___close_type;
Lexeme Lexeme__colon = Lexeme___colon;
Lexeme Lexeme__comma = Lexeme___comma;
Lexeme Lexeme__comment = Lexeme___comment;
Lexeme Lexeme__concatenate = Lexeme___concatenate;
Lexeme Lexeme__conditional_and = Lexeme___conditional_and;
Lexeme Lexeme__conditional_or = Lexeme___conditional_or;
Lexeme Lexeme__define_assign = Lexeme___define_assign;
Lexeme Lexeme__divide = Lexeme___divide;
Lexeme Lexeme__dot = Lexeme___dot;
Lexeme Lexeme__end = Lexeme___end;
Lexeme Lexeme__end_of_file = Lexeme___end_of_file;
Lexeme Lexeme__end_of_line = Lexeme___end_of_line;
Lexeme Lexeme__equals = Lexeme___equals;
Lexeme Lexeme__error = Lexeme___error;
Lexeme Lexeme__float_number = Lexeme___float_number;
Lexeme Lexeme__greater_than = Lexeme___greater_than;
Lexeme Lexeme__greater_than_or_equal = Lexeme___greater_than_or_equal;
Lexeme Lexeme__identical = Lexeme___identical;
Lexeme Lexeme__left_shift = Lexeme___left_shift;
Lexeme Lexeme__less_than = Lexeme___less_than;
Lexeme Lexeme__less_than_or_equal = Lexeme___less_than_or_equal;
Lexeme Lexeme__logical_not = Lexeme___logical_not;
Lexeme Lexeme__number = Lexeme___number;
Lexeme Lexeme__minus = Lexeme___minus;
Lexeme Lexeme__multiply = Lexeme___multiply;
Lexeme Lexeme__negative = Lexeme___negative;
Lexeme Lexeme__not = Lexeme___not;
Lexeme Lexeme__not_equal = Lexeme___not_equal;
Lexeme Lexeme__not_identical = Lexeme___not_identical;
Lexeme Lexeme__open_brace = Lexeme___open_brace;
Lexeme Lexeme__open_bracket = Lexeme___open_bracket;
Lexeme Lexeme__open_indent = Lexeme___open_indent;
Lexeme Lexeme__open_invoke = Lexeme___open_invoke;
Lexeme Lexeme__open_parenthesis = Lexeme___open_parenthesis;
Lexeme Lexeme__open_type = Lexeme___open_type;
Lexeme Lexeme__or = Lexeme___or;
Lexeme Lexeme__positive = Lexeme___positive;
Lexeme Lexeme__question_mark = Lexeme___question_mark;
Lexeme Lexeme__remainder = Lexeme___remainder;
Lexeme Lexeme__right_shift = Lexeme___right_shift;
Lexeme Lexeme__semicolon = Lexeme___semicolon;
Lexeme Lexeme__set = Lexeme___set;
Lexeme Lexeme__start = Lexeme___start;
Lexeme Lexeme__string = Lexeme___string;
Lexeme Lexeme__symbol = Lexeme___symbol;
Lexeme Lexeme__type_invoke = Lexeme___type_invoke;
Lexeme Lexeme__xor = Lexeme___xor;
void Lexeme__erase(
  Lexeme lexeme)
{
    /* do nothing */
}

void Lexeme__Initialize(void)
{
    Lexeme__erase(Lexeme__null);
}

/* {Message} stuff: */

struct Message__Struct Message__Initial = {
    &Token__Initial,
    &String__Initial,
    0,
};

Message Message__null = &Message__Initial;
void Message__erase(
  Message message)
{
    message->location = Token__null;
    message->text = String__null;
    message->sequence = 0;
}

Message Message__new(void)
{
    Message message;
    extern void *malloc(size_t);

    message = (Message)malloc(sizeof(*message));
    message->location = Token__null;
    message->text = String__null;
    message->sequence = Unsigned__null;
    return message;
}

void Message__Initialize(void)
{
    Message__erase(Message__null);
}

/* {Messages} stuff: */

struct Messages__Struct Messages__Initial = {
    (Array)0,
};

Messages Messages__null = &Messages__Initial;
void Messages__erase(
  Messages messages)
{
    if (messages->errors == 0) {
	messages->errors = Array__new();
    } else {
	Array__erase(messages->errors);
    }
}

Messages Messages__new(void)
{
    Messages messages;
    extern void *malloc(size_t);

    messages = (Messages)malloc(sizeof(*messages));
    messages->errors = Array__new();
    return messages;
}

void Messages__Initialize(void)
{
    Messages__erase(Messages__null);
}

/* {Token} stuff: */

struct Token__Struct Token__Initial = {
    &File__Initial,
    (Lexeme)0,
    0,
    &String__Initial,
    &String__Initial,
};

Token Token__null = &Token__Initial;
void Token__erase(
  Token token)
{
    token->file = File__null;
    token->lexeme = Lexeme__null;
    token->position = 0;
    token->value = String__null;
    token->white_space = String__null;
}

Token Token__new(void)
{
    Token token;
    extern void *malloc(size_t);

    token = (Token)malloc(sizeof(*token));
    token->file = File__null;
    token->lexeme = Lexeme__null;
    token->position = Unsigned__null;
    token->value = String__null;
    token->white_space = String__null;
    return token;
}

void Token__Initialize(void)
{
    Token__erase(Token__null);
}


