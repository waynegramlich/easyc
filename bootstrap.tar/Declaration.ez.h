#ifndef DECLARATION_INCLUDED
#define DECLARATION_INCLUDED 1

/* Declare all enum's and typedef's first: */
/* h_emit1 */
typedef struct Typed_Name_Object__Struct *Typed_Name_Object;
/* h_emit2 */
enum Typed_Name_Object_Kind__Enum {
    Typed_Name_Object_Kind___constant,
    Typed_Name_Object_Kind___external,
    Typed_Name_Object_Kind___external_named,
    Typed_Name_Object_Kind___global,
    Typed_Name_Object_Kind___routine,
};
typedef enum Typed_Name_Object_Kind__Enum Typed_Name_Object_Kind;
/* h_emit3 */

/* Include other libraries exactly once: */
#ifndef COMPILER_INCLUDED
#include "Compiler.ez.h"/*D2*/
#endif /* COMPILER_INCLUDED */
#ifndef EASY_C_INCLUDED
#include "Easy_C.ez.h"/*D2*/
#endif /* EASY_C_INCLUDED */
#ifndef TOKEN_INCLUDED
#include "Token.ez.h"/*D2*/
#endif /* TOKEN_INCLUDED */
#ifndef PARSE_INCLUDED
#include "Parse.ez.h"/*D2*/
#endif /* PARSE_INCLUDED */
#ifndef STATEMENT_INCLUDED
#include "Statement.ez.h"/*D2*/
#endif /* STATEMENT_INCLUDED */

/* Define the structures: */
struct Typed_Name_Object__Struct {
    Typed_Name_Object_Kind kind;
    union {
	Constant_Declaration constant;/*u*/
	External_Declaration external;/*u*/
	External_Named_Declaration external_named;/*u*/
	Global_Declaration global;/*u*/
	Routine_Declaration routine;/*u*/
    } kind__union;
};
extern struct Typed_Name_Object__Struct Typed_Name_Object__Initial;/*D1*/

/* Declare the routine prototypes: */
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__constant;/*D9*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__external;/*D9*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__external_named;/*D9*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__global;/*D9*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__routine;/*D9*/
extern Typed_Name_Object Typed_Name_Object__null;/*D10*/
extern Typed_Name_Object Typed_Name_Object__new(void);/*D11*/
extern void Typed_Name_Object__erase(Typed_Name_Object);/*D12*/
extern void Collection_Declaration__visit(Collection_Declaration, String, Compiler);
extern Logical Constant_Declaration__equal(Constant_Declaration, Constant_Declaration);
extern void Constant_Declaration__visit(Constant_Declaration, String, Compiler);
extern void Declaration__library_visit(Library_Declaration, Interface_Declaration, Global_Library_Declaration, String, String, Compiler);
extern Token Declaration__location_get(Declaration);
extern void Declaration__visit(Declaration, String, Compiler);
extern Integer Define_Declaration__compare(Define_Declaration, Define_Declaration);
extern void Define_Declaration__show(Define_Declaration, String);
extern void Define_Declaration__c_defines_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__h_structs_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__h_typedefs_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__initialize_emit(Define_Declaration, String, Compiler);
extern Logical Define_Declaration__is_enumeration(Define_Declaration);
extern Logical Define_Declaration__is_base_type(Define_Declaration);
extern Logical Define_Declaration__is_external(Define_Declaration);
extern Logical Define_Declaration__is_simple_numeric(Define_Declaration);
extern Logical Define_Declaration__is_simple(Define_Declaration);
extern Logical Define_Declaration__is_record(Define_Declaration);
extern Logical Define_Declaration__is_registers(Define_Declaration);
extern Logical Define_Declaration__is_record_import(Define_Declaration);
extern Logical Define_Declaration__is_variant(Define_Declaration);
extern Type Define_Declaration__record_field_type(Define_Declaration, String);
extern String Define_Declaration__record_field_name(Define_Declaration, String);
extern String Define_Declaration__register_bit_name(Define_Declaration, String);
extern String Define_Declaration__register_bit_byte_name(Define_Declaration, String);
extern String Define_Declaration__register_byte_name(Define_Declaration, String);
extern Type Define_Declaration__variant_field_type(Define_Declaration, String);
extern Variant_Clause Define_Declaration__variant_lookup(Define_Declaration, String);
extern void Define_Declaration__visit(Define_Declaration, String, Compiler);
extern void Define_Declaration__variant_globals_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__null_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__erase_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__new_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__ezh_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__h_externs_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__prefix_scan(Define_Declaration, String, Compiler);
extern void Define_Declaration__generate_emit(Define_Declaration, String, Compiler);
extern void Define_Declaration__parse_generate(Define_Declaration, String, Compiler);
extern void Define_Declaration__traverse_generate(Define_Declaration, String, Compiler);
extern Generate_Clause Define_Declaration__generate(Define_Declaration);
extern void Defines_Prefix_Declaration__visit(Defines_Prefix_Declaration, String, Compiler);
extern void Easy_C_Declaration__visit(Easy_C_Declaration, String, Compiler);
extern Logical External_Declaration__equal(External_Declaration, External_Declaration);
extern void External_Declaration__visit(External_Declaration, String, Compiler);
extern void External_Named_Declaration__visit(External_Named_Declaration, String, Compiler);
extern Logical External_Named_Declaration__equal(External_Named_Declaration, External_Named_Declaration);
extern Logical Global_Declaration__equal(Global_Declaration, Global_Declaration);
extern void Global_Declaration__visit(Global_Declaration, String, Compiler);
extern void Global_Library_Declaration__visit(Global_Library_Declaration, String, Compiler);
extern void Include_String_Declaration__visit(Include_String_Declaration, String, Compiler);
extern void Interface_Declaration__visit(Interface_Declaration, String, Compiler);
extern void Library_Declaration__visit(Library_Declaration, String, Compiler);
extern void Load_Declaration__visit(Load_Declaration, String, Compiler);
extern void Note__visit(Note, String, Compiler);
extern void Root__visit(Root, String, Compiler, Phase);
extern String Routine_Clause__f(Routine_Clause);
extern void Routine_Clause__format(Routine_Clause, String);
extern void Routine_Clause__visit(Routine_Clause, String, Compiler);
extern Logical Routine_Declaration__c_array_access(Routine_Declaration);
extern void Require_Declaration__visit(Require_Declaration, String, Compiler);
extern void Routine_Declaration__c_emit(Routine_Declaration, String, Compiler);
extern Logical Routine_Declaration__compatible(Routine_Declaration, Routine_Declaration);
extern String Routine_Declaration__external(Routine_Declaration);
extern void Routine_Declaration__h_externs_emit(Routine_Declaration, String, Compiler);
extern Array Routine_Declaration__take_clauses_extract(Routine_Declaration);
extern Type Routine_Declaration__return_type(Routine_Declaration);
extern Type Routine_Declaration__prototype_extract(Routine_Declaration);
extern void Routine_Declaration__visit(Routine_Declaration, String, Compiler);
extern String Routine_Declaration__interrupt(Routine_Declaration);
extern Logical Routine_Declaration__is_parameter(Routine_Declaration, Type);
extern Logical Routine_Declaration__returns_parameter(Routine_Declaration);
extern Type Routine_Declaration__scalar_cast(Routine_Declaration);
extern Logical Typed_Name_Object__equal(Typed_Name_Object, Typed_Name_Object);
extern void Typed_Name_Object__show(Typed_Name_Object, String);
extern Token Typed_Name_Object__location_get(Typed_Name_Object);
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__constant;/*D3*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__external;/*D3*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__external_named;/*D3*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__global;/*D3*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__routine;/*D3*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__null;/*D6*/
extern String Typed_Name_Object_Kind__string_convert(Typed_Name_Object_Kind);/*D7*/
extern void Typed_Name_Object_Kind__erase(Typed_Name_Object_Kind);/*D8*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__constant;;/*D13*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__external;;/*D13*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__external_named;;/*D13*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__global;;/*D13*/
extern Typed_Name_Object_Kind Typed_Name_Object_Kind__routine;;/*D13*/
extern String Typed_Name_Object_Kind__string_convert(Typed_Name_Object_Kind);
extern Typed_Name_Object Typed_Name_Object__null;;/*D13*/
extern Typed_Name_Object Typed_Name_Object__new(void);

/* Declare extracted #define values: */
extern Unsigned Unsigned__unix_errno_2big;
extern Unsigned Unsigned__unix_errno_acces;
extern Unsigned Unsigned__unix_errno_addrinuse;
extern Unsigned Unsigned__unix_errno_addrnotavail;
extern Unsigned Unsigned__unix_errno_adv;
extern Unsigned Unsigned__unix_errno_afnosupport;
extern Unsigned Unsigned__unix_errno_again;
extern Unsigned Unsigned__unix_errno_already;
extern Unsigned Unsigned__unix_errno_asy_c_included;
extern Unsigned Unsigned__unix_errno_bade;
extern Unsigned Unsigned__unix_errno_badf;
extern Unsigned Unsigned__unix_errno_badfd;
extern Unsigned Unsigned__unix_errno_badmsg;
extern Unsigned Unsigned__unix_errno_badr;
extern Unsigned Unsigned__unix_errno_badrqc;
extern Unsigned Unsigned__unix_errno_badslt;
extern Unsigned Unsigned__unix_errno_bfont;
extern Unsigned Unsigned__unix_errno_busy;
extern Unsigned Unsigned__unix_errno_canceled;
extern Unsigned Unsigned__unix_errno_child;
extern Unsigned Unsigned__unix_errno_chrng;
extern Unsigned Unsigned__unix_errno_comm;
extern Unsigned Unsigned__unix_errno_connaborted;
extern Unsigned Unsigned__unix_errno_connrefused;
extern Unsigned Unsigned__unix_errno_connreset;
extern Unsigned Unsigned__unix_errno_deadlk;
extern Unsigned Unsigned__unix_errno_destaddrreq;
extern Unsigned Unsigned__unix_errno_dom;
extern Unsigned Unsigned__unix_errno_dotdot;
extern Unsigned Unsigned__unix_errno_dquot;
extern Unsigned Unsigned__unix_errno_exist;
extern Unsigned Unsigned__unix_errno_fault;
extern Unsigned Unsigned__unix_errno_fbig;
extern Unsigned Unsigned__unix_errno_hostdown;
extern Unsigned Unsigned__unix_errno_hostunreach;
extern Unsigned Unsigned__unix_errno_hwpoison;
extern Unsigned Unsigned__unix_errno_idrm;
extern Unsigned Unsigned__unix_errno_ilseq;
extern Unsigned Unsigned__unix_errno_inprogress;
extern Unsigned Unsigned__unix_errno_intr;
extern Unsigned Unsigned__unix_errno_inval;
extern Unsigned Unsigned__unix_errno_io;
extern Unsigned Unsigned__unix_errno_isconn;
extern Unsigned Unsigned__unix_errno_isdir;
extern Unsigned Unsigned__unix_errno_isnam;
extern Unsigned Unsigned__unix_errno_keyexpired;
extern Unsigned Unsigned__unix_errno_keyrejected;
extern Unsigned Unsigned__unix_errno_keyrevoked;
extern Unsigned Unsigned__unix_errno_l2hlt;
extern Unsigned Unsigned__unix_errno_l2nsync;
extern Unsigned Unsigned__unix_errno_l3hlt;
extern Unsigned Unsigned__unix_errno_l3rst;
extern Unsigned Unsigned__unix_errno_libacc;
extern Unsigned Unsigned__unix_errno_libbad;
extern Unsigned Unsigned__unix_errno_libexec;
extern Unsigned Unsigned__unix_errno_libmax;
extern Unsigned Unsigned__unix_errno_libscn;
extern Unsigned Unsigned__unix_errno_lnrng;
extern Unsigned Unsigned__unix_errno_loop;
extern Unsigned Unsigned__unix_errno_mediumtype;
extern Unsigned Unsigned__unix_errno_mfile;
extern Unsigned Unsigned__unix_errno_mlink;
extern Unsigned Unsigned__unix_errno_msgsize;
extern Unsigned Unsigned__unix_errno_multihop;
extern Unsigned Unsigned__unix_errno_nametoolong;
extern Unsigned Unsigned__unix_errno_navail;
extern Unsigned Unsigned__unix_errno_netdown;
extern Unsigned Unsigned__unix_errno_netreset;
extern Unsigned Unsigned__unix_errno_netunreach;
extern Unsigned Unsigned__unix_errno_nfile;
extern Unsigned Unsigned__unix_errno_noano;
extern Unsigned Unsigned__unix_errno_nobufs;
extern Unsigned Unsigned__unix_errno_nocsi;
extern Unsigned Unsigned__unix_errno_nodata;
extern Unsigned Unsigned__unix_errno_nodev;
extern Unsigned Unsigned__unix_errno_noent;
extern Unsigned Unsigned__unix_errno_noexec;
extern Unsigned Unsigned__unix_errno_nokey;
extern Unsigned Unsigned__unix_errno_nolck;
extern Unsigned Unsigned__unix_errno_nolink;
extern Unsigned Unsigned__unix_errno_nomedium;
extern Unsigned Unsigned__unix_errno_nomem;
extern Unsigned Unsigned__unix_errno_nomsg;
extern Unsigned Unsigned__unix_errno_nonet;
extern Unsigned Unsigned__unix_errno_nopkg;
extern Unsigned Unsigned__unix_errno_noprotoopt;
extern Unsigned Unsigned__unix_errno_nospc;
extern Unsigned Unsigned__unix_errno_nosr;
extern Unsigned Unsigned__unix_errno_nostr;
extern Unsigned Unsigned__unix_errno_nosys;
extern Unsigned Unsigned__unix_errno_notblk;
extern Unsigned Unsigned__unix_errno_notconn;
extern Unsigned Unsigned__unix_errno_notdir;
extern Unsigned Unsigned__unix_errno_notempty;
extern Unsigned Unsigned__unix_errno_notnam;
extern Unsigned Unsigned__unix_errno_notrecoverable;
extern Unsigned Unsigned__unix_errno_notsock;
extern Unsigned Unsigned__unix_errno_notty;
extern Unsigned Unsigned__unix_errno_notuniq;
extern Unsigned Unsigned__unix_errno_nxio;
extern Unsigned Unsigned__unix_errno_opnotsupp;
extern Unsigned Unsigned__unix_errno_overflow;
extern Unsigned Unsigned__unix_errno_ownerdead;
extern Unsigned Unsigned__unix_errno_perm;
extern Unsigned Unsigned__unix_errno_pfnosupport;
extern Unsigned Unsigned__unix_errno_pipe;
extern Unsigned Unsigned__unix_errno_proto;
extern Unsigned Unsigned__unix_errno_protonosupport;
extern Unsigned Unsigned__unix_errno_prototype;
extern Unsigned Unsigned__unix_errno_range;
extern Unsigned Unsigned__unix_errno_remchg;
extern Unsigned Unsigned__unix_errno_remote;
extern Unsigned Unsigned__unix_errno_remoteio;
extern Unsigned Unsigned__unix_errno_restart;
extern Unsigned Unsigned__unix_errno_rfkill;
extern Unsigned Unsigned__unix_errno_rofs;
extern Unsigned Unsigned__unix_errno_shutdown;
extern Unsigned Unsigned__unix_errno_socktnosupport;
extern Unsigned Unsigned__unix_errno_spipe;
extern Unsigned Unsigned__unix_errno_srch;
extern Unsigned Unsigned__unix_errno_srmnt;
extern Unsigned Unsigned__unix_errno_stale;
extern Unsigned Unsigned__unix_errno_strpipe;
extern Unsigned Unsigned__unix_errno_time;
extern Unsigned Unsigned__unix_errno_timedout;
extern Unsigned Unsigned__unix_errno_toomanyrefs;
extern Unsigned Unsigned__unix_errno_txtbsy;
extern Unsigned Unsigned__unix_errno_uclean;
extern Unsigned Unsigned__unix_errno_unatch;
extern Unsigned Unsigned__unix_errno_users;
extern Unsigned Unsigned__unix_errno_xdev;
extern Unsigned Unsigned__unix_errno_xfull;
extern Unsigned Unsigned__unix_errno_xit_failure;
extern Unsigned Unsigned__unix_errno_xit_success;
extern Unsigned Unsigned__unix_errno_asyc_c_h_included;
extern Integer Integer__unix_file_f_dupfd;
extern Integer Integer__unix_file_f_dupfd_cloexec;
extern Integer Integer__unix_file_f_exlck;
extern Integer Integer__unix_file_f_getfd;
extern Integer Integer__unix_file_f_getfl;
extern Integer Integer__unix_file_f_getlk;
extern Integer Integer__unix_file_f_getlk64;
extern Integer Integer__unix_file_f_getown;
extern Integer Integer__unix_file_f_lock;
extern Integer Integer__unix_file_f_ok;
extern Integer Integer__unix_file_f_rdlck;
extern Integer Integer__unix_file_f_setfd;
extern Integer Integer__unix_file_f_setfl;
extern Integer Integer__unix_file_f_setlk;
extern Integer Integer__unix_file_f_setlk64;
extern Integer Integer__unix_file_f_setlkw;
extern Integer Integer__unix_file_f_setlkw64;
extern Integer Integer__unix_file_f_setown;
extern Integer Integer__unix_file_f_shlck;
extern Integer Integer__unix_file_f_test;
extern Integer Integer__unix_file_f_tlock;
extern Integer Integer__unix_file_f_ulock;
extern Integer Integer__unix_file_f_unlck;
extern Integer Integer__unix_file_f_wrlck;
extern Unsigned Unsigned__unix_file_o_accmode;
extern Unsigned Unsigned__unix_file_o_append;
extern Unsigned Unsigned__unix_file_o_async;
extern Unsigned Unsigned__unix_file_o_cloexec;
extern Unsigned Unsigned__unix_file_o_creat;
extern Unsigned Unsigned__unix_file_o_directory;
extern Unsigned Unsigned__unix_file_o_dsync;
extern Unsigned Unsigned__unix_file_o_excl;
extern Unsigned Unsigned__unix_file_o_noctty;
extern Unsigned Unsigned__unix_file_o_nofollow;
extern Unsigned Unsigned__unix_file_o_nonblock;
extern Unsigned Unsigned__unix_file_o_rdonly;
extern Unsigned Unsigned__unix_file_o_rdwr;
extern Unsigned Unsigned__unix_file_o_sync;
extern Unsigned Unsigned__unix_file_o_trunc;
extern Unsigned Unsigned__unix_file_o_wronly;
#endif /* DECLARATION_INCLUDED */
