#ifndef PARSE_INCLUDED
#define PARSE_INCLUDED 1

/* Declare all enum's and typedef's first: */
/* h_emit1 */
typedef struct Root__Struct *Root;
typedef struct Declaration__Struct *Declaration;
typedef struct Easy_C_Declaration__Struct *Easy_C_Declaration;
typedef struct Define_Declaration__Struct *Define_Declaration;
typedef struct Define_Clause__Struct *Define_Clause;
typedef struct Simple_Numeric_Clause__Struct *Simple_Numeric_Clause;
typedef struct Base_Type_Clause__Struct *Base_Type_Clause;
typedef struct Enumeration_Clause__Struct *Enumeration_Clause;
typedef struct Enumeration_Prefix_Clause__Struct *Enumeration_Prefix_Clause;
typedef struct Item_Clause__Struct *Item_Clause;
typedef struct Item__Struct *Item;
typedef struct Record_Clause__Struct *Record_Clause;
typedef struct Record_Import_Clause__Struct *Record_Import_Clause;
typedef struct Registers_Clause__Struct *Registers_Clause;
typedef struct Register_Clause__Struct *Register_Clause;
typedef struct Register_Bit__Struct *Register_Bit;
typedef struct Register_Byte__Struct *Register_Byte;
typedef struct Field_Clause__Struct *Field_Clause;
typedef struct Import_Field_Clause__Struct *Import_Field_Clause;
typedef struct Variant_Clause__Struct *Variant_Clause;
typedef struct Field__Struct *Field;
typedef struct Import_Field__Struct *Import_Field;
typedef struct Simple_Clause__Struct *Simple_Clause;
typedef struct Generate_Clause__Struct *Generate_Clause;
typedef struct Generate_Name__Struct *Generate_Name;
typedef struct External_Clause__Struct *External_Clause;
typedef struct External_Declaration__Struct *External_Declaration;
typedef struct External_Named_Declaration__Struct *External_Named_Declaration;
typedef struct Global_Declaration__Struct *Global_Declaration;
typedef struct Include_String_Declaration__Struct *Include_String_Declaration;
typedef struct Global_Library_Declaration__Struct *Global_Library_Declaration;
typedef struct Library_Declaration__Struct *Library_Declaration;
typedef struct Interface_Declaration__Struct *Interface_Declaration;
typedef struct Load_Declaration__Struct *Load_Declaration;
typedef struct Collection_Declaration__Struct *Collection_Declaration;
typedef struct Require_Declaration__Struct *Require_Declaration;
typedef struct Constant_Declaration__Struct *Constant_Declaration;
typedef struct Defines_Prefix_Declaration__Struct *Defines_Prefix_Declaration;
typedef struct Routine_Declaration__Struct *Routine_Declaration;
typedef struct Routine_Clause__Struct *Routine_Clause;
typedef struct Takes_Nothing_Clause__Struct *Takes_Nothing_Clause;
typedef struct Take_Clause__Struct *Take_Clause;
typedef struct Take_Import_Clause__Struct *Take_Import_Clause;
typedef struct Returns_Nothing_Clause__Struct *Returns_Nothing_Clause;
typedef struct Returns_Clause__Struct *Returns_Clause;
typedef struct External_Routine_Clause__Struct *External_Routine_Clause;
typedef struct Scalar_Cast_Clause__Struct *Scalar_Cast_Clause;
typedef struct Interrupt_Clause__Struct *Interrupt_Clause;
typedef struct C_Array_Access_Clause__Struct *C_Array_Access_Clause;
typedef struct Local_Clause__Struct *Local_Clause;
typedef struct Statement__Struct *Statement;
typedef struct Assert_Statement__Struct *Assert_Statement;
typedef struct Break_Empty_Statement__Struct *Break_Empty_Statement;
typedef struct Break_Level_Statement__Struct *Break_Level_Statement;
typedef struct Call_Statement__Struct *Call_Statement;
typedef struct Continue_Empty_Statement__Struct *Continue_Empty_Statement;
typedef struct Continue_Level_Statement__Struct *Continue_Level_Statement;
typedef struct Do_Nothing_Statement__Struct *Do_Nothing_Statement;
typedef struct Fail_Statement__Struct *Fail_Statement;
typedef struct If_Statement__Struct *If_Statement;
typedef struct If_Clause__Struct *If_Clause;
typedef struct If_Part__Struct *If_Part;
typedef struct Else_If_Part__Struct *Else_If_Part;
typedef struct Else_Part__Struct *Else_Part;
typedef struct Return_Statement__Struct *Return_Statement;
typedef struct Return_Clause_Expression__Struct *Return_Clause_Expression;
typedef struct Return_Clause_Empty__Struct *Return_Clause_Empty;
typedef struct Set_Statement__Struct *Set_Statement;
typedef struct Switch_Statement__Struct *Switch_Statement;
typedef struct Switch_Clause__Struct *Switch_Clause;
typedef struct Switch_Case__Struct *Switch_Case;
typedef struct Switch_Default__Struct *Switch_Default;
typedef struct Switch_All_Cases_Required__Struct *Switch_All_Cases_Required;
typedef struct Case_Name__Struct *Case_Name;
typedef struct While_Statement__Struct *While_Statement;
typedef struct Expression__Struct *Expression;
typedef struct Binary_Expression__Struct *Binary_Expression;
typedef struct Bracket_Expression__Struct *Bracket_Expression;
typedef struct List_Expression__Struct *List_Expression;
typedef struct Parenthesis_Expression__Struct *Parenthesis_Expression;
typedef struct Unary_Expression__Struct *Unary_Expression;
typedef struct Typed_Name__Struct *Typed_Name;
typedef struct Type__Struct *Type;
typedef struct Parameterized_Type__Struct *Parameterized_Type;
typedef struct Routine_Type__Struct *Routine_Type;
typedef struct Note__Struct *Note;
typedef struct Error__Struct *Error;
typedef struct Keyword__Struct *Keyword;
typedef struct Comma_Separated__Struct *Comma_Separated;
typedef struct Parser__Struct *Parser;
typedef struct Traverser__Struct *Traverser;
enum Expression_State__Enum {
    Expression_State___unary,
    Expression_State___leaf,
    Expression_State___binary,
    Expression_State___at_sign,
    Expression_State___at_leaf,
};
typedef enum Expression_State__Enum Expression_State;
/* h_emit2 */
enum Declaration_Kind__Enum {
    Declaration_Kind___easy_c,
    Declaration_Kind___end_of_line,
    Declaration_Kind___note,
    Declaration_Kind___routine,
    Declaration_Kind___define,
    Declaration_Kind___defines_prefix,
    Declaration_Kind___external_named,
    Declaration_Kind___external,
    Declaration_Kind___global,
    Declaration_Kind___global_library,
    Declaration_Kind___library,
    Declaration_Kind___interface,
    Declaration_Kind___load,
    Declaration_Kind___include_string,
    Declaration_Kind___constant,
    Declaration_Kind___require,
    Declaration_Kind___collection,
    Declaration_Kind___error,
};
typedef enum Declaration_Kind__Enum Declaration_Kind;
enum Define_Clause_Kind__Enum {
    Define_Clause_Kind___end_of_line,
    Define_Clause_Kind___note,
    Define_Clause_Kind___enumeration,
    Define_Clause_Kind___enumeration_prefix,
    Define_Clause_Kind___record,
    Define_Clause_Kind___record_import,
    Define_Clause_Kind___registers,
    Define_Clause_Kind___variant,
    Define_Clause_Kind___generate,
    Define_Clause_Kind___simple,
    Define_Clause_Kind___simple_numeric,
    Define_Clause_Kind___external,
    Define_Clause_Kind___base_type,
    Define_Clause_Kind___error,
};
typedef enum Define_Clause_Kind__Enum Define_Clause_Kind;
enum Item_Clause_Kind__Enum {
    Item_Clause_Kind___end_of_line,
    Item_Clause_Kind___note,
    Item_Clause_Kind___item,
    Item_Clause_Kind___error,
};
typedef enum Item_Clause_Kind__Enum Item_Clause_Kind;
enum Register_Clause_Kind__Enum {
    Register_Clause_Kind___end_of_line,
    Register_Clause_Kind___note,
    Register_Clause_Kind___bit,
    Register_Clause_Kind___byte,
    Register_Clause_Kind___error,
};
typedef enum Register_Clause_Kind__Enum Register_Clause_Kind;
enum Field_Clause_Kind__Enum {
    Field_Clause_Kind___end_of_line,
    Field_Clause_Kind___note,
    Field_Clause_Kind___field,
    Field_Clause_Kind___error,
};
typedef enum Field_Clause_Kind__Enum Field_Clause_Kind;
enum Import_Field_Clause_Kind__Enum {
    Import_Field_Clause_Kind___end_of_line,
    Import_Field_Clause_Kind___note,
    Import_Field_Clause_Kind___import_field,
    Import_Field_Clause_Kind___error,
};
typedef enum Import_Field_Clause_Kind__Enum Import_Field_Clause_Kind;
enum Routine_Clause_Kind__Enum {
    Routine_Clause_Kind___end_of_line,
    Routine_Clause_Kind___note,
    Routine_Clause_Kind___takes_nothing,
    Routine_Clause_Kind___take_import,
    Routine_Clause_Kind___take,
    Routine_Clause_Kind___interrupt,
    Routine_Clause_Kind___returns_nothing,
    Routine_Clause_Kind___returns,
    Routine_Clause_Kind___external,
    Routine_Clause_Kind___c_array_access,
    Routine_Clause_Kind___scalar_cast,
    Routine_Clause_Kind___local,
    Routine_Clause_Kind___assert,
    Routine_Clause_Kind___call,
    Routine_Clause_Kind___do_nothing,
    Routine_Clause_Kind___if,
    Routine_Clause_Kind___return,
    Routine_Clause_Kind___fail,
    Routine_Clause_Kind___set,
    Routine_Clause_Kind___switch,
    Routine_Clause_Kind___while,
    Routine_Clause_Kind___error,
};
typedef enum Routine_Clause_Kind__Enum Routine_Clause_Kind;
enum Statement_Kind__Enum {
    Statement_Kind___end_of_line,
    Statement_Kind___note,
    Statement_Kind___assert,
    Statement_Kind___break_level,
    Statement_Kind___break_empty,
    Statement_Kind___call,
    Statement_Kind___continue_level,
    Statement_Kind___continue_empty,
    Statement_Kind___do_nothing,
    Statement_Kind___if,
    Statement_Kind___return,
    Statement_Kind___set,
    Statement_Kind___switch,
    Statement_Kind___while,
    Statement_Kind___error,
};
typedef enum Statement_Kind__Enum Statement_Kind;
enum If_Clause_Kind__Enum {
    If_Clause_Kind___if_part,
    If_Clause_Kind___else_if_part,
    If_Clause_Kind___else_part,
};
typedef enum If_Clause_Kind__Enum If_Clause_Kind;
enum Return_Clause_Kind__Enum {
    Return_Clause_Kind___expression,
    Return_Clause_Kind___empty,
};
typedef enum Return_Clause_Kind__Enum Return_Clause_Kind;
enum Switch_Clause_Kind__Enum {
    Switch_Clause_Kind___end_of_line,
    Switch_Clause_Kind___note,
    Switch_Clause_Kind___case,
    Switch_Clause_Kind___default,
    Switch_Clause_Kind___all_cases_required,
    Switch_Clause_Kind___error,
};
typedef enum Switch_Clause_Kind__Enum Switch_Clause_Kind;
enum Expression_Kind__Enum {
    Expression_Kind___binary,
    Expression_Kind___bracket,
    Expression_Kind___character,
    Expression_Kind___float_number,
    Expression_Kind___list,
    Expression_Kind___number,
    Expression_Kind___parenthesis,
    Expression_Kind___string,
    Expression_Kind___symbol,
    Expression_Kind___unary,
    Expression_Kind___error,
};
typedef enum Expression_Kind__Enum Expression_Kind;
enum Type_Kind__Enum {
    Type_Kind___parameterized,
    Type_Kind___simple,
    Type_Kind___routine,
};
typedef enum Type_Kind__Enum Type_Kind;
/* h_emit3 */

/* Include other libraries exactly once: */
#ifndef COMPILER_INCLUDED
#include "Compiler.ez.h"/*D2*/
#endif /* COMPILER_INCLUDED */
#ifndef EASY_C_INCLUDED
#include "Easy_C.ez.h"/*D2*/
#endif /* EASY_C_INCLUDED */
#ifndef EXPRESSION_INCLUDED
#include "Expression.ez.h"/*D2*/
#endif /* EXPRESSION_INCLUDED */
#ifndef TOKEN_INCLUDED
#include "Token.ez.h"/*D2*/
#endif /* TOKEN_INCLUDED */

/* Define the structures: */
struct Root__Struct {
    Array declarations;
    Token end_of_file;
};
extern struct Root__Struct Root__Initial;/*D1*/
struct Declaration__Struct {
    Declaration_Kind kind;
    union {
	Easy_C_Declaration easy_c;/*u*/
	Token end_of_line;/*u*/
	Note note;/*u*/
	Routine_Declaration routine;/*u*/
	Define_Declaration define;/*u*/
	Defines_Prefix_Declaration defines_prefix;/*u*/
	External_Named_Declaration external_named;/*u*/
	External_Declaration external;/*u*/
	Global_Declaration global;/*u*/
	Global_Library_Declaration global_library;/*u*/
	Library_Declaration library;/*u*/
	Interface_Declaration interface;/*u*/
	Load_Declaration load;/*u*/
	Include_String_Declaration include_string;/*u*/
	Constant_Declaration constant;/*u*/
	Require_Declaration require;/*u*/
	Collection_Declaration collection;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Declaration__Struct Declaration__Initial;/*D1*/
struct Easy_C_Declaration__Struct {
    Keyword easy_c;
    Token float_number;
    Token end_of_line;
};
extern struct Easy_C_Declaration__Struct Easy_C_Declaration__Initial;/*D1*/
struct Define_Declaration__Struct {
    Keyword define;
    Type type;
    Token end_of_line;
    Token open_indent;
    Array define_clauses;
    Token close_indent;
};
extern struct Define_Declaration__Struct Define_Declaration__Initial;/*D1*/
struct Define_Clause__Struct {
    Define_Clause_Kind kind;
    union {
	Token end_of_line;/*u*/
	Note note;/*u*/
	Enumeration_Clause enumeration;/*u*/
	Enumeration_Prefix_Clause enumeration_prefix;/*u*/
	Record_Clause record;/*u*/
	Record_Import_Clause record_import;/*u*/
	Registers_Clause registers;/*u*/
	Variant_Clause variant;/*u*/
	Generate_Clause generate;/*u*/
	Simple_Clause simple;/*u*/
	Simple_Numeric_Clause simple_numeric;/*u*/
	External_Clause external;/*u*/
	Base_Type_Clause base_type;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Define_Clause__Struct Define_Clause__Initial;/*D1*/
struct Simple_Numeric_Clause__Struct {
    Keyword simple_numeric;
    Type type;
    Token end_of_line;
};
extern struct Simple_Numeric_Clause__Struct Simple_Numeric_Clause__Initial;/*D1*/
struct Base_Type_Clause__Struct {
    Keyword base_type;
    Token string;
    Token end_of_line;
};
extern struct Base_Type_Clause__Struct Base_Type_Clause__Initial;/*D1*/
struct Enumeration_Clause__Struct {
    Keyword enumeration;
    Token end_of_line;
    Token open_indent;
    Array item_clauses;
    Token close_indent;
};
extern struct Enumeration_Clause__Struct Enumeration_Clause__Initial;/*D1*/
struct Enumeration_Prefix_Clause__Struct {
    Keyword enumeration_prefix;
    Token prefix;
    Token end_of_line;
    Array define_datas;
    Logical define_datas_initialized;
};
extern struct Enumeration_Prefix_Clause__Struct Enumeration_Prefix_Clause__Initial;/*D1*/
struct Item_Clause__Struct {
    Item_Clause_Kind kind;
    union {
	Token end_of_line;/*u*/
	Note note;/*u*/
	Item item;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Item_Clause__Struct Item_Clause__Initial;/*D1*/
struct Item__Struct {
    Token name;
    Token end_of_line;
};
extern struct Item__Struct Item__Initial;/*D1*/
struct Record_Clause__Struct {
    Keyword record;
    Token end_of_line;
    Token open_indent;
    Array field_clauses;
    Token close_indent;
};
extern struct Record_Clause__Struct Record_Clause__Initial;/*D1*/
struct Record_Import_Clause__Struct {
    Keyword record_import;
    Token string;
    Token end_of_line;
    Token open_indent;
    Array import_field_clauses;
    Token close_indent;
};
extern struct Record_Import_Clause__Struct Record_Import_Clause__Initial;/*D1*/
struct Registers_Clause__Struct {
    Keyword registers;
    Token end_of_line;
    Token open_indent;
    Array register_clauses;
    Token close_indent;
};
extern struct Registers_Clause__Struct Registers_Clause__Initial;/*D1*/
struct Register_Clause__Struct {
    Register_Clause_Kind kind;
    union {
	Token end_of_line;/*u*/
	Note note;/*u*/
	Register_Bit bit;/*u*/
	Register_Byte byte;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Register_Clause__Struct Register_Clause__Initial;/*D1*/
struct Register_Bit__Struct {
    Keyword bit;
    Token name;
    Token equals;
    Token string;
    Token end_of_line;
};
extern struct Register_Bit__Struct Register_Bit__Initial;/*D1*/
struct Register_Byte__Struct {
    Keyword byte;
    Token name;
    Token equals;
    Token string;
    Token end_of_line;
};
extern struct Register_Byte__Struct Register_Byte__Initial;/*D1*/
struct Field_Clause__Struct {
    Field_Clause_Kind kind;
    union {
	Token end_of_line;/*u*/
	Note note;/*u*/
	Field field;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Field_Clause__Struct Field_Clause__Initial;/*D1*/
struct Import_Field_Clause__Struct {
    Import_Field_Clause_Kind kind;
    union {
	Token end_of_line;/*u*/
	Note note;/*u*/
	Import_Field import_field;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Import_Field_Clause__Struct Import_Field_Clause__Initial;/*D1*/
struct Variant_Clause__Struct {
    Keyword variant;
    Token kind_name;
    Type kind_type;
    Token end_of_line;
    Token open_indent;
    Array field_clauses;
    Token close_indent;
};
extern struct Variant_Clause__Struct Variant_Clause__Initial;/*D1*/
struct Field__Struct {
    Token name;
    Type type;
    Token end_of_line;
};
extern struct Field__Struct Field__Initial;/*D1*/
struct Import_Field__Struct {
    Token c_name;
    Token equals;
    Token name;
    Type type;
    Token end_of_line;
};
extern struct Import_Field__Struct Import_Field__Initial;/*D1*/
struct Simple_Clause__Struct {
    Keyword simple;
    Type type;
    Token end_of_line;
};
extern struct Simple_Clause__Struct Simple_Clause__Initial;/*D1*/
struct Generate_Clause__Struct {
    Keyword generate;
    Comma_Separated names;
    Token end_of_line;
};
extern struct Generate_Clause__Struct Generate_Clause__Initial;/*D1*/
struct Generate_Name__Struct {
    Token name;
};
extern struct Generate_Name__Struct Generate_Name__Initial;/*D1*/
struct External_Clause__Struct {
    Keyword external;
    Token end_of_line;
};
extern struct External_Clause__Struct External_Clause__Initial;/*D1*/
struct External_Declaration__Struct {
    Keyword external;
    Typed_Name typed_name;
    Type type;
    Token end_of_line;
};
extern struct External_Declaration__Struct External_Declaration__Initial;/*D1*/
struct External_Named_Declaration__Struct {
    Keyword external;
    Typed_Name typed_name;
    Token equals;
    Token string;
    Token end_of_line;
};
extern struct External_Named_Declaration__Struct External_Named_Declaration__Initial;/*D1*/
struct Global_Declaration__Struct {
    Keyword global;
    Typed_Name typed_name;
    Type type;
    Token end_of_line;
};
extern struct Global_Declaration__Struct Global_Declaration__Initial;/*D1*/
struct Include_String_Declaration__Struct {
    Keyword include;
    Token string;
    Token end_of_line;
};
extern struct Include_String_Declaration__Struct Include_String_Declaration__Initial;/*D1*/
struct Global_Library_Declaration__Struct {
    Keyword global_library;
    Token name;
    Token end_of_line;
};
extern struct Global_Library_Declaration__Struct Global_Library_Declaration__Initial;/*D1*/
struct Library_Declaration__Struct {
    Keyword library;
    Token name;
    Token end_of_line;
};
extern struct Library_Declaration__Struct Library_Declaration__Initial;/*D1*/
struct Interface_Declaration__Struct {
    Keyword interface;
    Token name;
    Token end_of_line;
};
extern struct Interface_Declaration__Struct Interface_Declaration__Initial;/*D1*/
struct Load_Declaration__Struct {
    Keyword load;
    Token string;
    Token end_of_line;
};
extern struct Load_Declaration__Struct Load_Declaration__Initial;/*D1*/
struct Collection_Declaration__Struct {
    Keyword collection;
    Token name;
    Token float_number;
    Token end_of_line;
};
extern struct Collection_Declaration__Struct Collection_Declaration__Initial;/*D1*/
struct Require_Declaration__Struct {
    Keyword require;
    Token name;
    Token end_of_line;
};
extern struct Require_Declaration__Struct Require_Declaration__Initial;/*D1*/
struct Constant_Declaration__Struct {
    Keyword constant;
    Typed_Name typed_name;
    Type type;
    Token equals;
    Expression expression;
    Token end_of_line;
};
extern struct Constant_Declaration__Struct Constant_Declaration__Initial;/*D1*/
struct Defines_Prefix_Declaration__Struct {
    Keyword defines_prefix;
    Token prefix;
    Token equals;
    Token match;
    Token at_sign;
    Token type_name;
    Token end_of_line;
};
extern struct Defines_Prefix_Declaration__Struct Defines_Prefix_Declaration__Initial;/*D1*/
struct Routine_Declaration__Struct {
    Keyword routine;
    Typed_Name typed_name;
    Token end_of_line;
    Token open_indent;
    Array routine_clauses;
    Token close_indent;
};
extern struct Routine_Declaration__Struct Routine_Declaration__Initial;/*D1*/
struct Routine_Clause__Struct {
    Routine_Clause_Kind kind;
    union {
	Token end_of_line;/*u*/
	Note note;/*u*/
	Takes_Nothing_Clause takes_nothing;/*u*/
	Take_Import_Clause take_import;/*u*/
	Take_Clause take;/*u*/
	Interrupt_Clause interrupt;/*u*/
	Returns_Nothing_Clause returns_nothing;/*u*/
	Returns_Clause returns;/*u*/
	External_Routine_Clause external;/*u*/
	C_Array_Access_Clause c_array_access;/*u*/
	Scalar_Cast_Clause scalar_cast;/*u*/
	Local_Clause local;/*u*/
	Assert_Statement assert;/*u*/
	Call_Statement call;/*u*/
	Do_Nothing_Statement do_nothing;/*u*/
	If_Statement if___k;/*u*/
	Return_Statement return___k;/*u*/
	Fail_Statement fail;/*u*/
	Set_Statement set;/*u*/
	Switch_Statement switch___k;/*u*/
	While_Statement while___k;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Routine_Clause__Struct Routine_Clause__Initial;/*D1*/
struct Takes_Nothing_Clause__Struct {
    Keyword takes_nothing;
    Token end_of_line;
};
extern struct Takes_Nothing_Clause__Struct Takes_Nothing_Clause__Initial;/*D1*/
struct Take_Clause__Struct {
    Keyword takes;
    Token name;
    Type type;
    Token end_of_line;
};
extern struct Take_Clause__Struct Take_Clause__Initial;/*D1*/
struct Take_Import_Clause__Struct {
    Keyword takes_import;
    Token name;
    Type type;
    Token equals;
    Token string;
    Token end_of_line;
};
extern struct Take_Import_Clause__Struct Take_Import_Clause__Initial;/*D1*/
struct Returns_Nothing_Clause__Struct {
    Keyword returns_nothing;
    Token end_of_line;
};
extern struct Returns_Nothing_Clause__Struct Returns_Nothing_Clause__Initial;/*D1*/
struct Returns_Clause__Struct {
    Keyword returns;
    Comma_Separated return_types;
    Token end_of_line;
};
extern struct Returns_Clause__Struct Returns_Clause__Initial;/*D1*/
struct External_Routine_Clause__Struct {
    Keyword external;
    Token name;
    Token end_of_line;
};
extern struct External_Routine_Clause__Struct External_Routine_Clause__Initial;/*D1*/
struct Scalar_Cast_Clause__Struct {
    Keyword scalar_cast;
    Type type;
    Token end_of_line;
};
extern struct Scalar_Cast_Clause__Struct Scalar_Cast_Clause__Initial;/*D1*/
struct Interrupt_Clause__Struct {
    Keyword interrupt;
    Token name;
    Token end_of_line;
};
extern struct Interrupt_Clause__Struct Interrupt_Clause__Initial;/*D1*/
struct C_Array_Access_Clause__Struct {
    Keyword c_array_access;
    Token end_of_line;
};
extern struct C_Array_Access_Clause__Struct C_Array_Access_Clause__Initial;/*D1*/
struct Local_Clause__Struct {
    Keyword local;
    Token name;
    Type type;
    Token end_of_line;
};
extern struct Local_Clause__Struct Local_Clause__Initial;/*D1*/
struct Statement__Struct {
    Statement_Kind kind;
    union {
	Token end_of_line;/*u*/
	Note note;/*u*/
	Assert_Statement assert;/*u*/
	Break_Level_Statement break_level;/*u*/
	Break_Empty_Statement break_empty;/*u*/
	Call_Statement call;/*u*/
	Continue_Level_Statement continue_level;/*u*/
	Continue_Empty_Statement continue_empty;/*u*/
	Do_Nothing_Statement do_nothing;/*u*/
	If_Statement if___k;/*u*/
	Return_Statement return___k;/*u*/
	Set_Statement set;/*u*/
	Switch_Statement switch___k;/*u*/
	While_Statement while___k;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Statement__Struct Statement__Initial;/*D1*/
struct Assert_Statement__Struct {
    Keyword assert;
    Expression expression;
    Token end_of_line;
};
extern struct Assert_Statement__Struct Assert_Statement__Initial;/*D1*/
struct Break_Empty_Statement__Struct {
    Keyword break___k;
    Token end_of_line;
};
extern struct Break_Empty_Statement__Struct Break_Empty_Statement__Initial;/*D1*/
struct Break_Level_Statement__Struct {
    Keyword break___k;
    Token number;
    Token end_of_line;
};
extern struct Break_Level_Statement__Struct Break_Level_Statement__Initial;/*D1*/
struct Call_Statement__Struct {
    Keyword call;
    Expression expression;
    Token end_of_line;
};
extern struct Call_Statement__Struct Call_Statement__Initial;/*D1*/
struct Continue_Empty_Statement__Struct {
    Keyword continue___k;
    Token end_of_line;
};
extern struct Continue_Empty_Statement__Struct Continue_Empty_Statement__Initial;/*D1*/
struct Continue_Level_Statement__Struct {
    Keyword continue___k;
    Token number;
    Token end_of_line;
};
extern struct Continue_Level_Statement__Struct Continue_Level_Statement__Initial;/*D1*/
struct Do_Nothing_Statement__Struct {
    Keyword do_nothing;
    Token end_of_line;
};
extern struct Do_Nothing_Statement__Struct Do_Nothing_Statement__Initial;/*D1*/
struct Fail_Statement__Struct {
    Keyword fail;
    Token string;
    Token end_of_line;
};
extern struct Fail_Statement__Struct Fail_Statement__Initial;/*D1*/
struct If_Statement__Struct {
    Array if_clauses;
};
extern struct If_Statement__Struct If_Statement__Initial;/*D1*/
struct If_Clause__Struct {
    If_Clause_Kind kind;
    union {
	If_Part if_part;/*u*/
	Else_If_Part else_if_part;/*u*/
	Else_Part else_part;/*u*/
    } kind__union;
};
extern struct If_Clause__Struct If_Clause__Initial;/*D1*/
struct If_Part__Struct {
    Keyword if___k;
    Expression expression;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
};
extern struct If_Part__Struct If_Part__Initial;/*D1*/
struct Else_If_Part__Struct {
    Keyword else_if;
    Expression expression;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
};
extern struct Else_If_Part__Struct Else_If_Part__Initial;/*D1*/
struct Else_Part__Struct {
    Keyword else___k;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
};
extern struct Else_Part__Struct Else_Part__Initial;/*D1*/
struct Return_Statement__Struct {
    Return_Clause_Kind kind;
    union {
	Return_Clause_Expression expression;/*u*/
	Return_Clause_Empty empty;/*u*/
    } kind__union;
};
extern struct Return_Statement__Struct Return_Statement__Initial;/*D1*/
struct Return_Clause_Expression__Struct {
    Keyword return___k;
    Expression expression;
    Token end_of_line;
};
extern struct Return_Clause_Expression__Struct Return_Clause_Expression__Initial;/*D1*/
struct Return_Clause_Empty__Struct {
    Keyword return___k;
    Token end_of_line;
};
extern struct Return_Clause_Empty__Struct Return_Clause_Empty__Initial;/*D1*/
struct Set_Statement__Struct {
    Token set;
    Expression expression;
    Token end_of_line;
};
extern struct Set_Statement__Struct Set_Statement__Initial;/*D1*/
struct Switch_Statement__Struct {
    Keyword switch___k;
    Expression expression;
    Token end_of_line;
    Token open_indent;
    Array switch_clauses;
    Token close_indent;
};
extern struct Switch_Statement__Struct Switch_Statement__Initial;/*D1*/
struct Switch_Clause__Struct {
    Switch_Clause_Kind kind;
    union {
	Token end_of_line;/*u*/
	Note note;/*u*/
	Switch_Case case___k;/*u*/
	Switch_Default default___k;/*u*/
	Switch_All_Cases_Required all_cases_required;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Switch_Clause__Struct Switch_Clause__Initial;/*D1*/
struct Switch_Case__Struct {
    Keyword case___k;
    Expression cases;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
};
extern struct Switch_Case__Struct Switch_Case__Initial;/*D1*/
struct Switch_Default__Struct {
    Keyword default___k;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
};
extern struct Switch_Default__Struct Switch_Default__Initial;/*D1*/
struct Switch_All_Cases_Required__Struct {
    Keyword all_cases_required;
    Token end_of_line;
};
extern struct Switch_All_Cases_Required__Struct Switch_All_Cases_Required__Initial;/*D1*/
struct Case_Name__Struct {
    Token name;
};
extern struct Case_Name__Struct Case_Name__Initial;/*D1*/
struct While_Statement__Struct {
    Keyword while___k;
    Expression expression;
    Token end_of_line;
    Token open_indent;
    Array statements;
    Token close_indent;
};
extern struct While_Statement__Struct While_Statement__Initial;/*D1*/
struct Expression__Struct {
    Expression_Kind kind;
    union {
	Binary_Expression binary;/*u*/
	Bracket_Expression bracket;/*u*/
	Token character;/*u*/
	Token float_number;/*u*/
	List_Expression list;/*u*/
	Token number;/*u*/
	Parenthesis_Expression parenthesis;/*u*/
	Token string;/*u*/
	Token symbol;/*u*/
	Unary_Expression unary;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Expression__Struct Expression__Initial;/*D1*/
struct Binary_Expression__Struct {
    Expression left;
    Token operator;
    Expression right;
};
extern struct Binary_Expression__Struct Binary_Expression__Initial;/*D1*/
struct Bracket_Expression__Struct {
    Expression expression1;
    Token open_bracket;
    Expression expression2;
    Token close_bracket;
};
extern struct Bracket_Expression__Struct Bracket_Expression__Initial;/*D1*/
struct List_Expression__Struct {
    Array operators;
    Array expressions;
    Token location;
};
extern struct List_Expression__Struct List_Expression__Initial;/*D1*/
struct Parenthesis_Expression__Struct {
    Token open_parenthesis;
    Expression expression;
    Token close_parenthesis;
};
extern struct Parenthesis_Expression__Struct Parenthesis_Expression__Initial;/*D1*/
struct Unary_Expression__Struct {
    Token operator;
    Expression expression;
};
extern struct Unary_Expression__Struct Unary_Expression__Initial;/*D1*/
struct Typed_Name__Struct {
    Token name;
    Token at_sign;
    Type type;
};
extern struct Typed_Name__Struct Typed_Name__Initial;/*D1*/
struct Type__Struct {
    Type_Kind kind;
    union {
	Parameterized_Type parameterized;/*u*/
	Token simple;/*u*/
	Routine_Type routine;/*u*/
    } kind__union;
    Logical replaced;
};
extern struct Type__Struct Type__Initial;/*D1*/
struct Parameterized_Type__Struct {
    Token name;
    Token open_bracket;
    Comma_Separated sub_types;
    Token close_bracket;
};
extern struct Parameterized_Type__Struct Parameterized_Type__Initial;/*D1*/
struct Routine_Type__Struct {
    Token open_bracket;
    Comma_Separated return_types;
    Token less_than_or_equal;
    Comma_Separated takes_types;
    Token close_bracket;
};
extern struct Routine_Type__Struct Routine_Type__Initial;/*D1*/
struct Note__Struct {
    Token comment;
    Token end_of_line;
};
extern struct Note__Struct Note__Initial;/*D1*/
struct Error__Struct {
    Array tokens;
};
extern struct Error__Struct Error__Initial;/*D1*/
struct Keyword__Struct {
    Token keyword;
};
extern struct Keyword__Struct Keyword__Initial;/*D1*/
struct Comma_Separated__Struct {
    Array commas;
    Array sub_types;
};
struct Parser__Struct {
    Hash_Table c_typedefs;
    Array expressions;
    Unsigned index;
    Messages messages;
    Array operators;
    String temporary;
    Token token_end;
    Token token_start;
    Array tokens;
};
extern struct Parser__Struct Parser__Initial;/*D1*/
struct Traverser__Struct {
    String buffer;
    Logical no_errors;
    Array tokens;
};
extern struct Traverser__Struct Traverser__Initial;/*D1*/

/* Declare the routine prototypes: */
extern Root Root__null;/*D10*/
extern Root Root__new(void);/*D11*/
extern void Root__erase(Root);/*D12*/
extern Declaration_Kind Declaration_Kind__easy_c;/*D9*/
extern Declaration_Kind Declaration_Kind__end_of_line;/*D9*/
extern Declaration_Kind Declaration_Kind__note;/*D9*/
extern Declaration_Kind Declaration_Kind__routine;/*D9*/
extern Declaration_Kind Declaration_Kind__define;/*D9*/
extern Declaration_Kind Declaration_Kind__defines_prefix;/*D9*/
extern Declaration_Kind Declaration_Kind__external_named;/*D9*/
extern Declaration_Kind Declaration_Kind__external;/*D9*/
extern Declaration_Kind Declaration_Kind__global;/*D9*/
extern Declaration_Kind Declaration_Kind__global_library;/*D9*/
extern Declaration_Kind Declaration_Kind__library;/*D9*/
extern Declaration_Kind Declaration_Kind__interface;/*D9*/
extern Declaration_Kind Declaration_Kind__load;/*D9*/
extern Declaration_Kind Declaration_Kind__include_string;/*D9*/
extern Declaration_Kind Declaration_Kind__constant;/*D9*/
extern Declaration_Kind Declaration_Kind__require;/*D9*/
extern Declaration_Kind Declaration_Kind__collection;/*D9*/
extern Declaration_Kind Declaration_Kind__error;/*D9*/
extern Declaration Declaration__null;/*D10*/
extern Declaration Declaration__new(void);/*D11*/
extern void Declaration__erase(Declaration);/*D12*/
extern Easy_C_Declaration Easy_C_Declaration__null;/*D10*/
extern Easy_C_Declaration Easy_C_Declaration__new(void);/*D11*/
extern void Easy_C_Declaration__erase(Easy_C_Declaration);/*D12*/
extern Define_Declaration Define_Declaration__null;/*D10*/
extern Define_Declaration Define_Declaration__new(void);/*D11*/
extern void Define_Declaration__erase(Define_Declaration);/*D12*/
extern Define_Clause_Kind Define_Clause_Kind__end_of_line;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__note;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__enumeration;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__enumeration_prefix;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__record;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__record_import;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__registers;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__variant;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__generate;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__simple;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__simple_numeric;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__external;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__base_type;/*D9*/
extern Define_Clause_Kind Define_Clause_Kind__error;/*D9*/
extern Define_Clause Define_Clause__null;/*D10*/
extern Define_Clause Define_Clause__new(void);/*D11*/
extern void Define_Clause__erase(Define_Clause);/*D12*/
extern Simple_Numeric_Clause Simple_Numeric_Clause__null;/*D10*/
extern Simple_Numeric_Clause Simple_Numeric_Clause__new(void);/*D11*/
extern void Simple_Numeric_Clause__erase(Simple_Numeric_Clause);/*D12*/
extern Base_Type_Clause Base_Type_Clause__null;/*D10*/
extern Base_Type_Clause Base_Type_Clause__new(void);/*D11*/
extern void Base_Type_Clause__erase(Base_Type_Clause);/*D12*/
extern Enumeration_Clause Enumeration_Clause__null;/*D10*/
extern Enumeration_Clause Enumeration_Clause__new(void);/*D11*/
extern void Enumeration_Clause__erase(Enumeration_Clause);/*D12*/
extern Enumeration_Prefix_Clause Enumeration_Prefix_Clause__null;/*D10*/
extern Enumeration_Prefix_Clause Enumeration_Prefix_Clause__new(void);/*D11*/
extern void Enumeration_Prefix_Clause__erase(Enumeration_Prefix_Clause);/*D12*/
extern Item_Clause_Kind Item_Clause_Kind__end_of_line;/*D9*/
extern Item_Clause_Kind Item_Clause_Kind__note;/*D9*/
extern Item_Clause_Kind Item_Clause_Kind__item;/*D9*/
extern Item_Clause_Kind Item_Clause_Kind__error;/*D9*/
extern Item_Clause Item_Clause__null;/*D10*/
extern Item_Clause Item_Clause__new(void);/*D11*/
extern void Item_Clause__erase(Item_Clause);/*D12*/
extern Item Item__null;/*D10*/
extern Item Item__new(void);/*D11*/
extern void Item__erase(Item);/*D12*/
extern Record_Clause Record_Clause__null;/*D10*/
extern Record_Clause Record_Clause__new(void);/*D11*/
extern void Record_Clause__erase(Record_Clause);/*D12*/
extern Record_Import_Clause Record_Import_Clause__null;/*D10*/
extern Record_Import_Clause Record_Import_Clause__new(void);/*D11*/
extern void Record_Import_Clause__erase(Record_Import_Clause);/*D12*/
extern Registers_Clause Registers_Clause__null;/*D10*/
extern Registers_Clause Registers_Clause__new(void);/*D11*/
extern void Registers_Clause__erase(Registers_Clause);/*D12*/
extern Register_Clause_Kind Register_Clause_Kind__end_of_line;/*D9*/
extern Register_Clause_Kind Register_Clause_Kind__note;/*D9*/
extern Register_Clause_Kind Register_Clause_Kind__bit;/*D9*/
extern Register_Clause_Kind Register_Clause_Kind__byte;/*D9*/
extern Register_Clause_Kind Register_Clause_Kind__error;/*D9*/
extern Register_Clause Register_Clause__null;/*D10*/
extern Register_Clause Register_Clause__new(void);/*D11*/
extern void Register_Clause__erase(Register_Clause);/*D12*/
extern Register_Bit Register_Bit__null;/*D10*/
extern Register_Bit Register_Bit__new(void);/*D11*/
extern void Register_Bit__erase(Register_Bit);/*D12*/
extern Register_Byte Register_Byte__null;/*D10*/
extern Register_Byte Register_Byte__new(void);/*D11*/
extern void Register_Byte__erase(Register_Byte);/*D12*/
extern Field_Clause_Kind Field_Clause_Kind__end_of_line;/*D9*/
extern Field_Clause_Kind Field_Clause_Kind__note;/*D9*/
extern Field_Clause_Kind Field_Clause_Kind__field;/*D9*/
extern Field_Clause_Kind Field_Clause_Kind__error;/*D9*/
extern Field_Clause Field_Clause__null;/*D10*/
extern Field_Clause Field_Clause__new(void);/*D11*/
extern void Field_Clause__erase(Field_Clause);/*D12*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__end_of_line;/*D9*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__note;/*D9*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__import_field;/*D9*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__error;/*D9*/
extern Import_Field_Clause Import_Field_Clause__null;/*D10*/
extern Import_Field_Clause Import_Field_Clause__new(void);/*D11*/
extern void Import_Field_Clause__erase(Import_Field_Clause);/*D12*/
extern Variant_Clause Variant_Clause__null;/*D10*/
extern Variant_Clause Variant_Clause__new(void);/*D11*/
extern void Variant_Clause__erase(Variant_Clause);/*D12*/
extern Field Field__null;/*D10*/
extern Field Field__new(void);/*D11*/
extern void Field__erase(Field);/*D12*/
extern Import_Field Import_Field__null;/*D10*/
extern Import_Field Import_Field__new(void);/*D11*/
extern void Import_Field__erase(Import_Field);/*D12*/
extern Simple_Clause Simple_Clause__null;/*D10*/
extern Simple_Clause Simple_Clause__new(void);/*D11*/
extern void Simple_Clause__erase(Simple_Clause);/*D12*/
extern Generate_Clause Generate_Clause__null;/*D10*/
extern Generate_Clause Generate_Clause__new(void);/*D11*/
extern void Generate_Clause__erase(Generate_Clause);/*D12*/
extern Generate_Name Generate_Name__null;/*D10*/
extern Generate_Name Generate_Name__new(void);/*D11*/
extern void Generate_Name__erase(Generate_Name);/*D12*/
extern External_Clause External_Clause__null;/*D10*/
extern External_Clause External_Clause__new(void);/*D11*/
extern void External_Clause__erase(External_Clause);/*D12*/
extern External_Declaration External_Declaration__null;/*D10*/
extern External_Declaration External_Declaration__new(void);/*D11*/
extern void External_Declaration__erase(External_Declaration);/*D12*/
extern External_Named_Declaration External_Named_Declaration__null;/*D10*/
extern External_Named_Declaration External_Named_Declaration__new(void);/*D11*/
extern void External_Named_Declaration__erase(External_Named_Declaration);/*D12*/
extern Global_Declaration Global_Declaration__null;/*D10*/
extern Global_Declaration Global_Declaration__new(void);/*D11*/
extern void Global_Declaration__erase(Global_Declaration);/*D12*/
extern Include_String_Declaration Include_String_Declaration__null;/*D10*/
extern Include_String_Declaration Include_String_Declaration__new(void);/*D11*/
extern void Include_String_Declaration__erase(Include_String_Declaration);/*D12*/
extern Global_Library_Declaration Global_Library_Declaration__null;/*D10*/
extern Global_Library_Declaration Global_Library_Declaration__new(void);/*D11*/
extern void Global_Library_Declaration__erase(Global_Library_Declaration);/*D12*/
extern Library_Declaration Library_Declaration__null;/*D10*/
extern Library_Declaration Library_Declaration__new(void);/*D11*/
extern void Library_Declaration__erase(Library_Declaration);/*D12*/
extern Interface_Declaration Interface_Declaration__null;/*D10*/
extern Interface_Declaration Interface_Declaration__new(void);/*D11*/
extern void Interface_Declaration__erase(Interface_Declaration);/*D12*/
extern Load_Declaration Load_Declaration__null;/*D10*/
extern Load_Declaration Load_Declaration__new(void);/*D11*/
extern void Load_Declaration__erase(Load_Declaration);/*D12*/
extern Collection_Declaration Collection_Declaration__null;/*D10*/
extern Collection_Declaration Collection_Declaration__new(void);/*D11*/
extern void Collection_Declaration__erase(Collection_Declaration);/*D12*/
extern Require_Declaration Require_Declaration__null;/*D10*/
extern Require_Declaration Require_Declaration__new(void);/*D11*/
extern void Require_Declaration__erase(Require_Declaration);/*D12*/
extern Constant_Declaration Constant_Declaration__null;/*D10*/
extern Constant_Declaration Constant_Declaration__new(void);/*D11*/
extern void Constant_Declaration__erase(Constant_Declaration);/*D12*/
extern Defines_Prefix_Declaration Defines_Prefix_Declaration__null;/*D10*/
extern Defines_Prefix_Declaration Defines_Prefix_Declaration__new(void);/*D11*/
extern void Defines_Prefix_Declaration__erase(Defines_Prefix_Declaration);/*D12*/
extern Routine_Declaration Routine_Declaration__null;/*D10*/
extern Routine_Declaration Routine_Declaration__new(void);/*D11*/
extern void Routine_Declaration__erase(Routine_Declaration);/*D12*/
extern Routine_Clause_Kind Routine_Clause_Kind__end_of_line;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__note;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__takes_nothing;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__take_import;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__take;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__interrupt;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__returns_nothing;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__returns;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__external;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__c_array_access;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__scalar_cast;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__local;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__assert;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__call;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__do_nothing;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__if;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__return;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__fail;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__set;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__switch;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__while;/*D9*/
extern Routine_Clause_Kind Routine_Clause_Kind__error;/*D9*/
extern Routine_Clause Routine_Clause__null;/*D10*/
extern Routine_Clause Routine_Clause__new(void);/*D11*/
extern void Routine_Clause__erase(Routine_Clause);/*D12*/
extern Takes_Nothing_Clause Takes_Nothing_Clause__null;/*D10*/
extern Takes_Nothing_Clause Takes_Nothing_Clause__new(void);/*D11*/
extern void Takes_Nothing_Clause__erase(Takes_Nothing_Clause);/*D12*/
extern Take_Clause Take_Clause__null;/*D10*/
extern Take_Clause Take_Clause__new(void);/*D11*/
extern void Take_Clause__erase(Take_Clause);/*D12*/
extern Take_Import_Clause Take_Import_Clause__null;/*D10*/
extern Take_Import_Clause Take_Import_Clause__new(void);/*D11*/
extern void Take_Import_Clause__erase(Take_Import_Clause);/*D12*/
extern Returns_Nothing_Clause Returns_Nothing_Clause__null;/*D10*/
extern Returns_Nothing_Clause Returns_Nothing_Clause__new(void);/*D11*/
extern void Returns_Nothing_Clause__erase(Returns_Nothing_Clause);/*D12*/
extern Returns_Clause Returns_Clause__null;/*D10*/
extern Returns_Clause Returns_Clause__new(void);/*D11*/
extern void Returns_Clause__erase(Returns_Clause);/*D12*/
extern External_Routine_Clause External_Routine_Clause__null;/*D10*/
extern External_Routine_Clause External_Routine_Clause__new(void);/*D11*/
extern void External_Routine_Clause__erase(External_Routine_Clause);/*D12*/
extern Scalar_Cast_Clause Scalar_Cast_Clause__null;/*D10*/
extern Scalar_Cast_Clause Scalar_Cast_Clause__new(void);/*D11*/
extern void Scalar_Cast_Clause__erase(Scalar_Cast_Clause);/*D12*/
extern Interrupt_Clause Interrupt_Clause__null;/*D10*/
extern Interrupt_Clause Interrupt_Clause__new(void);/*D11*/
extern void Interrupt_Clause__erase(Interrupt_Clause);/*D12*/
extern C_Array_Access_Clause C_Array_Access_Clause__null;/*D10*/
extern C_Array_Access_Clause C_Array_Access_Clause__new(void);/*D11*/
extern void C_Array_Access_Clause__erase(C_Array_Access_Clause);/*D12*/
extern Local_Clause Local_Clause__null;/*D10*/
extern Local_Clause Local_Clause__new(void);/*D11*/
extern void Local_Clause__erase(Local_Clause);/*D12*/
extern Statement_Kind Statement_Kind__end_of_line;/*D9*/
extern Statement_Kind Statement_Kind__note;/*D9*/
extern Statement_Kind Statement_Kind__assert;/*D9*/
extern Statement_Kind Statement_Kind__break_level;/*D9*/
extern Statement_Kind Statement_Kind__break_empty;/*D9*/
extern Statement_Kind Statement_Kind__call;/*D9*/
extern Statement_Kind Statement_Kind__continue_level;/*D9*/
extern Statement_Kind Statement_Kind__continue_empty;/*D9*/
extern Statement_Kind Statement_Kind__do_nothing;/*D9*/
extern Statement_Kind Statement_Kind__if;/*D9*/
extern Statement_Kind Statement_Kind__return;/*D9*/
extern Statement_Kind Statement_Kind__set;/*D9*/
extern Statement_Kind Statement_Kind__switch;/*D9*/
extern Statement_Kind Statement_Kind__while;/*D9*/
extern Statement_Kind Statement_Kind__error;/*D9*/
extern Statement Statement__null;/*D10*/
extern Statement Statement__new(void);/*D11*/
extern void Statement__erase(Statement);/*D12*/
extern Assert_Statement Assert_Statement__null;/*D10*/
extern Assert_Statement Assert_Statement__new(void);/*D11*/
extern void Assert_Statement__erase(Assert_Statement);/*D12*/
extern Break_Empty_Statement Break_Empty_Statement__null;/*D10*/
extern Break_Empty_Statement Break_Empty_Statement__new(void);/*D11*/
extern void Break_Empty_Statement__erase(Break_Empty_Statement);/*D12*/
extern Break_Level_Statement Break_Level_Statement__null;/*D10*/
extern Break_Level_Statement Break_Level_Statement__new(void);/*D11*/
extern void Break_Level_Statement__erase(Break_Level_Statement);/*D12*/
extern Call_Statement Call_Statement__null;/*D10*/
extern Call_Statement Call_Statement__new(void);/*D11*/
extern void Call_Statement__erase(Call_Statement);/*D12*/
extern Continue_Empty_Statement Continue_Empty_Statement__null;/*D10*/
extern Continue_Empty_Statement Continue_Empty_Statement__new(void);/*D11*/
extern void Continue_Empty_Statement__erase(Continue_Empty_Statement);/*D12*/
extern Continue_Level_Statement Continue_Level_Statement__null;/*D10*/
extern Continue_Level_Statement Continue_Level_Statement__new(void);/*D11*/
extern void Continue_Level_Statement__erase(Continue_Level_Statement);/*D12*/
extern Do_Nothing_Statement Do_Nothing_Statement__null;/*D10*/
extern Do_Nothing_Statement Do_Nothing_Statement__new(void);/*D11*/
extern void Do_Nothing_Statement__erase(Do_Nothing_Statement);/*D12*/
extern Fail_Statement Fail_Statement__null;/*D10*/
extern Fail_Statement Fail_Statement__new(void);/*D11*/
extern void Fail_Statement__erase(Fail_Statement);/*D12*/
extern If_Statement If_Statement__null;/*D10*/
extern If_Statement If_Statement__new(void);/*D11*/
extern void If_Statement__erase(If_Statement);/*D12*/
extern If_Clause_Kind If_Clause_Kind__if_part;/*D9*/
extern If_Clause_Kind If_Clause_Kind__else_if_part;/*D9*/
extern If_Clause_Kind If_Clause_Kind__else_part;/*D9*/
extern If_Clause If_Clause__null;/*D10*/
extern If_Clause If_Clause__new(void);/*D11*/
extern void If_Clause__erase(If_Clause);/*D12*/
extern If_Part If_Part__null;/*D10*/
extern If_Part If_Part__new(void);/*D11*/
extern void If_Part__erase(If_Part);/*D12*/
extern Else_If_Part Else_If_Part__null;/*D10*/
extern Else_If_Part Else_If_Part__new(void);/*D11*/
extern void Else_If_Part__erase(Else_If_Part);/*D12*/
extern Else_Part Else_Part__null;/*D10*/
extern Else_Part Else_Part__new(void);/*D11*/
extern void Else_Part__erase(Else_Part);/*D12*/
extern Return_Clause_Kind Return_Clause_Kind__expression;/*D9*/
extern Return_Clause_Kind Return_Clause_Kind__empty;/*D9*/
extern Return_Statement Return_Statement__null;/*D10*/
extern Return_Statement Return_Statement__new(void);/*D11*/
extern void Return_Statement__erase(Return_Statement);/*D12*/
extern Return_Clause_Expression Return_Clause_Expression__null;/*D10*/
extern Return_Clause_Expression Return_Clause_Expression__new(void);/*D11*/
extern void Return_Clause_Expression__erase(Return_Clause_Expression);/*D12*/
extern Return_Clause_Empty Return_Clause_Empty__null;/*D10*/
extern Return_Clause_Empty Return_Clause_Empty__new(void);/*D11*/
extern void Return_Clause_Empty__erase(Return_Clause_Empty);/*D12*/
extern Set_Statement Set_Statement__null;/*D10*/
extern Set_Statement Set_Statement__new(void);/*D11*/
extern void Set_Statement__erase(Set_Statement);/*D12*/
extern Switch_Statement Switch_Statement__null;/*D10*/
extern Switch_Statement Switch_Statement__new(void);/*D11*/
extern void Switch_Statement__erase(Switch_Statement);/*D12*/
extern Switch_Clause_Kind Switch_Clause_Kind__end_of_line;/*D9*/
extern Switch_Clause_Kind Switch_Clause_Kind__note;/*D9*/
extern Switch_Clause_Kind Switch_Clause_Kind__case;/*D9*/
extern Switch_Clause_Kind Switch_Clause_Kind__default;/*D9*/
extern Switch_Clause_Kind Switch_Clause_Kind__all_cases_required;/*D9*/
extern Switch_Clause_Kind Switch_Clause_Kind__error;/*D9*/
extern Switch_Clause Switch_Clause__null;/*D10*/
extern Switch_Clause Switch_Clause__new(void);/*D11*/
extern void Switch_Clause__erase(Switch_Clause);/*D12*/
extern Switch_Case Switch_Case__null;/*D10*/
extern Switch_Case Switch_Case__new(void);/*D11*/
extern void Switch_Case__erase(Switch_Case);/*D12*/
extern Switch_Default Switch_Default__null;/*D10*/
extern Switch_Default Switch_Default__new(void);/*D11*/
extern void Switch_Default__erase(Switch_Default);/*D12*/
extern Switch_All_Cases_Required Switch_All_Cases_Required__null;/*D10*/
extern Switch_All_Cases_Required Switch_All_Cases_Required__new(void);/*D11*/
extern void Switch_All_Cases_Required__erase(Switch_All_Cases_Required);/*D12*/
extern Case_Name Case_Name__null;/*D10*/
extern Case_Name Case_Name__new(void);/*D11*/
extern void Case_Name__erase(Case_Name);/*D12*/
extern While_Statement While_Statement__null;/*D10*/
extern While_Statement While_Statement__new(void);/*D11*/
extern void While_Statement__erase(While_Statement);/*D12*/
extern Expression_Kind Expression_Kind__binary;/*D9*/
extern Expression_Kind Expression_Kind__bracket;/*D9*/
extern Expression_Kind Expression_Kind__character;/*D9*/
extern Expression_Kind Expression_Kind__float_number;/*D9*/
extern Expression_Kind Expression_Kind__list;/*D9*/
extern Expression_Kind Expression_Kind__number;/*D9*/
extern Expression_Kind Expression_Kind__parenthesis;/*D9*/
extern Expression_Kind Expression_Kind__string;/*D9*/
extern Expression_Kind Expression_Kind__symbol;/*D9*/
extern Expression_Kind Expression_Kind__unary;/*D9*/
extern Expression_Kind Expression_Kind__error;/*D9*/
extern Expression Expression__null;/*D10*/
extern Expression Expression__new(void);/*D11*/
extern void Expression__erase(Expression);/*D12*/
extern Binary_Expression Binary_Expression__null;/*D10*/
extern Binary_Expression Binary_Expression__new(void);/*D11*/
extern void Binary_Expression__erase(Binary_Expression);/*D12*/
extern Bracket_Expression Bracket_Expression__null;/*D10*/
extern Bracket_Expression Bracket_Expression__new(void);/*D11*/
extern void Bracket_Expression__erase(Bracket_Expression);/*D12*/
extern List_Expression List_Expression__null;/*D10*/
extern List_Expression List_Expression__new(void);/*D11*/
extern void List_Expression__erase(List_Expression);/*D12*/
extern Parenthesis_Expression Parenthesis_Expression__null;/*D10*/
extern Parenthesis_Expression Parenthesis_Expression__new(void);/*D11*/
extern void Parenthesis_Expression__erase(Parenthesis_Expression);/*D12*/
extern Unary_Expression Unary_Expression__null;/*D10*/
extern Unary_Expression Unary_Expression__new(void);/*D11*/
extern void Unary_Expression__erase(Unary_Expression);/*D12*/
extern Typed_Name Typed_Name__null;/*D10*/
extern Typed_Name Typed_Name__new(void);/*D11*/
extern void Typed_Name__erase(Typed_Name);/*D12*/
extern Type_Kind Type_Kind__parameterized;/*D9*/
extern Type_Kind Type_Kind__simple;/*D9*/
extern Type_Kind Type_Kind__routine;/*D9*/
extern Type Type__null;/*D10*/
extern Type Type__new(void);/*D11*/
extern void Type__erase(Type);/*D12*/
extern Parameterized_Type Parameterized_Type__null;/*D10*/
extern Parameterized_Type Parameterized_Type__new(void);/*D11*/
extern void Parameterized_Type__erase(Parameterized_Type);/*D12*/
extern Routine_Type Routine_Type__null;/*D10*/
extern Routine_Type Routine_Type__new(void);/*D11*/
extern void Routine_Type__erase(Routine_Type);/*D12*/
extern Note Note__null;/*D10*/
extern Note Note__new(void);/*D11*/
extern void Note__erase(Note);/*D12*/
extern Error Error__null;/*D10*/
extern Error Error__new(void);/*D11*/
extern void Error__erase(Error);/*D12*/
extern Keyword Keyword__null;/*D10*/
extern Keyword Keyword__new(void);/*D11*/
extern void Keyword__erase(Keyword);/*D12*/
extern Comma_Separated Comma_Separated__null;/*D10*/
extern Comma_Separated Comma_Separated__new(void);/*D11*/
extern void Comma_Separated__erase(Comma_Separated);/*D12*/
extern Parser Parser__null;/*D10*/
extern Parser Parser__new(void);/*D11*/
extern void Parser__erase(Parser);/*D12*/
extern Traverser Traverser__null;/*D10*/
extern Traverser Traverser__new(void);/*D11*/
extern void Traverser__erase(Traverser);/*D12*/
extern Expression_State Expression_State__unary;/*D3*/
extern Expression_State Expression_State__leaf;/*D3*/
extern Expression_State Expression_State__binary;/*D3*/
extern Expression_State Expression_State__at_sign;/*D3*/
extern Expression_State Expression_State__at_leaf;/*D3*/
extern Expression_State Expression_State__null;/*D6*/
extern String Expression_State__string_convert(Expression_State);/*D7*/
extern void Expression_State__erase(Expression_State);/*D8*/
extern Array Array__parse(Parser, void * (*)(Parser), void *, Lexeme);
extern void Array__traverse(Array, Traverser, void (*)(void *, Traverser));
extern Integer Comma_Separated__compare(Comma_Separated, Comma_Separated, Integer (*)(void *, void *));
extern void Comma_Separated__copy_to(Comma_Separated, Comma_Separated, void * (*)(void *));
extern Logical Comma_Separated__equal(Comma_Separated, Comma_Separated, Logical (*)(void *, void *));
extern String Comma_Separated__f(Comma_Separated, String (*)(void *));
extern void * Comma_Separated__fetch1(Comma_Separated, Unsigned);
extern Unsigned Comma_Separated__hash(Comma_Separated, Unsigned (*)(void *));
extern Comma_Separated Comma_Separated__parse(Parser, void * (*)(Parser), void *, Lexeme);
extern Unsigned Comma_Separated__size_get(Comma_Separated);
extern void Comma_Separated__store1(Comma_Separated, Unsigned, void *);
extern void Comma_Separated__string_gap_insert(Comma_Separated, String, void (*)(void *, String));
extern void Comma_Separated__traverse(Comma_Separated, Traverser, void (*)(void *, Traverser));
extern Enumeration_Clause Define_Declaration__enumeration_get(Define_Declaration);
extern Enumeration_Prefix_Clause Define_Declaration__enumeration_prefix_get(Define_Declaration);
extern Array Enumeration_Clause__item_names(Enumeration_Clause);
extern Array Enumeration_Prefix_Clause__item_names(Enumeration_Prefix_Clause);
extern Error Error__parse(Parser);
extern void Error__traverse(Error, Traverser);
extern String Expression__f(Expression);
extern void Expression__format(Expression, String);
extern Expression Expression__leaf_create(Token);
extern Expression Expression__parse(Parser);
extern Unsigned Expression__prescan(Parser, Logical);
extern Expression Expression__shift_reduce(Parser, Unsigned, Logical);
extern void Parser__stacks_show(Parser, Unsigned);
extern Logical Expression__unary_reduce(Parser);
extern Logical Expression__bracket_reduce(Parser, Token, Unsigned);
extern Logical Expression__group_reduce(Parser, Token, Unsigned);
extern Logical Expression__binary_reduce(Parser);
extern Logical Expression__list_reduce(Parser);
extern Logical Expression__bracket_pop(Parser, Token, Logical);
extern Keyword Keyword__parse(Parser, String);
extern Unsigned Lexeme__f_precedence(Lexeme);
extern Unsigned Lexeme__g_precedence(Lexeme);
extern Lexeme Lexeme__invoke_transmute(Lexeme);
extern Lexeme Lexeme__type_transmute(Lexeme);
extern Lexeme Lexeme__unary_transmute(Lexeme);
extern void List_Expression__traverse(List_Expression, Traverser);
extern If_Statement If_Statement__parse(Parser);
extern Parameterized_Type Parameterized_Type__copy(Parameterized_Type);
extern void Parameterized_Type__copy_to(Parameterized_Type, Parameterized_Type);
extern Parser Parser__create(Array, Messages);
extern Root Parser__parse(Parser, Array);
extern void Parser__parse_append(Parser, Root, Array);
extern Root Parser__two_parse(Parser, Array, Array);
extern Token Routine_Clause__location_get(Routine_Clause);
extern Routine_Type Routine_Type__copy(Routine_Type);
extern void Routine_Type__copy_to(Routine_Type, Routine_Type);
extern String Routine_Type__f(Routine_Type);
extern void Routine_Type__format(Routine_Type, String);
extern Routine_Type Routine_Type__parse(Parser);
extern Token Token__parse(Parser, Lexeme);
extern void Token__traverse(Token, Traverser);
extern Traverser Traverser__create(String, Array);
extern String Type__base_name(Type);
extern String Type__c_base_name(Type);
extern void Type__buffer_append(Type, String);
extern String Type__replaced_c_type(Type, String);
extern String Type__c_type(Type, Type, String);
extern Integer Type__compare(Type, Type);
extern Type Type__copy(Type);
extern Logical Type__equal(Type, Type);
extern String Type__f(Type);
extern void Type__format(Type, String);
extern Unsigned Type__hash(Type);
extern Logical Type__is_parameterized(Type);
extern Logical Type__is_replaced(Type);
extern Logical Type__is_routine(Type);
extern Logical Type__is_scalar(Type);
extern Logical Type__is_float_scalar(Type);
extern Logical Type__is_number_scalar(Type);
extern Logical Type__is_logical(Type);
extern Logical Type__is_non_float_scalar(Type);
extern Logical Type__is_parameter(Type, Type);
extern Token Type__location_get(Type);
extern Type Type__replace(Type, Type, Type, Token, Unsigned);
extern Type Type__simple_create(String);
extern void Type__string_gap_insert(Type, String);
extern Logical Typed_Name__equal(Typed_Name, Typed_Name);
extern String Typed_Name__f(Typed_Name);
extern void Typed_Name__format(Typed_Name, String);
extern Unsigned Typed_Name__hash(Typed_Name);
extern void Typed_Name__show(Typed_Name, String);
extern Root Root__parse(Parser);
extern void Root__traverse(Root, Traverser);
extern Root Root__null;;/*D13*/
extern Root Root__new(void);
extern Declaration_Kind Declaration_Kind__easy_c;/*D3*/
extern Declaration_Kind Declaration_Kind__end_of_line;/*D3*/
extern Declaration_Kind Declaration_Kind__note;/*D3*/
extern Declaration_Kind Declaration_Kind__routine;/*D3*/
extern Declaration_Kind Declaration_Kind__define;/*D3*/
extern Declaration_Kind Declaration_Kind__defines_prefix;/*D3*/
extern Declaration_Kind Declaration_Kind__external_named;/*D3*/
extern Declaration_Kind Declaration_Kind__external;/*D3*/
extern Declaration_Kind Declaration_Kind__global;/*D3*/
extern Declaration_Kind Declaration_Kind__global_library;/*D3*/
extern Declaration_Kind Declaration_Kind__library;/*D3*/
extern Declaration_Kind Declaration_Kind__interface;/*D3*/
extern Declaration_Kind Declaration_Kind__load;/*D3*/
extern Declaration_Kind Declaration_Kind__include_string;/*D3*/
extern Declaration_Kind Declaration_Kind__constant;/*D3*/
extern Declaration_Kind Declaration_Kind__require;/*D3*/
extern Declaration_Kind Declaration_Kind__collection;/*D3*/
extern Declaration_Kind Declaration_Kind__error;/*D3*/
extern Declaration_Kind Declaration_Kind__null;/*D6*/
extern String Declaration_Kind__string_convert(Declaration_Kind);/*D7*/
extern void Declaration_Kind__erase(Declaration_Kind);/*D8*/
extern Declaration_Kind Declaration_Kind__easy_c;;/*D13*/
extern Declaration_Kind Declaration_Kind__end_of_line;;/*D13*/
extern Declaration_Kind Declaration_Kind__note;;/*D13*/
extern Declaration_Kind Declaration_Kind__routine;;/*D13*/
extern Declaration_Kind Declaration_Kind__define;;/*D13*/
extern Declaration_Kind Declaration_Kind__defines_prefix;;/*D13*/
extern Declaration_Kind Declaration_Kind__external_named;;/*D13*/
extern Declaration_Kind Declaration_Kind__external;;/*D13*/
extern Declaration_Kind Declaration_Kind__global;;/*D13*/
extern Declaration_Kind Declaration_Kind__global_library;;/*D13*/
extern Declaration_Kind Declaration_Kind__library;;/*D13*/
extern Declaration_Kind Declaration_Kind__interface;;/*D13*/
extern Declaration_Kind Declaration_Kind__load;;/*D13*/
extern Declaration_Kind Declaration_Kind__include_string;;/*D13*/
extern Declaration_Kind Declaration_Kind__constant;;/*D13*/
extern Declaration_Kind Declaration_Kind__require;;/*D13*/
extern Declaration_Kind Declaration_Kind__collection;;/*D13*/
extern Declaration_Kind Declaration_Kind__error;;/*D13*/
extern String Declaration_Kind__string_convert(Declaration_Kind);
extern Declaration Declaration__parse(Parser);
extern void Declaration__traverse(Declaration, Traverser);
extern Declaration Declaration__null;;/*D13*/
extern Declaration Declaration__new(void);
extern Easy_C_Declaration Easy_C_Declaration__parse(Parser);
extern void Easy_C_Declaration__traverse(Easy_C_Declaration, Traverser);
extern Easy_C_Declaration Easy_C_Declaration__null;;/*D13*/
extern Easy_C_Declaration Easy_C_Declaration__new(void);
extern Define_Declaration Define_Declaration__parse(Parser);
extern void Define_Declaration__traverse(Define_Declaration, Traverser);
extern Define_Declaration Define_Declaration__null;;/*D13*/
extern Define_Declaration Define_Declaration__new(void);
extern Define_Clause_Kind Define_Clause_Kind__end_of_line;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__note;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__enumeration;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__enumeration_prefix;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__record;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__record_import;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__registers;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__variant;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__generate;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__simple;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__simple_numeric;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__external;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__base_type;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__error;/*D3*/
extern Define_Clause_Kind Define_Clause_Kind__null;/*D6*/
extern String Define_Clause_Kind__string_convert(Define_Clause_Kind);/*D7*/
extern void Define_Clause_Kind__erase(Define_Clause_Kind);/*D8*/
extern Define_Clause_Kind Define_Clause_Kind__end_of_line;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__note;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__enumeration;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__enumeration_prefix;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__record;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__record_import;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__registers;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__variant;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__generate;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__simple;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__simple_numeric;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__external;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__base_type;;/*D13*/
extern Define_Clause_Kind Define_Clause_Kind__error;;/*D13*/
extern String Define_Clause_Kind__string_convert(Define_Clause_Kind);
extern Define_Clause Define_Clause__parse(Parser);
extern void Define_Clause__traverse(Define_Clause, Traverser);
extern Define_Clause Define_Clause__null;;/*D13*/
extern Define_Clause Define_Clause__new(void);
extern Simple_Numeric_Clause Simple_Numeric_Clause__parse(Parser);
extern void Simple_Numeric_Clause__traverse(Simple_Numeric_Clause, Traverser);
extern Simple_Numeric_Clause Simple_Numeric_Clause__null;;/*D13*/
extern Simple_Numeric_Clause Simple_Numeric_Clause__new(void);
extern Base_Type_Clause Base_Type_Clause__parse(Parser);
extern void Base_Type_Clause__traverse(Base_Type_Clause, Traverser);
extern Base_Type_Clause Base_Type_Clause__null;;/*D13*/
extern Base_Type_Clause Base_Type_Clause__new(void);
extern Enumeration_Clause Enumeration_Clause__parse(Parser);
extern void Enumeration_Clause__traverse(Enumeration_Clause, Traverser);
extern Enumeration_Clause Enumeration_Clause__null;;/*D13*/
extern Enumeration_Clause Enumeration_Clause__new(void);
extern Enumeration_Prefix_Clause Enumeration_Prefix_Clause__parse(Parser);
extern void Enumeration_Prefix_Clause__traverse(Enumeration_Prefix_Clause, Traverser);
extern Enumeration_Prefix_Clause Enumeration_Prefix_Clause__null;;/*D13*/
extern Enumeration_Prefix_Clause Enumeration_Prefix_Clause__new(void);
extern Item_Clause_Kind Item_Clause_Kind__end_of_line;/*D3*/
extern Item_Clause_Kind Item_Clause_Kind__note;/*D3*/
extern Item_Clause_Kind Item_Clause_Kind__item;/*D3*/
extern Item_Clause_Kind Item_Clause_Kind__error;/*D3*/
extern Item_Clause_Kind Item_Clause_Kind__null;/*D6*/
extern String Item_Clause_Kind__string_convert(Item_Clause_Kind);/*D7*/
extern void Item_Clause_Kind__erase(Item_Clause_Kind);/*D8*/
extern Item_Clause_Kind Item_Clause_Kind__end_of_line;;/*D13*/
extern Item_Clause_Kind Item_Clause_Kind__note;;/*D13*/
extern Item_Clause_Kind Item_Clause_Kind__item;;/*D13*/
extern Item_Clause_Kind Item_Clause_Kind__error;;/*D13*/
extern String Item_Clause_Kind__string_convert(Item_Clause_Kind);
extern Item_Clause Item_Clause__parse(Parser);
extern void Item_Clause__traverse(Item_Clause, Traverser);
extern Item_Clause Item_Clause__null;;/*D13*/
extern Item_Clause Item_Clause__new(void);
extern Item Item__parse(Parser);
extern void Item__traverse(Item, Traverser);
extern Item Item__null;;/*D13*/
extern Item Item__new(void);
extern Record_Clause Record_Clause__parse(Parser);
extern void Record_Clause__traverse(Record_Clause, Traverser);
extern Record_Clause Record_Clause__null;;/*D13*/
extern Record_Clause Record_Clause__new(void);
extern Record_Import_Clause Record_Import_Clause__parse(Parser);
extern void Record_Import_Clause__traverse(Record_Import_Clause, Traverser);
extern Record_Import_Clause Record_Import_Clause__null;;/*D13*/
extern Record_Import_Clause Record_Import_Clause__new(void);
extern Registers_Clause Registers_Clause__parse(Parser);
extern void Registers_Clause__traverse(Registers_Clause, Traverser);
extern Registers_Clause Registers_Clause__null;;/*D13*/
extern Registers_Clause Registers_Clause__new(void);
extern Register_Clause_Kind Register_Clause_Kind__end_of_line;/*D3*/
extern Register_Clause_Kind Register_Clause_Kind__note;/*D3*/
extern Register_Clause_Kind Register_Clause_Kind__bit;/*D3*/
extern Register_Clause_Kind Register_Clause_Kind__byte;/*D3*/
extern Register_Clause_Kind Register_Clause_Kind__error;/*D3*/
extern Register_Clause_Kind Register_Clause_Kind__null;/*D6*/
extern String Register_Clause_Kind__string_convert(Register_Clause_Kind);/*D7*/
extern void Register_Clause_Kind__erase(Register_Clause_Kind);/*D8*/
extern Register_Clause_Kind Register_Clause_Kind__end_of_line;;/*D13*/
extern Register_Clause_Kind Register_Clause_Kind__note;;/*D13*/
extern Register_Clause_Kind Register_Clause_Kind__bit;;/*D13*/
extern Register_Clause_Kind Register_Clause_Kind__byte;;/*D13*/
extern Register_Clause_Kind Register_Clause_Kind__error;;/*D13*/
extern String Register_Clause_Kind__string_convert(Register_Clause_Kind);
extern Register_Clause Register_Clause__parse(Parser);
extern void Register_Clause__traverse(Register_Clause, Traverser);
extern Register_Clause Register_Clause__null;;/*D13*/
extern Register_Clause Register_Clause__new(void);
extern Register_Bit Register_Bit__parse(Parser);
extern void Register_Bit__traverse(Register_Bit, Traverser);
extern Register_Bit Register_Bit__null;;/*D13*/
extern Register_Bit Register_Bit__new(void);
extern Register_Byte Register_Byte__parse(Parser);
extern void Register_Byte__traverse(Register_Byte, Traverser);
extern Register_Byte Register_Byte__null;;/*D13*/
extern Register_Byte Register_Byte__new(void);
extern Field_Clause_Kind Field_Clause_Kind__end_of_line;/*D3*/
extern Field_Clause_Kind Field_Clause_Kind__note;/*D3*/
extern Field_Clause_Kind Field_Clause_Kind__field;/*D3*/
extern Field_Clause_Kind Field_Clause_Kind__error;/*D3*/
extern Field_Clause_Kind Field_Clause_Kind__null;/*D6*/
extern String Field_Clause_Kind__string_convert(Field_Clause_Kind);/*D7*/
extern void Field_Clause_Kind__erase(Field_Clause_Kind);/*D8*/
extern Field_Clause_Kind Field_Clause_Kind__end_of_line;;/*D13*/
extern Field_Clause_Kind Field_Clause_Kind__note;;/*D13*/
extern Field_Clause_Kind Field_Clause_Kind__field;;/*D13*/
extern Field_Clause_Kind Field_Clause_Kind__error;;/*D13*/
extern String Field_Clause_Kind__string_convert(Field_Clause_Kind);
extern Field_Clause Field_Clause__parse(Parser);
extern void Field_Clause__traverse(Field_Clause, Traverser);
extern Field_Clause Field_Clause__null;;/*D13*/
extern Field_Clause Field_Clause__new(void);
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__end_of_line;/*D3*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__note;/*D3*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__import_field;/*D3*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__error;/*D3*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__null;/*D6*/
extern String Import_Field_Clause_Kind__string_convert(Import_Field_Clause_Kind);/*D7*/
extern void Import_Field_Clause_Kind__erase(Import_Field_Clause_Kind);/*D8*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__end_of_line;;/*D13*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__note;;/*D13*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__import_field;;/*D13*/
extern Import_Field_Clause_Kind Import_Field_Clause_Kind__error;;/*D13*/
extern String Import_Field_Clause_Kind__string_convert(Import_Field_Clause_Kind);
extern Import_Field_Clause Import_Field_Clause__parse(Parser);
extern void Import_Field_Clause__traverse(Import_Field_Clause, Traverser);
extern Import_Field_Clause Import_Field_Clause__null;;/*D13*/
extern Import_Field_Clause Import_Field_Clause__new(void);
extern Variant_Clause Variant_Clause__parse(Parser);
extern void Variant_Clause__traverse(Variant_Clause, Traverser);
extern Variant_Clause Variant_Clause__null;;/*D13*/
extern Variant_Clause Variant_Clause__new(void);
extern Field Field__parse(Parser);
extern void Field__traverse(Field, Traverser);
extern Field Field__null;;/*D13*/
extern Field Field__new(void);
extern Import_Field Import_Field__parse(Parser);
extern void Import_Field__traverse(Import_Field, Traverser);
extern Import_Field Import_Field__null;;/*D13*/
extern Import_Field Import_Field__new(void);
extern Simple_Clause Simple_Clause__parse(Parser);
extern void Simple_Clause__traverse(Simple_Clause, Traverser);
extern Simple_Clause Simple_Clause__null;;/*D13*/
extern Simple_Clause Simple_Clause__new(void);
extern Generate_Clause Generate_Clause__parse(Parser);
extern void Generate_Clause__traverse(Generate_Clause, Traverser);
extern Generate_Clause Generate_Clause__null;;/*D13*/
extern Generate_Clause Generate_Clause__new(void);
extern Generate_Name Generate_Name__parse(Parser);
extern void Generate_Name__traverse(Generate_Name, Traverser);
extern Generate_Name Generate_Name__null;;/*D13*/
extern Generate_Name Generate_Name__new(void);
extern External_Clause External_Clause__parse(Parser);
extern void External_Clause__traverse(External_Clause, Traverser);
extern External_Clause External_Clause__null;;/*D13*/
extern External_Clause External_Clause__new(void);
extern External_Declaration External_Declaration__parse(Parser);
extern void External_Declaration__traverse(External_Declaration, Traverser);
extern External_Declaration External_Declaration__null;;/*D13*/
extern External_Declaration External_Declaration__new(void);
extern External_Named_Declaration External_Named_Declaration__parse(Parser);
extern void External_Named_Declaration__traverse(External_Named_Declaration, Traverser);
extern External_Named_Declaration External_Named_Declaration__null;;/*D13*/
extern External_Named_Declaration External_Named_Declaration__new(void);
extern Global_Declaration Global_Declaration__parse(Parser);
extern void Global_Declaration__traverse(Global_Declaration, Traverser);
extern Global_Declaration Global_Declaration__null;;/*D13*/
extern Global_Declaration Global_Declaration__new(void);
extern Include_String_Declaration Include_String_Declaration__parse(Parser);
extern void Include_String_Declaration__traverse(Include_String_Declaration, Traverser);
extern Include_String_Declaration Include_String_Declaration__null;;/*D13*/
extern Include_String_Declaration Include_String_Declaration__new(void);
extern Global_Library_Declaration Global_Library_Declaration__parse(Parser);
extern void Global_Library_Declaration__traverse(Global_Library_Declaration, Traverser);
extern Global_Library_Declaration Global_Library_Declaration__null;;/*D13*/
extern Global_Library_Declaration Global_Library_Declaration__new(void);
extern Library_Declaration Library_Declaration__parse(Parser);
extern void Library_Declaration__traverse(Library_Declaration, Traverser);
extern Library_Declaration Library_Declaration__null;;/*D13*/
extern Library_Declaration Library_Declaration__new(void);
extern Interface_Declaration Interface_Declaration__parse(Parser);
extern void Interface_Declaration__traverse(Interface_Declaration, Traverser);
extern Interface_Declaration Interface_Declaration__null;;/*D13*/
extern Interface_Declaration Interface_Declaration__new(void);
extern Load_Declaration Load_Declaration__parse(Parser);
extern void Load_Declaration__traverse(Load_Declaration, Traverser);
extern Load_Declaration Load_Declaration__null;;/*D13*/
extern Load_Declaration Load_Declaration__new(void);
extern Collection_Declaration Collection_Declaration__parse(Parser);
extern void Collection_Declaration__traverse(Collection_Declaration, Traverser);
extern Collection_Declaration Collection_Declaration__null;;/*D13*/
extern Collection_Declaration Collection_Declaration__new(void);
extern Require_Declaration Require_Declaration__parse(Parser);
extern void Require_Declaration__traverse(Require_Declaration, Traverser);
extern Require_Declaration Require_Declaration__null;;/*D13*/
extern Require_Declaration Require_Declaration__new(void);
extern Constant_Declaration Constant_Declaration__parse(Parser);
extern void Constant_Declaration__traverse(Constant_Declaration, Traverser);
extern Constant_Declaration Constant_Declaration__null;;/*D13*/
extern Constant_Declaration Constant_Declaration__new(void);
extern Defines_Prefix_Declaration Defines_Prefix_Declaration__parse(Parser);
extern void Defines_Prefix_Declaration__traverse(Defines_Prefix_Declaration, Traverser);
extern Defines_Prefix_Declaration Defines_Prefix_Declaration__null;;/*D13*/
extern Defines_Prefix_Declaration Defines_Prefix_Declaration__new(void);
extern Routine_Declaration Routine_Declaration__parse(Parser);
extern void Routine_Declaration__traverse(Routine_Declaration, Traverser);
extern Routine_Declaration Routine_Declaration__null;;/*D13*/
extern Routine_Declaration Routine_Declaration__new(void);
extern Routine_Clause_Kind Routine_Clause_Kind__end_of_line;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__note;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__takes_nothing;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__take_import;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__take;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__interrupt;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__returns_nothing;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__returns;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__external;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__c_array_access;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__scalar_cast;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__local;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__assert;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__call;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__do_nothing;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__if;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__return;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__fail;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__set;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__switch;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__while;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__error;/*D3*/
extern Routine_Clause_Kind Routine_Clause_Kind__null;/*D6*/
extern String Routine_Clause_Kind__string_convert(Routine_Clause_Kind);/*D7*/
extern void Routine_Clause_Kind__erase(Routine_Clause_Kind);/*D8*/
extern Routine_Clause_Kind Routine_Clause_Kind__end_of_line;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__note;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__takes_nothing;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__take_import;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__take;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__interrupt;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__returns_nothing;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__returns;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__external;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__c_array_access;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__scalar_cast;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__local;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__assert;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__call;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__do_nothing;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__if;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__return;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__fail;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__set;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__switch;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__while;;/*D13*/
extern Routine_Clause_Kind Routine_Clause_Kind__error;;/*D13*/
extern String Routine_Clause_Kind__string_convert(Routine_Clause_Kind);
extern Routine_Clause Routine_Clause__parse(Parser);
extern void Routine_Clause__traverse(Routine_Clause, Traverser);
extern Routine_Clause Routine_Clause__null;;/*D13*/
extern Routine_Clause Routine_Clause__new(void);
extern Takes_Nothing_Clause Takes_Nothing_Clause__parse(Parser);
extern void Takes_Nothing_Clause__traverse(Takes_Nothing_Clause, Traverser);
extern Takes_Nothing_Clause Takes_Nothing_Clause__null;;/*D13*/
extern Takes_Nothing_Clause Takes_Nothing_Clause__new(void);
extern Take_Clause Take_Clause__parse(Parser);
extern void Take_Clause__traverse(Take_Clause, Traverser);
extern Take_Clause Take_Clause__null;;/*D13*/
extern Take_Clause Take_Clause__new(void);
extern Take_Import_Clause Take_Import_Clause__parse(Parser);
extern void Take_Import_Clause__traverse(Take_Import_Clause, Traverser);
extern Take_Import_Clause Take_Import_Clause__null;;/*D13*/
extern Take_Import_Clause Take_Import_Clause__new(void);
extern Returns_Nothing_Clause Returns_Nothing_Clause__parse(Parser);
extern void Returns_Nothing_Clause__traverse(Returns_Nothing_Clause, Traverser);
extern Returns_Nothing_Clause Returns_Nothing_Clause__null;;/*D13*/
extern Returns_Nothing_Clause Returns_Nothing_Clause__new(void);
extern Returns_Clause Returns_Clause__parse(Parser);
extern void Returns_Clause__traverse(Returns_Clause, Traverser);
extern Returns_Clause Returns_Clause__null;;/*D13*/
extern Returns_Clause Returns_Clause__new(void);
extern External_Routine_Clause External_Routine_Clause__parse(Parser);
extern void External_Routine_Clause__traverse(External_Routine_Clause, Traverser);
extern External_Routine_Clause External_Routine_Clause__null;;/*D13*/
extern External_Routine_Clause External_Routine_Clause__new(void);
extern Scalar_Cast_Clause Scalar_Cast_Clause__parse(Parser);
extern void Scalar_Cast_Clause__traverse(Scalar_Cast_Clause, Traverser);
extern Scalar_Cast_Clause Scalar_Cast_Clause__null;;/*D13*/
extern Scalar_Cast_Clause Scalar_Cast_Clause__new(void);
extern Interrupt_Clause Interrupt_Clause__parse(Parser);
extern void Interrupt_Clause__traverse(Interrupt_Clause, Traverser);
extern Interrupt_Clause Interrupt_Clause__null;;/*D13*/
extern Interrupt_Clause Interrupt_Clause__new(void);
extern C_Array_Access_Clause C_Array_Access_Clause__parse(Parser);
extern void C_Array_Access_Clause__traverse(C_Array_Access_Clause, Traverser);
extern C_Array_Access_Clause C_Array_Access_Clause__null;;/*D13*/
extern C_Array_Access_Clause C_Array_Access_Clause__new(void);
extern Local_Clause Local_Clause__parse(Parser);
extern void Local_Clause__traverse(Local_Clause, Traverser);
extern Local_Clause Local_Clause__null;;/*D13*/
extern Local_Clause Local_Clause__new(void);
extern Statement_Kind Statement_Kind__end_of_line;/*D3*/
extern Statement_Kind Statement_Kind__note;/*D3*/
extern Statement_Kind Statement_Kind__assert;/*D3*/
extern Statement_Kind Statement_Kind__break_level;/*D3*/
extern Statement_Kind Statement_Kind__break_empty;/*D3*/
extern Statement_Kind Statement_Kind__call;/*D3*/
extern Statement_Kind Statement_Kind__continue_level;/*D3*/
extern Statement_Kind Statement_Kind__continue_empty;/*D3*/
extern Statement_Kind Statement_Kind__do_nothing;/*D3*/
extern Statement_Kind Statement_Kind__if;/*D3*/
extern Statement_Kind Statement_Kind__return;/*D3*/
extern Statement_Kind Statement_Kind__set;/*D3*/
extern Statement_Kind Statement_Kind__switch;/*D3*/
extern Statement_Kind Statement_Kind__while;/*D3*/
extern Statement_Kind Statement_Kind__error;/*D3*/
extern Statement_Kind Statement_Kind__null;/*D6*/
extern String Statement_Kind__string_convert(Statement_Kind);/*D7*/
extern void Statement_Kind__erase(Statement_Kind);/*D8*/
extern Statement_Kind Statement_Kind__end_of_line;;/*D13*/
extern Statement_Kind Statement_Kind__note;;/*D13*/
extern Statement_Kind Statement_Kind__assert;;/*D13*/
extern Statement_Kind Statement_Kind__break_level;;/*D13*/
extern Statement_Kind Statement_Kind__break_empty;;/*D13*/
extern Statement_Kind Statement_Kind__call;;/*D13*/
extern Statement_Kind Statement_Kind__continue_level;;/*D13*/
extern Statement_Kind Statement_Kind__continue_empty;;/*D13*/
extern Statement_Kind Statement_Kind__do_nothing;;/*D13*/
extern Statement_Kind Statement_Kind__if;;/*D13*/
extern Statement_Kind Statement_Kind__return;;/*D13*/
extern Statement_Kind Statement_Kind__set;;/*D13*/
extern Statement_Kind Statement_Kind__switch;;/*D13*/
extern Statement_Kind Statement_Kind__while;;/*D13*/
extern Statement_Kind Statement_Kind__error;;/*D13*/
extern String Statement_Kind__string_convert(Statement_Kind);
extern Statement Statement__parse(Parser);
extern void Statement__traverse(Statement, Traverser);
extern Statement Statement__null;;/*D13*/
extern Statement Statement__new(void);
extern Assert_Statement Assert_Statement__parse(Parser);
extern void Assert_Statement__traverse(Assert_Statement, Traverser);
extern Assert_Statement Assert_Statement__null;;/*D13*/
extern Assert_Statement Assert_Statement__new(void);
extern Break_Empty_Statement Break_Empty_Statement__parse(Parser);
extern void Break_Empty_Statement__traverse(Break_Empty_Statement, Traverser);
extern Break_Empty_Statement Break_Empty_Statement__null;;/*D13*/
extern Break_Empty_Statement Break_Empty_Statement__new(void);
extern Break_Level_Statement Break_Level_Statement__parse(Parser);
extern void Break_Level_Statement__traverse(Break_Level_Statement, Traverser);
extern Break_Level_Statement Break_Level_Statement__null;;/*D13*/
extern Break_Level_Statement Break_Level_Statement__new(void);
extern Call_Statement Call_Statement__parse(Parser);
extern void Call_Statement__traverse(Call_Statement, Traverser);
extern Call_Statement Call_Statement__null;;/*D13*/
extern Call_Statement Call_Statement__new(void);
extern Continue_Empty_Statement Continue_Empty_Statement__parse(Parser);
extern void Continue_Empty_Statement__traverse(Continue_Empty_Statement, Traverser);
extern Continue_Empty_Statement Continue_Empty_Statement__null;;/*D13*/
extern Continue_Empty_Statement Continue_Empty_Statement__new(void);
extern Continue_Level_Statement Continue_Level_Statement__parse(Parser);
extern void Continue_Level_Statement__traverse(Continue_Level_Statement, Traverser);
extern Continue_Level_Statement Continue_Level_Statement__null;;/*D13*/
extern Continue_Level_Statement Continue_Level_Statement__new(void);
extern Do_Nothing_Statement Do_Nothing_Statement__parse(Parser);
extern void Do_Nothing_Statement__traverse(Do_Nothing_Statement, Traverser);
extern Do_Nothing_Statement Do_Nothing_Statement__null;;/*D13*/
extern Do_Nothing_Statement Do_Nothing_Statement__new(void);
extern Fail_Statement Fail_Statement__parse(Parser);
extern void Fail_Statement__traverse(Fail_Statement, Traverser);
extern Fail_Statement Fail_Statement__null;;/*D13*/
extern Fail_Statement Fail_Statement__new(void);
extern void If_Statement__traverse(If_Statement, Traverser);
extern If_Statement If_Statement__null;;/*D13*/
extern If_Statement If_Statement__new(void);
extern If_Clause_Kind If_Clause_Kind__if_part;/*D3*/
extern If_Clause_Kind If_Clause_Kind__else_if_part;/*D3*/
extern If_Clause_Kind If_Clause_Kind__else_part;/*D3*/
extern If_Clause_Kind If_Clause_Kind__null;/*D6*/
extern String If_Clause_Kind__string_convert(If_Clause_Kind);/*D7*/
extern void If_Clause_Kind__erase(If_Clause_Kind);/*D8*/
extern If_Clause_Kind If_Clause_Kind__if_part;;/*D13*/
extern If_Clause_Kind If_Clause_Kind__else_if_part;;/*D13*/
extern If_Clause_Kind If_Clause_Kind__else_part;;/*D13*/
extern String If_Clause_Kind__string_convert(If_Clause_Kind);
extern void If_Clause__traverse(If_Clause, Traverser);
extern If_Clause If_Clause__null;;/*D13*/
extern If_Clause If_Clause__new(void);
extern If_Part If_Part__parse(Parser);
extern void If_Part__traverse(If_Part, Traverser);
extern If_Part If_Part__null;;/*D13*/
extern If_Part If_Part__new(void);
extern Else_If_Part Else_If_Part__parse(Parser);
extern void Else_If_Part__traverse(Else_If_Part, Traverser);
extern Else_If_Part Else_If_Part__null;;/*D13*/
extern Else_If_Part Else_If_Part__new(void);
extern Else_Part Else_Part__parse(Parser);
extern void Else_Part__traverse(Else_Part, Traverser);
extern Else_Part Else_Part__null;;/*D13*/
extern Else_Part Else_Part__new(void);
extern Return_Clause_Kind Return_Clause_Kind__expression;/*D3*/
extern Return_Clause_Kind Return_Clause_Kind__empty;/*D3*/
extern Return_Clause_Kind Return_Clause_Kind__null;/*D6*/
extern String Return_Clause_Kind__string_convert(Return_Clause_Kind);/*D7*/
extern void Return_Clause_Kind__erase(Return_Clause_Kind);/*D8*/
extern Return_Clause_Kind Return_Clause_Kind__expression;;/*D13*/
extern Return_Clause_Kind Return_Clause_Kind__empty;;/*D13*/
extern String Return_Clause_Kind__string_convert(Return_Clause_Kind);
extern Return_Statement Return_Statement__parse(Parser);
extern void Return_Statement__traverse(Return_Statement, Traverser);
extern Return_Statement Return_Statement__null;;/*D13*/
extern Return_Statement Return_Statement__new(void);
extern Return_Clause_Expression Return_Clause_Expression__parse(Parser);
extern void Return_Clause_Expression__traverse(Return_Clause_Expression, Traverser);
extern Return_Clause_Expression Return_Clause_Expression__null;;/*D13*/
extern Return_Clause_Expression Return_Clause_Expression__new(void);
extern Return_Clause_Empty Return_Clause_Empty__parse(Parser);
extern void Return_Clause_Empty__traverse(Return_Clause_Empty, Traverser);
extern Return_Clause_Empty Return_Clause_Empty__null;;/*D13*/
extern Return_Clause_Empty Return_Clause_Empty__new(void);
extern Set_Statement Set_Statement__parse(Parser);
extern void Set_Statement__traverse(Set_Statement, Traverser);
extern Set_Statement Set_Statement__null;;/*D13*/
extern Set_Statement Set_Statement__new(void);
extern Switch_Statement Switch_Statement__parse(Parser);
extern void Switch_Statement__traverse(Switch_Statement, Traverser);
extern Switch_Statement Switch_Statement__null;;/*D13*/
extern Switch_Statement Switch_Statement__new(void);
extern Switch_Clause_Kind Switch_Clause_Kind__end_of_line;/*D3*/
extern Switch_Clause_Kind Switch_Clause_Kind__note;/*D3*/
extern Switch_Clause_Kind Switch_Clause_Kind__case;/*D3*/
extern Switch_Clause_Kind Switch_Clause_Kind__default;/*D3*/
extern Switch_Clause_Kind Switch_Clause_Kind__all_cases_required;/*D3*/
extern Switch_Clause_Kind Switch_Clause_Kind__error;/*D3*/
extern Switch_Clause_Kind Switch_Clause_Kind__null;/*D6*/
extern String Switch_Clause_Kind__string_convert(Switch_Clause_Kind);/*D7*/
extern void Switch_Clause_Kind__erase(Switch_Clause_Kind);/*D8*/
extern Switch_Clause_Kind Switch_Clause_Kind__end_of_line;;/*D13*/
extern Switch_Clause_Kind Switch_Clause_Kind__note;;/*D13*/
extern Switch_Clause_Kind Switch_Clause_Kind__case;;/*D13*/
extern Switch_Clause_Kind Switch_Clause_Kind__default;;/*D13*/
extern Switch_Clause_Kind Switch_Clause_Kind__all_cases_required;;/*D13*/
extern Switch_Clause_Kind Switch_Clause_Kind__error;;/*D13*/
extern String Switch_Clause_Kind__string_convert(Switch_Clause_Kind);
extern Switch_Clause Switch_Clause__parse(Parser);
extern void Switch_Clause__traverse(Switch_Clause, Traverser);
extern Switch_Clause Switch_Clause__null;;/*D13*/
extern Switch_Clause Switch_Clause__new(void);
extern Switch_Case Switch_Case__parse(Parser);
extern void Switch_Case__traverse(Switch_Case, Traverser);
extern Switch_Case Switch_Case__null;;/*D13*/
extern Switch_Case Switch_Case__new(void);
extern Switch_Default Switch_Default__parse(Parser);
extern void Switch_Default__traverse(Switch_Default, Traverser);
extern Switch_Default Switch_Default__null;;/*D13*/
extern Switch_Default Switch_Default__new(void);
extern Switch_All_Cases_Required Switch_All_Cases_Required__parse(Parser);
extern void Switch_All_Cases_Required__traverse(Switch_All_Cases_Required, Traverser);
extern Switch_All_Cases_Required Switch_All_Cases_Required__null;;/*D13*/
extern Switch_All_Cases_Required Switch_All_Cases_Required__new(void);
extern Case_Name Case_Name__parse(Parser);
extern void Case_Name__traverse(Case_Name, Traverser);
extern Case_Name Case_Name__null;;/*D13*/
extern Case_Name Case_Name__new(void);
extern While_Statement While_Statement__parse(Parser);
extern void While_Statement__traverse(While_Statement, Traverser);
extern While_Statement While_Statement__null;;/*D13*/
extern While_Statement While_Statement__new(void);
extern Expression_Kind Expression_Kind__binary;/*D3*/
extern Expression_Kind Expression_Kind__bracket;/*D3*/
extern Expression_Kind Expression_Kind__character;/*D3*/
extern Expression_Kind Expression_Kind__float_number;/*D3*/
extern Expression_Kind Expression_Kind__list;/*D3*/
extern Expression_Kind Expression_Kind__number;/*D3*/
extern Expression_Kind Expression_Kind__parenthesis;/*D3*/
extern Expression_Kind Expression_Kind__string;/*D3*/
extern Expression_Kind Expression_Kind__symbol;/*D3*/
extern Expression_Kind Expression_Kind__unary;/*D3*/
extern Expression_Kind Expression_Kind__error;/*D3*/
extern Expression_Kind Expression_Kind__null;/*D6*/
extern String Expression_Kind__string_convert(Expression_Kind);/*D7*/
extern void Expression_Kind__erase(Expression_Kind);/*D8*/
extern Expression_Kind Expression_Kind__binary;;/*D13*/
extern Expression_Kind Expression_Kind__bracket;;/*D13*/
extern Expression_Kind Expression_Kind__character;;/*D13*/
extern Expression_Kind Expression_Kind__float_number;;/*D13*/
extern Expression_Kind Expression_Kind__list;;/*D13*/
extern Expression_Kind Expression_Kind__number;;/*D13*/
extern Expression_Kind Expression_Kind__parenthesis;;/*D13*/
extern Expression_Kind Expression_Kind__string;;/*D13*/
extern Expression_Kind Expression_Kind__symbol;;/*D13*/
extern Expression_Kind Expression_Kind__unary;;/*D13*/
extern Expression_Kind Expression_Kind__error;;/*D13*/
extern String Expression_Kind__string_convert(Expression_Kind);
extern void Expression__traverse(Expression, Traverser);
extern Expression Expression__null;;/*D13*/
extern Expression Expression__new(void);
extern void Binary_Expression__traverse(Binary_Expression, Traverser);
extern Binary_Expression Binary_Expression__null;;/*D13*/
extern Binary_Expression Binary_Expression__new(void);
extern void Bracket_Expression__traverse(Bracket_Expression, Traverser);
extern Bracket_Expression Bracket_Expression__null;;/*D13*/
extern Bracket_Expression Bracket_Expression__new(void);
extern List_Expression List_Expression__null;;/*D13*/
extern List_Expression List_Expression__new(void);
extern void Parenthesis_Expression__traverse(Parenthesis_Expression, Traverser);
extern Parenthesis_Expression Parenthesis_Expression__null;;/*D13*/
extern Parenthesis_Expression Parenthesis_Expression__new(void);
extern void Unary_Expression__traverse(Unary_Expression, Traverser);
extern Unary_Expression Unary_Expression__null;;/*D13*/
extern Unary_Expression Unary_Expression__new(void);
extern Typed_Name Typed_Name__parse(Parser);
extern void Typed_Name__traverse(Typed_Name, Traverser);
extern Typed_Name Typed_Name__null;;/*D13*/
extern Typed_Name Typed_Name__new(void);
extern Type_Kind Type_Kind__parameterized;/*D3*/
extern Type_Kind Type_Kind__simple;/*D3*/
extern Type_Kind Type_Kind__routine;/*D3*/
extern Type_Kind Type_Kind__null;/*D6*/
extern String Type_Kind__string_convert(Type_Kind);/*D7*/
extern void Type_Kind__erase(Type_Kind);/*D8*/
extern Type_Kind Type_Kind__parameterized;;/*D13*/
extern Type_Kind Type_Kind__simple;;/*D13*/
extern Type_Kind Type_Kind__routine;;/*D13*/
extern String Type_Kind__string_convert(Type_Kind);
extern Type Type__parse(Parser);
extern void Type__traverse(Type, Traverser);
extern Type Type__null;;/*D13*/
extern Type Type__new(void);
extern Parameterized_Type Parameterized_Type__parse(Parser);
extern void Parameterized_Type__traverse(Parameterized_Type, Traverser);
extern Parameterized_Type Parameterized_Type__null;;/*D13*/
extern Parameterized_Type Parameterized_Type__new(void);
extern void Routine_Type__traverse(Routine_Type, Traverser);
extern Routine_Type Routine_Type__null;;/*D13*/
extern Routine_Type Routine_Type__new(void);
extern Note Note__parse(Parser);
extern void Note__traverse(Note, Traverser);
extern Note Note__null;;/*D13*/
extern Note Note__new(void);
extern Error Error__null;;/*D13*/
extern Error Error__new(void);
extern void Keyword__traverse(Keyword, Traverser);
extern Keyword Keyword__null;;/*D13*/
extern Keyword Keyword__new(void);
extern Comma_Separated Comma_Separated__null;;/*D13*/
extern Comma_Separated Comma_Separated__new(void);
extern Parser Parser__null;;/*D13*/
extern Parser Parser__new(void);
extern Traverser Traverser__null;;/*D13*/
extern Traverser Traverser__new(void);
extern Expression_State Expression_State__unary;;/*D13*/
extern Expression_State Expression_State__leaf;;/*D13*/
extern Expression_State Expression_State__binary;;/*D13*/
extern Expression_State Expression_State__at_sign;;/*D13*/
extern Expression_State Expression_State__at_leaf;;/*D13*/
extern String Expression_State__string_convert(Expression_State);
extern Expression_State Expression_State__null;;/*D13*/
extern Expression_State Expression_State__new(void);

/* Declare extracted #define values: */
extern Unsigned Unsigned__unix_errno_2big;
extern Unsigned Unsigned__unix_errno_acces;
extern Unsigned Unsigned__unix_errno_addrinuse;
extern Unsigned Unsigned__unix_errno_addrnotavail;
extern Unsigned Unsigned__unix_errno_adv;
extern Unsigned Unsigned__unix_errno_afnosupport;
extern Unsigned Unsigned__unix_errno_again;
extern Unsigned Unsigned__unix_errno_already;
extern Unsigned Unsigned__unix_errno_asy_c_included;
extern Unsigned Unsigned__unix_errno_bade;
extern Unsigned Unsigned__unix_errno_badf;
extern Unsigned Unsigned__unix_errno_badfd;
extern Unsigned Unsigned__unix_errno_badmsg;
extern Unsigned Unsigned__unix_errno_badr;
extern Unsigned Unsigned__unix_errno_badrqc;
extern Unsigned Unsigned__unix_errno_badslt;
extern Unsigned Unsigned__unix_errno_bfont;
extern Unsigned Unsigned__unix_errno_busy;
extern Unsigned Unsigned__unix_errno_canceled;
extern Unsigned Unsigned__unix_errno_child;
extern Unsigned Unsigned__unix_errno_chrng;
extern Unsigned Unsigned__unix_errno_comm;
extern Unsigned Unsigned__unix_errno_connaborted;
extern Unsigned Unsigned__unix_errno_connrefused;
extern Unsigned Unsigned__unix_errno_connreset;
extern Unsigned Unsigned__unix_errno_deadlk;
extern Unsigned Unsigned__unix_errno_destaddrreq;
extern Unsigned Unsigned__unix_errno_dom;
extern Unsigned Unsigned__unix_errno_dotdot;
extern Unsigned Unsigned__unix_errno_dquot;
extern Unsigned Unsigned__unix_errno_exist;
extern Unsigned Unsigned__unix_errno_fault;
extern Unsigned Unsigned__unix_errno_fbig;
extern Unsigned Unsigned__unix_errno_hostdown;
extern Unsigned Unsigned__unix_errno_hostunreach;
extern Unsigned Unsigned__unix_errno_hwpoison;
extern Unsigned Unsigned__unix_errno_idrm;
extern Unsigned Unsigned__unix_errno_ilseq;
extern Unsigned Unsigned__unix_errno_inprogress;
extern Unsigned Unsigned__unix_errno_intr;
extern Unsigned Unsigned__unix_errno_inval;
extern Unsigned Unsigned__unix_errno_io;
extern Unsigned Unsigned__unix_errno_isconn;
extern Unsigned Unsigned__unix_errno_isdir;
extern Unsigned Unsigned__unix_errno_isnam;
extern Unsigned Unsigned__unix_errno_keyexpired;
extern Unsigned Unsigned__unix_errno_keyrejected;
extern Unsigned Unsigned__unix_errno_keyrevoked;
extern Unsigned Unsigned__unix_errno_l2hlt;
extern Unsigned Unsigned__unix_errno_l2nsync;
extern Unsigned Unsigned__unix_errno_l3hlt;
extern Unsigned Unsigned__unix_errno_l3rst;
extern Unsigned Unsigned__unix_errno_libacc;
extern Unsigned Unsigned__unix_errno_libbad;
extern Unsigned Unsigned__unix_errno_libexec;
extern Unsigned Unsigned__unix_errno_libmax;
extern Unsigned Unsigned__unix_errno_libscn;
extern Unsigned Unsigned__unix_errno_lnrng;
extern Unsigned Unsigned__unix_errno_loop;
extern Unsigned Unsigned__unix_errno_mediumtype;
extern Unsigned Unsigned__unix_errno_mfile;
extern Unsigned Unsigned__unix_errno_mlink;
extern Unsigned Unsigned__unix_errno_msgsize;
extern Unsigned Unsigned__unix_errno_multihop;
extern Unsigned Unsigned__unix_errno_nametoolong;
extern Unsigned Unsigned__unix_errno_navail;
extern Unsigned Unsigned__unix_errno_netdown;
extern Unsigned Unsigned__unix_errno_netreset;
extern Unsigned Unsigned__unix_errno_netunreach;
extern Unsigned Unsigned__unix_errno_nfile;
extern Unsigned Unsigned__unix_errno_noano;
extern Unsigned Unsigned__unix_errno_nobufs;
extern Unsigned Unsigned__unix_errno_nocsi;
extern Unsigned Unsigned__unix_errno_nodata;
extern Unsigned Unsigned__unix_errno_nodev;
extern Unsigned Unsigned__unix_errno_noent;
extern Unsigned Unsigned__unix_errno_noexec;
extern Unsigned Unsigned__unix_errno_nokey;
extern Unsigned Unsigned__unix_errno_nolck;
extern Unsigned Unsigned__unix_errno_nolink;
extern Unsigned Unsigned__unix_errno_nomedium;
extern Unsigned Unsigned__unix_errno_nomem;
extern Unsigned Unsigned__unix_errno_nomsg;
extern Unsigned Unsigned__unix_errno_nonet;
extern Unsigned Unsigned__unix_errno_nopkg;
extern Unsigned Unsigned__unix_errno_noprotoopt;
extern Unsigned Unsigned__unix_errno_nospc;
extern Unsigned Unsigned__unix_errno_nosr;
extern Unsigned Unsigned__unix_errno_nostr;
extern Unsigned Unsigned__unix_errno_nosys;
extern Unsigned Unsigned__unix_errno_notblk;
extern Unsigned Unsigned__unix_errno_notconn;
extern Unsigned Unsigned__unix_errno_notdir;
extern Unsigned Unsigned__unix_errno_notempty;
extern Unsigned Unsigned__unix_errno_notnam;
extern Unsigned Unsigned__unix_errno_notrecoverable;
extern Unsigned Unsigned__unix_errno_notsock;
extern Unsigned Unsigned__unix_errno_notty;
extern Unsigned Unsigned__unix_errno_notuniq;
extern Unsigned Unsigned__unix_errno_nxio;
extern Unsigned Unsigned__unix_errno_opnotsupp;
extern Unsigned Unsigned__unix_errno_overflow;
extern Unsigned Unsigned__unix_errno_ownerdead;
extern Unsigned Unsigned__unix_errno_perm;
extern Unsigned Unsigned__unix_errno_pfnosupport;
extern Unsigned Unsigned__unix_errno_pipe;
extern Unsigned Unsigned__unix_errno_proto;
extern Unsigned Unsigned__unix_errno_protonosupport;
extern Unsigned Unsigned__unix_errno_prototype;
extern Unsigned Unsigned__unix_errno_range;
extern Unsigned Unsigned__unix_errno_remchg;
extern Unsigned Unsigned__unix_errno_remote;
extern Unsigned Unsigned__unix_errno_remoteio;
extern Unsigned Unsigned__unix_errno_restart;
extern Unsigned Unsigned__unix_errno_rfkill;
extern Unsigned Unsigned__unix_errno_rofs;
extern Unsigned Unsigned__unix_errno_shutdown;
extern Unsigned Unsigned__unix_errno_socktnosupport;
extern Unsigned Unsigned__unix_errno_spipe;
extern Unsigned Unsigned__unix_errno_srch;
extern Unsigned Unsigned__unix_errno_srmnt;
extern Unsigned Unsigned__unix_errno_stale;
extern Unsigned Unsigned__unix_errno_strpipe;
extern Unsigned Unsigned__unix_errno_time;
extern Unsigned Unsigned__unix_errno_timedout;
extern Unsigned Unsigned__unix_errno_toomanyrefs;
extern Unsigned Unsigned__unix_errno_txtbsy;
extern Unsigned Unsigned__unix_errno_uclean;
extern Unsigned Unsigned__unix_errno_unatch;
extern Unsigned Unsigned__unix_errno_users;
extern Unsigned Unsigned__unix_errno_xdev;
extern Unsigned Unsigned__unix_errno_xfull;
extern Unsigned Unsigned__unix_errno_xit_failure;
extern Unsigned Unsigned__unix_errno_xit_success;
extern Unsigned Unsigned__unix_errno_asyc_c_h_included;
extern Integer Integer__unix_file_f_dupfd;
extern Integer Integer__unix_file_f_dupfd_cloexec;
extern Integer Integer__unix_file_f_exlck;
extern Integer Integer__unix_file_f_getfd;
extern Integer Integer__unix_file_f_getfl;
extern Integer Integer__unix_file_f_getlk;
extern Integer Integer__unix_file_f_getlk64;
extern Integer Integer__unix_file_f_getown;
extern Integer Integer__unix_file_f_lock;
extern Integer Integer__unix_file_f_ok;
extern Integer Integer__unix_file_f_rdlck;
extern Integer Integer__unix_file_f_setfd;
extern Integer Integer__unix_file_f_setfl;
extern Integer Integer__unix_file_f_setlk;
extern Integer Integer__unix_file_f_setlk64;
extern Integer Integer__unix_file_f_setlkw;
extern Integer Integer__unix_file_f_setlkw64;
extern Integer Integer__unix_file_f_setown;
extern Integer Integer__unix_file_f_shlck;
extern Integer Integer__unix_file_f_test;
extern Integer Integer__unix_file_f_tlock;
extern Integer Integer__unix_file_f_ulock;
extern Integer Integer__unix_file_f_unlck;
extern Integer Integer__unix_file_f_wrlck;
extern Unsigned Unsigned__unix_file_o_accmode;
extern Unsigned Unsigned__unix_file_o_append;
extern Unsigned Unsigned__unix_file_o_async;
extern Unsigned Unsigned__unix_file_o_cloexec;
extern Unsigned Unsigned__unix_file_o_creat;
extern Unsigned Unsigned__unix_file_o_directory;
extern Unsigned Unsigned__unix_file_o_dsync;
extern Unsigned Unsigned__unix_file_o_excl;
extern Unsigned Unsigned__unix_file_o_noctty;
extern Unsigned Unsigned__unix_file_o_nofollow;
extern Unsigned Unsigned__unix_file_o_nonblock;
extern Unsigned Unsigned__unix_file_o_rdonly;
extern Unsigned Unsigned__unix_file_o_rdwr;
extern Unsigned Unsigned__unix_file_o_sync;
extern Unsigned Unsigned__unix_file_o_trunc;
extern Unsigned Unsigned__unix_file_o_wronly;
extern Integer Integer__unix_so_acceptconn;
extern Integer Integer__unix_so_attach_filter;
extern Integer Integer__unix_so_bindtodevice;
extern Integer Integer__unix_so_broadcast;
extern Integer Integer__unix_so_bsdcompat;
extern Integer Integer__unix_so_debug;
extern Integer Integer__unix_so_detach_filter;
extern Integer Integer__unix_so_domain;
extern Integer Integer__unix_so_dontroute;
extern Integer Integer__unix_so_error;
extern Integer Integer__unix_so_keepalive;
extern Integer Integer__unix_so_linger;
extern Integer Integer__unix_so_mark;
extern Integer Integer__unix_so_nofcs;
extern Integer Integer__unix_so_no_check;
extern Integer Integer__unix_so_oobinline;
extern Integer Integer__unix_so_passcred;
extern Integer Integer__unix_so_passsec;
extern Integer Integer__unix_so_peek_off;
extern Integer Integer__unix_so_peercred;
extern Integer Integer__unix_so_peername;
extern Integer Integer__unix_so_peersec;
extern Integer Integer__unix_so_priority;
extern Integer Integer__unix_so_protocol;
extern Integer Integer__unix_so_rcvbuf;
extern Integer Integer__unix_so_rcvbufforce;
extern Integer Integer__unix_so_rcvlowat;
extern Integer Integer__unix_so_rcvtimeo;
extern Integer Integer__unix_so_reuseaddr;
extern Integer Integer__unix_so_rxq_ovfl;
extern Integer Integer__unix_so_security_authentication;
extern Integer Integer__unix_so_security_encryption_network;
extern Integer Integer__unix_so_security_encryption_transport;
extern Integer Integer__unix_so_sndbuf;
extern Integer Integer__unix_so_sndbufforce;
extern Integer Integer__unix_so_sndlowat;
extern Integer Integer__unix_so_sndtimeo;
extern Integer Integer__unix_so_timestamp;
extern Integer Integer__unix_so_timestamping;
extern Integer Integer__unix_so_timestampns;
extern Integer Integer__unix_so_type;
extern Integer Integer__unix_so_wifi_status;
#endif /* PARSE_INCLUDED */
