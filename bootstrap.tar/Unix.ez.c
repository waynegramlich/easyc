#include "Unix.ez.h"/*cc2*/
/* # Copyright (c) 1998-2008 by Wayne C. Gramlich. */
/* # All rights reserved. */
#include "Easy_C.ez.h"/*D1*/
#include "fcntl.h"/*D3*/
#include "sys/select.h"/*D3*/
#include "sys/socket.h"/*D3*/
#include "Unix_C.h"/*D3*/
#include "errno.h"/*D3*/
/* #defines_prefix unix_so_ = SO_ @ Integer	# Grab the "SO_*" defines */
/* # {Unix_SHA1_Context} routines: */
/* #undef lower case macros */
#undef i386
#undef linux
#undef unix
#undef errno
#undef makedev
#undef major
#undef minor
#undef alloca

String Unix_SHA1_Context__f(
  Unix_SHA1_Context context)
{
    String value;
    Unsigned index;
    String t__0;
    value = Format__field_next();
    (void)String__trim(value, 0);
    index = 0;
    while ((index < 20)) {
        (void)String__string_append(value, (t__0 = String__form(((String)"\011%'0'f2ry%")), String__divide((t__0), Byte__f(Unix_SHA1_Context__fetch1(context, index)))));
        index = (index+1);
    }
    return value;
}

/* # {Unix_Status} stuff: */

/* # {Unix_Directory_Stream} stuff: */
/* # {Unix_File_Set} stuff: */
String Unix_File_Set__f(
  Unix_File_Set file_set)
{
    String value;
    String prefix;
    Unsigned size;
    Integer maximum;
    Unsigned index;
    String t__0;
    value = Format__field_next();
    (void)String__trim(value, 0);
    (void)String__character_append(value, ((Character)'{'));
    prefix = ((String)"\000");
    size = 0;
    maximum = Unix_File_Set__maximum_get(file_set);
    if ((maximum >= 0)) {
        size = ((Unsigned)(maximum));
    }
    index = 0;
    while ((index <= size)) {
        if (Unix_File_Set__is_set(file_set, ((Integer)(index)))) {
            (void)String__string_append(value, prefix);
            prefix = ((String)"\002, ");
            (void)String__string_append(value, (t__0 = String__form(((String)"\003%d%")), String__divide((t__0), Unsigned__f(index))));
        }
        index = (index+1);
    }
    (void)String__character_append(value, ((Character)'}'));
    return value;
}

/* # System calls: */
/* #procedure directory_create@Unix */
/* #    takes new_directory_name String */
/* #    takes new_directory_mode unsigned */
/* #    returns Integer */
/* #    external Unix__directory_create */
/* # */
/* #    # This procedure will create a directory named {new_directory_name} */
/* #    # with access mode bits of {new_directory_mode}.  A call to */
/* #    # {status_get}@{unix_system}() will indicate how successful the */
/* #    # operation is; the possible return values are {file_exists}, */
/* #    # {no_access}, {name_too_long}, {no_file}, {not_directory}, */
/* #    # {no_mememory}, and {read_only}. */
/* #    # */
/* #    # This procedure is equivalent to the mkdir(2) system call. */
/* # */
/* # */
/* #procedure duplicate@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	file_descriptor_number unsigned */
/* #    returns unsigned */
/* # */
/* #    # This procedure will duplicate the {file_descriptor_number} and */
/* #    # return the duplicate file descriptor number.  A call to */
/* #    # {status_get}@{unix_system}() will return one of {ok}, {not_open}, */
/* #    # and {none_available}. */
/* #    # */
/* #    # This procedure is equivalent to the dup(2) system call. */
/* # */
/* #    return file_control@(unix_system, file_descriptor_number, duplicate, 0) */
/* # */
/* # */
/* #procedure duplicate2@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	from_file_descriptor_number unsigned */
/* #	to_file_descriptor_number unsigned */
/* #    returns unsigned */
/* #    external unix_system__duplicate2 */
/* # */
/* #    # This procedure will duplicate the {from_file_descriptor_number} to */
/* #    # {to_file_descriptor_number}, closing {to_file_descriptor_number} if */
/* #    # necessary.  A call to {status_get}@{unix_system}() will return one */
/* #    # of {ok}, {not_open}, and {none_available}.  This call is permitted */
/* #    # modify file descriptors 0, 1, and 2. */
/* #    # */
/* #    # This procedure is equivalent to the dup2(2) system call. */
Array Unix__environment_all(void)
{
    String buffer;
    Array environment;
    Unsigned index;
    buffer = String__new();
    environment = Array__new();
    index = 0;
    while (1) {
        if (Unix__environment_fetch(index, buffer)) {
            break;
        }
        (void)Array__append(environment, ((void *)(String__read_only_copy(buffer))));
        index = (index+1);
    }
    return environment;
}

Logical Unix__executable_directory_lookup(
  String executable_name,
  String executable_directory)
{
    Logical result;
    Unsigned size;
    Unsigned index;
    String path;
    Character character;
    result = Logical__true;
    size = String__size_get(executable_name);
    index = 0;
    while ((index < size)) {
        if ((String__fetch1(executable_name, index) == ((Character)'/'))) {
            break;
        }
        index = (index+1);
    }
    if ((index < size)) {

        result = Unix__real_path(executable_name, executable_directory);
    } else {

        path = String__new();
        if (!(!Unix__environment_lookup(((String)"\004PATH"), path))) {
            System__assert_fail((String)"\10Unix.ezc", 514);
        }
        (void)String__trim(executable_directory, 0);
        size = String__size_get(path);
        index = 0;
        while ((index < size)) {
            character = String__fetch1(path, index);
            if ((character != ((Character)':'))) {
                (void)String__character_append(executable_directory, character);
            }
            /* #call d@(form@("dir=%v%\n\") / f@(executable_directory)) */
            if (((character == ((Character)':'))||((index+1) == size))) {
                (void)String__character_append(executable_directory, ((Character)'/'));
                (void)String__string_append(executable_directory, executable_name);
                /* #call d@(form@("test=%v%\n\") / f@(executable_directory)) */
                if (!Unix__real_path(executable_directory, executable_directory)) {
                    result = Logical__false;
                    break;
                }
                (void)String__trim(executable_directory, 0);
            }
            index = (index+1);
        }
    }
    if (!result) {
        while (Logical__true) {

            size = String__size_get(executable_directory);
            if ((size == 0)) {
                break;
            }
            character = String__fetch1(executable_directory, (size-1));
            (void)String__trim(executable_directory, (size-1));
            if ((character == ((Character)'/'))) {
                break;
            }
        }
    }
    return result;
}

/* #procedure kernel_system_name@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	system_name string */
/* #    returns_nothing */
/* #    external unix_system__kernel_system_name */
/* # */
/* #    # This procedure will store the kernel system name into the writable */
/* #    # string {system_name}. */
/* #    # */
/* #    # This procedure is equivalent to uname(2).sysname. */
/* # */
/* # */
/* #procedure kernel_node_name@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	node_name string */
/* #    returns_nothing */
/* #    external unix_system__kernel_node_name */
/* # */
/* #    # This procedure will store the kernel system name into the writable */
/* #    # string {node_name}. */
/* #    # */
/* #    # This procedure is equivalent to uname(2).nodename. */
/* # */
/* # */
/* #procedure kernel_domain_name@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	domain_name string */
/* #    returns_nothing */
/* # */
/* #    # This procedure will store the kernel system name into the writable */
/* #    # string {domain_name}. */
/* #    # */
/* #    # This procedure is equivalent to uname(2).domainname. */
/* # */
/* #    #FIXME: How is this done with the new glibc!!! */
/* #    assert false */
/* # */
/* # */
/* #procedure kill@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	process_number unsigned */
/* #	signal_number unsigned */
/* #    returns_nothing */
/* #    external unix_system__kill */
/* # */
/* #    # This procedure will send signal {signal_number} to process */
/* #    # {process_number}. */
/* #procedure pipe@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned, unsigned */
/* # */
/* #    # This procedure will invoke the unix pipe(2) system call and */
/* #    # return two file descriptors that correspond to either end of */
/* #    # the pipe.  The first file descriptor number is the read pipe */
/* #    # number and the second file descriptor number is the write pipe */
/* #    # number.  If any error occurs, 0xffffffff is returned for both */
/* #    # file descriptor numbers. */
/* # */
/* #    read_file_descriptor_number :@= 0xffffffff */
/* #    write_file_descriptor_number :@= 0xffffffff */
/* #    pipe_actual@(unix_system) */
/* #    if unix_system.status = ok */
/* #	read_file_descriptor_number :@= unix_system.pipe_read */
/* #	write_file_descriptor_number :@= unix_system.pipe_write */
/* #    return read_file_descriptor_number, write_file_descriptor_number */
/* # */
/* # */
/* #procedure pipe_actual@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns_nothing */
/* #    external unix_system__pipe_actual */
/* # */
/* #    # This procedure will perform the actual unix pipe(2) system call.  The */
/* #    # read file descriptor is obtained via {pipe_read_get}@{unix_system}() */
/* #    # procedure call.  The write file descriptor is obtained via */
/* #    # {pipe_write_get}@{unix_system}() procedure call. */
/* #    # */
/* #    # Note: This procedure should only be called from {pipe}@{unix_system}(). */
/* # */
/* # */
/* #procedure pipe_read_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__pipe_read_get */
/* # */
/* #    # This procedure will return the read file descriptor for the last */
/* #    # pipe created via a call to the {pipe_actual}@{unix_system}() */
/* #    # procedure. */
/* #    # */
/* #    # Note: This procedure should only be called from {pipe}@{unix_system}(). */
/* # */
/* # */
/* #procedure pipe_write_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__pipe_write_get */
/* # */
/* #    # This procedure will return the write file descriptor for the last */
/* #    # pipe created via a call to the {pipe_actual}@{unix_system}() */
/* #    # procedure. */
/* #    # */
/* #    # Note: This procedure should only be called from {pipe}@{unix_system}(). */
/* # */
/* # */
/* #procedure print@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	out_stream out_stream */
/* #    returns_nothing */
/* # */
/* #    # This procedure will print {unix_system} to {out_stream}. */
/* # */
/* #    put@("unix_system", out_stream) */
/* #procedure resource_user_time_seconds_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_user_time_seconds_get */
/* # */
/* #    # This procedure will return the number of user time seconds */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_user_time_microseconds_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_user_time_microseconds_get */
/* # */
/* #    # This procedure will return the number of user time microseconds */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_system_time_seconds_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_system_time_seconds_get */
/* # */
/* #    # This procedure will return the number of system time seconds */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_system_time_microseconds_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_system_time_microseconds_get */
/* # */
/* #    # This procedure will return the number of system time microseconds */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_maximum_resident_set_size_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_maximum_resident_size_get */
/* # */
/* #    # This procedure will return the maximum resident set size */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_maximum_shared_memory_size_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_maximum_shared_memory_size_get */
/* # */
/* #    # This procedure will return the maximum shared memory size */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_maximum_unshared_data_size_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_unshared_data_size_get */
/* # */
/* #    # This procedure will return the maximum unshared data size */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_maximum_unshared_stack_size_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_maximum_unshared_stack_size_get */
/* # */
/* #    # This procedure will return the maximum unshared stack size */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_minor_page_faults_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_minor_page_faults_get */
/* # */
/* #    # This procedure will return the number of minor page faults */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_major_page_faults_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_major_page_faults_get */
/* # */
/* #    # This procedure will return the number of major page faults */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_swaps_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_swaps_get */
/* # */
/* #    # This procedure will return the number of swaps */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_input_blocks_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_input_blocks_get */
/* # */
/* #    # This procedure will return the number of input blocks */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_output_blocks_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_output_blocks_get */
/* # */
/* #    # This procedure will return the number of output blocks */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_message_sends_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_message_sends_get */
/* # */
/* #    # This procedure will return the number of message send */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_message_receives_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_message_receives_get */
/* # */
/* #    # This procedure will return the number of message receives */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_signals_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_signals_get */
/* # */
/* #    # This procedure will return the number of signals */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_voluntary_context_switches_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_voluntary_context_switches_get */
/* # */
/* #    # This procedure will return the number of voluntary context switches */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure resource_involuntary_context_switches_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__resource_involuntary_context_switches_get */
/* # */
/* #    # This procedure will return the number of involuntary context switches */
/* #    # associated with {unix_system}.  This value is set via a call */
/* #    # to either {resources_obtain}@{unix_system}() or via a call */
/* #    # {wait}@{unix_system}(). */
/* # */
/* # */
/* #procedure seek@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	file_descriptor_number unsigned */
/* #	offset unsigned */
/* #    returns unsigned */
/* #    external unix_system__seek */
/* # */
/* #    # This procedure will cause the I/O pointer for {file_descriptor_number} */
/* #    # to be positioned to {offset}.  A call to {status_get}@{unix_system}() */
/* #    # return an indication of how successful the operation is.  The */
/* #    # possible return values are {ok}, {bad_file}, {illegal_seek}, or */
/* #    # {invalid}. */
/* #    # */
/* #    # This command is equivalent to the lseek(2) command. */
/* ##procedure status@unix_system */
/* ##    takes */
/* ##	file_descriptor_number unsigned */
/* ##	file_status file_status */
/* ##    returns_nothing */
/* ##    external unix_system__status */
/* ## */
/* ##    # This procedure will obtain the file information pertaining to */
/* ##    # {file_descriptor_number} and store the results into file_status. */
/* ##    # This is equivalent to the fstat(2) system call. */
/* #procedure truncate@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	file_descriptor_number unsigned */
/* #	length unsigned */
/* #    returns_nothing */
/* #    external unix_system__truncate */
/* # */
/* #    # This procedure will truncate the file refered to by */
/* #    # {file_descriptor_number} to no more than {length} bytes. */
/* #    # This is equivalent to the ftruncate(2) system call. */
/* #    # */
/* #    # Eventually, there needs to be a version of this call */
/* #    # that takes a 64-bit number. */
/* # */
/* # */
/* #procedure wait@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #	process_number unsigned */
/* #	no_hang logical */
/* #	stopped_too logical */
/* #    returns unsigned */
/* #    external unix_system__wait */
/* # */
/* #    # This procedure will perform a unix wait4(2) system call. */
/* #    # If {process_number} is 0, the procedure will wait until */
/* #    # any child process exits/stops; in which case the process */
/* #    # id of the child process that exited/stopped is returned. */
/* #    # If {process_number} is non-zero, the procedure will wait for */
/* #    # the specified child process to exit/stop.  If {no_hang} */
/* #    # is {true}, this procedure will not block waiting for the child */
/* #    # process exit/stop, instead it will return immediately with */
/* #    # a value of 0xffffffff if specified child process is not */
/* #    # exited/stopped.  If {stopped_too} is {true}, stopped processes */
/* #    # are reported in addition to exited processes; otherwise, only */
/* #    # exited processes are reported.  There are a number of */
/* #    # {wait_*_get}@{unix_system} procedures for figuring out whether */
/* #    # a process exited normally, via a signal, or is just stopped */
/* #    # (i.e. {stopped_too} is {true}.)  Finally, the resource usage */
/* #    # information for the exited/stopped process can be obatianed */
/* #    # via the {resource_*_get}@{unix_system} procedures. */
/* # */
/* # */
/* #procedure wait_exited_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns logical */
/* #    external unix_system__wait_exited_get */
/* # */
/* #    # This procedure will return {true}@{logical} if the last call */
/* #    # to {wait}@{unix_system}() resulted in a child process that */
/* #    # exited normally; otherwise, {false} is returned. */
/* # */
/* # */
/* #procedure wait_exit_status_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__exit_status_get */
/* # */
/* #    # This procedure will return the least significant 8 bits of */
/* #    # the return code for exiting process.  These 8 bits are only */
/* #    # valid if {wait_exited_get}@{unix_system} returned {true}. */
/* # */
/* # */
/* #procedure wait_signaled_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns logical */
/* #    external unix_system__signaled_get */
/* # */
/* #    # This procedure will return {true}@{logical} if the last call */
/* #    # to {wait}@{unix_system}() resulted in a child process that */
/* #    # exited because of a signal; otherwise {false} is returned. */
/* # */
/* # */
/* #procedure wait_signal_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__signaled_get */
/* # */
/* #    # This procedure will return the signal value that caused the */
/* #    # the last process to exit.  The signal value is only valid if */
/* #    # {wait_signaled_get}@{unix_system} returned {true}. */
/* # */
/* # */
/* #procedure wait_stopped_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns logical */
/* #    external unix_system__stopped_get */
/* # */
/* #    # This procedure will return {true}@{logical} if the last call */
/* #    # to {wait}@{unix_system}() resulted in a child process that */
/* #    # exited because of a signal; otherwise {false} is returned. */
/* # */
/* # */
/* #procedure wait_stop_get@unix_system */
/* #    takes */
/* #	unix_system unix_system */
/* #    returns unsigned */
/* #    external unix_system__stopget */
/* # */
/* #    # This procedure will return the signal value that caused the */
/* #    # the last process to stop.  The signal value is only valid if */
/* #    # {wait_stopped_get}@{unix_system} returned {true}. */
/* ## Here are some trivial {open_flags} routines: */
/* # */
/* #procedure set1@open_flags */
/* #    takes */
/* #	open_flags1 open_flags */
/* #    returns unsigned */
/* # */
/* #    # This procedure will return a mask with {open_flags1} set. */
/* # */
/* #    return 1<<unsigned_convert@(open_flags1) */
/* # */
/* # */
/* #procedure set2@open_flags */
/* #    takes */
/* #	open_flags1 open_flags */
/* #	open_flags2 open_flags */
/* #    returns unsigned */
/* # */
/* #    # This procedure will return a mask with {open_flags1} and {open_flags2} */
/* #    # set. */
/* # */
/* #    return set1@(open_flags1) | set1@(open_flags2) */
/* # */
/* # */
/* #procedure set3@open_flags */
/* #    takes */
/* #	open_flags1 open_flags */
/* #	open_flags2 open_flags */
/* #	open_flags3 open_flags */
/* #    returns unsigned */
/* # */
/* #    # This procedure will return a mask with {open_flags1}, {open_flags2}, */
/* #    # and {open_flags3} set. */
/* # */
/* #    return set2@(open_flags1, open_flags2) | set1@(open_flags3) */
/* # */
/* #     */
/* #procedure set4@open_flags */
/* #    takes */
/* #	open_flags1 open_flags */
/* #	open_flags2 open_flags */
/* #	open_flags3 open_flags */
/* #	open_flags4 open_flags */
/* #    returns unsigned */
/* # */
/* #    # This procedure will return a mask with {open_flags1}, {open_flags2}, */
/* #    # {open_flags3}, and {open_flags4} set. */
/* # */
/* #    return set2@(open_flags1, open_flags2) | set2@(open_flags3, open_flags4) */
/* # */
/* #     */
/* # */
/* #define open_flags		# Bit positions of open(2) flags */
/* #    enumeration */
/* #	write_only		# O_CREAT = 1<<0 */
/* #	read_write		# O_RDWR = 1<<1 */
/* #	unused1			# 1<<2 */
/* #	unused2			# 1<<3 */
/* #	unused3			# 1<<4 */
/* #	unused4			# 1<<5 */
/* #	create			# O_CREAT = 1<<6 */
/* #	exclusive		# O_EXCL = 1<<7 */
/* #	no_control_tty		# O_NOCTTY = 1<<8 */
/* #	truncate		# O_TRUNC = 1<<9 */
/* #	append			# O_APPEND = 1<<10 */
/* #	no_block		# O_NONBLOCK = O_NDELAY = 1<<11 */
/* #	synchronous		# O_SYNC = 1<<12 */
/* # */
/* #define file_control_operation	# File control (fcntl(2)) operation flags */
/* #    enumeration */
/* #	duplicate		# F_DUPFD(0) = Duplicate file descriptor */
/* #	get_close_on_execute	# F_GETFD(1) = Get close on execute flag */
/* #	set_close_on_execute	# F_SETFD(2) = Get close on execute flag */
/* #	get_flags		# F_GETFL(3) = Get file descriptor flags */
/* #	set_flags		# F_SETFL(4) = Set file_descriptor flags */
/* #	get_lock		# F_GETLK(5) = Get file descretionary lock */
/* #	set_lock		# F_GETLK(6) = Set file descretionary lock */
/* #	set_lock_wait		# F_GETLKW(7) = Set file descr. lock, wait */
/* #	get_owner		# F_GETOWN(8) = Get owner (for sockets) */
/* #	set_owner		# F_SETOWN(9) = Set owner (for sockets) */
/* # */
/* #define socket_options		# Socket options for setsockopt(2) */
/* #    enumeration */
/* #	unused1			# Unused 1 */
/* #	debug			# SO_DEBUG(1) - Enable debugging */
/* #	reuse_address		# SO_REUSEADDR(2) - Enable local address reuse */
/* #	type			# SO_TYPE(3) - Get Socket type */
/* #	error			# SO_ERROR(4) - Get and clear socket error */
/* #	do_not_route		# SO_DONTROUTE(5) - Bypass output msg. routing */
/* #	broadcast		# SO_BROADCAST(6) - Enable broadcast messages */
/* #	send_buffer		# SO_SNDBUF(7) - Set send buffer size */
/* #	receive_buffer		# SO_RCVBUF(8) - Set receive buffer size */
/* #	keep_alive		# SO_KEEPALIVE(9) - Keep connection alive */
/* #	out_of_band		# SO_OOBINLINE(10) - Enable out of band data */
/* #	no_check		# SO_NO_CHECK(11) - ?? */
/* #	priority		# SO_PRIORITY(12) - ?? */
/* #	linger			# SO_LINGER(13) - Linger on close */
/* #	bsd_compatible		# SO_BSDCOMPAT(14) - ?? */
/* # */

/* #define values: */
Unsigned Unsigned__unix_errno_2big = E2BIG;	/* =7 */
Unsigned Unsigned__unix_errno_acces = EACCES;	/* =13 */
Unsigned Unsigned__unix_errno_addrinuse = EADDRINUSE;	/* =98 */
Unsigned Unsigned__unix_errno_addrnotavail = EADDRNOTAVAIL;	/* =99 */
Unsigned Unsigned__unix_errno_adv = EADV;	/* =68 */
Unsigned Unsigned__unix_errno_afnosupport = EAFNOSUPPORT;	/* =97 */
Unsigned Unsigned__unix_errno_again = EAGAIN;	/* =11 */
Unsigned Unsigned__unix_errno_already = EALREADY;	/* =114 */
Unsigned Unsigned__unix_errno_asy_c_included = EASY_C_INCLUDED;	/* =1 */
Unsigned Unsigned__unix_errno_bade = EBADE;	/* =52 */
Unsigned Unsigned__unix_errno_badf = EBADF;	/* =9 */
Unsigned Unsigned__unix_errno_badfd = EBADFD;	/* =77 */
Unsigned Unsigned__unix_errno_badmsg = EBADMSG;	/* =74 */
Unsigned Unsigned__unix_errno_badr = EBADR;	/* =53 */
Unsigned Unsigned__unix_errno_badrqc = EBADRQC;	/* =56 */
Unsigned Unsigned__unix_errno_badslt = EBADSLT;	/* =57 */
Unsigned Unsigned__unix_errno_bfont = EBFONT;	/* =59 */
Unsigned Unsigned__unix_errno_busy = EBUSY;	/* =16 */
Unsigned Unsigned__unix_errno_canceled = ECANCELED;	/* =125 */
Unsigned Unsigned__unix_errno_child = ECHILD;	/* =10 */
Unsigned Unsigned__unix_errno_chrng = ECHRNG;	/* =44 */
Unsigned Unsigned__unix_errno_comm = ECOMM;	/* =70 */
Unsigned Unsigned__unix_errno_connaborted = ECONNABORTED;	/* =103 */
Unsigned Unsigned__unix_errno_connrefused = ECONNREFUSED;	/* =111 */
Unsigned Unsigned__unix_errno_connreset = ECONNRESET;	/* =104 */
Unsigned Unsigned__unix_errno_deadlk = EDEADLK;	/* =35 */
Unsigned Unsigned__unix_errno_destaddrreq = EDESTADDRREQ;	/* =89 */
Unsigned Unsigned__unix_errno_dom = EDOM;	/* =33 */
Unsigned Unsigned__unix_errno_dotdot = EDOTDOT;	/* =73 */
Unsigned Unsigned__unix_errno_dquot = EDQUOT;	/* =122 */
Unsigned Unsigned__unix_errno_exist = EEXIST;	/* =17 */
Unsigned Unsigned__unix_errno_fault = EFAULT;	/* =14 */
Unsigned Unsigned__unix_errno_fbig = EFBIG;	/* =27 */
Unsigned Unsigned__unix_errno_hostdown = EHOSTDOWN;	/* =112 */
Unsigned Unsigned__unix_errno_hostunreach = EHOSTUNREACH;	/* =113 */
Unsigned Unsigned__unix_errno_hwpoison = EHWPOISON;	/* =133 */
Unsigned Unsigned__unix_errno_idrm = EIDRM;	/* =43 */
Unsigned Unsigned__unix_errno_ilseq = EILSEQ;	/* =84 */
Unsigned Unsigned__unix_errno_inprogress = EINPROGRESS;	/* =115 */
Unsigned Unsigned__unix_errno_intr = EINTR;	/* =4 */
Unsigned Unsigned__unix_errno_inval = EINVAL;	/* =22 */
Unsigned Unsigned__unix_errno_io = EIO;	/* =5 */
Unsigned Unsigned__unix_errno_isconn = EISCONN;	/* =106 */
Unsigned Unsigned__unix_errno_isdir = EISDIR;	/* =21 */
Unsigned Unsigned__unix_errno_isnam = EISNAM;	/* =120 */
Unsigned Unsigned__unix_errno_keyexpired = EKEYEXPIRED;	/* =127 */
Unsigned Unsigned__unix_errno_keyrejected = EKEYREJECTED;	/* =129 */
Unsigned Unsigned__unix_errno_keyrevoked = EKEYREVOKED;	/* =128 */
Unsigned Unsigned__unix_errno_l2hlt = EL2HLT;	/* =51 */
Unsigned Unsigned__unix_errno_l2nsync = EL2NSYNC;	/* =45 */
Unsigned Unsigned__unix_errno_l3hlt = EL3HLT;	/* =46 */
Unsigned Unsigned__unix_errno_l3rst = EL3RST;	/* =47 */
Unsigned Unsigned__unix_errno_libacc = ELIBACC;	/* =79 */
Unsigned Unsigned__unix_errno_libbad = ELIBBAD;	/* =80 */
Unsigned Unsigned__unix_errno_libexec = ELIBEXEC;	/* =83 */
Unsigned Unsigned__unix_errno_libmax = ELIBMAX;	/* =82 */
Unsigned Unsigned__unix_errno_libscn = ELIBSCN;	/* =81 */
Unsigned Unsigned__unix_errno_lnrng = ELNRNG;	/* =48 */
Unsigned Unsigned__unix_errno_loop = ELOOP;	/* =40 */
Unsigned Unsigned__unix_errno_mediumtype = EMEDIUMTYPE;	/* =124 */
Unsigned Unsigned__unix_errno_mfile = EMFILE;	/* =24 */
Unsigned Unsigned__unix_errno_mlink = EMLINK;	/* =31 */
Unsigned Unsigned__unix_errno_msgsize = EMSGSIZE;	/* =90 */
Unsigned Unsigned__unix_errno_multihop = EMULTIHOP;	/* =72 */
Unsigned Unsigned__unix_errno_nametoolong = ENAMETOOLONG;	/* =36 */
Unsigned Unsigned__unix_errno_navail = ENAVAIL;	/* =119 */
Unsigned Unsigned__unix_errno_netdown = ENETDOWN;	/* =100 */
Unsigned Unsigned__unix_errno_netreset = ENETRESET;	/* =102 */
Unsigned Unsigned__unix_errno_netunreach = ENETUNREACH;	/* =101 */
Unsigned Unsigned__unix_errno_nfile = ENFILE;	/* =23 */
Unsigned Unsigned__unix_errno_noano = ENOANO;	/* =55 */
Unsigned Unsigned__unix_errno_nobufs = ENOBUFS;	/* =105 */
Unsigned Unsigned__unix_errno_nocsi = ENOCSI;	/* =50 */
Unsigned Unsigned__unix_errno_nodata = ENODATA;	/* =61 */
Unsigned Unsigned__unix_errno_nodev = ENODEV;	/* =19 */
Unsigned Unsigned__unix_errno_noent = ENOENT;	/* =2 */
Unsigned Unsigned__unix_errno_noexec = ENOEXEC;	/* =8 */
Unsigned Unsigned__unix_errno_nokey = ENOKEY;	/* =126 */
Unsigned Unsigned__unix_errno_nolck = ENOLCK;	/* =37 */
Unsigned Unsigned__unix_errno_nolink = ENOLINK;	/* =67 */
Unsigned Unsigned__unix_errno_nomedium = ENOMEDIUM;	/* =123 */
Unsigned Unsigned__unix_errno_nomem = ENOMEM;	/* =12 */
Unsigned Unsigned__unix_errno_nomsg = ENOMSG;	/* =42 */
Unsigned Unsigned__unix_errno_nonet = ENONET;	/* =64 */
Unsigned Unsigned__unix_errno_nopkg = ENOPKG;	/* =65 */
Unsigned Unsigned__unix_errno_noprotoopt = ENOPROTOOPT;	/* =92 */
Unsigned Unsigned__unix_errno_nospc = ENOSPC;	/* =28 */
Unsigned Unsigned__unix_errno_nosr = ENOSR;	/* =63 */
Unsigned Unsigned__unix_errno_nostr = ENOSTR;	/* =60 */
Unsigned Unsigned__unix_errno_nosys = ENOSYS;	/* =38 */
Unsigned Unsigned__unix_errno_notblk = ENOTBLK;	/* =15 */
Unsigned Unsigned__unix_errno_notconn = ENOTCONN;	/* =107 */
Unsigned Unsigned__unix_errno_notdir = ENOTDIR;	/* =20 */
Unsigned Unsigned__unix_errno_notempty = ENOTEMPTY;	/* =39 */
Unsigned Unsigned__unix_errno_notnam = ENOTNAM;	/* =118 */
Unsigned Unsigned__unix_errno_notrecoverable = ENOTRECOVERABLE;	/* =131 */
Unsigned Unsigned__unix_errno_notsock = ENOTSOCK;	/* =88 */
Unsigned Unsigned__unix_errno_notty = ENOTTY;	/* =25 */
Unsigned Unsigned__unix_errno_notuniq = ENOTUNIQ;	/* =76 */
Unsigned Unsigned__unix_errno_nxio = ENXIO;	/* =6 */
Unsigned Unsigned__unix_errno_opnotsupp = EOPNOTSUPP;	/* =95 */
Unsigned Unsigned__unix_errno_overflow = EOVERFLOW;	/* =75 */
Unsigned Unsigned__unix_errno_ownerdead = EOWNERDEAD;	/* =130 */
Unsigned Unsigned__unix_errno_perm = EPERM;	/* =1 */
Unsigned Unsigned__unix_errno_pfnosupport = EPFNOSUPPORT;	/* =96 */
Unsigned Unsigned__unix_errno_pipe = EPIPE;	/* =32 */
Unsigned Unsigned__unix_errno_proto = EPROTO;	/* =71 */
Unsigned Unsigned__unix_errno_protonosupport = EPROTONOSUPPORT;	/* =93 */
Unsigned Unsigned__unix_errno_prototype = EPROTOTYPE;	/* =91 */
Unsigned Unsigned__unix_errno_range = ERANGE;	/* =34 */
Unsigned Unsigned__unix_errno_remchg = EREMCHG;	/* =78 */
Unsigned Unsigned__unix_errno_remote = EREMOTE;	/* =66 */
Unsigned Unsigned__unix_errno_remoteio = EREMOTEIO;	/* =121 */
Unsigned Unsigned__unix_errno_restart = ERESTART;	/* =85 */
Unsigned Unsigned__unix_errno_rfkill = ERFKILL;	/* =132 */
Unsigned Unsigned__unix_errno_rofs = EROFS;	/* =30 */
Unsigned Unsigned__unix_errno_shutdown = ESHUTDOWN;	/* =108 */
Unsigned Unsigned__unix_errno_socktnosupport = ESOCKTNOSUPPORT;	/* =94 */
Unsigned Unsigned__unix_errno_spipe = ESPIPE;	/* =29 */
Unsigned Unsigned__unix_errno_srch = ESRCH;	/* =3 */
Unsigned Unsigned__unix_errno_srmnt = ESRMNT;	/* =69 */
Unsigned Unsigned__unix_errno_stale = ESTALE;	/* =116 */
Unsigned Unsigned__unix_errno_strpipe = ESTRPIPE;	/* =86 */
Unsigned Unsigned__unix_errno_time = ETIME;	/* =62 */
Unsigned Unsigned__unix_errno_timedout = ETIMEDOUT;	/* =110 */
Unsigned Unsigned__unix_errno_toomanyrefs = ETOOMANYREFS;	/* =109 */
Unsigned Unsigned__unix_errno_txtbsy = ETXTBSY;	/* =26 */
Unsigned Unsigned__unix_errno_uclean = EUCLEAN;	/* =117 */
Unsigned Unsigned__unix_errno_unatch = EUNATCH;	/* =49 */
Unsigned Unsigned__unix_errno_users = EUSERS;	/* =87 */
Unsigned Unsigned__unix_errno_xdev = EXDEV;	/* =18 */
Unsigned Unsigned__unix_errno_xfull = EXFULL;	/* =54 */
Unsigned Unsigned__unix_errno_xit_failure = EXIT_FAILURE;	/* =1 */
Unsigned Unsigned__unix_errno_xit_success = EXIT_SUCCESS;	/* =0 */
Unsigned Unsigned__unix_errno_asyc_c_h_included = EasyC_C_H_INCLUDED;	/* =1 */
Integer Integer__unix_file_f_dupfd = F_DUPFD;	/* =0 */
Integer Integer__unix_file_f_dupfd_cloexec = F_DUPFD_CLOEXEC;	/* =1030 */
Integer Integer__unix_file_f_exlck = F_EXLCK;	/* =4 */
Integer Integer__unix_file_f_getfd = F_GETFD;	/* =1 */
Integer Integer__unix_file_f_getfl = F_GETFL;	/* =3 */
Integer Integer__unix_file_f_getlk = F_GETLK;	/* =5 */
Integer Integer__unix_file_f_getlk64 = F_GETLK64;	/* =12 */
Integer Integer__unix_file_f_getown = F_GETOWN;	/* =9 */
Integer Integer__unix_file_f_lock = F_LOCK;	/* =1 */
Integer Integer__unix_file_f_ok = F_OK;	/* =0 */
Integer Integer__unix_file_f_rdlck = F_RDLCK;	/* =0 */
Integer Integer__unix_file_f_setfd = F_SETFD;	/* =2 */
Integer Integer__unix_file_f_setfl = F_SETFL;	/* =4 */
Integer Integer__unix_file_f_setlk = F_SETLK;	/* =6 */
Integer Integer__unix_file_f_setlk64 = F_SETLK64;	/* =13 */
Integer Integer__unix_file_f_setlkw = F_SETLKW;	/* =7 */
Integer Integer__unix_file_f_setlkw64 = F_SETLKW64;	/* =14 */
Integer Integer__unix_file_f_setown = F_SETOWN;	/* =8 */
Integer Integer__unix_file_f_shlck = F_SHLCK;	/* =8 */
Integer Integer__unix_file_f_test = F_TEST;	/* =3 */
Integer Integer__unix_file_f_tlock = F_TLOCK;	/* =2 */
Integer Integer__unix_file_f_ulock = F_ULOCK;	/* =0 */
Integer Integer__unix_file_f_unlck = F_UNLCK;	/* =2 */
Integer Integer__unix_file_f_wrlck = F_WRLCK;	/* =1 */
Unsigned Unsigned__unix_file_o_accmode = O_ACCMODE;	/* =0003 */
Unsigned Unsigned__unix_file_o_append = O_APPEND;	/* =02000 */
Unsigned Unsigned__unix_file_o_async = O_ASYNC;	/* =020000 */
Unsigned Unsigned__unix_file_o_cloexec = O_CLOEXEC;	/* =02000000 */
Unsigned Unsigned__unix_file_o_creat = O_CREAT;	/* =0100 */
Unsigned Unsigned__unix_file_o_directory = O_DIRECTORY;	/* =0200000 */
Unsigned Unsigned__unix_file_o_dsync = O_DSYNC;	/* =010000 */
Unsigned Unsigned__unix_file_o_excl = O_EXCL;	/* =0200 */
Unsigned Unsigned__unix_file_o_noctty = O_NOCTTY;	/* =0400 */
Unsigned Unsigned__unix_file_o_nofollow = O_NOFOLLOW;	/* =0400000 */
Unsigned Unsigned__unix_file_o_nonblock = O_NONBLOCK;	/* =04000 */
Unsigned Unsigned__unix_file_o_rdonly = O_RDONLY;	/* =00 */
Unsigned Unsigned__unix_file_o_rdwr = O_RDWR;	/* =02 */
Unsigned Unsigned__unix_file_o_sync = O_SYNC;	/* =04010000 */
Unsigned Unsigned__unix_file_o_trunc = O_TRUNC;	/* =01000 */
Unsigned Unsigned__unix_file_o_wronly = O_WRONLY;	/* =01 */

/* {Unix_Directory_Stream} stuff: */

/* {Unix_File_Set} stuff: */

/* {Unix_SHA1_Context} stuff: */

/* {Unix_Status} stuff: */


