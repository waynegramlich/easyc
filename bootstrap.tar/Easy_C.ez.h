#ifndef EASY_C_INCLUDED
#define EASY_C_INCLUDED 1

/* Declare all enum's and typedef's first: */
/* h_emit1 */
typedef struct Format__Struct *Format;
typedef struct Format_Frame__Struct *Format_Frame;
typedef struct Format_Field__Struct *Format_Field;
typedef struct Hash_Table_Pair__Struct *Hash_Table_Pair;
typedef struct Hash_Table_Row__Struct *Hash_Table_Row;
typedef struct Hash_Table__Struct *Hash_Table;
typedef struct System__Struct *System;
/* h_emit2 */
/* h_emit3 */

/* Include other libraries exactly once: */
#ifndef EASY_C_C_H_INCLUDED
#include "Easy_C_C.h"/*D4*/
#endif /* EASY_C_C_H_INCLUDED */

/* Define the structures: */
struct Format__Struct {
    Logical initialized;
    Array available_fields;
    Array available_frames;
    Array frames;
    Unsigned frame_count;
    Unsigned field_count;
};
extern struct Format__Struct Format__Initial;/*D1*/
struct Format_Frame__Struct {
    Array fields;
    Unsigned index;
    String result;
};
extern struct Format_Frame__Struct Format_Frame__Initial;/*D1*/
struct Format_Field__Struct {
    String before;
    String control;
    String value;
};
extern struct Format_Field__Struct Format_Field__Initial;/*D1*/
struct Hash_Table_Pair__Struct {
    void *key;
    void *value;
    Unsigned hash;
};
struct Hash_Table_Row__Struct {
    Unsigned index;
    Unsigned mask;
    Array pairs;
};
struct Hash_Table__Struct {
    String buffer;
    Logical (*key_equal)(void *, void *);
    Unsigned (*key_hash)(void *);
    void (*key_show)(void *, String);
    Unsigned mask;
    Hash_Table_Pair null_pair;
    Unsigned power;
    Array rows;
    Unsigned size;
    Unsigned trace_level;
    void *value_empty;
    void (*value_show)(void *, String);
};
struct System__Struct {
    Out_Stream error_out_stream;
    Out_Stream standard_out_stream;
    In_Stream standard_in_stream;
    void (*fail_routine)(String, String, Unsigned);
    Logical fail_routine_present;
};
extern struct System__Struct System__Initial;/*D1*/

/* Declare the routine prototypes: */
extern void Array__append(Array, void *);
extern void Array__array_append(Array, Array);
extern Array Array__copy_shallow(Array);
extern void Array__delete(Array, Unsigned);
extern Logical Array__equal(Array, Array, Logical (*)(void *, void *));
extern void Array__erase(Array);
extern String Array__f(Array, String (*)(void *));
extern void * Array__fetch1(Array, Unsigned);
extern Unsigned Array__hash(Array, Unsigned (*)(void *));
extern void Array__insert(Array, Unsigned, void *);
extern void * Array__lop(Array);
extern Array Array__new(void);
extern void * Array__pop(Array);
extern void Array__print(Array, Out_Stream, void (*)(void *, Out_Stream));
extern void Array__put(Array, Out_Stream, void (*)(void *, Out_Stream));
extern void Array__range_delete(Array, Unsigned, Unsigned);
extern void Array__range_insert(Array, Unsigned, Unsigned, void *);
extern void Array__reverse(Array);
extern Unsigned Array__size_get(Array);
extern void Array__sort(Array, Integer (*)(void *, void *));
extern void Array__store1(Array, Unsigned, void *);
extern void Array__transfer(Array, Unsigned, Array, Unsigned, Unsigned);
extern void Array__trim(Array, Unsigned);
extern void Array__unique(Array, Logical (*)(void *, void *));
extern void Array__xvisit(Array, void (*)(void *));
extern Byte Byte__null;;/*D13*/
extern Character Byte__character(Byte);
extern String Byte__f(Byte);
extern Float Byte__float(Byte);
extern Integer Byte__integer(Byte);
extern Long_Integer Byte__long_integer(Byte);
extern Long_Unsigned Byte__long_unsigned(Byte);
extern Short Byte__short(Byte);
extern Unsigned Byte__unsigned(Byte);
extern Character Character__null;;/*D13*/
extern void Character__buffer_append(Character, String);
extern Byte Character__byte(Character);
extern Integer Character__compare(Character, Character);
extern Unsigned Character__decimal_convert(Character);
extern Double Character__double(Character);
extern void Character__erase(Character);
extern String Character__f(Character);
extern Float Character__float(Character);
extern Unsigned Character__hexadecimal_convert(Character);
extern Integer Character__integer(Character);
extern Long_Integer Character__long_integer(Character);
extern Long_Unsigned Character__long_unsigned(Character);
extern Logical Character__is_alpha_numeric(Character);
extern Logical Character__is_decimal_digit(Character);
extern Logical Character__is_letter(Character);
extern Logical Character__is_white_space(Character);
extern Logical Character__is_hex_digit(Character);
extern Logical Character__is_lower_case(Character);
extern Logical Character__is_printing(Character);
extern Logical Character__is_upper_case(Character);
extern Character Character__lower_case(Character);
extern void Character__put(Character, Out_Stream);
extern Short Character__short(Character);
extern Character Character__upper_case(Character);
extern Unsigned Character__unsigned(Character);
extern Double Double__null;;/*D13*/
extern Byte Double__byte(Double);
extern Character Double__character(Double);
extern Integer Double__compare(Double, Double);
extern String Double__f(Double);
extern void Double__f_helper(Double, Unsigned, Character, String);
extern Float Double__float(Double);
extern Integer Double__integer(Double);
extern Long_Integer Double__long_integer(Double);
extern Long_Unsigned Double__long_unsigned(Double);
extern Short Double__short(Double);
extern Unsigned Double__unsigned(Double);
extern void Easy_C__fail(String, Unsigned, String);
extern Float Float__null;;/*D13*/
extern Byte Float__byte(Float);
extern Character Float__character(Float);
extern Integer Float__compare(Float, Float);
extern Double Float__double(Float);
extern String Float__f(Float);
extern Unsigned Float__hash(Float);
extern Integer Float__integer(Float);
extern Long_Integer Float__long_integer(Float);
extern Long_Unsigned Float__long_unsigned(Float);
extern Short Float__short(Float);
extern Unsigned Float__unsigned(Float);
extern Format Format__null;/*D10*/
extern Format Format__new(void);/*D11*/
extern void Format__erase(Format);/*D12*/
extern Format_Frame Format__frame_allocate(Format);
extern void Format__frame_release(Format, Format_Frame);
extern Format_Field Format__field_allocate(Format);
extern String Format__field_next(void);
extern void Format__field_release(Format, Format_Field);
extern Format Format__one_and_only(void);
extern Format_Frame Format_Frame__null;/*D10*/
extern Format_Frame Format_Frame__new(void);/*D11*/
extern void Format_Frame__erase(Format_Frame);/*D12*/
extern Format_Frame Format_Frame__create(void);
extern Format_Field Format_Field__null;/*D10*/
extern Format_Field Format_Field__new(void);/*D11*/
extern void Format_Field__erase(Format_Field);/*D12*/
extern Hash_Table_Pair Hash_Table_Pair__null;/*D10*/
extern Hash_Table_Pair Hash_Table_Pair__new(void);/*D11*/
extern void Hash_Table_Pair__erase(Hash_Table_Pair);/*D12*/
extern Hash_Table_Pair Hash_Table_Pair__create(void *, void *, Unsigned);
extern Hash_Table_Row Hash_Table_Row__null;/*D10*/
extern Hash_Table_Row Hash_Table_Row__new(void);/*D11*/
extern void Hash_Table_Row__erase(Hash_Table_Row);/*D12*/
extern Hash_Table_Row Hash_Table_Row__create(Unsigned);
extern Hash_Table Hash_Table__null;/*D10*/
extern Hash_Table Hash_Table__new(void);/*D11*/
extern void Hash_Table__erase(Hash_Table);/*D12*/
extern Hash_Table Hash_Table__create(void *, Unsigned (*)(void *), Logical (*)(void *, void *), void (*)(void *, String), void (*)(void *, String));
extern Logical Hash_Table__delete(Hash_Table, void *);
extern void * Hash_Table__lookup(Hash_Table, void *);
extern Logical Hash_Table__insert(Hash_Table, void *, void *);
extern Logical Hash_Table__is_in(Hash_Table, void *);
extern void * Hash_Table__key_lookup(Hash_Table, void *);
extern void * Hash_Table__replace(Hash_Table, void *, void *);
extern void Hash_Table__show(Hash_Table, Out_Stream);
extern Hash_Table_Row Hash_Table__row_lookup(Hash_Table, void *, Unsigned);
In_Stream In_Stream__null;
In_Stream In_Stream__standard;
extern void In_Stream__Initialize(void);
extern String In_Stream__all_read(In_Stream, String);
extern Unsigned In_Stream__byte_get(In_Stream);
extern Character In_Stream__character_read(In_Stream);
extern void In_Stream__character_unread(In_Stream, Character);
extern void In_Stream__close(In_Stream);
extern void In_Stream__erase(In_Stream);
extern In_Stream In_Stream__fd_open(Integer);
extern Logical feof(In_Stream);
extern String In_Stream__line_read(In_Stream, String);
extern Unsigned In_Stream__little_endian_short_get(In_Stream);
extern In_Stream In_Stream__open(String);
extern In_Stream In_Stream__pipe_read(String);
extern Logical In_Stream__xml_attribute_read(In_Stream, String, String);
extern Character In_Stream__xml_space_skip(In_Stream);
extern Logical In_Stream__xml_tag_read(In_Stream, String);
extern Logical In_Stream__xml_tag_end(In_Stream, Logical);
extern Logical In_Stream__xml_tag_match(In_Stream, String);
extern Integer Integer__null;;/*D13*/
extern Integer Integer__zero;;/*D13*/
extern Integer Integer__one;;/*D13*/
extern Integer Integer__negative_one;;/*D13*/
extern Integer Integer__minimum;;/*D13*/
extern Integer Integer__maximum;;/*D13*/
extern Byte Integer__byte(Integer);
extern Character Integer__character(Integer);
extern Integer Integer__compare(Integer, Integer);
extern Double Integer__double(Integer);
extern void Integer__erase(Integer);
extern String Integer__f(Integer);
extern void Integer__f_helper(Integer, Integer, String);
extern Float Integer__float(Integer);
extern Long_Integer Integer__long_integer(Integer);
extern Long_Unsigned Integer__long_unsigned(Integer);
extern Short Integer__short(Integer);
extern Unsigned Integer__unsigned(Integer);
extern Logical Logical__null;;/*D13*/
extern Logical Logical__true;;/*D13*/
extern Logical Logical__false;;/*D13*/
extern void Logical__erase(Logical);
extern String Logical__f(Logical);
extern Long_Integer Long_Integer__null;;/*D13*/
extern Long_Integer Long_Integer__zero;;/*D13*/
extern Long_Integer Long_Integer__one;;/*D13*/
extern Long_Integer Long_Integer__negative_one;;/*D13*/
extern Long_Integer Long_Integer__minimum;;/*D13*/
extern Long_Integer Long_Integer__maximum;;/*D13*/
extern Byte Long_Integer__byte(Long_Integer);
extern Character Long_Integer__character(Long_Integer);
extern Integer Long_Integer__compare(Long_Integer, Long_Integer);
extern Double Long_Integer__double(Long_Integer);
extern void Long_Integer__erase(Long_Integer);
extern String Long_Integer__f(Long_Integer);
extern void Long_Integer__f_helper(Long_Integer, Long_Integer, String);
extern Float Long_Integer__float(Long_Integer);
extern Integer Long_Integer__integer(Long_Integer);
extern Long_Unsigned Long_Integer__long_unsigned(Long_Integer);
extern Short Long_Integer__short(Long_Integer);
extern Unsigned Long_Integer__unsigned(Long_Integer);
extern Long_Unsigned Long_Unsigned__null;;/*D13*/
extern Long_Unsigned Long_Unsigned__zero;;/*D13*/
extern Long_Unsigned Long_Unsigned__one;;/*D13*/
extern Long_Unsigned Long_Unsigned__negative_one;;/*D13*/
extern Long_Unsigned Long_Unsigned__minimum;;/*D13*/
extern Long_Unsigned Long_Unsigned__maximum;;/*D13*/
extern Byte Long_Unsigned__byte(Long_Unsigned);
extern Character Long_Unsigned__character(Long_Unsigned);
extern Integer Long_Unsigned__compare(Long_Unsigned, Long_Unsigned);
extern Double Long_Unsigned__double(Long_Unsigned);
extern void Long_Unsigned__erase(Long_Unsigned);
extern String Long_Unsigned__f(Long_Unsigned);
extern void Long_Unsigned__f_helper(Long_Unsigned, Long_Unsigned, String);
extern Float Long_Unsigned__float(Long_Unsigned);
extern Integer Long_Unsigned__integer(Long_Unsigned);
extern Long_Integer Long_Unsigned__long_integer(Long_Unsigned);
extern Short Long_Unsigned__short(Long_Unsigned);
extern Unsigned Long_Unsigned__unsigned(Long_Unsigned);
extern Out_Stream Out_Stream__null;;/*D13*/
extern Out_Stream Out_Stream__standard;;/*D13*/
extern Out_Stream Out_Stream__error;;/*D13*/
extern void Out_Stream__big_endian_short_put(Out_Stream, Unsigned);
extern void Out_Stream__byte_put(Out_Stream, Unsigned);
extern void Out_Stream__little_endian_short_put(Out_Stream, Unsigned);
extern void Out_Stream__erase(Out_Stream);
extern void Out_Stream__Initialize(void);
extern void Out_Stream__close(Out_Stream);
extern Out_Stream Out_Stream__fd_open(Integer);
extern void Out_Stream__flush(Out_Stream);
extern Out_Stream Out_Stream__open(String);
extern Out_Stream Out_Stream__pipe_write(String);
extern Short Short__null;;/*D13*/
extern Byte Short__byte(Short);
extern Character Short__character(Short);
extern Double Short__double(Short);
extern String Short__f(Short);
extern Float Short__float(Short);
extern Integer Short__integer(Short);
extern Long_Integer Short__long_integer(Short);
extern Long_Unsigned Short__long_unsigned(Short);
extern Unsigned Short__unsigned(Short);
extern String String__null;;/*D13*/
extern String String__new(void);
extern Unsigned String__address_get(String);
extern void String__buffer_append(String, String);
extern void String__c_character_append(String, Character);
extern void String__character_append(String, Character);
extern void String__character_delete(String, Unsigned);
extern void String__character_insert(String, Unsigned, Character);
extern void String__character_gap_insert(String, Character);
extern void String__character_prepend(String, Character);
extern Integer String__compare(String, String);
extern void String__d(String);
extern String String__divide(String, String);
extern Double String__double_convert(String);
extern void String__erase(String);
extern Logical String__equal(String, String);
extern String String__f(String);
extern Character String__fetch1(String, Unsigned);
extern Float String__float_convert(String);
extern void String__flush(String, Out_Stream);
extern String String__form(String);
extern Unsigned String__format_begin(String);
extern void String__format_end(String, Unsigned);
extern void String__format_prepare(String, String);
extern Unsigned String__front_size_get(String);
extern void String__gap_set(String, Unsigned);
extern Unsigned String__hash(String);
extern Integer String__integer_convert(String);
extern Logical String__is_buffered(String);
extern Logical String__is_c_keyword(String);
extern Logical String__is_buffered(String);
extern Unsigned String__limit_get(String);
extern Character String__lop(String);
extern void String__lower_case(String);
extern void String__lower_case_append(String, String);
extern void String__p(String);
extern Unsigned String__partial_match(String, String);
extern void String__put(String, Out_Stream);
extern void String__range_append(String, String, Unsigned, Unsigned);
extern Integer String__range_compare(String, Unsigned, Unsigned, String, Unsigned, Unsigned);
extern void String__range_copy(String, Unsigned, String, Unsigned, Unsigned);
extern void String__range_delete(String, Unsigned, Unsigned);
extern Logical String__range_equal(String, Unsigned, Unsigned, String, Unsigned, Unsigned);
extern void String__range_insert(String, Unsigned, String, Unsigned, Unsigned);
extern void String__range_nulls_insert(String, Unsigned, Unsigned);
extern Unsigned String__read(String, Unsigned, Unsigned, In_Stream);
extern String String__read_only_copy(String);
extern String String__remainder(String, String);
extern Unsigned String__size_get(String);
extern void String__store1(String, Unsigned, Character);
extern void String__string_append(String, String);
extern void String__string_gap_insert(String, String);
extern void String__string_insert(String, Unsigned, String);
extern void String__string_prepend(String, String);
extern Logical String__suffix_match(String, String);
extern void String__trim(String, Unsigned);
extern void String__upper_case(String);
extern void String__upper_case_append(String, String);
extern Unsigned String__unsigned_convert(String);
extern Logical String__visual_character_append(String, Logical, Character);
extern String String__word_lop(String, String);
extern void String__white_space_lop(String, String);
extern String String__writable_copy(String);
extern System System__null;/*D10*/
extern System System__new(void);/*D11*/
extern void System__erase(System);/*D12*/
extern void System__abort(void);
extern Logical System__careful(void (*)(void));
extern String System__current_working_directory(String);
extern String System__executable_directory(String);
extern Integer System__execute(String);
extern void System__exit(Unsigned);
extern void System__assert_fail(String, Unsigned);
extern void System__fail(String, String, Unsigned);
extern void System__fail_routine_set(void (*)(String, String, Unsigned));
extern String System__file_real_path(String, String);
extern Unsigned System__variant_scalar_fail(String, Unsigned);
extern System System__variant_object_fail(String, Unsigned);
extern System System__one_and_only(void);
extern void System__reset(System);
extern Integer setjmp(System_Jump_Buffer);
extern void longjmp(System_Jump_Buffer, Integer);
extern Unsigned Unsigned__null;;/*D13*/
extern Unsigned Unsigned__maximum;;/*D13*/
extern void Unsigned__buffer_append(Unsigned, String);
extern Byte Unsigned__byte(Unsigned);
extern Character Unsigned__character(Unsigned);
extern Integer Unsigned__compare(Unsigned, Unsigned);
extern void Unsigned__decimal_put(Unsigned, Out_Stream);
extern Double Unsigned__double(Unsigned);
extern void Unsigned__erase(Unsigned);
extern String Unsigned__f(Unsigned);
extern Unsigned Unsigned__hash(Unsigned);
extern void Unsigned__f_helper(Unsigned, Unsigned, String);
extern Float Unsigned__float(Unsigned);
extern Integer Unsigned__integer(Unsigned);
extern Long_Integer Unsigned__long_integer(Unsigned);
extern Long_Unsigned Unsigned__long_unsigned(Unsigned);
extern Short Unsigned__short(Unsigned);
extern Format Format__null;;/*D13*/
extern Format Format__new(void);
extern Format_Frame Format_Frame__null;;/*D13*/
extern Format_Frame Format_Frame__new(void);
extern Format_Field Format_Field__null;;/*D13*/
extern Format_Field Format_Field__new(void);
extern Hash_Table_Pair Hash_Table_Pair__null;;/*D13*/
extern Hash_Table_Pair Hash_Table_Pair__new(void);
extern Hash_Table_Row Hash_Table_Row__null;;/*D13*/
extern Hash_Table_Row Hash_Table_Row__new(void);
extern Hash_Table Hash_Table__null;;/*D13*/
extern Hash_Table Hash_Table__new(void);
extern System System__null;;/*D13*/
extern System System__new(void);

/* Declare extracted #define values: */
extern Unsigned Unsigned__unix_errno_2big;
extern Unsigned Unsigned__unix_errno_acces;
extern Unsigned Unsigned__unix_errno_addrinuse;
extern Unsigned Unsigned__unix_errno_addrnotavail;
extern Unsigned Unsigned__unix_errno_adv;
extern Unsigned Unsigned__unix_errno_afnosupport;
extern Unsigned Unsigned__unix_errno_again;
extern Unsigned Unsigned__unix_errno_already;
extern Unsigned Unsigned__unix_errno_asy_c_included;
extern Unsigned Unsigned__unix_errno_bade;
extern Unsigned Unsigned__unix_errno_badf;
extern Unsigned Unsigned__unix_errno_badfd;
extern Unsigned Unsigned__unix_errno_badmsg;
extern Unsigned Unsigned__unix_errno_badr;
extern Unsigned Unsigned__unix_errno_badrqc;
extern Unsigned Unsigned__unix_errno_badslt;
extern Unsigned Unsigned__unix_errno_bfont;
extern Unsigned Unsigned__unix_errno_busy;
extern Unsigned Unsigned__unix_errno_canceled;
extern Unsigned Unsigned__unix_errno_child;
extern Unsigned Unsigned__unix_errno_chrng;
extern Unsigned Unsigned__unix_errno_comm;
extern Unsigned Unsigned__unix_errno_connaborted;
extern Unsigned Unsigned__unix_errno_connrefused;
extern Unsigned Unsigned__unix_errno_connreset;
extern Unsigned Unsigned__unix_errno_deadlk;
extern Unsigned Unsigned__unix_errno_destaddrreq;
extern Unsigned Unsigned__unix_errno_dom;
extern Unsigned Unsigned__unix_errno_dotdot;
extern Unsigned Unsigned__unix_errno_dquot;
extern Unsigned Unsigned__unix_errno_exist;
extern Unsigned Unsigned__unix_errno_fault;
extern Unsigned Unsigned__unix_errno_fbig;
extern Unsigned Unsigned__unix_errno_hostdown;
extern Unsigned Unsigned__unix_errno_hostunreach;
extern Unsigned Unsigned__unix_errno_hwpoison;
extern Unsigned Unsigned__unix_errno_idrm;
extern Unsigned Unsigned__unix_errno_ilseq;
extern Unsigned Unsigned__unix_errno_inprogress;
extern Unsigned Unsigned__unix_errno_intr;
extern Unsigned Unsigned__unix_errno_inval;
extern Unsigned Unsigned__unix_errno_io;
extern Unsigned Unsigned__unix_errno_isconn;
extern Unsigned Unsigned__unix_errno_isdir;
extern Unsigned Unsigned__unix_errno_isnam;
extern Unsigned Unsigned__unix_errno_keyexpired;
extern Unsigned Unsigned__unix_errno_keyrejected;
extern Unsigned Unsigned__unix_errno_keyrevoked;
extern Unsigned Unsigned__unix_errno_l2hlt;
extern Unsigned Unsigned__unix_errno_l2nsync;
extern Unsigned Unsigned__unix_errno_l3hlt;
extern Unsigned Unsigned__unix_errno_l3rst;
extern Unsigned Unsigned__unix_errno_libacc;
extern Unsigned Unsigned__unix_errno_libbad;
extern Unsigned Unsigned__unix_errno_libexec;
extern Unsigned Unsigned__unix_errno_libmax;
extern Unsigned Unsigned__unix_errno_libscn;
extern Unsigned Unsigned__unix_errno_lnrng;
extern Unsigned Unsigned__unix_errno_loop;
extern Unsigned Unsigned__unix_errno_mediumtype;
extern Unsigned Unsigned__unix_errno_mfile;
extern Unsigned Unsigned__unix_errno_mlink;
extern Unsigned Unsigned__unix_errno_msgsize;
extern Unsigned Unsigned__unix_errno_multihop;
extern Unsigned Unsigned__unix_errno_nametoolong;
extern Unsigned Unsigned__unix_errno_navail;
extern Unsigned Unsigned__unix_errno_netdown;
extern Unsigned Unsigned__unix_errno_netreset;
extern Unsigned Unsigned__unix_errno_netunreach;
extern Unsigned Unsigned__unix_errno_nfile;
extern Unsigned Unsigned__unix_errno_noano;
extern Unsigned Unsigned__unix_errno_nobufs;
extern Unsigned Unsigned__unix_errno_nocsi;
extern Unsigned Unsigned__unix_errno_nodata;
extern Unsigned Unsigned__unix_errno_nodev;
extern Unsigned Unsigned__unix_errno_noent;
extern Unsigned Unsigned__unix_errno_noexec;
extern Unsigned Unsigned__unix_errno_nokey;
extern Unsigned Unsigned__unix_errno_nolck;
extern Unsigned Unsigned__unix_errno_nolink;
extern Unsigned Unsigned__unix_errno_nomedium;
extern Unsigned Unsigned__unix_errno_nomem;
extern Unsigned Unsigned__unix_errno_nomsg;
extern Unsigned Unsigned__unix_errno_nonet;
extern Unsigned Unsigned__unix_errno_nopkg;
extern Unsigned Unsigned__unix_errno_noprotoopt;
extern Unsigned Unsigned__unix_errno_nospc;
extern Unsigned Unsigned__unix_errno_nosr;
extern Unsigned Unsigned__unix_errno_nostr;
extern Unsigned Unsigned__unix_errno_nosys;
extern Unsigned Unsigned__unix_errno_notblk;
extern Unsigned Unsigned__unix_errno_notconn;
extern Unsigned Unsigned__unix_errno_notdir;
extern Unsigned Unsigned__unix_errno_notempty;
extern Unsigned Unsigned__unix_errno_notnam;
extern Unsigned Unsigned__unix_errno_notrecoverable;
extern Unsigned Unsigned__unix_errno_notsock;
extern Unsigned Unsigned__unix_errno_notty;
extern Unsigned Unsigned__unix_errno_notuniq;
extern Unsigned Unsigned__unix_errno_nxio;
extern Unsigned Unsigned__unix_errno_opnotsupp;
extern Unsigned Unsigned__unix_errno_overflow;
extern Unsigned Unsigned__unix_errno_ownerdead;
extern Unsigned Unsigned__unix_errno_perm;
extern Unsigned Unsigned__unix_errno_pfnosupport;
extern Unsigned Unsigned__unix_errno_pipe;
extern Unsigned Unsigned__unix_errno_proto;
extern Unsigned Unsigned__unix_errno_protonosupport;
extern Unsigned Unsigned__unix_errno_prototype;
extern Unsigned Unsigned__unix_errno_range;
extern Unsigned Unsigned__unix_errno_remchg;
extern Unsigned Unsigned__unix_errno_remote;
extern Unsigned Unsigned__unix_errno_remoteio;
extern Unsigned Unsigned__unix_errno_restart;
extern Unsigned Unsigned__unix_errno_rfkill;
extern Unsigned Unsigned__unix_errno_rofs;
extern Unsigned Unsigned__unix_errno_shutdown;
extern Unsigned Unsigned__unix_errno_socktnosupport;
extern Unsigned Unsigned__unix_errno_spipe;
extern Unsigned Unsigned__unix_errno_srch;
extern Unsigned Unsigned__unix_errno_srmnt;
extern Unsigned Unsigned__unix_errno_stale;
extern Unsigned Unsigned__unix_errno_strpipe;
extern Unsigned Unsigned__unix_errno_time;
extern Unsigned Unsigned__unix_errno_timedout;
extern Unsigned Unsigned__unix_errno_toomanyrefs;
extern Unsigned Unsigned__unix_errno_txtbsy;
extern Unsigned Unsigned__unix_errno_uclean;
extern Unsigned Unsigned__unix_errno_unatch;
extern Unsigned Unsigned__unix_errno_users;
extern Unsigned Unsigned__unix_errno_xdev;
extern Unsigned Unsigned__unix_errno_xfull;
extern Unsigned Unsigned__unix_errno_xit_failure;
extern Unsigned Unsigned__unix_errno_xit_success;
extern Unsigned Unsigned__unix_errno_asyc_c_h_included;
extern Integer Integer__unix_file_f_dupfd;
extern Integer Integer__unix_file_f_dupfd_cloexec;
extern Integer Integer__unix_file_f_exlck;
extern Integer Integer__unix_file_f_getfd;
extern Integer Integer__unix_file_f_getfl;
extern Integer Integer__unix_file_f_getlk;
extern Integer Integer__unix_file_f_getlk64;
extern Integer Integer__unix_file_f_getown;
extern Integer Integer__unix_file_f_lock;
extern Integer Integer__unix_file_f_ok;
extern Integer Integer__unix_file_f_rdlck;
extern Integer Integer__unix_file_f_setfd;
extern Integer Integer__unix_file_f_setfl;
extern Integer Integer__unix_file_f_setlk;
extern Integer Integer__unix_file_f_setlk64;
extern Integer Integer__unix_file_f_setlkw;
extern Integer Integer__unix_file_f_setlkw64;
extern Integer Integer__unix_file_f_setown;
extern Integer Integer__unix_file_f_shlck;
extern Integer Integer__unix_file_f_test;
extern Integer Integer__unix_file_f_tlock;
extern Integer Integer__unix_file_f_ulock;
extern Integer Integer__unix_file_f_unlck;
extern Integer Integer__unix_file_f_wrlck;
extern Unsigned Unsigned__unix_file_o_accmode;
extern Unsigned Unsigned__unix_file_o_append;
extern Unsigned Unsigned__unix_file_o_async;
extern Unsigned Unsigned__unix_file_o_cloexec;
extern Unsigned Unsigned__unix_file_o_creat;
extern Unsigned Unsigned__unix_file_o_directory;
extern Unsigned Unsigned__unix_file_o_dsync;
extern Unsigned Unsigned__unix_file_o_excl;
extern Unsigned Unsigned__unix_file_o_noctty;
extern Unsigned Unsigned__unix_file_o_nofollow;
extern Unsigned Unsigned__unix_file_o_nonblock;
extern Unsigned Unsigned__unix_file_o_rdonly;
extern Unsigned Unsigned__unix_file_o_rdwr;
extern Unsigned Unsigned__unix_file_o_sync;
extern Unsigned Unsigned__unix_file_o_trunc;
extern Unsigned Unsigned__unix_file_o_wronly;
#endif /* EASY_C_INCLUDED */
