#ifndef UNIX_INCLUDED
#define UNIX_INCLUDED 1

/* Declare all enum's and typedef's first: */
/* h_emit1 */
/* h_emit2 */
/* h_emit3 */

/* Include other libraries exactly once: */
#ifndef EASY_C_INCLUDED
#include "Easy_C.h"/*D2*/
#endif /* EASY_C_INCLUDED */
#ifndef FCNTL_H_INCLUDED
#include "fcntl.h"/*D4*/
#endif /* FCNTL_H_INCLUDED */
#ifndef SYS_SELECT_H_INCLUDED
#include "sys/select.h"/*D4*/
#endif /* SYS_SELECT_H_INCLUDED */
#ifndef SYS_SOCKET_H_INCLUDED
#include "sys/socket.h"/*D4*/
#endif /* SYS_SOCKET_H_INCLUDED */
#ifndef UNIX_C_H_INCLUDED
#include "Unix_C.h"/*D4*/
#endif /* UNIX_C_H_INCLUDED */
#ifndef ERRNO_H_INCLUDED
#include "errno.h"/*D4*/
#endif /* ERRNO_H_INCLUDED */

/* Define the structures: */

/* Declare the routine prototypes: */
extern Unix_SHA1_Context Unix_SHA1_Context__null;;/*D13*/
extern Unix_SHA1_Context Unix_SHA1_Context__new(void);
extern String Unix_SHA1_Context__f(Unix_SHA1_Context);
extern Byte Unix_SHA1_Context__fetch1(Unix_SHA1_Context, Unsigned);
extern void Unix_SHA1_Context__final(Unix_SHA1_Context);
extern Integer Unix_SHA1_Context__test(void);
extern void Unix_SHA1_Context__reset(Unix_SHA1_Context);
extern void Unix_SHA1_Context__update(Unix_SHA1_Context, String);
extern Unix_Status Unix_Status__null;;/*D13*/
extern Unix_Status Unix_Status__new(void);
extern Logical Unix_Status__is_directory(Unix_Status);
extern Logical Unix_Status__is_regular_file(Unix_Status);
extern Logical Unix_Status__is_symbolic_link(Unix_Status);
extern Unsigned Unix_Status__mode_get(Unix_Status);
extern Unsigned Unix_Status__modification_time_get(Unix_Status);
extern Long_Unsigned Unix_Status__size_get(Unix_Status);
extern Unix_Directory_Stream Unix_Directory_Stream__null;;/*D13*/
extern void Unix_Directory_Stream__close(Unix_Directory_Stream);
extern Unix_Directory_Stream Unix_Directory_Stream__open(String);
extern String Unix_Directory_Stream__read(Unix_Directory_Stream, String);
extern Unix_File_Set Unix_File_Set__null;;/*D13*/
extern Unix_File_Set Unix_File_Set__new(void);
extern void Unix_File_Set__clear(Unix_File_Set, Integer);
extern void Unix_File_Set__contents_copy(Unix_File_Set, Unix_File_Set);
extern String Unix_File_Set__f(Unix_File_Set);
extern Logical Unix_File_Set__is_set(Unix_File_Set, Integer);
extern Integer Unix_File_Set__maximum_get(Unix_File_Set);
extern void Unix_File_Set__set(Unix_File_Set, Integer);
extern void Unix_File_Set__update(Unix_File_Set);
extern void Unix_File_Set__zero(Unix_File_Set);
extern Integer Unix__accept(Integer);
extern Integer Unix__bind(Integer, Unsigned, Unsigned);
extern Integer Unix__connect(Integer, Unsigned, Unsigned);
extern Integer close(Integer);
extern Logical Unix__current_working_directory(String);
extern Array Unix__environment_all(void);
extern Logical Unix__environment_fetch(Unsigned, String);
extern Logical Unix__environment_lookup(String, String);
extern Unsigned Unix__environment_size(void);
extern String Unix__errno_convert(String, Unsigned);
extern Unsigned Unix__errno(void);
extern Logical Unix__executable_directory_lookup(String, String);
extern Integer Unix__execve(String, Array, Array);
extern void exit(Integer);
extern Integer Unix__file_control(Integer, Integer, Integer);
extern Integer Unix__fork(void);
extern Long_Integer Unix__get_time_of_day(void);
extern Integer unix_system__get_socket_option(Integer, Integer);
extern Logical Unix__host_lookup(Unsigned, String);
extern Unsigned Unix__internet_address_lookup(String);
extern Integer listen(Integer, Integer);
extern Integer Unix__lstat(String, Unix_Status);
extern Integer Unix__mkdir(String, Unsigned);
extern Integer Unix__open(String, Unsigned, Unsigned);
extern Integer Unix__read(Integer, String, Unsigned, Unsigned);
extern Integer Unix__readlink(String, String);
extern Logical Unix__real_path(String, String);
extern Integer Unix__rename(String, String);
extern Integer Unix__set_socket_option(Integer, Integer, Integer);
extern Integer Unix__select(Unix_File_Set, Unix_File_Set, Unix_File_Set, Unsigned, Unsigned);
extern Integer Unix__lstat(String, Unix_Status);
extern Integer Unix__socket_stream_create(void);
extern Integer Unix__symlink(String, String);
extern Integer Unix__system(String);
extern Integer Unix__unlink(String);
extern Integer Unix__write(Integer, String, Unsigned, Unsigned);
extern Unsigned Unsigned__unix_errno_2big;;/*D13*/
extern Unsigned Unsigned__unix_errno_acces;;/*D13*/
extern Unsigned Unsigned__unix_errno_addrinuse;;/*D13*/
extern Unsigned Unsigned__unix_errno_addrnotavail;;/*D13*/
extern Unsigned Unsigned__unix_errno_adv;;/*D13*/
extern Unsigned Unsigned__unix_errno_afnosupport;;/*D13*/
extern Unsigned Unsigned__unix_errno_again;;/*D13*/
extern Unsigned Unsigned__unix_errno_already;;/*D13*/
extern Unsigned Unsigned__unix_errno_asy_c_included;;/*D13*/
extern Unsigned Unsigned__unix_errno_bade;;/*D13*/
extern Unsigned Unsigned__unix_errno_badf;;/*D13*/
extern Unsigned Unsigned__unix_errno_badfd;;/*D13*/
extern Unsigned Unsigned__unix_errno_badmsg;;/*D13*/
extern Unsigned Unsigned__unix_errno_badr;;/*D13*/
extern Unsigned Unsigned__unix_errno_badrqc;;/*D13*/
extern Unsigned Unsigned__unix_errno_badslt;;/*D13*/
extern Unsigned Unsigned__unix_errno_bfont;;/*D13*/
extern Unsigned Unsigned__unix_errno_busy;;/*D13*/
extern Unsigned Unsigned__unix_errno_canceled;;/*D13*/
extern Unsigned Unsigned__unix_errno_child;;/*D13*/
extern Unsigned Unsigned__unix_errno_chrng;;/*D13*/
extern Unsigned Unsigned__unix_errno_comm;;/*D13*/
extern Unsigned Unsigned__unix_errno_connaborted;;/*D13*/
extern Unsigned Unsigned__unix_errno_connrefused;;/*D13*/
extern Unsigned Unsigned__unix_errno_connreset;;/*D13*/
extern Unsigned Unsigned__unix_errno_deadlk;;/*D13*/
extern Unsigned Unsigned__unix_errno_destaddrreq;;/*D13*/
extern Unsigned Unsigned__unix_errno_dom;;/*D13*/
extern Unsigned Unsigned__unix_errno_dotdot;;/*D13*/
extern Unsigned Unsigned__unix_errno_dquot;;/*D13*/
extern Unsigned Unsigned__unix_errno_exist;;/*D13*/
extern Unsigned Unsigned__unix_errno_fault;;/*D13*/
extern Unsigned Unsigned__unix_errno_fbig;;/*D13*/
extern Unsigned Unsigned__unix_errno_hostdown;;/*D13*/
extern Unsigned Unsigned__unix_errno_hostunreach;;/*D13*/
extern Unsigned Unsigned__unix_errno_hwpoison;;/*D13*/
extern Unsigned Unsigned__unix_errno_idrm;;/*D13*/
extern Unsigned Unsigned__unix_errno_ilseq;;/*D13*/
extern Unsigned Unsigned__unix_errno_inprogress;;/*D13*/
extern Unsigned Unsigned__unix_errno_intr;;/*D13*/
extern Unsigned Unsigned__unix_errno_inval;;/*D13*/
extern Unsigned Unsigned__unix_errno_io;;/*D13*/
extern Unsigned Unsigned__unix_errno_isconn;;/*D13*/
extern Unsigned Unsigned__unix_errno_isdir;;/*D13*/
extern Unsigned Unsigned__unix_errno_isnam;;/*D13*/
extern Unsigned Unsigned__unix_errno_keyexpired;;/*D13*/
extern Unsigned Unsigned__unix_errno_keyrejected;;/*D13*/
extern Unsigned Unsigned__unix_errno_keyrevoked;;/*D13*/
extern Unsigned Unsigned__unix_errno_l2hlt;;/*D13*/
extern Unsigned Unsigned__unix_errno_l2nsync;;/*D13*/
extern Unsigned Unsigned__unix_errno_l3hlt;;/*D13*/
extern Unsigned Unsigned__unix_errno_l3rst;;/*D13*/
extern Unsigned Unsigned__unix_errno_libacc;;/*D13*/
extern Unsigned Unsigned__unix_errno_libbad;;/*D13*/
extern Unsigned Unsigned__unix_errno_libexec;;/*D13*/
extern Unsigned Unsigned__unix_errno_libmax;;/*D13*/
extern Unsigned Unsigned__unix_errno_libscn;;/*D13*/
extern Unsigned Unsigned__unix_errno_lnrng;;/*D13*/
extern Unsigned Unsigned__unix_errno_loop;;/*D13*/
extern Unsigned Unsigned__unix_errno_mediumtype;;/*D13*/
extern Unsigned Unsigned__unix_errno_mfile;;/*D13*/
extern Unsigned Unsigned__unix_errno_mlink;;/*D13*/
extern Unsigned Unsigned__unix_errno_msgsize;;/*D13*/
extern Unsigned Unsigned__unix_errno_multihop;;/*D13*/
extern Unsigned Unsigned__unix_errno_nametoolong;;/*D13*/
extern Unsigned Unsigned__unix_errno_navail;;/*D13*/
extern Unsigned Unsigned__unix_errno_netdown;;/*D13*/
extern Unsigned Unsigned__unix_errno_netreset;;/*D13*/
extern Unsigned Unsigned__unix_errno_netunreach;;/*D13*/
extern Unsigned Unsigned__unix_errno_nfile;;/*D13*/
extern Unsigned Unsigned__unix_errno_noano;;/*D13*/
extern Unsigned Unsigned__unix_errno_nobufs;;/*D13*/
extern Unsigned Unsigned__unix_errno_nocsi;;/*D13*/
extern Unsigned Unsigned__unix_errno_nodata;;/*D13*/
extern Unsigned Unsigned__unix_errno_nodev;;/*D13*/
extern Unsigned Unsigned__unix_errno_noent;;/*D13*/
extern Unsigned Unsigned__unix_errno_noexec;;/*D13*/
extern Unsigned Unsigned__unix_errno_nokey;;/*D13*/
extern Unsigned Unsigned__unix_errno_nolck;;/*D13*/
extern Unsigned Unsigned__unix_errno_nolink;;/*D13*/
extern Unsigned Unsigned__unix_errno_nomedium;;/*D13*/
extern Unsigned Unsigned__unix_errno_nomem;;/*D13*/
extern Unsigned Unsigned__unix_errno_nomsg;;/*D13*/
extern Unsigned Unsigned__unix_errno_nonet;;/*D13*/
extern Unsigned Unsigned__unix_errno_nopkg;;/*D13*/
extern Unsigned Unsigned__unix_errno_noprotoopt;;/*D13*/
extern Unsigned Unsigned__unix_errno_nospc;;/*D13*/
extern Unsigned Unsigned__unix_errno_nosr;;/*D13*/
extern Unsigned Unsigned__unix_errno_nostr;;/*D13*/
extern Unsigned Unsigned__unix_errno_nosys;;/*D13*/
extern Unsigned Unsigned__unix_errno_notblk;;/*D13*/
extern Unsigned Unsigned__unix_errno_notconn;;/*D13*/
extern Unsigned Unsigned__unix_errno_notdir;;/*D13*/
extern Unsigned Unsigned__unix_errno_notempty;;/*D13*/
extern Unsigned Unsigned__unix_errno_notnam;;/*D13*/
extern Unsigned Unsigned__unix_errno_notrecoverable;;/*D13*/
extern Unsigned Unsigned__unix_errno_notsock;;/*D13*/
extern Unsigned Unsigned__unix_errno_notty;;/*D13*/
extern Unsigned Unsigned__unix_errno_notuniq;;/*D13*/
extern Unsigned Unsigned__unix_errno_nxio;;/*D13*/
extern Unsigned Unsigned__unix_errno_opnotsupp;;/*D13*/
extern Unsigned Unsigned__unix_errno_overflow;;/*D13*/
extern Unsigned Unsigned__unix_errno_ownerdead;;/*D13*/
extern Unsigned Unsigned__unix_errno_perm;;/*D13*/
extern Unsigned Unsigned__unix_errno_pfnosupport;;/*D13*/
extern Unsigned Unsigned__unix_errno_pipe;;/*D13*/
extern Unsigned Unsigned__unix_errno_proto;;/*D13*/
extern Unsigned Unsigned__unix_errno_protonosupport;;/*D13*/
extern Unsigned Unsigned__unix_errno_prototype;;/*D13*/
extern Unsigned Unsigned__unix_errno_range;;/*D13*/
extern Unsigned Unsigned__unix_errno_remchg;;/*D13*/
extern Unsigned Unsigned__unix_errno_remote;;/*D13*/
extern Unsigned Unsigned__unix_errno_remoteio;;/*D13*/
extern Unsigned Unsigned__unix_errno_restart;;/*D13*/
extern Unsigned Unsigned__unix_errno_rfkill;;/*D13*/
extern Unsigned Unsigned__unix_errno_rofs;;/*D13*/
extern Unsigned Unsigned__unix_errno_shutdown;;/*D13*/
extern Unsigned Unsigned__unix_errno_socktnosupport;;/*D13*/
extern Unsigned Unsigned__unix_errno_spipe;;/*D13*/
extern Unsigned Unsigned__unix_errno_srch;;/*D13*/
extern Unsigned Unsigned__unix_errno_srmnt;;/*D13*/
extern Unsigned Unsigned__unix_errno_stale;;/*D13*/
extern Unsigned Unsigned__unix_errno_strpipe;;/*D13*/
extern Unsigned Unsigned__unix_errno_time;;/*D13*/
extern Unsigned Unsigned__unix_errno_timedout;;/*D13*/
extern Unsigned Unsigned__unix_errno_toomanyrefs;;/*D13*/
extern Unsigned Unsigned__unix_errno_txtbsy;;/*D13*/
extern Unsigned Unsigned__unix_errno_uclean;;/*D13*/
extern Unsigned Unsigned__unix_errno_unatch;;/*D13*/
extern Unsigned Unsigned__unix_errno_users;;/*D13*/
extern Unsigned Unsigned__unix_errno_xdev;;/*D13*/
extern Unsigned Unsigned__unix_errno_xfull;;/*D13*/
extern Unsigned Unsigned__unix_errno_xit_failure;;/*D13*/
extern Unsigned Unsigned__unix_errno_xit_success;;/*D13*/
extern Unsigned Unsigned__unix_errno_asyc_c_h_included;;/*D13*/
extern Integer Integer__unix_file_f_dupfd;;/*D13*/
extern Integer Integer__unix_file_f_dupfd_cloexec;;/*D13*/
extern Integer Integer__unix_file_f_exlck;;/*D13*/
extern Integer Integer__unix_file_f_getfd;;/*D13*/
extern Integer Integer__unix_file_f_getfl;;/*D13*/
extern Integer Integer__unix_file_f_getlk;;/*D13*/
extern Integer Integer__unix_file_f_getlk64;;/*D13*/
extern Integer Integer__unix_file_f_getown;;/*D13*/
extern Integer Integer__unix_file_f_lock;;/*D13*/
extern Integer Integer__unix_file_f_ok;;/*D13*/
extern Integer Integer__unix_file_f_rdlck;;/*D13*/
extern Integer Integer__unix_file_f_setfd;;/*D13*/
extern Integer Integer__unix_file_f_setfl;;/*D13*/
extern Integer Integer__unix_file_f_setlk;;/*D13*/
extern Integer Integer__unix_file_f_setlk64;;/*D13*/
extern Integer Integer__unix_file_f_setlkw;;/*D13*/
extern Integer Integer__unix_file_f_setlkw64;;/*D13*/
extern Integer Integer__unix_file_f_setown;;/*D13*/
extern Integer Integer__unix_file_f_shlck;;/*D13*/
extern Integer Integer__unix_file_f_test;;/*D13*/
extern Integer Integer__unix_file_f_tlock;;/*D13*/
extern Integer Integer__unix_file_f_ulock;;/*D13*/
extern Integer Integer__unix_file_f_unlck;;/*D13*/
extern Integer Integer__unix_file_f_wrlck;;/*D13*/
extern Unsigned Unsigned__unix_file_o_accmode;;/*D13*/
extern Unsigned Unsigned__unix_file_o_append;;/*D13*/
extern Unsigned Unsigned__unix_file_o_async;;/*D13*/
extern Unsigned Unsigned__unix_file_o_cloexec;;/*D13*/
extern Unsigned Unsigned__unix_file_o_creat;;/*D13*/
extern Unsigned Unsigned__unix_file_o_directory;;/*D13*/
extern Unsigned Unsigned__unix_file_o_dsync;;/*D13*/
extern Unsigned Unsigned__unix_file_o_excl;;/*D13*/
extern Unsigned Unsigned__unix_file_o_noctty;;/*D13*/
extern Unsigned Unsigned__unix_file_o_nofollow;;/*D13*/
extern Unsigned Unsigned__unix_file_o_nonblock;;/*D13*/
extern Unsigned Unsigned__unix_file_o_rdonly;;/*D13*/
extern Unsigned Unsigned__unix_file_o_rdwr;;/*D13*/
extern Unsigned Unsigned__unix_file_o_sync;;/*D13*/
extern Unsigned Unsigned__unix_file_o_trunc;;/*D13*/
extern Unsigned Unsigned__unix_file_o_wronly;;/*D13*/

/* Declare extracted #define values: */
extern Unsigned Unsigned__unix_errno_2big;
extern Unsigned Unsigned__unix_errno_acces;
extern Unsigned Unsigned__unix_errno_addrinuse;
extern Unsigned Unsigned__unix_errno_addrnotavail;
extern Unsigned Unsigned__unix_errno_adv;
extern Unsigned Unsigned__unix_errno_afnosupport;
extern Unsigned Unsigned__unix_errno_again;
extern Unsigned Unsigned__unix_errno_already;
extern Unsigned Unsigned__unix_errno_asy_c_included;
extern Unsigned Unsigned__unix_errno_bade;
extern Unsigned Unsigned__unix_errno_badf;
extern Unsigned Unsigned__unix_errno_badfd;
extern Unsigned Unsigned__unix_errno_badmsg;
extern Unsigned Unsigned__unix_errno_badr;
extern Unsigned Unsigned__unix_errno_badrqc;
extern Unsigned Unsigned__unix_errno_badslt;
extern Unsigned Unsigned__unix_errno_bfont;
extern Unsigned Unsigned__unix_errno_busy;
extern Unsigned Unsigned__unix_errno_canceled;
extern Unsigned Unsigned__unix_errno_child;
extern Unsigned Unsigned__unix_errno_chrng;
extern Unsigned Unsigned__unix_errno_comm;
extern Unsigned Unsigned__unix_errno_connaborted;
extern Unsigned Unsigned__unix_errno_connrefused;
extern Unsigned Unsigned__unix_errno_connreset;
extern Unsigned Unsigned__unix_errno_deadlk;
extern Unsigned Unsigned__unix_errno_destaddrreq;
extern Unsigned Unsigned__unix_errno_dom;
extern Unsigned Unsigned__unix_errno_dotdot;
extern Unsigned Unsigned__unix_errno_dquot;
extern Unsigned Unsigned__unix_errno_exist;
extern Unsigned Unsigned__unix_errno_fault;
extern Unsigned Unsigned__unix_errno_fbig;
extern Unsigned Unsigned__unix_errno_hostdown;
extern Unsigned Unsigned__unix_errno_hostunreach;
extern Unsigned Unsigned__unix_errno_hwpoison;
extern Unsigned Unsigned__unix_errno_idrm;
extern Unsigned Unsigned__unix_errno_ilseq;
extern Unsigned Unsigned__unix_errno_inprogress;
extern Unsigned Unsigned__unix_errno_intr;
extern Unsigned Unsigned__unix_errno_inval;
extern Unsigned Unsigned__unix_errno_io;
extern Unsigned Unsigned__unix_errno_isconn;
extern Unsigned Unsigned__unix_errno_isdir;
extern Unsigned Unsigned__unix_errno_isnam;
extern Unsigned Unsigned__unix_errno_keyexpired;
extern Unsigned Unsigned__unix_errno_keyrejected;
extern Unsigned Unsigned__unix_errno_keyrevoked;
extern Unsigned Unsigned__unix_errno_l2hlt;
extern Unsigned Unsigned__unix_errno_l2nsync;
extern Unsigned Unsigned__unix_errno_l3hlt;
extern Unsigned Unsigned__unix_errno_l3rst;
extern Unsigned Unsigned__unix_errno_libacc;
extern Unsigned Unsigned__unix_errno_libbad;
extern Unsigned Unsigned__unix_errno_libexec;
extern Unsigned Unsigned__unix_errno_libmax;
extern Unsigned Unsigned__unix_errno_libscn;
extern Unsigned Unsigned__unix_errno_lnrng;
extern Unsigned Unsigned__unix_errno_loop;
extern Unsigned Unsigned__unix_errno_mediumtype;
extern Unsigned Unsigned__unix_errno_mfile;
extern Unsigned Unsigned__unix_errno_mlink;
extern Unsigned Unsigned__unix_errno_msgsize;
extern Unsigned Unsigned__unix_errno_multihop;
extern Unsigned Unsigned__unix_errno_nametoolong;
extern Unsigned Unsigned__unix_errno_navail;
extern Unsigned Unsigned__unix_errno_netdown;
extern Unsigned Unsigned__unix_errno_netreset;
extern Unsigned Unsigned__unix_errno_netunreach;
extern Unsigned Unsigned__unix_errno_nfile;
extern Unsigned Unsigned__unix_errno_noano;
extern Unsigned Unsigned__unix_errno_nobufs;
extern Unsigned Unsigned__unix_errno_nocsi;
extern Unsigned Unsigned__unix_errno_nodata;
extern Unsigned Unsigned__unix_errno_nodev;
extern Unsigned Unsigned__unix_errno_noent;
extern Unsigned Unsigned__unix_errno_noexec;
extern Unsigned Unsigned__unix_errno_nokey;
extern Unsigned Unsigned__unix_errno_nolck;
extern Unsigned Unsigned__unix_errno_nolink;
extern Unsigned Unsigned__unix_errno_nomedium;
extern Unsigned Unsigned__unix_errno_nomem;
extern Unsigned Unsigned__unix_errno_nomsg;
extern Unsigned Unsigned__unix_errno_nonet;
extern Unsigned Unsigned__unix_errno_nopkg;
extern Unsigned Unsigned__unix_errno_noprotoopt;
extern Unsigned Unsigned__unix_errno_nospc;
extern Unsigned Unsigned__unix_errno_nosr;
extern Unsigned Unsigned__unix_errno_nostr;
extern Unsigned Unsigned__unix_errno_nosys;
extern Unsigned Unsigned__unix_errno_notblk;
extern Unsigned Unsigned__unix_errno_notconn;
extern Unsigned Unsigned__unix_errno_notdir;
extern Unsigned Unsigned__unix_errno_notempty;
extern Unsigned Unsigned__unix_errno_notnam;
extern Unsigned Unsigned__unix_errno_notrecoverable;
extern Unsigned Unsigned__unix_errno_notsock;
extern Unsigned Unsigned__unix_errno_notty;
extern Unsigned Unsigned__unix_errno_notuniq;
extern Unsigned Unsigned__unix_errno_nxio;
extern Unsigned Unsigned__unix_errno_opnotsupp;
extern Unsigned Unsigned__unix_errno_overflow;
extern Unsigned Unsigned__unix_errno_ownerdead;
extern Unsigned Unsigned__unix_errno_perm;
extern Unsigned Unsigned__unix_errno_pfnosupport;
extern Unsigned Unsigned__unix_errno_pipe;
extern Unsigned Unsigned__unix_errno_proto;
extern Unsigned Unsigned__unix_errno_protonosupport;
extern Unsigned Unsigned__unix_errno_prototype;
extern Unsigned Unsigned__unix_errno_range;
extern Unsigned Unsigned__unix_errno_remchg;
extern Unsigned Unsigned__unix_errno_remote;
extern Unsigned Unsigned__unix_errno_remoteio;
extern Unsigned Unsigned__unix_errno_restart;
extern Unsigned Unsigned__unix_errno_rfkill;
extern Unsigned Unsigned__unix_errno_rofs;
extern Unsigned Unsigned__unix_errno_shutdown;
extern Unsigned Unsigned__unix_errno_socktnosupport;
extern Unsigned Unsigned__unix_errno_spipe;
extern Unsigned Unsigned__unix_errno_srch;
extern Unsigned Unsigned__unix_errno_srmnt;
extern Unsigned Unsigned__unix_errno_stale;
extern Unsigned Unsigned__unix_errno_strpipe;
extern Unsigned Unsigned__unix_errno_time;
extern Unsigned Unsigned__unix_errno_timedout;
extern Unsigned Unsigned__unix_errno_toomanyrefs;
extern Unsigned Unsigned__unix_errno_txtbsy;
extern Unsigned Unsigned__unix_errno_uclean;
extern Unsigned Unsigned__unix_errno_unatch;
extern Unsigned Unsigned__unix_errno_users;
extern Unsigned Unsigned__unix_errno_xdev;
extern Unsigned Unsigned__unix_errno_xfull;
extern Unsigned Unsigned__unix_errno_xit_failure;
extern Unsigned Unsigned__unix_errno_xit_success;
extern Unsigned Unsigned__unix_errno_asyc_c_h_included;
extern Integer Integer__unix_file_f_dupfd;
extern Integer Integer__unix_file_f_dupfd_cloexec;
extern Integer Integer__unix_file_f_exlck;
extern Integer Integer__unix_file_f_getfd;
extern Integer Integer__unix_file_f_getfl;
extern Integer Integer__unix_file_f_getlk;
extern Integer Integer__unix_file_f_getlk64;
extern Integer Integer__unix_file_f_getown;
extern Integer Integer__unix_file_f_lock;
extern Integer Integer__unix_file_f_ok;
extern Integer Integer__unix_file_f_rdlck;
extern Integer Integer__unix_file_f_setfd;
extern Integer Integer__unix_file_f_setfl;
extern Integer Integer__unix_file_f_setlk;
extern Integer Integer__unix_file_f_setlk64;
extern Integer Integer__unix_file_f_setlkw;
extern Integer Integer__unix_file_f_setlkw64;
extern Integer Integer__unix_file_f_setown;
extern Integer Integer__unix_file_f_shlck;
extern Integer Integer__unix_file_f_test;
extern Integer Integer__unix_file_f_tlock;
extern Integer Integer__unix_file_f_ulock;
extern Integer Integer__unix_file_f_unlck;
extern Integer Integer__unix_file_f_wrlck;
extern Unsigned Unsigned__unix_file_o_accmode;
extern Unsigned Unsigned__unix_file_o_append;
extern Unsigned Unsigned__unix_file_o_async;
extern Unsigned Unsigned__unix_file_o_cloexec;
extern Unsigned Unsigned__unix_file_o_creat;
extern Unsigned Unsigned__unix_file_o_directory;
extern Unsigned Unsigned__unix_file_o_dsync;
extern Unsigned Unsigned__unix_file_o_excl;
extern Unsigned Unsigned__unix_file_o_noctty;
extern Unsigned Unsigned__unix_file_o_nofollow;
extern Unsigned Unsigned__unix_file_o_nonblock;
extern Unsigned Unsigned__unix_file_o_rdonly;
extern Unsigned Unsigned__unix_file_o_rdwr;
extern Unsigned Unsigned__unix_file_o_sync;
extern Unsigned Unsigned__unix_file_o_trunc;
extern Unsigned Unsigned__unix_file_o_wronly;
#endif /* UNIX_INCLUDED */
