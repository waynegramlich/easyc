#include "Expression.ez.h"/*cc2*/
/* # Copyright (c) 2004-2010 by Wayne C. Gramlich. */
/* # All rights reserved. */
/* # This module will generate code for expressions: */
#include "Compiler.ez.h"/*D1*/
#include "Declaration.ez.h"/*D1*/
#include "Easy_C.ez.h"/*D1*/
#include "Parse.ez.h"/*D1*/
#include "Token.ez.h"/*D1*/
#include "Statement.ez.h"/*D1*/
/* # {Code_Chunk} stuff: */
/* #undef lower case macros */
#undef i386
#undef linux
#undef unix
#undef errno
#undef makedev
#undef major
#undef minor
#undef alloca

void Code_Chunk__buffer_append(
  Code_Chunk code_chunk,
  String buffer)
{
    (void)String__buffer_append(code_chunk->code, buffer);
}

void Code_Chunk__character_append(
  Code_Chunk code_chunk,
  Character character)
{
    (void)String__character_append(code_chunk->code, character);
}

void Code_Chunk__chunk_append(
  Code_Chunk to_code_chunk,
  Code_Chunk from_code_chunk)
{
    (void)String__string_append(to_code_chunk->code, from_code_chunk->code);
    if (from_code_chunk->contains_call) {
        to_code_chunk->contains_call = Logical__true;
    }
}

void Code_Chunk__comma_types_append(
  Code_Chunk code_chunk,
  Comma_Separated comma_types)
{
    Array types;
    Unsigned size;
    Unsigned index;
    types = code_chunk->types;
    size = Comma_Separated__size_get(comma_types);
    index = 0;
    while ((index < size)) {
        (void)Array__append(types, ((void *)(((Type)Comma_Separated__fetch1(comma_types, index)))));
        index = (index+1);
    }
}

Code_Chunk Code_Chunk__create(void)
{
    Code_Chunk code_chunk;
    code_chunk = Code_Chunk__new();
    code_chunk->code = String__new();
    code_chunk->contains_call = Logical__false;
    return code_chunk;
}

void Code_Chunk__decimal_append(
  Code_Chunk code_chunk,
  Unsigned number)
{
    (void)Unsigned__buffer_append(number, code_chunk->code);
}

String Code_Chunk__f(
  Code_Chunk code_chunk)
{
    Logical expanded;
    String value;
    Unsigned size;
    Unsigned index;
    Character character;
    String t__0;
    String t__1;
    expanded = Logical__false;
    value = Format__field_next();
    size = String__size_get(value);
    index = 0;
    while ((index < size)) {
        character = String__fetch1(value, index);
        if ((character == ((Character)'x'))) {
            expanded = Logical__true;
        }
        index = (index+1);
    }
    (void)String__trim(value, 0);
    if (expanded) {
        if ((code_chunk == Code_Chunk__null)) {
            (void)String__string_append(value, ((String)"\007{?? <>}"));
        } else {
            (void)String__string_append(value, (t__0 = String__form(((String)"\015{ %s% <%t%> }")), t__1 = String__f(code_chunk->code), String__divide(String__remainder((t__0), t__1), Array__f(code_chunk->types, ((String (*)(void *))(Type__f))))));
        }
    } else {
        (void)String__string_append(value, code_chunk->code);
    }
    return value;
}

void Code_Chunk__format(
  Code_Chunk code_chunk,
  String buffer)
{
    Unsigned anchor;
    Logical expanded;
    Unsigned size;
    Unsigned index;
    Character character;
    String prefix;
    Array types;
    anchor = String__format_begin(buffer);
    expanded = Logical__false;
    size = String__size_get(buffer);
    index = (anchor+1);
    character = ((Character)' ');
    while (((index < size)&&(character != ((Character)'%')))) {
        character = String__fetch1(buffer, index);
        if ((character == ((Character)'x'))) {
            expanded = Logical__true;
        }
        index = (index+1);
    }
    if (expanded) {
        if ((code_chunk == Code_Chunk__null)) {
            (void)String__string_gap_insert(buffer, ((String)"\007{?? <>}"));
        } else {
            (void)String__string_gap_insert(buffer, ((String)"\002{'"));
            (void)String__string_gap_insert(buffer, code_chunk->code);
            (void)String__string_gap_insert(buffer, ((String)"\003' <"));
            prefix = ((String)"\000");
            types = code_chunk->types;
            size = Array__size_get(types);
            index = 0;
            while ((index < size)) {
                (void)String__string_gap_insert(buffer, prefix);
                (void)Type__string_gap_insert(((Type)Array__fetch1(types, index)), buffer);
                prefix = ((String)"\002, ");
                index = (index+1);
            }
            (void)String__string_gap_insert(buffer, ((String)"\002>}"));
        }
    } else {
        (void)String__string_gap_insert(buffer, code_chunk->code);
    }
    (void)String__format_end(buffer, anchor);
}

void Code_Chunk__space_append(
  Code_Chunk code_chunk)
{
    (void)String__string_append(code_chunk->code, ((String)"\001 "));
}

void Code_Chunk__string_append(
  Code_Chunk code_chunk,
  String text)
{
    (void)String__string_append(code_chunk->code, text);
}

void Code_Chunk__typed_name_append(
  Code_Chunk code_chunk,
  Typed_Name typed_name)
{
    (void)Code_Chunk__string_append(code_chunk, Type__base_name(typed_name->type));
    (void)Code_Chunk__string_append(code_chunk, ((String)"\002__"));
    (void)Code_Chunk__string_append(code_chunk, typed_name->name->value);
}

Type Code_Chunk__type(
  Code_Chunk code_chunk,
  Expression expression)
{
    Type type;
    Array types;
    Unsigned size;
    Compiler compiler;
    String t__0;
    String t__1;
    type = Type__null;
    if ((code_chunk != Code_Chunk__null)) {
        types = code_chunk->types;
        size = Array__size_get(types);
        if ((size == 1)) {
            type = ((Type)Array__fetch1(types, 0));
        } else {
            compiler = Compiler__one_and_only();
            (void)Compiler__log(compiler, Expression__location_get(expression), (t__0 = String__form(((String)"\045Expression %e% evaluates to %d% types")), t__1 = Expression__f(expression), String__divide(String__remainder((t__0), t__1), Unsigned__f(size))));
        }
    }
    return type;
}

void Code_Chunk__type_append(
  Code_Chunk code_chunk,
  Type type)
{
    (void)Array__append(code_chunk->types, ((void *)(type)));
}

void Code_Chunk__types_append(
  Code_Chunk code_chunk,
  Array types)
{
    (void)Array__array_append(code_chunk->types, types);
}

/* # {Binary_Expression} routines: */
Code_Chunk Binary_Expression__c_emit(
  Binary_Expression binary,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token operator;
    Expression right_expression;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Logical is_conditional;
    Logical is_equals;
    Logical is_identical;
    Logical is_not_identical;
    Logical is_relational;
    Code_Chunk left_code_chunk;
    Code_Chunk right_code_chunk;
    Type left_type;
    Type right_type;
    String left_type_base;
    Define_Declaration define;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    left_expression = Expression__parenthesis_remove(binary->left);
    operator = binary->operator;
    right_expression = Expression__parenthesis_remove(binary->right);
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__4 = String__form(((String)"\053%p%=>c_emit@Binary_Expression(%e% %s% %e%)\n")), t__5 = Unsigned__f(level), t__6 = Expression__f(left_expression), t__7 = String__f(operator->value), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), Expression__f(right_expression))), Out_Stream__error);
    }
    code_chunk = Code_Chunk__null;
    is_conditional = Logical__false;
    is_equals = Logical__false;
    is_identical = Logical__false;
    is_not_identical = Logical__false;
    is_relational = Logical__false;
    switch (operator->lexeme) {
        case Lexeme___assign:
            code_chunk = Binary_Expression__assign_c_emit(binary, compiler, (level+1));
            break;
        case Lexeme___at_sign:
            code_chunk = Binary_Expression__typed_name_access_c_emit(binary, compiler, (level+1));
            break;
        case Lexeme___dot:
            code_chunk = Binary_Expression__field_access_c_emit(binary, compiler, (level+1));
            break;
        case Lexeme___conditional_and:
        case Lexeme___conditional_or:
            is_relational = Logical__true;
            is_conditional = Logical__true;
            break;
        case Lexeme___define_assign:
            code_chunk = Binary_Expression__define_assign_c_emit(binary, compiler, (level+1));
            break;
        case Lexeme___not_equal:
        case Lexeme___less_than:
        case Lexeme___less_than_or_equal:
        case Lexeme___greater_than:
        case Lexeme___greater_than_or_equal:
            is_relational = Logical__true;
            break;
        case Lexeme___equals:
            is_relational = Logical__true;
            is_equals = Logical__true;
            break;
        case Lexeme___identical:
            is_relational = Logical__true;
            is_equals = Logical__true;
            is_identical = Logical__true;
            break;
        case Lexeme___not_identical:
            is_relational = Logical__true;
            is_not_identical = Logical__true;
            break;
        default:
            (void)String__put((t__9 = String__form(((String)"\027Need some code for %l%\n")), String__divide((t__9), Lexeme__f(operator->lexeme))), Out_Stream__error);
            if (!(Logical__false)) {
                System__assert_fail((String)"\16Expression.ezc", 289);
            }
            break;
    }
    if (is_relational) {
        left_code_chunk = Expression__c_emit(left_expression, compiler, (level+1));
        right_code_chunk = Expression__c_emit(right_expression, compiler, (level+1));
        left_type = Code_Chunk__type(left_code_chunk, left_expression);
        right_type = Code_Chunk__type(right_code_chunk, right_expression);
        if (((left_type != Type__null)&&(right_type != Type__null))) {
            if (Type__equal(left_type, right_type)) {
                left_type_base = Type__base_name(left_type);
                define = ((Define_Declaration)Hash_Table__lookup(compiler->define_table, ((void *)(left_type_base))));
                if ((((define != Define_Declaration__null)&&Define_Declaration__is_enumeration(define))||Type__is_number_scalar(left_type))) {
                    code_chunk = Code_Chunk__create();
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\001("));
                    (void)Code_Chunk__chunk_append(code_chunk, left_code_chunk);
                    (void)Code_Chunk__space_append(code_chunk);
                    if (is_equals) {
                        (void)Code_Chunk__string_append(code_chunk, ((String)"\002=="));
                    } else if (is_not_identical) {
                        (void)Code_Chunk__string_append(code_chunk, ((String)"\002!="));
                    } else {
                        if (is_conditional) {
                            (void)Code_Chunk__string_append(code_chunk, ((String)"\001 "));
                            (void)Code_Chunk__string_append(code_chunk, operator->value);
                            (void)Code_Chunk__string_append(code_chunk, ((String)"\001 "));
                        } else {
                            (void)Code_Chunk__string_append(code_chunk, operator->value);
                        }
                    }
                    (void)Code_Chunk__space_append(code_chunk);
                    (void)Code_Chunk__chunk_append(code_chunk, right_code_chunk);
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
                    (void)Code_Chunk__type_append(code_chunk, compiler->type_logical);
                } else if ((is_identical||is_not_identical)) {
                    code_chunk = Code_Chunk__create();
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\001("));
                    (void)Code_Chunk__chunk_append(code_chunk, left_code_chunk);
                    if (is_identical) {
                        (void)Code_Chunk__string_append(code_chunk, ((String)"\004 == "));
                    } else {
                        (void)Code_Chunk__string_append(code_chunk, ((String)"\004 != "));
                    }
                    (void)Code_Chunk__chunk_append(code_chunk, right_code_chunk);
                    (void)Code_Chunk__type_append(code_chunk, compiler->type_logical);
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
                } else {
                    (void)Compiler__log(compiler, operator, (t__10 = String__form(((String)"\047%e% is not scalar type (Character, ...)")), String__divide((t__10), Expression__f(left_expression))));
                }
            } else {
                (void)Compiler__log(compiler, operator, (t__11 = String__form(((String)"\046%e% %s% %e% Type mismatch (%t% != %t%)")), t__12 = Expression__f(left_expression), t__13 = String__f(operator->value), t__14 = Expression__f(right_expression), t__15 = Type__f(left_type), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__11), t__12), t__13), t__14), t__15), Type__f(right_type))));
            }
        }
    }
    if ((code_chunk == Code_Chunk__null)) {
        code_chunk = Code_Chunk__create();
    }
    if (tracing) {
        (void)String__put((t__21 = String__form(((String)"\060%p%<=c_emit@Binary_Expression(%e% %s% %e%)=>%c%\n")), t__22 = Unsigned__f(level), t__23 = Expression__f(left_expression), t__24 = String__f(operator->value), t__25 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__21), t__22), t__23), t__24), t__25), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Code_Chunk Binary_Expression__assign_c_emit(
  Binary_Expression binary,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token assign;
    Expression right_expression;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    left_expression = Expression__parenthesis_remove(binary->left);
    assign = binary->operator;
    right_expression = Expression__parenthesis_remove(binary->right);
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__4 = String__form(((String)"\054%p%=>assign_c_emit@Binary_Expr(%e% %s% %e%)\n")), t__5 = Unsigned__f(level), t__6 = Expression__f(left_expression), t__7 = String__f(assign->value), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), Expression__f(right_expression))), Out_Stream__error);
    }
    if (!((assign->lexeme == Lexeme__assign))) {
        System__assert_fail((String)"\16Expression.ezc", 369);
    }
    code_chunk = Code_Chunk__null;
    switch (left_expression->kind) {
        case Expression_Kind___binary:
            code_chunk = Binary_Expression__binary_assign_c_emit(binary, compiler, (level+1));
            break;
        case Expression_Kind___bracket:
            code_chunk = Binary_Expression__array_assign_c_emit(binary, compiler, (level+1));
            break;
        case Expression_Kind___symbol:
            code_chunk = Binary_Expression__symbol_assign_c_emit(binary, compiler, (level+1));
            break;
        default:
            (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__8 = String__form(((String)"\067%e% must be either a symbol, field, or array assignment")), String__divide((t__8), Expression__f(left_expression))));
            break;
    }
    if (tracing) {
        (void)String__put((t__14 = String__form(((String)"\060%p%<=assign_c_emit@Bin_Expr(%e% %s% %e%) => %c%\n")), t__15 = Unsigned__f(level), t__16 = Expression__f(left_expression), t__17 = String__f(assign->value), t__18 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__14), t__15), t__16), t__17), t__18), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Code_Chunk Binary_Expression__define_assign_c_emit(
  Binary_Expression binary,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token define_assign;
    Expression right_expression;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Token symbol;
    Code_Chunk right_code_chunk;
    Type right_type;
    String variable_name;
    Variable variable;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    left_expression = Expression__parenthesis_remove(binary->left);
    define_assign = binary->operator;
    right_expression = Expression__parenthesis_remove(binary->right);
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__4 = String__form(((String)"\060%p%=>define_assign_c_emit@Bin_Expr(%e% %s% %e%)\n")), t__5 = Unsigned__f(level), t__6 = Expression__f(left_expression), t__7 = String__f(define_assign->value), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), Expression__f(right_expression))), Out_Stream__error);
    }
    if (!((define_assign->lexeme == Lexeme__define_assign))) {
        System__assert_fail((String)"\16Expression.ezc", 408);
    }
    code_chunk = Code_Chunk__null;
    switch (left_expression->kind) {
        case Expression_Kind___symbol:
            code_chunk = Code_Chunk__create();
            if (!((left_expression->kind == Expression_Kind__symbol))) {
                System__assert_fail((String)"\16Expression.ezc", 414);
            }
            symbol = ((left_expression->kind == Expression_Kind___symbol) ? left_expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 415));
            right_code_chunk = Expression__c_emit(right_expression, compiler, (level+1));
            right_type = Code_Chunk__type(right_code_chunk, right_expression);
            if ((right_type != Type__null)) {
                variable_name = symbol->value;
                variable = Compiler__variable_lookup(compiler, variable_name);
                if ((variable == Variable__null)) {

                    variable = Compiler__variable_insert(compiler, variable_name, right_type, Logical__false);
                    variable->level = compiler->level;
                    /* # Generate the assignment */
                    (void)Code_Chunk__string_append(code_chunk, (t__8 = String__form(((String)"\011%k% = %c%")), t__9 = String__f(variable_name), String__divide(String__remainder((t__8), t__9), Code_Chunk__f(right_code_chunk))));
                } else {

                    if (Type__equal(variable->type, right_type)) {
                        if ((variable->level == 0xffffffff)) {

                            variable->level = compiler->level;
                            /* # Generate the assignment: */
                            (void)Code_Chunk__string_append(code_chunk, (t__10 = String__form(((String)"\011%k% = %c%")), t__11 = String__f(variable_name), String__divide(String__remainder((t__10), t__11), Code_Chunk__f(right_code_chunk))));
                        } else {
                            (void)Compiler__log(compiler, define_assign, (t__12 = String__form(((String)"\035Variable %qv% defined earlier")), String__divide((t__12), String__f(variable_name))));
                        }
                    } else {
                        (void)Compiler__log(compiler, define_assign, (t__13 = String__form(((String)"\065Previous variable %qv% type %t% != expr %e% type %dt%")), t__14 = String__f(variable_name), t__15 = Type__f(variable->type), t__16 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder((t__13), t__14), t__15), t__16), Type__f(right_type))));
                    }
                }
            }
            break;
        default:
            (void)Compiler__log(compiler, define_assign, (t__17 = String__form(((String)"\076%e% is not a symbol; only a variable can be to the left of :@=")), String__divide((t__17), Expression__f(left_expression))));
            break;
    }
    if (tracing) {
        (void)String__put((t__23 = String__form(((String)"\067%p%<=define_assign_c_emit@Bin_Expr(%e% %s% %e%) => %c%\n")), t__24 = Unsigned__f(level), t__25 = Expression__f(left_expression), t__26 = String__f(define_assign->value), t__27 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__23), t__24), t__25), t__26), t__27), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Code_Chunk Binary_Expression__binary_assign_c_emit(
  Binary_Expression assign_expression,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token assign;
    Expression right_expression;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Binary_Expression binary_expression;
    Code_Chunk right_code_chunk;
    Expression record_expression;
    Expression field_expression;
    Token symbol;
    String field_name;
    Code_Chunk record_code_chunk;
    Type record_type;
    Type right_type;
    String record_type_base;
    Define_Declaration define;
    String bit_byte_name;
    String bit_name;
    String byte_name;
    String right_code;
    Type record_field_type;
    String record_field_name;
    Type variant_field_type;
    Variant_Clause variant;
    String kind_name;
    Expression name_expression;
    Expression type_expression;
    Type type;
    Token name;
    Typed_Name_Object typed_name_object;
    External_Named_Declaration external_named;
    String raw_string;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    String t__37;
    String t__38;
    String t__39;
    String t__40;
    String t__41;
    String t__42;
    String t__43;
    String t__44;
    String t__45;
    String t__46;
    String t__47;
    String t__48;
    String t__49;
    String t__50;
    String t__51;
    String t__52;
    String t__53;
    String t__54;
    String t__55;
    String t__56;
    String t__57;
    String t__58;
    String t__59;
    String t__60;
    String t__61;
    String t__62;
    String t__63;
    String t__64;
    String t__65;
    String t__66;
    String t__67;
    String t__68;
    String t__69;
    left_expression = Expression__parenthesis_remove(assign_expression->left);
    assign = assign_expression->operator;
    right_expression = Expression__parenthesis_remove(assign_expression->right);
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__4 = String__form(((String)"\060%p%=>binary_assign_c_emit@Bin_Expr(%e% %s% %e%)\n")), t__5 = Unsigned__f(level), t__6 = Expression__f(left_expression), t__7 = String__f(assign->value), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), Expression__f(right_expression))), Out_Stream__error);
    }
    switch (assign->lexeme) {
        case Lexeme___assign:
        case Lexeme___define_assign:
            /* do_nothing */
            break;
        default:
            if (!(Logical__false)) {
                System__assert_fail((String)"\16Expression.ezc", 483);
            }
            break;
    }
    code_chunk = Code_Chunk__create();
    if (!((left_expression->kind == Expression_Kind__binary))) {
        System__assert_fail((String)"\16Expression.ezc", 486);
    }
    binary_expression = ((left_expression->kind == Expression_Kind___binary) ? left_expression->kind__union.binary : (Binary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 487));
    right_code_chunk = Expression__c_emit(right_expression, compiler, (level+1));
    switch (binary_expression->operator->lexeme) {
        case Lexeme___dot:

            record_expression = binary_expression->left;
            field_expression = binary_expression->right;
            switch (field_expression->kind) {
                case Expression_Kind___symbol:
                    symbol = ((field_expression->kind == Expression_Kind___symbol) ? field_expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 497));
                    field_name = symbol->value;
                    record_code_chunk = Expression__c_emit(record_expression, compiler, (level+1));
                    record_type = Code_Chunk__type(record_code_chunk, record_expression);
                    right_type = Code_Chunk__type(right_code_chunk, right_expression);
                    if (((record_type != Type__null)&&(right_type != Type__null))) {
                        record_type_base = Type__base_name(record_type);
                        define = ((Define_Declaration)Hash_Table__lookup(compiler->define_table, ((void *)(record_type_base))));
                        if ((define == Define_Declaration__null)) {
                            (void)Compiler__log(compiler, Expression__location_get(record_expression), (t__8 = String__form(((String)"\036%e% is not a known record type")), String__divide((t__8), Expression__f(record_expression))));
                        } else {
                            if (Define_Declaration__is_registers(define)) {
                                if (tracing) {
                                    (void)String__d((t__11 = String__form(((String)"\024%p%%v% is registers\n")), t__12 = Unsigned__f(level), String__divide(String__remainder((t__11), t__12), String__f(record_type_base))));
                                }
                                /* # We are assigning to an I/O register: */
                                bit_byte_name = Define_Declaration__register_bit_byte_name(define, field_name);
                                bit_name = Define_Declaration__register_bit_name(define, field_name);
                                byte_name = Define_Declaration__register_byte_name(define, field_name);
                                if (((bit_byte_name != String__null)&&(bit_name != String__null))) {
                                    right_code = right_code_chunk->code;
                                    if (String__equal(right_code, ((String)"\0011"))) {
                                        (void)Code_Chunk__string_append(code_chunk, (t__13 = String__form(((String)"\015%s% |= 1<<%s%")), t__14 = String__f(bit_byte_name), String__divide(String__remainder((t__13), t__14), String__f(bit_name))));
                                    } else if (String__equal(right_code, ((String)"\0010"))) {
                                        (void)Code_Chunk__string_append(code_chunk, (t__15 = String__form(((String)"\020%s% &= ~(1<<%s%)")), t__16 = String__f(bit_byte_name), String__divide(String__remainder((t__15), t__16), String__f(bit_name))));
                                    } else {
                                        (void)Code_Chunk__string_append(code_chunk, (t__17 = String__form(((String)"\070if (%c%) { %s% |= (1<<%s%); } else { %s% &= ~(1<<%s%); }")), t__18 = Code_Chunk__f(right_code_chunk), t__19 = String__f(bit_byte_name), t__20 = String__f(bit_name), t__21 = String__f(bit_byte_name), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__17), t__18), t__19), t__20), t__21), String__f(bit_name))));
                                    }
                                } else if ((byte_name != String__null)) {
                                    (void)Code_Chunk__string_append(code_chunk, (t__22 = String__form(((String)"\010%s% = %c")), t__23 = String__f(byte_name), String__divide(String__remainder((t__22), t__23), Code_Chunk__f(right_code_chunk))));
                                } else {
                                    (void)Compiler__log(compiler, symbol, (t__24 = String__form(((String)"\041Field name %s% is not recoginized")), String__divide((t__24), String__f(field_name))));
                                }
                            } else {
                                if (tracing) {
                                    (void)String__d((t__27 = String__form(((String)"\021%p%%v% is record\n")), t__28 = Unsigned__f(level), String__divide(String__remainder((t__27), t__28), String__f(record_type_base))));
                                }
                                record_field_type = Define_Declaration__record_field_type(define, field_name);
                                record_field_name = Define_Declaration__record_field_name(define, field_name);
                                variant_field_type = Define_Declaration__variant_field_type(define, field_name);
                                /* #FIXME: deal with __set routines!!! */
                                if (((record_field_type == Type__null)&&(variant_field_type == Type__null))) {
                                    (void)Compiler__log(compiler, symbol, (t__29 = String__form(((String)"\046Field %ds% does not exist for type %t%")), t__30 = String__f(field_name), String__divide(String__remainder((t__29), t__30), Type__f(record_type))));
                                } else if ((record_field_type != Type__null)) {
                                    if (Type__equal(record_field_type, right_type)) {

                                        code_chunk = Code_Chunk__create();
                                        (void)Code_Chunk__string_append(code_chunk, (t__31 = String__form(((String)"\016%c%->%k% = %c%")), t__32 = Code_Chunk__f(record_code_chunk), t__33 = String__f(record_field_name), String__divide(String__remainder(String__remainder((t__31), t__32), t__33), Code_Chunk__f(right_code_chunk))));
                                    } else {
                                        (void)Compiler__log(compiler, assign, (t__34 = String__form(((String)"\045Type mismatch: %t% (%e%) != %t% (%e%)")), t__35 = Type__f(record_field_type), t__36 = Expression__f(left_expression), t__37 = Type__f(right_type), String__divide(String__remainder(String__remainder(String__remainder((t__34), t__35), t__36), t__37), Expression__f(right_expression))));
                                    }
                                } else if ((variant_field_type != Type__null)) {
                                    variant = Define_Declaration__variant_lookup(define, field_name);
                                    if (!((variant != Variant_Clause__null))) {
                                        System__assert_fail((String)"\16Expression.ezc", 576);
                                    }
                                    if (Type__equal(variant_field_type, right_type)) {

                                        /* #FIXME: Code evaluates {record_code_chunk} */
                                        /* # twice!!! */
                                        kind_name = variant->kind_name->value;
                                        code_chunk = Code_Chunk__create();
                                        (void)Code_Chunk__string_append(code_chunk, (t__38 = String__form(((String)"\057%c%->%k% = %s%___%s%; %c%->%k%__union.%k% = %c%")), t__39 = Code_Chunk__f(record_code_chunk), t__40 = String__f(kind_name), t__41 = String__f(Type__base_name(variant->kind_type)), t__42 = String__f(field_name), t__43 = Code_Chunk__f(record_code_chunk), t__44 = String__f(kind_name), t__45 = String__f(field_name), String__divide(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder((t__38), t__39), t__40), t__41), t__42), t__43), t__44), t__45), Code_Chunk__f(right_code_chunk))));
                                    } else {
                                        (void)Compiler__log(compiler, assign, (t__46 = String__form(((String)"\045Type mismatch: %t% (%e%) != %t% (%e%)")), t__47 = Type__f(variant_field_type), t__48 = Expression__f(left_expression), t__49 = Type__f(right_type), String__divide(String__remainder(String__remainder(String__remainder((t__46), t__47), t__48), t__49), Expression__f(right_expression))));
                                    }
                                } else {
                                    if (!(Logical__false)) {
                                        System__assert_fail((String)"\16Expression.ezc", 596);
                                    }
                                }
                            }
                        }
                    }
                    break;
                default:
                    (void)Compiler__log(compiler, Expression__location_get(field_expression), (t__50 = String__form(((String)"\037%e% must be a simple field name")), String__divide((t__50), Expression__f(field_expression))));
                    break;
            }
            break;
        case Lexeme___at_sign:

            name_expression = binary_expression->left;
            type_expression = binary_expression->right;
            type = Expression__type_convert(type_expression, compiler, level);
            if ((type != Type__null)) {

                switch (name_expression->kind) {
                    case Expression_Kind___symbol:
                        name = ((name_expression->kind == Expression_Kind___symbol) ? name_expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 609));
                        typed_name_object = Compiler__type_name_lookup(compiler, name->value, type, assign);
                        if ((typed_name_object != Typed_Name_Object__null)) {
                            switch (typed_name_object->kind) {
                                case Typed_Name_Object_Kind___global:
                                case Typed_Name_Object_Kind___external:

                                    (void)Code_Chunk__string_append(code_chunk, (t__51 = String__form(((String)"\016%s%__%s% = %c%")), t__52 = String__f(Type__base_name(type)), t__53 = String__f(name->value), String__divide(String__remainder(String__remainder((t__51), t__52), t__53), Code_Chunk__f(right_code_chunk))));
                                    break;
                                case Typed_Name_Object_Kind___external_named:

                                    external_named = ((typed_name_object->kind == Typed_Name_Object_Kind___external_named) ? typed_name_object->kind__union.external_named : (External_Named_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 621));
                                    raw_string = Token__string_convert(external_named->string);
                                    (void)Code_Chunk__string_append(code_chunk, (t__54 = String__form(((String)"\011%s% = %c%")), t__55 = String__f(raw_string), String__divide(String__remainder((t__54), t__55), Code_Chunk__f(right_code_chunk))));
                                    break;
                                default:
                                    (void)Compiler__log(compiler, assign, (t__56 = String__form(((String)"\051%s%@%t% is not a global/external variable")), t__57 = Token__f(name), String__divide(String__remainder((t__56), t__57), Type__f(type))));
                                    break;
                            }
                        }
                        break;
                    default:

                        (void)Compiler__log(compiler, Expression__location_get(name_expression), (t__58 = String__form(((String)"\047%e% is not a simple name to left of '@'")), String__divide((t__58), Expression__f(name_expression))));
                        break;
                }
            }
            break;
        default:
            (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__59 = String__form(((String)"\056%e% is not allowed to the left of an assignemt")), String__divide((t__59), Expression__f(left_expression))));
            break;
    }
    if (tracing) {
        (void)String__put((t__65 = String__form(((String)"\067%p%=>binary_assign_c_emit@Bin_Expr(%e% %s% %e%) => %c%\n")), t__66 = Unsigned__f(level), t__67 = Expression__f(left_expression), t__68 = String__f(assign->value), t__69 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__65), t__66), t__67), t__68), t__69), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Code_Chunk Binary_Expression__array_assign_c_emit(
  Binary_Expression binary,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token assign;
    Expression right_expression;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Bracket_Expression bracket_expression;
    Token open_bracket;
    Code_Chunk right_code_chunk;
    Expression expression1;
    Expression expression2;
    Code_Chunk code_chunk1;
    Code_Chunk code_chunk2;
    Type type1;
    String type1_base;
    Type type2;
    Type right_type;
    Typed_Name_Object typed_name_object;
    Routine_Declaration routine;
    Logical c_array_access;
    Type prototype;
    Routine_Type routine_type;
    Comma_Separated actual_takes_types;
    Comma_Separated takes_types;
    Comma_Separated return_types;
    String prefix;
    String postfix;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    String t__37;
    String t__38;
    String t__39;
    String t__40;
    left_expression = Expression__parenthesis_remove(binary->left);
    assign = binary->operator;
    right_expression = Expression__parenthesis_remove(binary->right);
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__4 = String__form(((String)"\057%p%=>array_assign_c_emit@Bin_Expr(%e% %s% %e%)\n")), t__5 = Unsigned__f(level), t__6 = Expression__f(left_expression), t__7 = String__f(assign->value), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), Expression__f(right_expression))), Out_Stream__error);
    }
    switch (assign->lexeme) {
        case Lexeme___assign:
        case Lexeme___define_assign:
            /* do_nothing */
            break;
        default:
            if (!(Logical__false)) {
                System__assert_fail((String)"\16Expression.ezc", 667);
            }
            break;
    }
    code_chunk = Code_Chunk__create();
    if (!((left_expression->kind == Expression_Kind__bracket))) {
        System__assert_fail((String)"\16Expression.ezc", 670);
    }
    bracket_expression = ((left_expression->kind == Expression_Kind___bracket) ? left_expression->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 671));
    open_bracket = bracket_expression->open_bracket;
    if ((open_bracket->lexeme == Lexeme__open_invoke)) {
        (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__8 = String__form(((String)"\054Can not assign to a routine invocation (%e%)")), String__divide((t__8), Expression__f(left_expression))));
    } else {
        if (!((open_bracket->lexeme == Lexeme__open_bracket))) {
            System__assert_fail((String)"\16Expression.ezc", 678);
        }
        right_code_chunk = Expression__c_emit(right_expression, compiler, (level+1));
        expression1 = bracket_expression->expression1;
        expression2 = bracket_expression->expression2;
        code_chunk1 = Expression__c_emit(expression1, compiler, (level+1));
        code_chunk2 = Expression__c_emit(expression2, compiler, (level+1));
        type1 = Code_Chunk__type(code_chunk1, expression1);
        type1_base = Type__base_name(type1);
        type2 = Code_Chunk__type(code_chunk2, expression2);
        right_type = Code_Chunk__type(right_code_chunk, right_expression);
        if (((type1 != Type__null)&&(type2 != Type__null)&&(right_type != Type__null))) {
            typed_name_object = Compiler__type_name_routine_lookup(compiler, ((String)"\006store1"), type1, open_bracket);
            if ((typed_name_object != Typed_Name_Object__null)) {

                routine = ((typed_name_object->kind == Typed_Name_Object_Kind___routine) ? typed_name_object->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 696));
                c_array_access = Routine_Declaration__c_array_access(routine);
                prototype = Routine_Declaration__prototype_extract(routine);
                routine_type = ((prototype->kind == Type_Kind___routine) ? prototype->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\16Expression.ezc", 699));
                actual_takes_types = routine_type->takes_types;
                prototype = Type__replace(prototype, routine->typed_name->type, type1, assign, (level+1));
                routine_type = ((prototype->kind == Type_Kind___routine) ? prototype->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\16Expression.ezc", 703));
                takes_types = routine_type->takes_types;
                return_types = routine_type->return_types;
                if ((Comma_Separated__size_get(takes_types) != 3)) {
                    (void)Compiler__log(compiler, assign, (t__9 = String__form(((String)"\061Routine store1@%t% has %d% arguments instead of 3")), t__10 = Type__f(type1), String__divide(String__remainder((t__9), t__10), Unsigned__f(Comma_Separated__size_get(takes_types)))));
                } else if ((Comma_Separated__size_get(return_types) != 0)) {
                    (void)Compiler__log(compiler, assign, (t__11 = String__form(((String)"\057Routine store1@%t% has %d% returns instead of 0")), t__12 = Type__f(type1), String__divide(String__remainder((t__11), t__12), Unsigned__f(Comma_Separated__size_get(return_types)))));
                } else if (!Type__equal(((Type)Comma_Separated__fetch1(takes_types, 0)), type1)) {
                    (void)Compiler__log(compiler, assign, (t__13 = String__form(((String)"\060Routine store1@%t% wants arg 1 to be %t% not %t%")), t__14 = Type__f(type1), t__15 = Type__f(((Type)Comma_Separated__fetch1(takes_types, 0))), String__divide(String__remainder(String__remainder((t__13), t__14), t__15), Type__f(type1))));
                } else if (!Type__equal(((Type)Comma_Separated__fetch1(takes_types, 1)), type2)) {
                    (void)Compiler__log(compiler, assign, (t__16 = String__form(((String)"\060Routine store1@%t% wants arg 2 to be %t% not %t%")), t__17 = Type__f(type1), t__18 = Type__f(((Type)Comma_Separated__fetch1(takes_types, 1))), String__divide(String__remainder(String__remainder((t__16), t__17), t__18), Type__f(type2))));
                } else if (!Type__equal(((Type)Comma_Separated__fetch1(takes_types, 2)), right_type)) {
                    (void)Compiler__log(compiler, assign, (t__19 = String__form(((String)"\057Routine store1%t% wants arg 3 to be %t% not %t%")), t__20 = Type__f(type1), t__21 = Type__f(((Type)Comma_Separated__fetch1(takes_types, 2))), String__divide(String__remainder(String__remainder((t__19), t__20), t__21), Type__f(right_type))));
                } else {

                    prefix = ((String)"\000");
                    postfix = ((String)"\000");
                    if (Type__equal(((Type)Comma_Separated__fetch1(actual_takes_types, 2)), ((Type)Comma_Separated__fetch1(takes_types, 2)))) {
                        /* do_nothing */
                    } else if (Type__is_scalar(((Type)Comma_Separated__fetch1(actual_takes_types, 2)))) {
                        prefix = ((String)"\010((CAST)(");
                        postfix = ((String)"\013)).xpointer");
                    } else {
                        prefix = ((String)"\011(void *)(");
                        postfix = ((String)"\001)");
                    }
                    code_chunk = Code_Chunk__create();
                    if (c_array_access) {
                        (void)Code_Chunk__string_append(code_chunk, (t__22 = String__form(((String)"\016%s%[%c%] = %c%")), t__23 = Code_Chunk__f(code_chunk1), t__24 = Code_Chunk__f(code_chunk2), String__divide(String__remainder(String__remainder((t__22), t__23), t__24), Code_Chunk__f(right_code_chunk))));
                    } else {
                        (void)Code_Chunk__string_append(code_chunk, (t__25 = String__form(((String)"\040%s%__store1(%c%, %c%, %s%%c%%s%)")), t__26 = String__f(type1_base), t__27 = Code_Chunk__f(code_chunk1), t__28 = Code_Chunk__f(code_chunk2), t__29 = String__f(prefix), t__30 = Code_Chunk__f(right_code_chunk), String__divide(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder((t__25), t__26), t__27), t__28), t__29), t__30), String__f(postfix))));
                        code_chunk->contains_call = Logical__true;
                    }
                }
            }
        }
        /* #else error already generated */
    }
    if (tracing) {
        (void)String__put((t__36 = String__form(((String)"\064%p%=>array_assign_c_emit@Bin_Expr(%e% %s% %e%)=>%c%\n")), t__37 = Unsigned__f(level), t__38 = Expression__f(left_expression), t__39 = String__f(assign->value), t__40 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__36), t__37), t__38), t__39), t__40), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Logical Binary_Expression__equal(
  Binary_Expression binary_expression1,
  Binary_Expression binary_expression2)
{
    Logical result;
    result = (Expression__equal(binary_expression1->left, binary_expression2->left)&&Token__equal(binary_expression1->operator, binary_expression2->operator)&&Expression__equal(binary_expression1->right, binary_expression2->right));
    return result;
}

Code_Chunk Binary_Expression__symbol_assign_c_emit(
  Binary_Expression binary,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token assign;
    Expression right_expression;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Token symbol;
    Code_Chunk right_code_chunk;
    String variable_name;
    Variable variable;
    Type right_type;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    left_expression = Expression__parenthesis_remove(binary->left);
    assign = binary->operator;
    right_expression = Expression__parenthesis_remove(binary->right);
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__4 = String__form(((String)"\060%p%=>symbol_assign_c_emit@Bin_Expr(%e% %s% %e%)\n")), t__5 = Unsigned__f(level), t__6 = Expression__f(left_expression), t__7 = String__f(assign->value), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), Expression__f(right_expression))), Out_Stream__error);
    }
    switch (assign->lexeme) {
        case Lexeme___assign:
        case Lexeme___define_assign:
            /* do_nothing */
            break;
        default:
            if (!(Logical__false)) {
                System__assert_fail((String)"\16Expression.ezc", 795);
            }
            break;
    }
    code_chunk = Code_Chunk__create();
    if (!((left_expression->kind == Expression_Kind__symbol))) {
        System__assert_fail((String)"\16Expression.ezc", 798);
    }
    symbol = ((left_expression->kind == Expression_Kind___symbol) ? left_expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 799));
    right_code_chunk = Expression__c_emit(right_expression, compiler, (level+1));
    variable_name = symbol->value;
    variable = Compiler__variable_lookup(compiler, variable_name);
    if ((variable == Variable__null)) {
        (void)Compiler__log(compiler, symbol, (t__8 = String__form(((String)"\051Argument/global/local %qv% is not defined")), String__divide((t__8), String__f(variable_name))));
    } else {
        right_type = Code_Chunk__type(right_code_chunk, right_expression);
        if ((right_type != Type__null)) {
            if (!Type__equal(variable->type, right_type)) {
                (void)Compiler__log(compiler, assign, (t__9 = String__form(((String)"\062Variable %qv% type %t% != expression %e% type %dt%")), t__10 = String__f(variable_name), t__11 = Type__f(variable->type), t__12 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder((t__9), t__10), t__11), t__12), Type__f(right_type))));
            }
            if ((variable->level == 0xffffffff)) {
                variable->level = compiler->level;
            }
            (void)Code_Chunk__string_append(code_chunk, (t__13 = String__form(((String)"\011%k% = %c%")), t__14 = String__f(variable_name), String__divide(String__remainder((t__13), t__14), Code_Chunk__f(right_code_chunk))));
        }
    }
    if (tracing) {
        (void)String__put((t__20 = String__form(((String)"\065%p%<=symbol_assign_c_emit@Bin_Expr(%e% %s% %e%)=>%c%\n")), t__21 = Unsigned__f(level), t__22 = Expression__f(left_expression), t__23 = String__f(assign->value), t__24 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__20), t__21), t__22), t__23), t__24), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Code_Chunk Binary_Expression__typed_name_access_c_emit(
  Binary_Expression binary,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token at_sign;
    Expression right_expression;
    Code_Chunk code_chunk;
    String temporary;
    Logical tracing;
    Token symbol;
    String left_name;
    Type right_type;
    Typed_Name_Object typed_name_object;
    String full_name;
    Routine_Declaration routine;
    Type prototype;
    String external_routine;
    External_Declaration external;
    External_Named_Declaration external_named;
    String raw_string;
    Global_Declaration global;
    Constant_Declaration constant;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    left_expression = Expression__parenthesis_remove(binary->left);
    at_sign = binary->operator;
    right_expression = Expression__parenthesis_remove(binary->right);
    code_chunk = Code_Chunk__null;
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__4 = String__form(((String)"\075%p%=>typed_name_access_c_emit@Binary_Expression(%e% %s% %e%)\n")), t__5 = Unsigned__f(level), t__6 = Expression__f(left_expression), t__7 = String__f(at_sign->value), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), Expression__f(right_expression))), Out_Stream__error);
    }
    if (!((at_sign->lexeme == Lexeme__at_sign))) {
        System__assert_fail((String)"\16Expression.ezc", 849);
    }
    switch (left_expression->kind) {
        case Expression_Kind___symbol:
            symbol = ((left_expression->kind == Expression_Kind___symbol) ? left_expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 853));
            left_name = symbol->value;
            right_type = Expression__type_convert(right_expression, compiler, (level+1));
            if (tracing) {
                (void)String__put((t__12 = String__form(((String)"\044%p%l_name=%ds% r_exp=%e% r_type=%t%\n")), t__13 = Unsigned__f(level), t__14 = String__f(left_name), t__15 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder((t__12), t__13), t__14), t__15), Type__f(right_type))), Out_Stream__error);
            }
            if ((right_type != Type__null)) {
                typed_name_object = Compiler__type_name_lookup(compiler, symbol->value, right_type, symbol);
                if ((typed_name_object == Typed_Name_Object__null)) {

                    if (tracing) {
                        (void)String__put(((String)"\016Lookup failed\n"), Out_Stream__error);
                    }
                } else {
                    full_name = String__new();
                    (void)String__string_append(full_name, (t__16 = String__form(((String)"\010%s%__%s%")), t__17 = String__f(Type__base_name(right_type)), String__divide(String__remainder((t__16), t__17), String__f(left_name))));
                    switch (typed_name_object->kind) {
                        case Typed_Name_Object_Kind___routine:
                            code_chunk = Code_Chunk__create();
                            routine = ((typed_name_object->kind == Typed_Name_Object_Kind___routine) ? typed_name_object->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 878));
                            prototype = Routine_Declaration__prototype_extract(routine);
                            if (!((prototype != Type__null))) {
                                System__assert_fail((String)"\16Expression.ezc", 880);
                            }
                            prototype = Type__replace(prototype, routine->typed_name->type, right_type, at_sign, (level+1));
                            (void)Code_Chunk__type_append(code_chunk, prototype);
                            external_routine = Routine_Declaration__external(routine);
                            if ((external_routine == String__null)) {
                                (void)Code_Chunk__string_append(code_chunk, full_name);
                            } else {
                                (void)Code_Chunk__string_append(code_chunk, external_routine);
                            }
                            break;
                        case Typed_Name_Object_Kind___external:
                            external = ((typed_name_object->kind == Typed_Name_Object_Kind___external) ? typed_name_object->kind__union.external : (External_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 891));
                            code_chunk = Code_Chunk__create();
                            (void)Code_Chunk__string_append(code_chunk, full_name);
                            (void)Code_Chunk__type_append(code_chunk, external->type);
                            break;
                        case Typed_Name_Object_Kind___external_named:
                            external_named = ((typed_name_object->kind == Typed_Name_Object_Kind___external_named) ? typed_name_object->kind__union.external_named : (External_Named_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 896));
                            raw_string = Token__string_convert(external_named->string);
                            code_chunk = Code_Chunk__create();
                            (void)Code_Chunk__string_append(code_chunk, raw_string);
                            break;
                        case Typed_Name_Object_Kind___global:
                            global = ((typed_name_object->kind == Typed_Name_Object_Kind___global) ? typed_name_object->kind__union.global : (Global_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 901));
                            code_chunk = Code_Chunk__create();
                            (void)Code_Chunk__string_append(code_chunk, full_name);
                            (void)Code_Chunk__type_append(code_chunk, global->type);
                            break;
                        case Typed_Name_Object_Kind___constant:

                            constant = ((typed_name_object->kind == Typed_Name_Object_Kind___constant) ? typed_name_object->kind__union.constant : (Constant_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 907));
                            code_chunk = Code_Chunk__create();
                            (void)Code_Chunk__typed_name_append(code_chunk, constant->typed_name);
                            (void)Code_Chunk__type_append(code_chunk, constant->type);
                            break;
                    }
                }
            }
            break;
        default:
            (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__18 = String__form(((String)"\047%e% must a routine/global/external name")), String__divide((t__18), Expression__f(left_expression))));
            break;
    }
    if (tracing) {
        (void)String__put((t__24 = String__form(((String)"\073%p%<=typed_name_access_c_emit@Bin_Expr(%e% %s% %e%) => %x%\n")), t__25 = Unsigned__f(level), t__26 = Expression__f(left_expression), t__27 = String__f(at_sign->value), t__28 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__24), t__25), t__26), t__27), t__28), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Code_Chunk Binary_Expression__field_access_c_emit(
  Binary_Expression binary,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token dot;
    Expression right_expression;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Code_Chunk left_code_chunk;
    Token symbol;
    String field_name;
    Type left_type;
    String left_type_base;
    Define_Declaration define;
    String bit_byte_name;
    String bit_name;
    String byte_name;
    Type record_field_type;
    Type variant_field_type;
    String routine_name;
    Typed_Name_Object typed_name_object;
    Routine_Declaration routine;
    Type prototype;
    Routine_Type routine_type;
    Comma_Separated return_types;
    Comma_Separated takes_types;
    Type return_type;
    Type argument_type;
    String record_field_name;
    Type final_record_field_type;
    Variant_Clause variant;
    Token operator;
    String label;
    String kind_name;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    String t__37;
    String t__38;
    String t__39;
    String t__40;
    String t__41;
    String t__42;
    String t__43;
    String t__44;
    String t__45;
    String t__46;
    String t__47;
    String t__48;
    String t__49;
    String t__50;
    String t__51;
    String t__52;
    String t__53;
    String t__54;
    String t__55;
    String t__56;
    String t__57;
    String t__58;
    String t__59;
    String t__60;
    String t__61;
    String t__62;
    String t__63;
    String t__64;
    String t__65;
    String t__66;
    String t__67;
    String t__68;
    String t__69;
    String t__70;
    String t__71;
    String t__72;
    String t__73;
    String t__74;
    String t__75;
    String t__76;
    String t__77;
    String t__78;
    String t__79;
    String t__80;
    String t__81;
    left_expression = Expression__parenthesis_remove(binary->left);
    dot = binary->operator;
    right_expression = Expression__parenthesis_remove(binary->right);
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__4 = String__form(((String)"\070%p%=>field_access_c_emit@Binary_Expression(%e% %s% %e%)\n")), t__5 = Unsigned__f(level), t__6 = Expression__f(left_expression), t__7 = String__f(dot->value), String__divide(String__remainder(String__remainder(String__remainder((t__4), t__5), t__6), t__7), Expression__f(right_expression))), Out_Stream__error);
    }
    if (!((dot->lexeme == Lexeme__dot))) {
        System__assert_fail((String)"\16Expression.ezc", 943);
    }
    code_chunk = Code_Chunk__null;
    left_code_chunk = Expression__c_emit(left_expression, compiler, (level+1));
    switch (right_expression->kind) {
        case Expression_Kind___symbol:
            symbol = ((right_expression->kind == Expression_Kind___symbol) ? right_expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 949));
            field_name = symbol->value;
            if (tracing) {
                (void)String__put((t__10 = String__form(((String)"\015%p%field=%s%\n")), t__11 = Unsigned__f(level), String__divide(String__remainder((t__10), t__11), String__f(field_name))), Out_Stream__error);
            }
            left_type = Code_Chunk__type(left_code_chunk, left_expression);
            if ((left_type != Type__null)) {
                left_type_base = Type__base_name(left_type);
                define = ((Define_Declaration)Hash_Table__lookup(compiler->define_table, ((void *)(left_type_base))));
                if ((define == Define_Declaration__null)) {
                    (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__12 = String__form(((String)"\037Type %t% is not defined for %e%")), t__13 = Type__f(left_type), String__divide(String__remainder((t__12), t__13), Expression__f(left_expression))));
                } else if (Define_Declaration__is_registers(define)) {
                    /* do_nothing */
                    bit_byte_name = Define_Declaration__register_bit_byte_name(define, field_name);
                    bit_name = Define_Declaration__register_bit_name(define, field_name);
                    byte_name = Define_Declaration__register_byte_name(define, field_name);
                    if (((bit_name != String__null)&&(bit_byte_name != String__null))) {

                        code_chunk = Code_Chunk__create();
                        (void)Code_Chunk__string_append(code_chunk, (t__14 = String__form(((String)"\027((%s% & (1<<%s%)) != 0)")), t__15 = String__f(bit_byte_name), String__divide(String__remainder((t__14), t__15), String__f(bit_name))));
                        (void)Code_Chunk__type_append(code_chunk, compiler->type_logical);
                    } else if ((byte_name != String__null)) {

                        code_chunk = Code_Chunk__create();
                        (void)Code_Chunk__string_append(code_chunk, byte_name);
                        (void)Code_Chunk__type_append(code_chunk, compiler->type_byte);
                    } else {
                        (void)Compiler__log(compiler, symbol, (t__16 = String__form(((String)"\044%s% is not a valid register/bit name")), String__divide((t__16), String__f(field_name))));
                    }
                } else {

                    record_field_type = Define_Declaration__record_field_type(define, field_name);
                    variant_field_type = Define_Declaration__variant_field_type(define, field_name);
                    if (((record_field_type == Type__null)&&(variant_field_type == Type__null))) {

                        routine_name = String__new();
                        (void)String__string_append(routine_name, (t__17 = String__form(((String)"\007%s%_get")), String__divide((t__17), String__f(field_name))));
                        routine_name = String__read_only_copy(routine_name);
                        typed_name_object = Compiler__type_name_routine_lookup(compiler, routine_name, left_type, dot);
                        if ((typed_name_object != Typed_Name_Object__null)) {
                            if (tracing) {
                                (void)String__put((t__21 = String__form(((String)"\021%p%Found %s%@%t%\n")), t__22 = Unsigned__f(level), t__23 = String__f(routine_name), String__divide(String__remainder(String__remainder((t__21), t__22), t__23), Type__f(left_type))), Out_Stream__error);
                            }
                            routine = ((typed_name_object->kind == Typed_Name_Object_Kind___routine) ? typed_name_object->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 1002));
                            prototype = Routine_Declaration__prototype_extract(routine);
                            if (!((prototype != Type__null))) {
                                System__assert_fail((String)"\16Expression.ezc", 1004);
                            }
                            prototype = Type__replace(prototype, routine->typed_name->type, left_type, dot, (level+1));
                            if ((prototype == Type__null)) {

                                /* do_nothing */
                            } else {
                                if (!((prototype->kind == Type_Kind__routine))) {
                                    System__assert_fail((String)"\16Expression.ezc", 1011);
                                }
                                routine_type = ((prototype->kind == Type_Kind___routine) ? prototype->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\16Expression.ezc", 1012));
                                if (tracing) {
                                    (void)String__put((t__26 = String__form(((String)"\021%p%prototype=%t%\n")), t__27 = Unsigned__f(level), String__divide(String__remainder((t__26), t__27), Type__f(prototype))), Out_Stream__error);
                                }
                                return_types = routine_type->return_types;
                                takes_types = routine_type->takes_types;
                                if ((Comma_Separated__size_get(return_types) != 1)) {
                                    (void)Compiler__log(compiler, dot, (t__28 = String__form(((String)"\045%s%@%t% returns %d% values (1 needed)")), t__29 = String__f(routine_name), t__30 = Type__f(left_type), String__divide(String__remainder(String__remainder((t__28), t__29), t__30), Unsigned__f(Comma_Separated__size_get(return_types)))));
                                } else if ((Comma_Separated__size_get(takes_types) != 1)) {
                                    (void)Compiler__log(compiler, dot, (t__31 = String__form(((String)"\046%s%@%t% takes %d% arguments (1 needed)")), t__32 = String__f(routine_name), t__33 = Type__f(left_type), String__divide(String__remainder(String__remainder((t__31), t__32), t__33), Unsigned__f(Comma_Separated__size_get(takes_types)))));
                                } else {

                                    return_type = ((Type)Comma_Separated__fetch1(return_types, 0));
                                    argument_type = ((Type)Comma_Separated__fetch1(takes_types, 0));
                                    if (tracing) {
                                        (void)String__put((t__37 = String__form(((String)"\040%p%arg_type=%t% return_type=%t%\n")), t__38 = Unsigned__f(level), t__39 = Type__f(argument_type), String__divide(String__remainder(String__remainder((t__37), t__38), t__39), Type__f(return_type))), Out_Stream__error);
                                    }
                                    if (!Type__equal(argument_type, left_type)) {
                                        (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__40 = String__form(((String)"\043%s%@%t% needs %t% (not %t%) as arg.")), t__41 = String__f(routine_name), t__42 = Type__f(left_type), t__43 = Type__f(argument_type), String__divide(String__remainder(String__remainder(String__remainder((t__40), t__41), t__42), t__43), Type__f(left_type))));
                                    } else {
                                        code_chunk = Code_Chunk__create();
                                        (void)Code_Chunk__string_append(code_chunk, (t__44 = String__form(((String)"\015%s%__%s%(%c%)")), t__45 = String__f(Type__base_name(left_type)), t__46 = String__f(routine_name), String__divide(String__remainder(String__remainder((t__44), t__45), t__46), Code_Chunk__f(left_code_chunk))));
                                        (void)Code_Chunk__type_append(code_chunk, return_type);
                                        code_chunk->contains_call = Logical__true;
                                    }
                                }
                            }
                        }
                    } else if ((record_field_type != Type__null)) {

                        record_field_name = Define_Declaration__record_field_name(define, field_name);
                        code_chunk = Code_Chunk__create();
                        final_record_field_type = Type__replace(record_field_type, define->type, left_type, dot, (level+1));
                        if (tracing) {
                            (void)String__put((t__50 = String__form(((String)"\033%p%record_type= %t% => %t%\n")), t__51 = Unsigned__f(level), t__52 = Type__f(record_field_type), String__divide(String__remainder(String__remainder((t__50), t__51), t__52), Type__f(final_record_field_type))), Out_Stream__error);
                        }
                        if (!Type__equal(record_field_type, final_record_field_type)) {

                            (void)Code_Chunk__string_append(code_chunk, (t__53 = String__form(((String)"\005(%s%)")), String__divide((t__53), String__f(Type__base_name(final_record_field_type)))));
                        }
                        code_chunk = Code_Chunk__create();
                        (void)Code_Chunk__string_append(code_chunk, (t__54 = String__form(((String)"\010%c%->%k%")), t__55 = Code_Chunk__f(left_code_chunk), String__divide(String__remainder((t__54), t__55), String__f(record_field_name))));
                        (void)Code_Chunk__type_append(code_chunk, final_record_field_type);
                    } else if ((variant_field_type != Type__null)) {
                        variant = Define_Declaration__variant_lookup(define, field_name);
                        /* # Now generate the code: */
                        /* # ((%e%->%k% == %s%___s%) ? %e%->%s%__union.%k% :  */
                        /* # System__variant_fail(file, line_number)) */
                        if (tracing) {
                            (void)String__put((t__58 = String__form(((String)"\024%p%variant_type=%t%\n")), t__59 = Unsigned__f(level), String__divide(String__remainder((t__58), t__59), Type__f(variant_field_type))), Out_Stream__error);
                        }
                        /* #FIXME:  We are evaluating {left_code_chunk} twice!!! */
                        operator = binary->operator;
                        label = ((String)"\006object");
                        if (Type__is_scalar(variant_field_type)) {
                            label = ((String)"\006scalar");
                        }
                        kind_name = variant->kind_name->value;
                        code_chunk = Code_Chunk__create();
                        (void)Code_Chunk__string_append(code_chunk, (t__60 = String__form(((String)"\141((%c%->%k% == %s%___%s%) ? %c%->%k%__union.%k% : (%s%)System__variant_%s%_fail((String)%e%, %d%))")), t__61 = Code_Chunk__f(left_code_chunk), t__62 = String__f(kind_name), t__63 = String__f(Type__base_name(variant->kind_type)), t__64 = String__f(field_name), t__65 = Code_Chunk__f(left_code_chunk), t__66 = String__f(kind_name), t__67 = String__f(field_name), t__68 = String__f(Type__c_base_name(variant_field_type)), t__69 = String__f(label), t__70 = String__f(operator->file->name), String__divide(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder((t__60), t__61), t__62), t__63), t__64), t__65), t__66), t__67), t__68), t__69), t__70), Unsigned__f(Token__line_number_get(operator)))));
                        (void)Code_Chunk__type_append(code_chunk, variant_field_type);
                    } else {
                        if (!(Logical__false)) {
                            System__assert_fail((String)"\16Expression.ezc", 1099);
                        }
                    }
                }
            }
            break;
        default:
            (void)Compiler__log(compiler, Expression__location_get(right_expression), (t__71 = String__form(((String)"\040%e should be a simple field name")), String__divide((t__71), Expression__f(right_expression))));
            break;
    }
    if ((code_chunk == Code_Chunk__null)) {
        code_chunk = Code_Chunk__create();
    }
    if (tracing) {
        (void)String__put((t__77 = String__form(((String)"\077%p%<=field_access_c_emit@Binary_Expression(%e% %s% %e%) => %x%\n")), t__78 = Unsigned__f(level), t__79 = Expression__f(left_expression), t__80 = String__f(dot->value), t__81 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__77), t__78), t__79), t__80), t__81), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Token Expression__location_get(
  Expression expression)
{
    Token location;
    Binary_Expression binary_expression;
    Bracket_Expression bracket_expression;
    List_Expression list_expression;
    Parenthesis_Expression parenthesis_expression;
    Unary_Expression unary_expression;
    Error error;
    Array tokens;
    location = Token__null;
    switch (expression->kind) {
        case Expression_Kind___binary:
            binary_expression = ((expression->kind == Expression_Kind___binary) ? expression->kind__union.binary : (Binary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1124));
            location = binary_expression->operator;
            break;
        case Expression_Kind___bracket:
            bracket_expression = ((expression->kind == Expression_Kind___bracket) ? expression->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1127));
            location = bracket_expression->open_bracket;
            break;
        case Expression_Kind___character:
            location = ((expression->kind == Expression_Kind___character) ? expression->kind__union.character : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1130));
            break;
        case Expression_Kind___float_number:
            location = ((expression->kind == Expression_Kind___float_number) ? expression->kind__union.float_number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1132));
            break;
        case Expression_Kind___number:
            location = ((expression->kind == Expression_Kind___number) ? expression->kind__union.number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1134));
            break;
        case Expression_Kind___list:
            list_expression = ((expression->kind == Expression_Kind___list) ? expression->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1136));
            location = list_expression->location;
            break;
        case Expression_Kind___parenthesis:
            parenthesis_expression = ((expression->kind == Expression_Kind___parenthesis) ? expression->kind__union.parenthesis : (Parenthesis_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1139));
            break;
        case Expression_Kind___string:
            location = ((expression->kind == Expression_Kind___string) ? expression->kind__union.string : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1141));
            break;
        case Expression_Kind___symbol:
            location = ((expression->kind == Expression_Kind___symbol) ? expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1143));
            break;
        case Expression_Kind___unary:
            unary_expression = ((expression->kind == Expression_Kind___unary) ? expression->kind__union.unary : (Unary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1145));
            location = unary_expression->operator;
            break;
        case Expression_Kind___error:
            error = ((expression->kind == Expression_Kind___error) ? expression->kind__union.error : (Error)System__variant_object_fail((String)"\16Expression.ezc", 1148));
            tokens = error->tokens;
            if ((Array__size_get(tokens) != 0)) {
                location = ((Token)Array__fetch1(tokens, 0));
            }
            break;
    }
    return location;
}

Type Expression__type_convert(
  Expression expression,
  Compiler compiler,
  Unsigned level)
{
    String temporary;
    Logical tracing;
    Type type;
    Token symbol;
    Bracket_Expression bracket_expression;
    Expression expression1;
    Token open_bracket;
    Expression expression2;
    Token close_bracket;
    Logical errors;
    Comma_Separated comma_types;
    Array sub_types;
    Array commas;
    Token sub_symbol;
    Type sub_type;
    List_Expression list_expression;
    Array operators;
    Unsigned size;
    Token operator;
    Array expressions;
    Unsigned index;
    Expression sub_expression;
    Parameterized_Type parameterized_type;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__2 = String__form(((String)"\027%p%=>type_convert(%e%)\n")), t__3 = Unsigned__f(level), String__divide(String__remainder((t__2), t__3), Expression__f(expression))), Out_Stream__error);
    }
    type = Type__null;
    switch (expression->kind) {
        case Expression_Kind___symbol:
            symbol = ((expression->kind == Expression_Kind___symbol) ? expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1172));
            type = Type__new();
            type->kind = Type_Kind___simple; type->kind__union.simple = symbol;
            break;
        case Expression_Kind___bracket:
            bracket_expression = ((expression->kind == Expression_Kind___bracket) ? expression->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1176));
            expression1 = bracket_expression->expression1;
            open_bracket = bracket_expression->open_bracket;
            expression2 = bracket_expression->expression2;
            close_bracket = bracket_expression->close_bracket;
            errors = Logical__false;
            switch (expression1->kind) {
                case Expression_Kind___symbol:
                    symbol = ((expression1->kind == Expression_Kind___symbol) ? expression1->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1185));
                    if (tracing) {
                        (void)String__put((t__6 = String__form(((String)"\021%p%base_name=%s%\n")), t__7 = Unsigned__f(level), String__divide(String__remainder((t__6), t__7), String__f(symbol->value))), Out_Stream__error);
                    }
                    comma_types = Comma_Separated__new();
                    sub_types = comma_types->sub_types;
                    commas = comma_types->commas;
                    switch (expression2->kind) {
                        case Expression_Kind___symbol:
                            sub_symbol = ((expression2->kind == Expression_Kind___symbol) ? expression2->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1195));
                            if (tracing) {
                                (void)String__put((t__10 = String__form(((String)"\017%p%symbol=%ds%\n")), t__11 = Unsigned__f(level), String__divide(String__remainder((t__10), t__11), String__f(sub_symbol->value))), Out_Stream__error);
                            }
                            sub_type = Expression__type_convert(expression2, compiler, (level+1));
                            if (!((sub_type != Type__null))) {
                                System__assert_fail((String)"\16Expression.ezc", 1200);
                            }
                            (void)Array__append(sub_types, ((void *)(sub_type)));
                            break;
                        case Expression_Kind___bracket:
                            if (tracing) {
                                (void)String__put((t__13 = String__form(((String)"\013%p%bracket\n")), String__divide((t__13), Unsigned__f(level))), Out_Stream__error);
                            }
                            sub_type = Expression__type_convert(expression2, compiler, (level+1));
                            if ((sub_type != Type__null)) {
                                (void)Array__append(sub_types, ((void *)(sub_type)));
                            }
                            break;
                        case Expression_Kind___list:
                            list_expression = ((expression2->kind == Expression_Kind___list) ? expression2->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1210));
                            /* # Make sure each operator in {operators} is a {comma}: */
                            if (tracing) {
                                (void)String__put((t__15 = String__form(((String)"\010%p%list\n")), String__divide((t__15), Unsigned__f(level))), Out_Stream__error);
                            }
                            operators = list_expression->operators;
                            size = Array__size_get(operators);
                            if ((size >= 2)) {
                                operator = ((Token)Array__fetch1(operators, 1));
                                if ((operator->lexeme == Lexeme__comma)) {
                                    (void)Array__append(commas, ((void *)(operator)));
                                } else {
                                    (void)Compiler__log(compiler, operator, (t__16 = String__form(((String)"\054%e% does not separate parameters with commas")), String__divide((t__16), Expression__f(expression2))));
                                    if (tracing) {
                                        (void)String__put((t__18 = String__form(((String)"\016%p%comma error")), String__divide((t__18), Unsigned__f(level))), Out_Stream__error);
                                    }
                                    errors = Logical__true;
                                }
                            }
                            /* # Convert each expression in {expressions} to a {parsed_type}: */
                            if (!errors) {
                                expressions = list_expression->expressions;
                                operators = list_expression->operators;
                                size = Array__size_get(expressions);
                                index = 0;
                                while ((index < size)) {
                                    sub_expression = ((Expression)Array__fetch1(expressions, index));
                                    if (tracing) {
                                        (void)String__put((t__22 = String__form(((String)"\016%p%[%d%]: %e%\n")), t__23 = Unsigned__f(level), t__24 = Unsigned__f(index), String__divide(String__remainder(String__remainder((t__22), t__23), t__24), Expression__f(sub_expression))), Out_Stream__error);
                                    }
                                    operator = ((Token)Array__fetch1(operators, index));
                                    if ((index != 0)) {
                                        (void)Array__append(commas, ((void *)(operator)));
                                    }
                                    sub_type = Expression__type_convert(sub_expression, compiler, (level+1));
                                    if ((sub_type == Type__null)) {
                                        (void)Compiler__log(compiler, Expression__location_get(sub_expression), (t__25 = String__form(((String)"\042%e% is not a correctly formed type")), String__divide((t__25), Expression__f(sub_expression))));
                                        errors = Logical__true;
                                    }
                                    (void)Array__append(sub_types, ((void *)(sub_type)));
                                    index = (index+1);
                                }
                            }
                            break;
                        default:
                            (void)Compiler__log(compiler, Expression__location_get(expression2), (t__26 = String__form(((String)"\042%e% is not a correctly formed type")), String__divide((t__26), Expression__f(expression2))));
                            break;
                    }
                    if (!errors) {
                        parameterized_type = Parameterized_Type__new();
                        parameterized_type->name = symbol;
                        parameterized_type->open_bracket = open_bracket;
                        parameterized_type->sub_types = comma_types;
                        parameterized_type->close_bracket = close_bracket;
                        type = Type__new();
                        type->kind = Type_Kind___parameterized; type->kind__union.parameterized = parameterized_type;
                    }
                    break;
                default:
                    (void)Compiler__log(compiler, Expression__location_get(expression1), (t__27 = String__form(((String)"\040%e% does not specify a base type")), String__divide((t__27), Expression__f(expression1))));
                    break;
            }
            break;
        default:
            (void)Compiler__log(compiler, Expression__location_get(expression), (t__28 = String__form(((String)"\027%e% is not a valid type")), String__divide((t__28), Expression__f(expression))));
            break;
    }
    if (tracing) {
        (void)String__put((t__32 = String__form(((String)"\036%p%<=type_convert(%e%) => %t%\n")), t__33 = Unsigned__f(level), t__34 = Expression__f(expression), String__divide(String__remainder(String__remainder((t__32), t__33), t__34), Type__f(type))), Out_Stream__error);
    }
    return type;
}

/* # {Bracket_Expression} routines: */
Code_Chunk Bracket_Expression__c_emit(
  Bracket_Expression bracket,
  Compiler compiler,
  Unsigned level)
{
    Code_Chunk code_chunk;
    code_chunk = Code_Chunk__null;
    switch (bracket->open_bracket->lexeme) {
        case Lexeme___open_bracket:
            code_chunk = Bracket_Expression__array_access_c_emit(bracket, compiler, level);
            break;
        case Lexeme___open_invoke:
            code_chunk = Bracket_Expression__invoke_c_emit(bracket, compiler, level);
            break;
        case Lexeme___type_invoke:
            code_chunk = Bracket_Expression__type_invoke_c_emit(bracket, compiler, level);
            break;
        default:
            if (!(Logical__false)) {
                System__assert_fail((String)"\16Expression.ezc", 1300);
            }
            break;
    }
    return code_chunk;
}

Logical Bracket_Expression__equal(
  Bracket_Expression bracket_expression1,
  Bracket_Expression bracket_expression2)
{
    Logical result;
    result = 1;
    result = (Expression__equal(bracket_expression1->expression1, bracket_expression2->expression1)&&Token__equal(bracket_expression1->open_bracket, bracket_expression2->open_bracket)&&Expression__equal(bracket_expression1->expression2, bracket_expression2->expression2)&&Token__equal(bracket_expression1->close_bracket, bracket_expression2->close_bracket));
    return 1;
}

Code_Chunk Bracket_Expression__type_invoke_c_emit(
  Bracket_Expression bracket,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token open_bracket;
    Expression right_expression;
    Token close_bracket;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Token routine_name;
    List_Expression list_expression;
    Array expressions;
    Unsigned expressions_size;
    Expression expression0;
    Code_Chunk code_chunk0;
    Type type0;
    Typed_Name typed_name;
    Typed_Name_Object typed_name_object;
    Routine_Declaration routine;
    Type prototype;
    Code_Chunk left_code_chunk;
    Type scalar_cast;
    String external;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    String t__37;
    String t__38;
    String t__39;
    String t__40;
    String t__41;
    left_expression = bracket->expression1;
    open_bracket = bracket->open_bracket;
    right_expression = bracket->expression2;
    close_bracket = bracket->close_bracket;
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__5 = String__form(((String)"\074%p%=>type_invoke_c_emit@bracket_expression(%e% %s% %e% %s%)\n")), t__6 = Unsigned__f(level), t__7 = Expression__f(left_expression), t__8 = String__f(open_bracket->value), t__9 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__5), t__6), t__7), t__8), t__9), String__f(close_bracket->value))), Out_Stream__error);
    }
    if (!((open_bracket->lexeme == Lexeme__type_invoke))) {
        System__assert_fail((String)"\16Expression.ezc", 1346);
    }
    if (!((close_bracket->lexeme == Lexeme__close_invoke))) {
        System__assert_fail((String)"\16Expression.ezc", 1347);
    }
    code_chunk = Code_Chunk__create();
    switch (left_expression->kind) {
        case Expression_Kind___symbol:
            routine_name = ((left_expression->kind == Expression_Kind___symbol) ? left_expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1352));
            right_expression = Expression__comma_listify(right_expression);
            list_expression = ((right_expression->kind == Expression_Kind___list) ? right_expression->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1355));
            expressions = list_expression->expressions;
            expressions_size = Array__size_get(expressions);
            if ((expressions_size == 0)) {
                (void)Compiler__log(compiler, open_bracket, (t__10 = String__form(((String)"\061'%s%@(' must be followed by at least one argument")), String__divide((t__10), String__f(routine_name->value))));
            } else {
                expression0 = ((Expression)Array__fetch1(expressions, 0));
                code_chunk0 = Expression__c_emit(expression0, compiler, (level+1));
                type0 = Code_Chunk__type(code_chunk0, expression0);
                if ((type0 != Type__null)) {


                    typed_name = compiler->typed_name;
                    typed_name->name = routine_name;
                    typed_name->type = type0;
                    typed_name_object = Compiler__typed_name_lookup(compiler, typed_name, open_bracket);
                    if ((typed_name_object == Typed_Name_Object__null)) {

                        /* do_nothing */
                    } else if ((typed_name_object->kind != Typed_Name_Object_Kind__routine)) {
                        (void)Compiler__log(compiler, open_bracket, (t__11 = String__form(((String)"\024%t% is not a routine")), String__divide((t__11), Typed_Name__f(typed_name))));
                    } else {
                        routine = ((typed_name_object->kind == Typed_Name_Object_Kind___routine) ? typed_name_object->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 1382));
                        prototype = Routine_Declaration__prototype_extract(routine);
                        if (!((prototype != Type__null))) {
                            System__assert_fail((String)"\16Expression.ezc", 1385);
                        }
                        prototype = Type__replace(prototype, routine->typed_name->type, type0, open_bracket, (level+1));
                        left_code_chunk = Code_Chunk__create();
                        scalar_cast = Routine_Declaration__scalar_cast(routine);
                        external = Routine_Declaration__external(routine);
                        if ((external != String__null)) {
                            if (tracing) {
                                (void)String__d((t__14 = String__form(((String)"\020%p%external=%v%\n")), t__15 = Unsigned__f(level), String__divide(String__remainder((t__14), t__15), String__f(external))));
                            }
                            (void)Code_Chunk__string_append(left_code_chunk, external);
                            (void)Compiler__routine_call(compiler, left_expression, ((prototype->kind == Type_Kind___routine) ? prototype->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\16Expression.ezc", 1399)), left_code_chunk, open_bracket, expressions, code_chunk, (level+1));
                        } else if ((scalar_cast != Type__null)) {
                            if (tracing) {
                                (void)String__d((t__18 = String__form(((String)"\016%p%scalar=%t%\n")), t__19 = Unsigned__f(level), String__divide(String__remainder((t__18), t__19), Type__f(scalar_cast))));
                            }
                            if ((expressions_size != 1)) {
                                (void)Compiler__log(compiler, open_bracket, (t__20 = String__form(((String)"\054%s@(...) must be called with only 1 argument")), String__divide((t__20), String__f(routine_name->value))));
                            } else {
                                (void)Code_Chunk__string_append(code_chunk, (t__21 = String__form(((String)"\014((%s%)(%c%))")), t__22 = String__f(Type__base_name(scalar_cast)), String__divide(String__remainder((t__21), t__22), Code_Chunk__f(code_chunk0))));
                                (void)Code_Chunk__type_append(code_chunk, scalar_cast);
                            }
                        } else {
                            if (tracing) {
                                (void)String__d((t__25 = String__form(((String)"\017%p%routine=%v%\n")), t__26 = Unsigned__f(level), String__divide(String__remainder((t__25), t__26), String__f(routine_name->value))));
                            }
                            (void)Code_Chunk__string_append(left_code_chunk, (t__27 = String__form(((String)"\010%s%__%s%")), t__28 = String__f(Type__base_name(type0)), String__divide(String__remainder((t__27), t__28), String__f(routine_name->value))));
                            (void)Compiler__routine_call(compiler, left_expression, ((prototype->kind == Type_Kind___routine) ? prototype->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\16Expression.ezc", 1422)), left_code_chunk, open_bracket, expressions, code_chunk, (level+1));
                        }
                    }
                }
            }
            break;
        default:
            (void)Compiler__log(compiler, open_bracket, (t__29 = String__form(((String)"\040%e% @(...) is not a routine name")), String__divide((t__29), Expression__f(left_expression))));
            break;
    }
    if (tracing) {
        (void)String__put((t__36 = String__form(((String)"\073%p%<=type_invoke_c_emit@bracket_expr(%e% %s% %e% %s%)=>%x%\n")), t__37 = Unsigned__f(level), t__38 = Expression__f(left_expression), t__39 = String__f(open_bracket->value), t__40 = Expression__f(right_expression), t__41 = String__f(close_bracket->value), String__divide(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder((t__36), t__37), t__38), t__39), t__40), t__41), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Code_Chunk Bracket_Expression__invoke_c_emit(
  Bracket_Expression bracket,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token open_bracket;
    Expression right_expression;
    Token close_bracket;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Code_Chunk left_code_chunk;
    Type left_type;
    List_Expression list_expression;
    Array expressions;
    Unsigned expressions_size;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    left_expression = bracket->expression1;
    open_bracket = bracket->open_bracket;
    right_expression = bracket->expression2;
    close_bracket = bracket->close_bracket;
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__5 = String__form(((String)"\067%p%=>invoke_c_emit@bracket_expression(%e% %s% %e% %s%)\n")), t__6 = Unsigned__f(level), t__7 = Expression__f(left_expression), t__8 = String__f(open_bracket->value), t__9 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__5), t__6), t__7), t__8), t__9), String__f(close_bracket->value))), Out_Stream__error);
    }
    if (!((open_bracket->lexeme == Lexeme__open_invoke))) {
        System__assert_fail((String)"\16Expression.ezc", 1459);
    }
    if (!((close_bracket->lexeme == Lexeme__close_invoke))) {
        System__assert_fail((String)"\16Expression.ezc", 1460);
    }
    code_chunk = Code_Chunk__create();
    left_code_chunk = Expression__c_emit(left_expression, compiler, (level+1));
    left_type = Code_Chunk__type(left_code_chunk, left_expression);
    right_expression = Expression__comma_listify(right_expression);
    list_expression = ((right_expression->kind == Expression_Kind___list) ? right_expression->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1466));
    expressions = list_expression->expressions;
    expressions_size = Array__size_get(expressions);
    if ((left_type != Type__null)) {
        switch (left_type->kind) {
            case Type_Kind___routine:
                (void)Compiler__routine_call(compiler, left_expression, ((left_type->kind == Type_Kind___routine) ? left_type->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\16Expression.ezc", 1473)), left_code_chunk, open_bracket, expressions, code_chunk, (level+1));
                break;
            default:
                (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__10 = String__form(((String)"\025%qe% is not a routine")), String__divide((t__10), Expression__f(left_expression))));
                break;
        }
    }
    if (tracing) {
        (void)String__put((t__17 = String__form(((String)"\076%p%<=invoke_c_emit@bracket_expression(%e% %s% %e% %s%) => %x%\n")), t__18 = Unsigned__f(level), t__19 = Expression__f(left_expression), t__20 = String__f(open_bracket->value), t__21 = Expression__f(right_expression), t__22 = String__f(close_bracket->value), String__divide(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder((t__17), t__18), t__19), t__20), t__21), t__22), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

void Compiler__routine_call(
  Compiler compiler,
  Expression left_expression,
  Routine_Type routine_type,
  Code_Chunk left_code_chunk,
  Token open_bracket,
  Array expressions,
  Code_Chunk code_chunk,
  Unsigned level)
{
    String temporary;
    Logical tracing;
    Unsigned level1;
    Comma_Separated return_types;
    Unsigned return_types_size;
    Comma_Separated takes_types;
    Unsigned takes_types_size;
    Type return_type;
    Unsigned expressions_size;
    String temporary_name;
    Logical need_close_parenthesis;
    Logical need_close_cast;
    String prefix;
    Unsigned index;
    Type take_type;
    Expression sub_expression;
    Code_Chunk sub_code_chunk;
    Token symbol;
    String symbol_name;
    Variable variable;
    Typed_Name_Object typed_name_object;
    Constant_Declaration constant;
    Expression constant_expression;
    Type actual_type;
    Type sub_type;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__5 = String__form(((String)"\071%p%=>routine_call@Compiler(*, %e%, %r%, %c%, %qv%, *, *)\n")), t__6 = Unsigned__f(level), t__7 = Expression__f(left_expression), t__8 = Routine_Type__f(routine_type), t__9 = Code_Chunk__f(left_code_chunk), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__5), t__6), t__7), t__8), t__9), String__f(open_bracket->value))), Out_Stream__error);
    }
    level1 = (level+1);
    return_types = routine_type->return_types;
    return_types_size = Comma_Separated__size_get(return_types);
    takes_types = routine_type->takes_types;
    takes_types_size = Comma_Separated__size_get(takes_types);
    return_type = Type__null;
    expressions_size = Array__size_get(expressions);
    temporary_name = ((String)"\000");
    if ((takes_types_size == expressions_size)) {
        need_close_parenthesis = Logical__false;
        need_close_cast = Logical__false;
        if ((return_types_size == 1)) {
            return_type = ((Type)Comma_Separated__fetch1(return_types, 0));
            if (return_type->replaced) {
                if (tracing) {
                    (void)String__d((t__11 = String__form(((String)"\023%p%return_replaced\n")), String__divide((t__11), Unsigned__f(level))));
                }
                if (Routine_Declaration__is_parameter(compiler->current_routine, return_type)) {
                    if (tracing) {
                        (void)String__d((t__13 = String__form(((String)"\015%p%parameter\n")), String__divide((t__13), Unsigned__f(level))));
                    }
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\011((void *)"));
                } else if (Type__is_scalar(return_type)) {

                    /* # treat it like a scalar.  We generate the code */
                    /* # "(temp = (void **)exp, *(scalar *)(&temp))", */
                    /* # which is real ugly and hard to understand, but */
                    /* # it works 100% of the time: */
                    if (tracing) {
                        (void)String__d((t__15 = String__form(((String)"\012%p%scalar\n")), String__divide((t__15), Unsigned__f(level))));
                    }
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\011((void *)"));
                    temporary_name = Compiler__variable_temporary(compiler, compiler->type_pointer_pointer);
                    (void)Code_Chunk__string_append(code_chunk, (t__16 = String__form(((String)"\031(%s% = (Pointer_Pointer)(")), String__divide((t__16), String__f(temporary_name))));
                    need_close_cast = Logical__true;
                } else {
                    if (tracing) {
                        (void)String__d((t__18 = String__form(((String)"\013%p%default\n")), String__divide((t__18), Unsigned__f(level))));
                    }
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\002(("));
                    (void)Code_Chunk__string_append(code_chunk, Type__base_name(return_type));
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
                }
                need_close_parenthesis = Logical__true;
            }
        }
        (void)Code_Chunk__chunk_append(code_chunk, left_code_chunk);
        (void)Code_Chunk__string_append(code_chunk, ((String)"\001("));
        prefix = ((String)"\000");
        index = 0;
        while ((index < expressions_size)) {
            take_type = ((Type)Comma_Separated__fetch1(takes_types, index));
            sub_expression = ((Expression)Array__fetch1(expressions, index));
            /* # We allow simple enumeration names as arguments, provided they */
            /* # do not conflict with a variable/argument name. */
            sub_code_chunk = Code_Chunk__null;
            switch (sub_expression->kind) {
                case Expression_Kind___symbol:
                    symbol = ((sub_expression->kind == Expression_Kind___symbol) ? sub_expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1568));
                    symbol_name = symbol->value;
                    variable = Compiler__variable_lookup(compiler, symbol_name);
                    if ((variable == Variable__null)) {

                        typed_name_object = Compiler__type_name_lookup(compiler, symbol_name, take_type, Token__null);
                        if ((typed_name_object != Typed_Name_Object__null)) {


                            /* #FIXME: We should probably repartition with */
                            /* # {typed_name_access_c_emit@Binary_Expression()}!!! */
                            switch (typed_name_object->kind) {
                                case Typed_Name_Object_Kind___constant:
                                    constant = ((typed_name_object->kind == Typed_Name_Object_Kind___constant) ? typed_name_object->kind__union.constant : (Constant_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 1583));
                                    constant_expression = constant->expression;
                                    sub_code_chunk = Expression__constant_evaluate(constant_expression, compiler, level1);
                                    actual_type = Code_Chunk__type(sub_code_chunk, constant_expression);
                                    if (((actual_type == Type__null)||!Type__equal(constant->type, actual_type))) {

                                        sub_code_chunk = Code_Chunk__null;
                                    }
                                    /* #else all is well!! */
                                    break;
                            }
                        }
                    }
                    break;
            }
            if ((sub_code_chunk == Code_Chunk__null)) {

                sub_code_chunk = Expression__c_emit(sub_expression, compiler, level1);
            }
            sub_type = Type__null;
            if ((sub_code_chunk != Code_Chunk__null)) {
                sub_type = Code_Chunk__type(sub_code_chunk, sub_expression);
            }
            if ((sub_type != Type__null)) {
                if (Type__equal(take_type, sub_type)) {

                    (void)Code_Chunk__string_append(code_chunk, prefix);
                    prefix = ((String)"\002, ");
                    /* #call string_append@(code_chunk, "(") */
                    if ((Type__is_routine(sub_type)&&Type__is_replaced(take_type))) {

                        (void)Code_Chunk__string_append(code_chunk, ((String)"\002(("));
                        (void)Code_Chunk__string_append(code_chunk, Type__replaced_c_type(take_type, String__null));
                        (void)Code_Chunk__string_append(code_chunk, ((String)"\002)("));
                        (void)Code_Chunk__chunk_append(code_chunk, sub_code_chunk);
                        (void)Code_Chunk__string_append(code_chunk, ((String)"\002))"));
                    } else if (take_type->replaced) {
                        if (Type__is_scalar(take_type)) {
                            (void)Code_Chunk__string_append(code_chunk, ((String)"\010((CAST)("));
                            (void)Code_Chunk__chunk_append(code_chunk, sub_code_chunk);
                            (void)Code_Chunk__string_append(code_chunk, ((String)"\013)).xpointer"));
                        } else {
                            (void)Code_Chunk__string_append(code_chunk, ((String)"\012((void *)("));
                            (void)Code_Chunk__chunk_append(code_chunk, sub_code_chunk);
                            (void)Code_Chunk__string_append(code_chunk, ((String)"\002))"));
                        }
                    } else {
                        (void)Code_Chunk__chunk_append(code_chunk, sub_code_chunk);
                    }
                    /* #call string_append@(code_chunk, ")") */
                } else {
                    (void)Compiler__log(compiler, open_bracket, (t__19 = String__form(((String)"\052Argument %d% needs %t% but got %t% instead")), t__20 = Unsigned__f((index+1)), t__21 = Type__f(take_type), String__divide(String__remainder(String__remainder((t__19), t__20), t__21), Type__f(sub_type))));
                    break;
                }
            }
            index = (index+1);
        }
        (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
        code_chunk->contains_call = Logical__true;
        if (need_close_parenthesis) {
            (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
        }
        if (need_close_cast) {
            (void)Code_Chunk__string_append(code_chunk, (t__22 = String__form(((String)"\022), *(%s% *)(&%s%))")), t__23 = String__f(Type__base_name(return_type)), String__divide(String__remainder((t__22), t__23), String__f(temporary_name))));
        }
        (void)Code_Chunk__comma_types_append(code_chunk, return_types);
    } else {
        (void)Compiler__log(compiler, open_bracket, (t__24 = String__form(((String)"\071%qe% expects %d% arguments, but got %d% arguments instead")), t__25 = Expression__f(left_expression), t__26 = Unsigned__f(takes_types_size), String__divide(String__remainder(String__remainder((t__24), t__25), t__26), Unsigned__f(expressions_size))));
    }
    if (tracing) {
        (void)String__put((t__32 = String__form(((String)"\071%p%<=routine_call@Compiler(*, %e%, %r%, %c%, %qv%, *, *)\n")), t__33 = Unsigned__f(level), t__34 = Expression__f(left_expression), t__35 = Routine_Type__f(routine_type), t__36 = Code_Chunk__f(left_code_chunk), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__32), t__33), t__34), t__35), t__36), String__f(open_bracket->value))), Out_Stream__error);
    }
}

Code_Chunk Bracket_Expression__array_access_c_emit(
  Bracket_Expression bracket,
  Compiler compiler,
  Unsigned level)
{
    Expression left_expression;
    Token open_bracket;
    Expression right_expression;
    Token close_bracket;
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Code_Chunk left_code_chunk;
    Code_Chunk right_code_chunk;
    Type left_type;
    Routine_Declaration current_routine;
    Type right_type;
    Typed_Name_Object typed_name_object;
    Routine_Declaration routine;
    Type prototype;
    Logical c_array_access;
    Routine_Type routine_type;
    Comma_Separated takes_types;
    Comma_Separated return_types;
    Type return_type;
    Type argument_type0;
    Type argument_type1;
    Logical need_cast;
    String post_fix;
    String temporary_name;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    String t__37;
    String t__38;
    String t__39;
    String t__40;
    left_expression = bracket->expression1;
    open_bracket = bracket->open_bracket;
    right_expression = bracket->expression2;
    close_bracket = bracket->close_bracket;
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__5 = String__form(((String)"\075%p%=>array_access_c_emit@Bracket_Expression(%e% %s% %e% %s%)\n")), t__6 = Unsigned__f(level), t__7 = Expression__f(left_expression), t__8 = String__f(open_bracket->value), t__9 = Expression__f(right_expression), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__5), t__6), t__7), t__8), t__9), String__f(close_bracket->value))), Out_Stream__error);
    }
    code_chunk = Code_Chunk__create();
    left_code_chunk = Expression__c_emit(left_expression, compiler, (level+1));
    right_code_chunk = Expression__c_emit(right_expression, compiler, (level+1));
    left_type = Code_Chunk__type(left_code_chunk, left_expression);
    current_routine = compiler->current_routine;
    right_type = Code_Chunk__type(right_code_chunk, right_expression);
    if (((left_type != Type__null)&&(right_type != Type__null))) {
        typed_name_object = Compiler__type_name_routine_lookup(compiler, ((String)"\006fetch1"), left_type, open_bracket);
        if ((typed_name_object != Typed_Name_Object__null)) {
            routine = ((typed_name_object->kind == Typed_Name_Object_Kind___routine) ? typed_name_object->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 1692));
            prototype = Routine_Declaration__prototype_extract(routine);
            c_array_access = Routine_Declaration__c_array_access(routine);
            if (!((prototype != Type__null))) {
                System__assert_fail((String)"\16Expression.ezc", 1695);
            }
            prototype = Type__replace(prototype, routine->typed_name->type, left_type, Expression__location_get(left_expression), (level+1));
            if ((prototype != Type__null)) {
                routine_type = ((prototype->kind == Type_Kind___routine) ? prototype->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\16Expression.ezc", 1699));
                takes_types = routine_type->takes_types;
                return_types = routine_type->return_types;
                if ((Comma_Separated__size_get(takes_types) != 2)) {
                    (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__10 = String__form(((String)"\053fetch1@%t% takes %d% arguments instead of 2")), t__11 = Type__f(left_type), String__divide(String__remainder((t__10), t__11), Unsigned__f(Comma_Separated__size_get(takes_types)))));
                } else if ((Comma_Separated__size_get(return_types) != 1)) {
                    (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__12 = String__form(((String)"\052fetch1@%t% returns %d% values instead of 1")), t__13 = Type__f(left_type), String__divide(String__remainder((t__12), t__13), Unsigned__f(Comma_Separated__size_get(return_types)))));
                } else {
                    return_type = ((Type)Comma_Separated__fetch1(return_types, 0));
                    argument_type0 = ((Type)Comma_Separated__fetch1(takes_types, 0));
                    argument_type1 = ((Type)Comma_Separated__fetch1(takes_types, 1));
                    if (!Type__equal(argument_type0, left_type)) {
                        (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__14 = String__form(((String)"\050fetch1@%t% takes %t% as 1st arg, not %t%")), t__15 = Type__f(left_type), t__16 = Type__f(argument_type0), String__divide(String__remainder(String__remainder((t__14), t__15), t__16), Type__f(left_type))));
                    } else if (!Type__equal(argument_type1, right_type)) {
                        (void)Compiler__log(compiler, Expression__location_get(left_expression), (t__17 = String__form(((String)"\050fetch1@%t% takes %t% as 2nd arg, not %t%")), t__18 = Type__f(left_type), t__19 = Type__f(argument_type1), String__divide(String__remainder(String__remainder((t__17), t__18), t__19), Type__f(right_type))));
                    } else {
                        code_chunk = Code_Chunk__create();
                        /* #FIXME: is this needed!!! */
                        need_cast = Logical__false;
                        post_fix = ((String)"\000");
                        temporary_name = ((String)"\000");
                        if (return_type->replaced) {
                            if (Routine_Declaration__is_parameter(current_routine, return_type)) {
                                (void)Code_Chunk__string_append(code_chunk, ((String)"\011((void *)"));
                                post_fix = ((String)"\001)");
                            } else if (Type__is_scalar(return_type)) {
                                temporary_name = Compiler__variable_temporary(compiler, compiler->type_pointer_pointer);
                                (void)Code_Chunk__string_append(code_chunk, (t__20 = String__form(((String)"\031(%s% = (Pointer_Pointer)(")), String__divide((t__20), String__f(temporary_name))));
                                need_cast = Logical__true;
                            } else {
                                (void)Code_Chunk__string_append(code_chunk, ((String)"\002(("));
                                (void)Code_Chunk__string_append(code_chunk, Type__base_name(return_type));
                                (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
                                post_fix = ((String)"\001)");
                            }
                        }
                        if (c_array_access) {
                            (void)Code_Chunk__string_append(code_chunk, (t__21 = String__form(((String)"\010%c%[%c%]")), t__22 = Code_Chunk__f(left_code_chunk), String__divide(String__remainder((t__21), t__22), Code_Chunk__f(right_code_chunk))));
                        } else {
                            (void)Code_Chunk__string_append(code_chunk, (t__23 = String__form(((String)"\030%s%__fetch1(%c%, %c%)%s%")), t__24 = String__f(Type__base_name(left_type)), t__25 = Code_Chunk__f(left_code_chunk), t__26 = Code_Chunk__f(right_code_chunk), String__divide(String__remainder(String__remainder(String__remainder((t__23), t__24), t__25), t__26), String__f(post_fix))));
                        }
                        if (need_cast) {
                            (void)Code_Chunk__string_append(code_chunk, (t__27 = String__form(((String)"\022), *(%s% *)(&%s%))")), t__28 = String__f(Type__base_name(return_type)), String__divide(String__remainder((t__27), t__28), String__f(temporary_name))));
                        }
                        (void)Code_Chunk__type_append(code_chunk, return_type);
                        code_chunk->contains_call = Logical__true;
                    }
                }
            }
        }
    }
    if (tracing) {
        (void)String__put((t__35 = String__form(((String)"\076%p%<=array_access_c_emit@Bracket_Expr(%e% %s% %e% %s%) => %x%\n")), t__36 = Unsigned__f(level), t__37 = Expression__f(left_expression), t__38 = String__f(open_bracket->value), t__39 = Expression__f(right_expression), t__40 = String__f(close_bracket->value), String__divide(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder((t__35), t__36), t__37), t__38), t__39), t__40), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

/* # {Expression} routines: */
Code_Chunk Expression__c_emit(
  Expression expression,
  Compiler compiler,
  Unsigned level)
{
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Binary_Expression binary_expression;
    Bracket_Expression bracket_expression;
    Token character;
    Token float_number;
    String value;
    Unsigned size;
    Type type;
    Character suffix_character;
    Logical have_float_suffix;
    Logical have_double_suffix;
    List_Expression list_expression;
    Token number;
    Logical is_hex;
    Logical have_byte_suffix;
    Logical have_false_suffix;
    Logical have_integer_suffix;
    Logical have_short_suffix;
    Logical have_true_suffix;
    Logical have_unsigned_suffix;
    Logical have_long_integer_suffix;
    Logical have_long_unsigned_suffix;
    Parenthesis_Expression parenthesis_expression;
    Code_Chunk sub_code_chunk;
    Type sub_type;
    Token string;
    Token symbol;
    Unary_Expression unary_expression;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__2 = String__form(((String)"\034%p%=>c_emit@Expression(%e%)\n")), t__3 = Unsigned__f(level), String__divide(String__remainder((t__2), t__3), Expression__f(expression))), Out_Stream__error);
    }
    code_chunk = Code_Chunk__null;
    switch (expression->kind) {
        case Expression_Kind___binary:
            binary_expression = ((expression->kind == Expression_Kind___binary) ? expression->kind__union.binary : (Binary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1793));
            code_chunk = Binary_Expression__c_emit(binary_expression, compiler, (level+1));
            break;
        case Expression_Kind___bracket:
            bracket_expression = ((expression->kind == Expression_Kind___bracket) ? expression->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1796));
            code_chunk = Bracket_Expression__c_emit(bracket_expression, compiler, (level+1));
            break;
        case Expression_Kind___character:
            character = ((expression->kind == Expression_Kind___character) ? expression->kind__union.character : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1799));
            code_chunk = Expression__character_c_emit(character, compiler, (level+1));
            break;
        case Expression_Kind___error:
            /* do_nothing */
            break;
        case Expression_Kind___float_number:
            float_number = ((expression->kind == Expression_Kind___float_number) ? expression->kind__union.float_number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1805));
            code_chunk = Code_Chunk__create();
            /* # Take a peek at the back end: */
            value = float_number->value;
            size = String__size_get(value);
            type = compiler->type_double;
            if ((size != 0)) {
                suffix_character = String__fetch1(value, (size-1));
                have_float_suffix = ((suffix_character == ((Character)'f'))||(suffix_character == ((Character)'F')));
                have_double_suffix = ((suffix_character == ((Character)'d'))||(suffix_character == ((Character)'D')));
                if (have_double_suffix) {
                    value = String__writable_copy(value);
                    (void)String__trim(value, (size-1));
                }
                if (have_float_suffix) {
                    type = compiler->type_float;
                }
            }
            (void)Code_Chunk__string_append(code_chunk, value);
            (void)Code_Chunk__type_append(code_chunk, type);
            break;
        case Expression_Kind___list:
            list_expression = ((expression->kind == Expression_Kind___list) ? expression->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1826));
            code_chunk = List_Expression__c_emit(list_expression, compiler, (level+1));
            break;
        case Expression_Kind___number:
            number = ((expression->kind == Expression_Kind___number) ? expression->kind__union.number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1829));
            code_chunk = Code_Chunk__create();
            /* # Take a peek at the back end: */
            value = number->value;
            size = String__size_get(value);
            type = compiler->type_unsigned;
            if ((size != 0)) {

                suffix_character = String__fetch1(value, (size-1));
                is_hex = ((size >= 2)&&(String__fetch1(value, 0) == ((Character)'0'))&&(((String__fetch1(value, 1) == ((Character)'x'))||(String__fetch1(value, 1) == ((Character)'X')))));
                have_byte_suffix = (!is_hex&&(((suffix_character == ((Character)'b'))||(suffix_character == ((Character)'B')))));
                have_false_suffix = (!is_hex&&(((suffix_character == ((Character)'f'))||(suffix_character == ((Character)'F')))));
                have_integer_suffix = ((suffix_character == ((Character)'i'))||(suffix_character == ((Character)'I')));
                have_short_suffix = ((suffix_character == ((Character)'s'))||(suffix_character == ((Character)'S')));
                have_true_suffix = ((suffix_character == ((Character)'t'))||(suffix_character == ((Character)'T')));
                have_unsigned_suffix = ((suffix_character == ((Character)'u'))||(suffix_character == ((Character)'U')));
                /* # Deal with 'lu' and 'li' suffixes: */
                have_long_integer_suffix = 0;
                have_long_unsigned_suffix = 0;
                if ((have_integer_suffix||have_unsigned_suffix)) {
                    if ((size >= 2)) {
                        suffix_character = String__fetch1(value, (size-2));
                        if (((suffix_character == ((Character)'l'))||(suffix_character == ((Character)'L')))) {
                            have_long_integer_suffix = have_integer_suffix;
                            have_long_unsigned_suffix = have_unsigned_suffix;
                            have_integer_suffix = 0;
                            have_unsigned_suffix = 0;
                        }
                    }
                }
                /* # Trim the suffix off the number: */
                if ((have_byte_suffix||have_false_suffix||have_integer_suffix||have_short_suffix||have_true_suffix||have_unsigned_suffix)) {
                    value = String__writable_copy(value);
                    (void)String__trim(value, (size-1));
                } else if ((have_long_integer_suffix||have_long_unsigned_suffix)) {
                    value = String__writable_copy(value);
                    (void)String__trim(value, (size-2));
                    if (have_long_integer_suffix) {
                        (void)String__string_append(value, ((String)"\002ll"));
                    } else if (have_long_unsigned_suffix) {
                        (void)String__string_append(value, ((String)"\003ull"));
                    }
                }
                /* # Set {type} based on the suffix: */
                if (have_byte_suffix) {
                    type = compiler->type_byte;
                } else if (have_false_suffix) {
                    type = compiler->type_logical;
                } else if (have_integer_suffix) {
                    type = compiler->type_integer;
                } else if (have_long_integer_suffix) {
                    type = compiler->type_long_integer;
                } else if (have_long_unsigned_suffix) {
                    type = compiler->type_long_unsigned;
                } else if (have_short_suffix) {
                    type = compiler->type_short;
                } else if (have_true_suffix) {
                    type = compiler->type_logical;
                } else if (have_unsigned_suffix) {
                    type = compiler->type_unsigned;
                }
            }
            (void)Code_Chunk__string_append(code_chunk, value);
            (void)Code_Chunk__type_append(code_chunk, type);
            break;
        case Expression_Kind___parenthesis:
            parenthesis_expression = ((expression->kind == Expression_Kind___parenthesis) ? expression->kind__union.parenthesis : (Parenthesis_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1900));
            sub_code_chunk = Expression__c_emit(parenthesis_expression->expression, compiler, (level+1));
            sub_type = Code_Chunk__type(sub_code_chunk, parenthesis_expression->expression);
            if ((sub_type != Type__null)) {
                code_chunk = Code_Chunk__create();
                (void)Code_Chunk__string_append(code_chunk, ((String)"\001("));
                (void)Code_Chunk__chunk_append(code_chunk, sub_code_chunk);
                (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
                (void)Code_Chunk__type_append(code_chunk, sub_type);
            }
            break;
        case Expression_Kind___string:
            string = ((expression->kind == Expression_Kind___string) ? expression->kind__union.string : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1911));
            code_chunk = Expression__string_c_emit(string, compiler, (level+1));
            break;
        case Expression_Kind___symbol:
            symbol = ((expression->kind == Expression_Kind___symbol) ? expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 1914));
            code_chunk = Expression__symbol_c_emit(symbol, compiler, (level+1));
            break;
        case Expression_Kind___unary:
            unary_expression = ((expression->kind == Expression_Kind___unary) ? expression->kind__union.unary : (Unary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1917));
            code_chunk = Unary_Expression__c_emit(unary_expression, compiler, (level+1));
            break;
    }
    if (tracing) {
        (void)String__put((t__7 = String__form(((String)"\043%p%<=c_emit@Expression(%e%) => %x%\n")), t__8 = Unsigned__f(level), t__9 = Expression__f(expression), String__divide(String__remainder(String__remainder((t__7), t__8), t__9), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Code_Chunk Expression__character_c_emit(
  Token character,
  Compiler compiler,
  Unsigned level)
{
    Code_Chunk code_chunk;
    String raw_string;
    Unsigned raw_string_size;
    Character char___k;
    Unsigned code;
    String t__0;
    String t__1;
    code_chunk = Code_Chunk__null;
    raw_string = Token__string_convert(character);
    raw_string_size = String__size_get(raw_string);
    if ((raw_string_size == 0)) {
        (void)Compiler__log(compiler, character, (t__0 = String__form(((String)"\053Character literal %s% contains no character")), String__divide((t__0), String__f(character->value))));
    } else if ((raw_string_size > 1)) {
        (void)Compiler__log(compiler, character, (t__1 = String__form(((String)"\062Character literal %s% contains multiple characters")), String__divide((t__1), String__f(character->value))));
    } else {
        char___k = String__fetch1(raw_string, 0);
        code = ((Unsigned)(char___k));
        code_chunk = Code_Chunk__create();
        (void)Code_Chunk__string_append(code_chunk, ((String)"\014((Character)"));
        if (((code&0x80) != 0)) {

            (void)Code_Chunk__decimal_append(code_chunk, code);
            (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
        } else {
            (void)Code_Chunk__string_append(code_chunk, ((String)"\001'"));
            if ((Character__is_printing(char___k)&&(char___k != ((Character)'\047'))&&(char___k != ((Character)'\134')))) {
                (void)Code_Chunk__character_append(code_chunk, char___k);
            } else {
                (void)Code_Chunk__string_append(code_chunk, ((String)"\001\\"));
                code = ((Unsigned)(char___k));
                (void)Code_Chunk__character_append(code_chunk, String__fetch1(((String)"\01001234567"), (code>>6)));
                (void)Code_Chunk__character_append(code_chunk, String__fetch1(((String)"\01001234567"), (((code>>3))&7)));
                (void)Code_Chunk__character_append(code_chunk, String__fetch1(((String)"\01001234567"), (code&7)));
            }
            (void)Code_Chunk__string_append(code_chunk, ((String)"\002')"));
        }
        (void)Code_Chunk__type_append(code_chunk, compiler->type_character);
    }
    return code_chunk;
}

Code_Chunk Expression__constant_evaluate(
  Expression expression,
  Compiler compiler,
  Unsigned level)
{
    Logical tracing;
    Unsigned level1;
    Code_Chunk code_chunk;
    String failure;
    Binary_Expression binary;
    Expression left;
    Token operator;
    Expression right;
    Token symbol;
    String name;
    Type type;
    Typed_Name_Object typed_name_object;
    Constant_Declaration constant;
    Bracket_Expression bracket;
    Expression expression1;
    Token open_bracket;
    Expression expression2;
    String symbol_value;
    Code_Chunk constant_chunk;
    Token character;
    String value;
    Unsigned size;
    String temporary;
    Unsigned character_value;
    Token float_number;
    Character last;
    List_Expression list;
    Array operators;
    Array expressions;
    Token location;
    Array code_chunks;
    Array types;
    Unsigned index;
    Expression sub_expression;
    Code_Chunk sub_code_chunk;
    Type sub_type;
    Token number;
    Character first;
    Character second;
    Logical trim;
    Parenthesis_Expression parenthesis;
    Unary_Expression unary;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    Unsigned t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    tracing = Logical__false;
    if (tracing) {
        (void)String__d((t__2 = String__form(((String)"\046%p%=>constant_evalute@Expression(%e%)\n")), t__3 = Unsigned__f(level), String__divide(String__remainder((t__2), t__3), Expression__f(expression))));
    }
    level1 = (level+1);
    code_chunk = Code_Chunk__null;
    failure = String__null;
    switch (expression->kind) {
        case Expression_Kind___binary:
            binary = ((expression->kind == Expression_Kind___binary) ? expression->kind__union.binary : (Binary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 1996));
            left = binary->left;
            operator = binary->operator;
            right = binary->right;
            switch (operator->lexeme) {
                case Lexeme___at_sign:

                    switch (left->kind) {
                        case Expression_Kind___symbol:
                            symbol = ((left->kind == Expression_Kind___symbol) ? left->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2005));
                            name = symbol->value;
                            type = Expression__type_convert(right, compiler, level1);
                            if ((type == Type__null)) {
                                failure = ((String)"\016binary:no type");
                            } else {
                                typed_name_object = Compiler__type_name_lookup(compiler, name, type, operator);
                                if ((typed_name_object == Typed_Name_Object__null)) {
                                    failure = ((String)"\024binary:no typed_name");
                                } else {
                                    switch (typed_name_object->kind) {
                                        case Typed_Name_Object_Kind___constant:
                                            constant = ((typed_name_object->kind == Typed_Name_Object_Kind___constant) ? typed_name_object->kind__union.constant : (Constant_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 2018));
                                            code_chunk = Expression__constant_evaluate(constant->expression, compiler, (level+1));
                                            break;
                                        default:
                                            failure = ((String)"\022binary:no constant");
                                            break;
                                    }
                                }
                            }
                            break;
                        default:
                            failure = ((String)"\020binary:no symbol");
                            break;
                    }
                    break;
            }
            break;
        case Expression_Kind___bracket:
            bracket = ((expression->kind == Expression_Kind___bracket) ? expression->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2027));
            expression1 = bracket->expression1;
            open_bracket = bracket->open_bracket;
            expression2 = bracket->expression2;
            switch (open_bracket->lexeme) {
                case Lexeme___type_invoke:
                    switch (expression1->kind) {
                        case Expression_Kind___symbol:

                            symbol = ((expression1->kind == Expression_Kind___symbol) ? expression1->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2036));
                            symbol_value = symbol->value;
                            type = Compiler__scalar_lookup(compiler, symbol_value);
                            if ((type == Type__null)) {
                                (void)Compiler__log(compiler, symbol, (t__4 = String__form(((String)"\041%s%@() is not a scalar conversion")), String__divide((t__4), String__f(symbol_value))));
                            }
                            constant_chunk = Expression__constant_evaluate(expression2, compiler, level1);
                            code_chunk = Code_Chunk__create();
                            (void)Code_Chunk__string_append(code_chunk, (t__5 = String__form(((String)"\014((%c%)(%c%))")), t__6 = Type__f(type), String__divide(String__remainder((t__5), t__6), Code_Chunk__f(constant_chunk))));
                            (void)Code_Chunk__type_append(code_chunk, type);
                            break;
                        default:
                            if (!(Logical__false)) {
                                System__assert_fail((String)"\16Expression.ezc", 2050);
                            }
                            break;
                    }
                    break;
                default:
                    if (!(Logical__false)) {
                        System__assert_fail((String)"\16Expression.ezc", 2052);
                    }
                    break;
            }
            break;
        case Expression_Kind___character:
            character = ((expression->kind == Expression_Kind___character) ? expression->kind__union.character : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2054));
            value = character->value;
            size = String__size_get(value);
            if (((size == 3)&&(String__fetch1(value, 0) == ((Character)'\047'))&&(String__fetch1(value, 2) == ((Character)'\047')))) {

                /* do_nothing */
            } else if (((size >= 5)&&(String__fetch1(value, 0) == ((Character)'\047'))&&(String__fetch1(value, 1) == ((Character)'\134'))&&(String__fetch1(value, (size-1)) == ((Character)'\047'))&&(String__fetch1(value, (size-2)) == ((Character)'\134')))) {


                /* # Strip off the "'\" and the "\'": */
                temporary = compiler->temporary;
                (void)String__trim(temporary, 0);
                (void)String__string_append(temporary, value);
                (void)String__trim(temporary, (size-2));
                (void)String__lop(temporary);
                (void)String__lop(temporary);
                size = String__size_get(temporary);
                if (!((size >= 1))) {
                    System__assert_fail((String)"\16Expression.ezc", 2072);
                }
                character_value = 0;
                if (((size == 1)&&Character__is_decimal_digit(String__fetch1(temporary, 0)))) {
                    character_value = Character__decimal_convert(String__fetch1(temporary, 0));
                    (void)String__trim(temporary, 0);
                } else if (((size == 2)&&Character__is_decimal_digit(String__fetch1(temporary, 0))&&Character__is_decimal_digit(String__fetch1(temporary, 1)))) {
                    character_value = (t__7 = (Character__decimal_convert(String__fetch1(temporary, 0))*10), (t__7+Character__decimal_convert(String__fetch1(temporary, 1))));
                } else if (String__equal(temporary, ((String)"\001n"))) {
                    character_value = ((Unsigned)(((Character)'\012')));
                } else if (String__equal(temporary, ((String)"\001t"))) {
                    character_value = ((Unsigned)(((Character)'\011')));
                } else if (String__equal(temporary, ((String)"\001r"))) {
                    character_value = ((Unsigned)(((Character)'\015')));
                } else {
                    (void)Compiler__log(compiler, Expression__location_get(expression), (t__8 = String__form(((String)"\047%e% is not recognized (compiler error?)")), String__divide((t__8), Expression__f(expression))));
                }
                /* # Format the final value: */
                value = temporary;
                (void)String__trim(temporary, 0);
                (void)String__string_append(temporary, (t__9 = String__form(((String)"\006'\\%o%'")), String__divide((t__9), Unsigned__f(character_value))));
            } else {
                (void)Compiler__log(compiler, Expression__location_get(expression), (t__10 = String__form(((String)"\043Unrecognized character constant %e%")), String__divide((t__10), Expression__f(expression))));
                value = ((String)"\0010");
            }
            code_chunk = Code_Chunk__create();
            (void)Code_Chunk__string_append(code_chunk, value);
            (void)Code_Chunk__type_append(code_chunk, compiler->type_character);
            break;
        case Expression_Kind___error:
            /* do_nothing */
            break;
        case Expression_Kind___float_number:
            float_number = ((expression->kind == Expression_Kind___float_number) ? expression->kind__union.float_number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2108));
            code_chunk = Code_Chunk__create();
            temporary = compiler->temporary;
            (void)String__trim(temporary, 0);
            value = float_number->value;
            (void)String__string_append(temporary, value);
            type = compiler->type_double;
            size = String__size_get(value);
            if ((size >= 2)) {
                last = Character__lower_case(String__fetch1(value, (size-1)));
                if ((last == ((Character)'f'))) {
                    type = compiler->type_float;
                    (void)String__range_delete(temporary, (size-1), 1);
                } else if ((last == ((Character)'d'))) {
                    (void)String__range_delete(temporary, (size-1), 1);
                }
            }
            if ((type == compiler->type_float)) {
                (void)Code_Chunk__string_append(code_chunk, ((String)"\010((Float)"));
            } else if ((type == compiler->type_double)) {
                (void)Code_Chunk__string_append(code_chunk, ((String)"\011((Double)"));
            }
            (void)Code_Chunk__string_append(code_chunk, temporary);
            (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
            (void)Code_Chunk__type_append(code_chunk, type);
            if (tracing) {
                (void)String__d((t__13 = String__form(((String)"\037constant_evaluate@(%e%) => %t%\n")), t__14 = Expression__f(expression), String__divide(String__remainder((t__13), t__14), Type__f(type))));
            }
            break;
        case Expression_Kind___list:

            list = ((expression->kind == Expression_Kind___list) ? expression->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2136));
            operators = list->operators;
            expressions = list->expressions;
            location = list->location;
            size = Array__size_get(expressions);
            code_chunks = Array__new();
            types = Array__new();
            index = 0;
            while ((index < size)) {
                sub_expression = ((Expression)Array__fetch1(expressions, index));
                sub_code_chunk = Expression__constant_evaluate(sub_expression, compiler, level1);
                if ((sub_code_chunk == Code_Chunk__null)) {
                    failure = ((String)"\020list:no constant");
                    break;
                }
                (void)Array__append(code_chunks, ((void *)(sub_code_chunk)));
                sub_type = Code_Chunk__type(sub_code_chunk, sub_expression);
                if ((sub_type == Type__null)) {
                    failure = ((String)"\014list:no type");
                    break;
                }
                (void)Array__append(types, ((void *)(sub_type)));
                if ((index != 0)) {
                    if (!Type__equal(((Type)Array__fetch1(types, (index-1))), sub_type)) {
                        (void)Compiler__log(compiler, Expression__location_get(sub_expression), (t__15 = String__form(((String)"\045Type %t% (%e%) differs from %t% (%e%)")), t__16 = Type__f(((Type)Array__fetch1(types, (index-1)))), t__17 = Expression__f(((Expression)Array__fetch1(expressions, (index-1)))), t__18 = Type__f(sub_type), String__divide(String__remainder(String__remainder(String__remainder((t__15), t__16), t__17), t__18), Expression__f(sub_expression))));
                        failure = ((String)"\017list: type diff");
                        break;
                    }
                }
                index = (index+1);
            }
            if ((failure == String__null)) {
                code_chunk = Code_Chunk__create();
                (void)Code_Chunk__string_append(code_chunk, ((String)"\001("));
                index = 0;
                while ((index < size)) {
                    if ((index != 0)) {
                        (void)Code_Chunk__string_append(code_chunk, ((String)"\001 "));
                        (void)Code_Chunk__string_append(code_chunk, ((Token)Array__fetch1(operators, index))->value);
                        (void)Code_Chunk__string_append(code_chunk, ((String)"\001 "));
                    }
                    (void)Code_Chunk__chunk_append(code_chunk, ((Code_Chunk)Array__fetch1(code_chunks, index)));
                    index = (index+1);
                }
                (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
                (void)Array__append(code_chunk->types, ((void *)(((Type)Array__fetch1(types, 0)))));
            }
            break;
        case Expression_Kind___number:
            number = ((expression->kind == Expression_Kind___number) ? expression->kind__union.number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2180));
            code_chunk = Code_Chunk__create();
            temporary = compiler->temporary;
            (void)String__trim(temporary, 0);
            value = number->value;
            (void)String__string_append(temporary, value);
            type = compiler->type_unsigned;
            size = String__size_get(value);
            if ((size >= 2)) {
                first = String__fetch1(value, 0);
                second = String__fetch1(value, 1);
                last = String__fetch1(value, (size-1));
                if (tracing) {
                    (void)String__d((t__22 = String__form(((String)"\036first=%c% second=%c% last=%c%\n")), t__23 = Character__f(first), t__24 = Character__f(second), String__divide(String__remainder(String__remainder((t__22), t__23), t__24), Character__f(last))));
                }
                if (((first != ((Character)'0'))||((second != ((Character)'x'))&&(second != ((Character)'X'))))) {

                    trim = Logical__false;
                    if (((last == ((Character)'b'))||(last == ((Character)'B')))) {
                        type = compiler->type_byte;
                        trim = Logical__true;
                    } else if (((last == ((Character)'c'))||(last == ((Character)'C')))) {
                        type = compiler->type_character;
                        trim = Logical__true;
                    } else if (((last == ((Character)'i'))||(last == ((Character)'I')))) {
                        type = compiler->type_integer;
                        trim = Logical__true;
                    } else if (((last == ((Character)'s'))||(last == ((Character)'S')))) {
                        type = compiler->type_short;
                        trim = Logical__true;
                    } else if (((last == ((Character)'u'))||(last == ((Character)'U')))) {
                        type = compiler->type_unsigned;
                        trim = Logical__true;
                    }
                    if (trim) {
                        (void)String__trim(temporary, (size-1));
                    }
                }
            }
            (void)Code_Chunk__string_append(code_chunk, temporary);
            (void)Code_Chunk__type_append(code_chunk, type);
            if (tracing) {
                (void)String__d((t__27 = String__form(((String)"\037constant_evaluate@(%e%) => %t%\n")), t__28 = Expression__f(expression), String__divide(String__remainder((t__27), t__28), Type__f(type))));
            }
            break;
        case Expression_Kind___parenthesis:
            parenthesis = ((expression->kind == Expression_Kind___parenthesis) ? expression->kind__union.parenthesis : (Parenthesis_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2221));
            code_chunk = Expression__constant_evaluate(parenthesis->expression, compiler, level1);
            break;
        case Expression_Kind___string:
            failure = ((String)"\006string");
            break;
        case Expression_Kind___symbol:
            failure = ((String)"\006symbol");
            break;
        case Expression_Kind___unary:
            unary = ((expression->kind == Expression_Kind___unary) ? expression->kind__union.unary : (Unary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2229));
            sub_code_chunk = Expression__constant_evaluate(unary->expression, compiler, (level+1));
            code_chunk = Code_Chunk__create();
            (void)Code_Chunk__type_append(code_chunk, Code_Chunk__type(sub_code_chunk, expression));
            (void)Code_Chunk__string_append(code_chunk, ((String)"\001("));
            (void)Code_Chunk__string_append(code_chunk, unary->operator->value);
            (void)Code_Chunk__chunk_append(code_chunk, sub_code_chunk);
            (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
            break;
    }
    if ((failure != String__null)) {
        (void)Compiler__log(compiler, Expression__location_get(expression), (t__29 = String__form(((String)"\063Unable to evaluate %e% as a constant (reason: %vs%)")), t__30 = Expression__f(expression), String__divide(String__remainder((t__29), t__30), String__f(failure))));
    }
    if (tracing) {
        (void)String__d((t__34 = String__form(((String)"\056%p%<=constant_evalute@Expression(%e%) => %xc%\n")), t__35 = Unsigned__f(level), t__36 = Expression__f(expression), String__divide(String__remainder(String__remainder((t__34), t__35), t__36), Code_Chunk__f(code_chunk))));
    }
    return code_chunk;
}

Logical Expression__equal(
  Expression expression1,
  Expression expression2)
{
    Logical result;
    result = 0;
    switch (expression1->kind) {
        case Expression_Kind___binary:
            switch (expression2->kind) {
                case Expression_Kind___binary:
                    result = Binary_Expression__equal(((expression1->kind == Expression_Kind___binary) ? expression1->kind__union.binary : (Binary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2265)), ((expression2->kind == Expression_Kind___binary) ? expression2->kind__union.binary : (Binary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2265)));
                    break;
            }
            break;
        case Expression_Kind___bracket:
            switch (expression2->kind) {
                case Expression_Kind___bracket:
                    result = Bracket_Expression__equal(((expression1->kind == Expression_Kind___bracket) ? expression1->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2269)), ((expression2->kind == Expression_Kind___bracket) ? expression2->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2269)));
                    break;
            }
            break;
        case Expression_Kind___character:
            switch (expression2->kind) {
                case Expression_Kind___character:
                    result = Token__equal(((expression1->kind == Expression_Kind___character) ? expression1->kind__union.character : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2273)), ((expression2->kind == Expression_Kind___character) ? expression2->kind__union.character : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2273)));
                    break;
            }
            break;
        case Expression_Kind___float_number:
            switch (expression2->kind) {
                case Expression_Kind___float_number:
                    result = Token__equal(((expression1->kind == Expression_Kind___float_number) ? expression1->kind__union.float_number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2277)), ((expression2->kind == Expression_Kind___float_number) ? expression2->kind__union.float_number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2277)));
                    break;
            }
            break;
        case Expression_Kind___list:
            switch (expression2->kind) {
                case Expression_Kind___list:
                    result = List_Expression__equal(((expression1->kind == Expression_Kind___list) ? expression1->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2281)), ((expression2->kind == Expression_Kind___list) ? expression2->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2281)));
                    break;
            }
            break;
        case Expression_Kind___number:
            switch (expression2->kind) {
                case Expression_Kind___number:
                    result = Token__equal(((expression1->kind == Expression_Kind___number) ? expression1->kind__union.number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2285)), ((expression2->kind == Expression_Kind___number) ? expression2->kind__union.number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2285)));
                    break;
            }
            break;
        case Expression_Kind___parenthesis:
            switch (expression2->kind) {
                case Expression_Kind___parenthesis:
                    result = Expression__equal(((expression1->kind == Expression_Kind___parenthesis) ? expression1->kind__union.parenthesis : (Parenthesis_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2289))->expression, ((expression2->kind == Expression_Kind___parenthesis) ? expression2->kind__union.parenthesis : (Parenthesis_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2290))->expression);
                    break;
            }
            break;
        case Expression_Kind___string:
            switch (expression2->kind) {
                case Expression_Kind___string:
                    result = Token__equal(((expression1->kind == Expression_Kind___string) ? expression1->kind__union.string : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2294)), ((expression2->kind == Expression_Kind___string) ? expression2->kind__union.string : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2294)));
                    break;
            }
            break;
        case Expression_Kind___symbol:
            switch (expression2->kind) {
                case Expression_Kind___symbol:
                    result = Token__equal(((expression1->kind == Expression_Kind___symbol) ? expression1->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2298)), ((expression2->kind == Expression_Kind___symbol) ? expression2->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2298)));
                    break;
            }
            break;
        case Expression_Kind___unary:
            switch (expression2->kind) {
                case Expression_Kind___unary:
                    result = Unary_Expression__equal(((expression1->kind == Expression_Kind___unary) ? expression1->kind__union.unary : (Unary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2302)), ((expression2->kind == Expression_Kind___unary) ? expression2->kind__union.unary : (Unary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2302)));
                    break;
            }
            break;
        case Expression_Kind___error:
            /* do_nothing */
            break;
    }
    return result;
}

Array Expression__expression_list(
  Expression expression)
{
    List_Expression list_expression;
    Array operators;
    Unsigned operators_size;
    Array expressions;
    switch (expression->kind) {
        case Expression_Kind___list:
            list_expression = ((expression->kind == Expression_Kind___list) ? expression->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2319));
            operators = list_expression->operators;
            operators_size = Array__size_get(operators);
            if (((operators_size != 0)&&(((Token)Array__fetch1(operators, (operators_size-1)))->lexeme == Lexeme__comma))) {
                return list_expression->expressions;
            }
            break;
    }
    expressions = Array__new();
    (void)Array__append(expressions, ((void *)(expression)));
    return expressions;
}

Expression Expression__comma_listify(
  Expression expression)
{
    Expression new_expression;
    Logical listify;
    List_Expression list;
    Array operators;
    Unsigned size;
    List_Expression list_expression;
    new_expression = expression;
    listify = Logical__false;
    switch (expression->kind) {
        case Expression_Kind___list:
            list = ((expression->kind == Expression_Kind___list) ? expression->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2340));
            operators = list->operators;
            size = Array__size_get(operators);
            if ((size == 0)) {
                listify = Logical__false;
            } else if ((size == 1)) {
                listify = Logical__true;
            } else {

                listify = (((Token)Array__fetch1(operators, 1))->lexeme != Lexeme__comma);
            }
            break;
        default:
            listify = Logical__true;
            break;
    }
    if (listify) {
        list_expression = List_Expression__new();
        (void)Array__append(list_expression->operators, ((void *)(Token__null)));
        (void)Array__append(list_expression->expressions, ((void *)(expression)));
        list_expression->location = Expression__location_get(expression);
        new_expression = Expression__new();
        new_expression->kind = Expression_Kind___list; new_expression->kind__union.list = list_expression;
    }
    return new_expression;
}

String Expression__macro_evaluate(
  Expression expression,
  Compiler compiler,
  String result)
{
    Logical tracing;
    Binary_Expression binary;
    Expression name_expression;
    Expression type_expression;
    Type type;
    Token symbol;
    Bracket_Expression bracket;
    Expression expression1;
    Token open_bracket;
    Expression expression2;
    String symbol_value;
    List_Expression list;
    Array operators;
    Array expressions;
    Unsigned size;
    Unsigned index;
    Expression sub_expression;
    Token float_number;
    String float_value;
    Character character;
    Token number;
    String number_value;
    Logical is_hex;
    Character character1;
    Character character2;
    Parenthesis_Expression parenthesis;
    Unary_Expression unary;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    tracing = Logical__false;
    if (tracing) {
        (void)String__d((t__1 = String__form(((String)"\027=>macro_evaluate@(%e%)\n")), String__divide((t__1), Expression__f(expression))));
    }
    if ((result == String__null)) {
        result = String__new();
    }
    switch (expression->kind) {
        case Expression_Kind___binary:
            binary = ((expression->kind == Expression_Kind___binary) ? expression->kind__union.binary : (Binary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2381));
            switch (binary->operator->lexeme) {
                case Lexeme___at_sign:
                    name_expression = binary->left;
                    type_expression = binary->right;
                    type = Expression__type_convert(type_expression, compiler, 0);
                    if ((type == Type__null)) {
                        if (!(Logical__false)) {
                            System__assert_fail((String)"\16Expression.ezc", 2388);
                        }
                    } else {
                        switch (name_expression->kind) {
                            case Expression_Kind___symbol:
                                symbol = ((name_expression->kind == Expression_Kind___symbol) ? name_expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2392));
                                (void)String__string_append(result, (t__2 = String__form(((String)"\010%s%__%s%")), t__3 = String__f(Type__base_name(type)), String__divide(String__remainder((t__2), t__3), String__f(symbol->value))));
                                break;
                            default:
                                if (!(Logical__false)) {
                                    System__assert_fail((String)"\16Expression.ezc", 2396);
                                }
                                break;
                        }
                    }
                    break;
                default:
                    if (!(Logical__false)) {
                        System__assert_fail((String)"\16Expression.ezc", 2398);
                    }
                    break;
            }
            break;
        case Expression_Kind___bracket:
            bracket = ((expression->kind == Expression_Kind___bracket) ? expression->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2400));
            expression1 = bracket->expression1;
            open_bracket = bracket->open_bracket;
            expression2 = bracket->expression2;
            switch (open_bracket->lexeme) {
                case Lexeme___type_invoke:
                    switch (expression1->kind) {
                        case Expression_Kind___symbol:

                            symbol = ((expression1->kind == Expression_Kind___symbol) ? expression1->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2409));
                            symbol_value = symbol->value;
                            type = Compiler__scalar_lookup(compiler, symbol_value);
                            if ((type == Type__null)) {
                                (void)Compiler__log(compiler, symbol, (t__4 = String__form(((String)"\036%s% is not a scalar conversion")), String__divide((t__4), String__f(symbol_value))));
                            }
                            (void)String__string_append(result, (t__5 = String__form(((String)"\006((%c%)")), String__divide((t__5), Type__f(type))));
                            (void)Expression__macro_evaluate(expression2, compiler, result);
                            (void)String__string_append(result, ((String)"\001)"));
                            break;
                        default:
                            if (!(Logical__false)) {
                                System__assert_fail((String)"\16Expression.ezc", 2421);
                            }
                            break;
                    }
                    break;
                default:
                    if (!(Logical__false)) {
                        System__assert_fail((String)"\16Expression.ezc", 2423);
                    }
                    break;
            }
            break;
        case Expression_Kind___character:
            if (!(Logical__false)) {
                System__assert_fail((String)"\16Expression.ezc", 2425);
            }
            break;
        case Expression_Kind___error:
            if (!(Logical__false)) {
                System__assert_fail((String)"\16Expression.ezc", 2427);
            }
            break;
        case Expression_Kind___list:
            list = ((expression->kind == Expression_Kind___list) ? expression->kind__union.list : (List_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2429));
            operators = list->operators;
            expressions = list->expressions;
            (void)String__string_append(result, ((String)"\001("));
            size = Array__size_get(expressions);
            index = 0;
            while ((index < size)) {
                if ((index != 0)) {
                    (void)String__string_append(result, ((Token)Array__fetch1(operators, (index-1)))->value);
                }
                sub_expression = ((Expression)Array__fetch1(expressions, index));
                (void)Expression__macro_evaluate(sub_expression, compiler, result);
                index = (index+1);
            }
            (void)String__string_append(result, ((String)"\001)"));
            break;
        case Expression_Kind___float_number:
            float_number = ((expression->kind == Expression_Kind___float_number) ? expression->kind__union.float_number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2443));
            float_value = float_number->value;
            size = String__size_get(float_value);
            index = 0;
            while ((index < size)) {
                character = Character__lower_case(String__fetch1(float_value, index));
                if (((character == ((Character)'f'))||(character == ((Character)'d')))) {
                    /* do_nothing */
                } else {
                    (void)String__character_append(result, character);
                }
                index = (index+1);
            }
            break;
        case Expression_Kind___number:
            number = ((expression->kind == Expression_Kind___number) ? expression->kind__union.number : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2455));
            number_value = number->value;
            size = String__size_get(number_value);
            /* # Check for hexadecimal: */
            is_hex = Logical__false;
            if ((size >= 2)) {
                character = String__fetch1(number_value, 1);
                if (((character == ((Character)'x'))||(character == ((Character)'X')))) {
                    is_hex = Logical__true;
                }
            }
            /* # Slap the value onto the end of {result}: */
            (void)String__string_append(result, number_value);
            /* # Check for suffix character: */
            if ((!is_hex&&(size >= 2))) {
                character1 = String__fetch1(number_value, (size-1));
                character2 = String__fetch1(number_value, (size-2));
                if (Character__is_letter(character1)) {

                    if (Character__is_letter(character2)) {

                        (void)String__trim(result, (String__size_get(result)-2));
                        /* # Now figure out which C syntax suffix to replace it with: */
                        if (((character1 == ((Character)'i'))||(character1 == ((Character)'I')))) {

                            (void)String__string_append(result, ((String)"\002ll"));
                        } else if (((character1 == ((Character)'u'))||(character2 == ((Character)'U')))) {

                            (void)String__string_append(result, ((String)"\003ull"));
                        } else {
                            if (!(0)) {
                                System__assert_fail((String)"\16Expression.ezc", 2487);
                            }
                        }
                    } else {

                        (void)String__trim(result, (String__size_get(result)-1));
                    }
                }
            }
            break;
        case Expression_Kind___parenthesis:
            parenthesis = ((expression->kind == Expression_Kind___parenthesis) ? expression->kind__union.parenthesis : (Parenthesis_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2492));
            (void)String__string_append(result, ((String)"\001("));
            (void)Expression__macro_evaluate(parenthesis->expression, compiler, result);
            (void)String__string_append(result, ((String)"\001)"));
            break;
        case Expression_Kind___string:
            if (!(Logical__false)) {
                System__assert_fail((String)"\16Expression.ezc", 2497);
            }
            break;
        case Expression_Kind___symbol:
            if (!(Logical__false)) {
                System__assert_fail((String)"\16Expression.ezc", 2499);
            }
            break;
        case Expression_Kind___unary:
            unary = ((expression->kind == Expression_Kind___unary) ? expression->kind__union.unary : (Unary_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2501));
            (void)String__string_append(result, ((String)"\001("));
            (void)String__string_append(result, unary->operator->value);
            (void)Expression__macro_evaluate(unary->expression, compiler, result);
            (void)String__string_append(result, ((String)"\001)"));
            break;
    }
    if (tracing) {
        (void)String__d((t__8 = String__form(((String)"\036<=macro_evaluate@(%e%) => %v%\n")), t__9 = Expression__f(expression), String__divide(String__remainder((t__8), t__9), String__f(result))));
    }
    return result;
}

Expression Expression__parenthesis_remove(
  Expression expression)
{
    Parenthesis_Expression parenthesis_expression;
    while (Logical__true) {
        switch (expression->kind) {
            case Expression_Kind___parenthesis:
                parenthesis_expression = ((expression->kind == Expression_Kind___parenthesis) ? expression->kind__union.parenthesis : (Parenthesis_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2524));
                expression = parenthesis_expression->expression;
                break;
            default:
                goto break__1;
                break;
        }
    }
    break__1:;
    return expression;
}

Code_Chunk Expression__string_c_emit(
  Token string,
  Compiler compiler,
  Unsigned level)
{
    Code_Chunk code_chunk;
    String raw_string;
    Unsigned size;
    Unsigned index;
    Character char___k;
    Unsigned code;
    if (!((String__fetch1(string->value, 0) == ((Character)'"')))) {
        System__assert_fail((String)"\16Expression.ezc", 2539);
    }
    code_chunk = Code_Chunk__create();
    raw_string = Token__string_convert(string);
    size = String__size_get(raw_string);
    if ((size <= 250)) {

        (void)Code_Chunk__string_append(code_chunk, ((String)"\013((String)\"\\"));
        (void)Code_Chunk__character_append(code_chunk, String__fetch1(((String)"\01001234567"), (size>>6)));
        (void)Code_Chunk__character_append(code_chunk, String__fetch1(((String)"\01001234567"), (((size>>3))&7)));
        (void)Code_Chunk__character_append(code_chunk, String__fetch1(((String)"\01001234567"), (size&7)));
        index = 0;
        while ((index < size)) {
            char___k = String__fetch1(raw_string, index);
            if ((char___k == ((Character)' '))) {
                (void)Code_Chunk__character_append(code_chunk, ((Character)' '));
            } else if ((char___k == ((Character)'\134'))) {
                (void)Code_Chunk__string_append(code_chunk, ((String)"\002\\\\"));
            } else if ((char___k == ((Character)'\011'))) {
                (void)Code_Chunk__string_append(code_chunk, ((String)"\002\\t"));
            } else if ((char___k == ((Character)'\012'))) {
                (void)Code_Chunk__string_append(code_chunk, ((String)"\002\\n"));
            } else if ((char___k == ((Character)'"'))) {
                (void)Code_Chunk__string_append(code_chunk, ((String)"\002\\\""));
            } else if (Character__is_printing(char___k)) {
                (void)Code_Chunk__character_append(code_chunk, char___k);
            } else {
                (void)Code_Chunk__character_append(code_chunk, ((Character)'\134'));
                code = ((Unsigned)(char___k));
                (void)Code_Chunk__character_append(code_chunk, String__fetch1(((String)"\01001234567"), (((code>>6))&7)));
                (void)Code_Chunk__character_append(code_chunk, String__fetch1(((String)"\01001234567"), (((code>>3))&7)));
                (void)Code_Chunk__character_append(code_chunk, String__fetch1(((String)"\01001234567"), (code&7)));
            }
            index = (index+1);
        }
        (void)Code_Chunk__string_append(code_chunk, ((String)"\002\")"));
        (void)Code_Chunk__type_append(code_chunk, compiler->type_string);
    }
    return code_chunk;
}

Code_Chunk Expression__symbol_c_emit(
  Token symbol,
  Compiler compiler,
  Unsigned level)
{
    String temporary;
    Code_Chunk code_chunk;
    String symbol_name;
    Variable variable;
    String t__0;
    String t__1;
    String t__2;
    temporary = compiler->temporary;
    code_chunk = Code_Chunk__null;
    symbol_name = symbol->value;
    variable = Compiler__variable_lookup(compiler, symbol_name);
    if ((variable == Variable__null)) {
        (void)Compiler__log(compiler, symbol, (t__0 = String__form(((String)"\042%ds% is not a variable or argument")), String__divide((t__0), String__f(symbol_name))));
    } else {
        code_chunk = Code_Chunk__create();
        (void)Code_Chunk__string_append(code_chunk, (t__1 = String__form(((String)"\003%k%")), String__divide((t__1), String__f(symbol_name))));
        (void)Code_Chunk__type_append(code_chunk, variable->type);
        if ((variable->level == 0xffffffff)) {
            (void)Compiler__log(compiler, symbol, (t__2 = String__form(((String)"\072Variable/argument %ds% being used before being assigned to")), String__divide((t__2), String__f(symbol_name))));
        }
    }
    return code_chunk;
}

/* # {List_Expression} routines: */
Code_Chunk List_Expression__c_emit(
  List_Expression list,
  Compiler compiler,
  Unsigned level)
{
    String temporary;
    Logical tracing;
    Code_Chunk code_chunk;
    Array expressions;
    Array operators;
    Unsigned size;
    Unsigned calls;
    Logical code_generate;
    Token operator;
    Array sub_code_chunks;
    Array types;
    Unsigned index;
    Expression expression;
    Code_Chunk sub_code_chunk;
    Type sub_type;
    Type type;
    Logical is_conditional;
    Logical types_match;
    Logical number_check;
    Logical integer_check;
    Logical logical_check;
    Logical is_divide_multiply_remainder;
    String operator_name;
    Lexeme lexeme;
    Code_Chunk prefix_code_chunk;
    String temporary_name;
    Logical parenthesis_enclosed;
    String routine_name;
    Routine_Declaration routine;
    Type type_before;
    Typed_Name typed_name;
    Typed_Name_Object typed_name_object;
    Type prototype;
    Routine_Type routine_type;
    Comma_Separated take_types;
    Comma_Separated return_types;
    Expression expression0;
    Bracket_Expression bracket;
    Expression expression1;
    Expression expression2;
    Token string;
    String raw_string;
    Unsigned raw_string_size;
    Unsigned fields_count;
    Character character;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    String t__37;
    String t__38;
    String t__39;
    String t__40;
    String t__41;
    String t__42;
    String t__43;
    String t__44;
    String t__45;
    String t__46;
    String t__47;
    temporary = compiler->temporary;
    tracing = compiler->tracing;
    if (tracing) {
        (void)String__put((t__1 = String__form(((String)"\037%p%=>c_emit@List_Expression(*)\n")), String__divide((t__1), Unsigned__f(level))), Out_Stream__error);
    }
    code_chunk = Code_Chunk__create();
    expressions = list->expressions;
    operators = list->operators;
    size = Array__size_get(expressions);
    if (!((Array__size_get(operators) == size))) {
        System__assert_fail((String)"\16Expression.ezc", 2629);
    }
    calls = 0;
    code_generate = Logical__true;
    operator = Token__null;
    sub_code_chunks = Array__new();
    types = Array__new();
    index = 0;
    while ((index < size)) {
        expression = ((Expression)Array__fetch1(expressions, index));
        operator = ((Token)Array__fetch1(operators, index));
        sub_code_chunk = Expression__c_emit(expression, compiler, (level+1));
        sub_type = Code_Chunk__type(sub_code_chunk, expression);
        if ((sub_type == Type__null)) {
            code_generate = Logical__false;
        } else {
            (void)Array__append(types, ((void *)(sub_type)));
            (void)Array__append(sub_code_chunks, ((void *)(sub_code_chunk)));
            if (sub_code_chunk->contains_call) {
                calls = (calls+1);
            }
        }
        index = (index+1);
    }
    type = Type__null;
    is_conditional = Logical__false;
    types_match = Logical__false;
    number_check = Logical__false;
    integer_check = Logical__false;
    logical_check = Logical__false;
    is_divide_multiply_remainder = Logical__false;
    operator_name = String__null;
    if (code_generate) {
        if (!((size == Array__size_get(types)))) {
            System__assert_fail((String)"\16Expression.ezc", 2661);
        }
        if (!((size == Array__size_get(sub_code_chunks)))) {
            System__assert_fail((String)"\16Expression.ezc", 2662);
        }
        /* # Figure out appropriate type checking: */
        if ((size != 0)) {
            lexeme = operator->lexeme;
            switch (lexeme) {
                case Lexeme___comma:

                    types_match = Logical__false;
                    break;
                case Lexeme___add:
                case Lexeme___and:
                case Lexeme___divide:
                case Lexeme___minus:
                case Lexeme___multiply:
                case Lexeme___or:
                case Lexeme___remainder:
                case Lexeme___xor:
                    types_match = Logical__true;
                    number_check = Logical__true;
                    is_divide_multiply_remainder = Logical__true;
                    break;
                case Lexeme___left_shift:
                case Lexeme___right_shift:

                    types_match = Logical__true;
                    integer_check = Logical__true;
                    break;
                case Lexeme___conditional_and:
                case Lexeme___conditional_or:
                    types_match = Logical__true;
                    logical_check = Logical__true;
                    is_conditional = Logical__true;
                    break;
                default:
                    (void)Compiler__log(compiler, operator, (t__2 = String__form(((String)"\055Internal error: Not prepared for %l% operator")), String__divide((t__2), Lexeme__f(operator->lexeme))));
                    code_generate = Logical__false;
                    break;
            }
        }
    }
    if (code_generate) {

        code_chunk = Code_Chunk__create();
        prefix_code_chunk = Code_Chunk__null;
        /* # We want to convert all but one of the calls to comma separated */
        /* # expression.  Thus, "a() + b + c() + d + e()" gets converted */
        /* # to "(t__1 = a(), t__2 = c(), t__1 + b + t__2 + d + e())". */
        if ((!is_conditional&&(calls >= 2)&&types_match)) {
            (void)Code_Chunk__string_append(code_chunk, ((String)"\001("));
            index = 0;
            while (((index < size)&&(calls > 1))) {
                sub_code_chunk = ((Code_Chunk)Array__fetch1(sub_code_chunks, index));
                type = ((Type)Array__fetch1(types, index));
                if (sub_code_chunk->contains_call) {
                    temporary_name = Compiler__variable_temporary(compiler, type);
                    (void)Code_Chunk__string_append(code_chunk, temporary_name);
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\003 = "));
                    (void)Code_Chunk__chunk_append(code_chunk, sub_code_chunk);
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\002, "));
                    sub_code_chunk = Code_Chunk__create();
                    (void)Code_Chunk__string_append(sub_code_chunk, temporary_name);
                    (void)Code_Chunk__type_append(sub_code_chunk, type);
                    Array__store1(sub_code_chunks, index, (void *)(sub_code_chunk));
                    calls = (calls-1);
                }
                index = (index+1);
            }
            prefix_code_chunk = code_chunk;
            code_chunk = Code_Chunk__create();
        }
        parenthesis_enclosed = Logical__false;
        index = 0;
        while ((index < size)) {
            type = ((Type)Array__fetch1(types, index));
            routine_name = String__null;
            if ((index == 0)) {

                sub_code_chunk = ((Code_Chunk)Array__fetch1(sub_code_chunks, index));
                parenthesis_enclosed = Logical__true;
                (void)Code_Chunk__string_append(code_chunk, ((String)"\001("));
                (void)Code_Chunk__chunk_append(code_chunk, sub_code_chunk);
            } else {

                operator = ((Token)Array__fetch1(operators, index));
                routine = Routine_Declaration__null;
                if (types_match) {

                    type_before = ((Type)Array__fetch1(types, (index-1)));
                    if (!Type__equal(type_before, type)) {

                        (void)Compiler__log(compiler, operator, (t__3 = String__form(((String)"\047%e% %qv% %e% type mismatch (%t% != %t%)")), t__4 = Expression__f(((Expression)Array__fetch1(expressions, (index-1)))), t__5 = String__f(operator->value), t__6 = Expression__f(((Expression)Array__fetch1(expressions, index))), t__7 = Type__f(type_before), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__3), t__4), t__5), t__6), t__7), Type__f(type))));
                        break;
                    }
                    /* # Look for an overload routine: */
                    switch (operator->lexeme) {
                        case Lexeme___add:
                            routine_name = ((String)"\003add");
                            break;
                        case Lexeme___and:
                            routine_name = ((String)"\003and");
                            break;
                        case Lexeme___divide:
                            routine_name = ((String)"\006divide");
                            break;
                        case Lexeme___minus:
                            routine_name = ((String)"\005minus");
                            break;
                        case Lexeme___or:
                            routine_name = ((String)"\002or");
                            break;
                        case Lexeme___remainder:
                            routine_name = ((String)"\011remainder");
                            break;
                        case Lexeme___xor:
                            routine_name = ((String)"\003xor");
                            break;
                    }
                    if ((routine_name != String__null)) {
                        typed_name = compiler->typed_name;
                        /* #FIXME: Do not call new@Token()!!! */
                        typed_name->name = Token__new();
                        typed_name->name->value = routine_name;
                        typed_name->type = type;
                        typed_name_object = ((Typed_Name_Object)Hash_Table__lookup(compiler->xtyped_name_object_table, ((void *)(typed_name))));
                        if ((typed_name_object != Typed_Name_Object__null)) {
                            switch (typed_name_object->kind) {
                                default:
                                    (void)Compiler__log(compiler, operator, (t__8 = String__form(((String)"\044%s%@%t% exists, but is not a routine")), t__9 = String__f(routine_name), String__divide(String__remainder((t__8), t__9), Type__f(type))));
                                    goto break__1;
                                    break;
                                case Typed_Name_Object_Kind___routine:
                                    routine = ((typed_name_object->kind == Typed_Name_Object_Kind___routine) ? typed_name_object->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\16Expression.ezc", 2779));
                                    break;
                            }
                        }
                    }
                    if ((routine == Routine_Declaration__null)) {

                        /* # Do additional type checking: */
                        type = ((Type)Array__fetch1(types, index));
                        expression = ((Expression)Array__fetch1(expressions, index));
                        if ((number_check||integer_check)) {
                            if ((number_check&&!Type__is_number_scalar(type))) {
                                (void)Compiler__log(compiler, operator, (t__10 = String__form(((String)"\047%e% isn't Integer/Unsigned/Float/Double")), String__divide((t__10), Expression__f(expression))));
                                break;
                            }
                            if ((integer_check&&!Type__is_non_float_scalar(type))) {
                                (void)Compiler__log(compiler, operator, (t__11 = String__form(((String)"\043%e% is neither Integer nor Unsigned")), String__divide((t__11), Expression__f(expression))));
                                break;
                            }
                        } else if ((logical_check&&!Type__is_logical(type))) {
                            (void)Compiler__log(compiler, operator, (t__12 = String__form(((String)"\035%e% is an not of type Logical")), String__divide((t__12), Expression__f(expression))));
                            break;
                        }
                    } else {

                        prototype = Routine_Declaration__prototype_extract(routine);
                        routine_type = ((prototype->kind == Type_Kind___routine) ? prototype->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\16Expression.ezc", 2805));
                        take_types = routine_type->takes_types;
                        return_types = routine_type->return_types;
                        if ((Comma_Separated__size_get(take_types) != 2)) {
                            (void)Compiler__log(compiler, operator, (t__13 = String__form(((String)"\050%s%@%t% routine has %d% arguments, not 2")), t__14 = String__f(routine_name), t__15 = Type__f(type), String__divide(String__remainder(String__remainder((t__13), t__14), t__15), Unsigned__f(Comma_Separated__size_get(take_types)))));
                            break;
                        }
                        if ((Comma_Separated__size_get(return_types) != 1)) {
                            (void)Compiler__log(compiler, operator, (t__16 = String__form(((String)"\051%s%@%t% routine returns %d% values, not 1")), t__17 = String__f(routine_name), t__18 = Type__f(type), String__divide(String__remainder(String__remainder((t__16), t__17), t__18), Unsigned__f(Comma_Separated__size_get(return_types)))));
                            break;
                        }
                        if (!Type__equal(((Type)Comma_Separated__fetch1(take_types, 0)), type)) {
                            (void)Compiler__log(compiler, operator, (t__19 = String__form(((String)"\053Argument 1 of %s%@%t% has type %t%, not %t%")), t__20 = String__f(routine_name), t__21 = Type__f(type), t__22 = Type__f(((Type)Comma_Separated__fetch1(take_types, 0))), String__divide(String__remainder(String__remainder(String__remainder((t__19), t__20), t__21), t__22), Type__f(type))));
                            break;
                        }
                        if (!Type__equal(((Type)Comma_Separated__fetch1(take_types, 1)), type)) {
                            (void)Compiler__log(compiler, operator, (t__23 = String__form(((String)"\053Argument 2 of %s%@%t% has type %t%, not %t%")), t__24 = String__f(routine_name), t__25 = Type__f(type), t__26 = Type__f(((Type)Comma_Separated__fetch1(take_types, 1))), String__divide(String__remainder(String__remainder(String__remainder((t__23), t__24), t__25), t__26), Type__f(type))));
                            break;
                        }
                        if (!Type__equal(((Type)Comma_Separated__fetch1(return_types, 0)), type)) {
                            (void)Compiler__log(compiler, operator, (t__27 = String__form(((String)"\041%s%@%t% returns type %t%, not %t%")), t__28 = String__f(routine_name), t__29 = Type__f(type), t__30 = Type__f(((Type)Comma_Separated__fetch1(return_types, 0))), String__divide(String__remainder(String__remainder(String__remainder((t__27), t__28), t__29), t__30), Type__f(type))));
                            break;
                        }
                    }
                }
                if ((routine == Routine_Declaration__null)) {
                    (void)Code_Chunk__string_append(code_chunk, operator->value);
                    (void)Code_Chunk__chunk_append(code_chunk, ((Code_Chunk)Array__fetch1(sub_code_chunks, index)));
                } else {
                    if (parenthesis_enclosed) {
                        (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
                        parenthesis_enclosed = Logical__false;
                    }
                    sub_code_chunk = code_chunk;
                    code_chunk = Code_Chunk__create();
                    (void)Code_Chunk__string_append(code_chunk, Type__base_name(type));
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\002__"));
                    (void)Code_Chunk__string_append(code_chunk, routine_name);
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\001("));
                    (void)Code_Chunk__chunk_append(code_chunk, sub_code_chunk);
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\002, "));
                    (void)Code_Chunk__chunk_append(code_chunk, ((Code_Chunk)Array__fetch1(sub_code_chunks, index)));
                    (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
                }
            }
            index = (index+1);
        }
        break__1:;
        /* # Do extra checking for formatting: */
        if ((is_divide_multiply_remainder&&Type__equal(type, compiler->type_string))) {
            expression0 = ((Expression)Array__fetch1(expressions, 0));
            switch (expression0->kind) {
                case Expression_Kind___bracket:
                    bracket = ((expression0->kind == Expression_Kind___bracket) ? expression0->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2862));
                    expression1 = bracket->expression1;
                    expression2 = bracket->expression2;
                    if (((expression1->kind == Expression_Kind__symbol)&&String__equal(((expression1->kind == Expression_Kind___symbol) ? expression1->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2866))->value, ((String)"\004form"))&&(expression2->kind == Expression_Kind__string))) {

                        string = ((expression2->kind == Expression_Kind___string) ? expression2->kind__union.string : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2869));
                        index = 1;
                        while ((index < size)) {
                            expression = ((Expression)Array__fetch1(expressions, index));
                            operator = ((Token)Array__fetch1(operators, index));
                            switch (expression->kind) {
                                case Expression_Kind___bracket:
                                    bracket = ((expression->kind == Expression_Kind___bracket) ? expression->kind__union.bracket : (Bracket_Expression)System__variant_object_fail((String)"\16Expression.ezc", 2876));
                                    expression1 = bracket->expression1;
                                    expression2 = bracket->expression2;
                                    if (((expression1->kind == Expression_Kind__symbol)&&String__equal(((expression1->kind == Expression_Kind___symbol) ? expression1->kind__union.symbol : (Token)System__variant_object_fail((String)"\16Expression.ezc", 2880))->value, ((String)"\001f")))) {
                                        /* do_nothing */
                                    } else {
                                        (void)Compiler__log(compiler, operator, (t__31 = String__form(((String)"\050Expression %e% should be f@(...) instead")), String__divide((t__31), Expression__f(expression))));
                                    }
                                    if ((((index+1) >= size)&&(operator->lexeme != Lexeme__divide))) {
                                        (void)Compiler__log(compiler, operator, (t__32 = String__form(((String)"\051Last operator form@(%s%) is '%s%' not '/'")), t__33 = String__f(string->value), String__divide(String__remainder((t__32), t__33), String__f(operator->value))));
                                    }
                                    if ((((index+1) < size)&&(operator->lexeme != Lexeme__remainder))) {
                                        (void)Compiler__log(compiler, operator, (t__34 = String__form(((String)"\057Operator %d% after form@(%s%) is '%s%' not '%%'")), t__35 = Unsigned__f(index), t__36 = String__f(string->value), String__divide(String__remainder(String__remainder((t__34), t__35), t__36), String__f(operator->value))));
                                    }
                                    break;
                            }
                            index = (index+1);
                        }
                        /* # Now make sure we have the right number of everything: */
                        raw_string = Token__string_convert(string);
                        raw_string_size = String__size_get(raw_string);
                        fields_count = 0;
                        index = 0;
                        while ((index < raw_string_size)) {
                            character = String__fetch1(raw_string, index);
                            if ((character == ((Character)'%'))) {
                                if ((((index+1) < raw_string_size)&&(String__fetch1(raw_string, (index+1)) == ((Character)'%')))) {
                                    index = (index+2);
                                } else {
                                    index = (index+1);
                                    fields_count = (fields_count+1);
                                    while (((index < raw_string_size)&&(String__fetch1(raw_string, index) != ((Character)'%')))) {
                                        index = (index+1);
                                    }
                                    index = (index+1);
                                }
                            } else {
                                index = (index+1);
                            }
                        }
                        if ((fields_count != (size-1))) {
                            (void)Compiler__log(compiler, string, (t__37 = String__form(((String)"\063form@(%s%) has %d% fields, only %d% fields supplied")), t__38 = String__f(string->value), t__39 = Unsigned__f(fields_count), String__divide(String__remainder(String__remainder((t__37), t__38), t__39), Unsigned__f((size-1)))));
                        }
                    }
                    break;
            }
            /* #FIXME: What is this!!! */
            while ((index < size)) {
                (void)String__put((t__42 = String__form(((String)"\013[%d%]: %e%\n")), t__43 = Unsigned__f(index), String__divide(String__remainder((t__42), t__43), Expression__f(((Expression)Array__fetch1(expressions, index))))), Out_Stream__error);
                index = (index+1);
            }
        }
        if (parenthesis_enclosed) {
            (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
        }
        if ((prefix_code_chunk != Code_Chunk__null)) {
            (void)Code_Chunk__chunk_append(prefix_code_chunk, code_chunk);
            code_chunk = prefix_code_chunk;
            (void)Code_Chunk__string_append(code_chunk, ((String)"\001)"));
        }
        if (types_match) {
            (void)Array__trim(types, 1);
        }
        (void)Code_Chunk__types_append(code_chunk, types);
    }
    if (tracing) {
        (void)String__put((t__46 = String__form(((String)"\046%p%<=c_emit@List_Expression(*) => %x%\n")), t__47 = Unsigned__f(level), String__divide(String__remainder((t__46), t__47), Code_Chunk__f(code_chunk))), Out_Stream__error);
    }
    return code_chunk;
}

Logical List_Expression__equal(
  List_Expression list_expression1,
  List_Expression list_expression2)
{
    Logical result;
    Array operators1;
    Array operators2;
    Array expressions1;
    Array expressions2;
    result = 0;
    operators1 = list_expression1->operators;
    operators2 = list_expression2->operators;
    expressions1 = list_expression1->expressions;
    expressions2 = list_expression2->expressions;
    result = (Array__equal(operators1, operators2, ((Logical (*)(void *, void *))(Token__equal)))&&Array__equal(expressions1, expressions2, ((Logical (*)(void *, void *))(Expression__equal))));
    return result;
}

/* # {Unary_Expression} stuff: */
Code_Chunk Unary_Expression__c_emit(
  Unary_Expression unary_expression,
  Compiler compiler,
  Unsigned level)
{
    Expression expression;
    Token operator;
    Code_Chunk code_chunk;
    Code_Chunk unary_code_chunk;
    expression = unary_expression->expression;
    operator = unary_expression->operator;
    code_chunk = Code_Chunk__create();
    unary_code_chunk = Expression__c_emit(expression, compiler, (level+1));
    (void)Code_Chunk__string_append(code_chunk, operator->value);
    (void)Code_Chunk__chunk_append(code_chunk, unary_code_chunk);
    (void)Code_Chunk__type_append(code_chunk, Code_Chunk__type(unary_code_chunk, expression));
    return code_chunk;
}

Logical Unary_Expression__equal(
  Unary_Expression unary_expression1,
  Unary_Expression unary_expression2)
{
    Logical result;
    result = 0;
    result = (Token__equal(unary_expression1->operator, unary_expression2->operator)&&Expression__equal(unary_expression1->expression, unary_expression2->expression));
    return result;
}


/* {Code_Chunk} stuff: */

struct Code_Chunk__Struct Code_Chunk__Initial = {
    (Array)0,
    &String__Initial,
    0,
};

Code_Chunk Code_Chunk__null = &Code_Chunk__Initial;
void Code_Chunk__erase(
  Code_Chunk code_chunk)
{
    if (code_chunk->types == 0) {
	code_chunk->types = Array__new();
    } else {
	Array__erase(code_chunk->types);
    }
    code_chunk->code = String__null;
    code_chunk->contains_call = 0;
}

Code_Chunk Code_Chunk__new(void)
{
    Code_Chunk code_chunk;
    extern void *malloc(size_t);

    code_chunk = (Code_Chunk)malloc(sizeof(*code_chunk));
    code_chunk->types = Array__new();
    code_chunk->code = String__null;
    code_chunk->contains_call = Logical__null;
    return code_chunk;
}

void Code_Chunk__Initialize(void)
{
    Code_Chunk__erase(Code_Chunk__null);
}


