#ifndef STATEMENT_INCLUDED
#define STATEMENT_INCLUDED 1

/* Declare all enum's and typedef's first: */
/* h_emit1 */
/* h_emit2 */
/* h_emit3 */

/* Include other libraries exactly once: */
#ifndef COMPILER_INCLUDED
#include "Compiler.ez.h"/*D2*/
#endif /* COMPILER_INCLUDED */
#ifndef DECLARATION_INCLUDED
#include "Declaration.ez.h"/*D2*/
#endif /* DECLARATION_INCLUDED */
#ifndef EZCC_INCLUDED
#include "EZCC.ez.h"/*D2*/
#endif /* EZCC_INCLUDED */
#ifndef EASY_C_INCLUDED
#include "Easy_C.ez.h"/*D2*/
#endif /* EASY_C_INCLUDED */
#ifndef EXPRESSION_INCLUDED
#include "Expression.ez.h"/*D2*/
#endif /* EXPRESSION_INCLUDED */
#ifndef PARSE_INCLUDED
#include "Parse.ez.h"/*D2*/
#endif /* PARSE_INCLUDED */
#ifndef TOKEN_INCLUDED
#include "Token.ez.h"/*D2*/
#endif /* TOKEN_INCLUDED */

/* Define the structures: */

/* Declare the routine prototypes: */
extern void Assert_Statement__visit(Assert_Statement, String, Compiler);
extern void Break_Empty_Statement__visit(Break_Empty_Statement, String, Compiler);
extern void Break_Level_Statement__visit(Break_Level_Statement, String, Compiler);
extern void Call_Statement__visit(Call_Statement, String, Compiler);
extern void Continue_Empty_Statement__visit(Continue_Empty_Statement, String, Compiler);
extern void Continue_Level_Statement__visit(Continue_Level_Statement, String, Compiler);
extern void If_Statement__visit(If_Statement, String, Compiler);
extern void Return_Statement__visit(Return_Statement, String, Compiler);
extern void Set_Statement__visit(Set_Statement, String, Compiler);
extern String Statement__f(Statement);
extern void Statement__format(Statement, String);
extern Token Statement__location_get(Statement);
extern void Statement__visit(Statement, String, Compiler);
extern void Switch_Statement__visit(Switch_Statement, String, Compiler);
extern void While_Statement__visit(While_Statement, String, Compiler);

/* Declare extracted #define values: */
extern Unsigned Unsigned__unix_errno_2big;
extern Unsigned Unsigned__unix_errno_acces;
extern Unsigned Unsigned__unix_errno_addrinuse;
extern Unsigned Unsigned__unix_errno_addrnotavail;
extern Unsigned Unsigned__unix_errno_adv;
extern Unsigned Unsigned__unix_errno_afnosupport;
extern Unsigned Unsigned__unix_errno_again;
extern Unsigned Unsigned__unix_errno_already;
extern Unsigned Unsigned__unix_errno_asy_c_included;
extern Unsigned Unsigned__unix_errno_bade;
extern Unsigned Unsigned__unix_errno_badf;
extern Unsigned Unsigned__unix_errno_badfd;
extern Unsigned Unsigned__unix_errno_badmsg;
extern Unsigned Unsigned__unix_errno_badr;
extern Unsigned Unsigned__unix_errno_badrqc;
extern Unsigned Unsigned__unix_errno_badslt;
extern Unsigned Unsigned__unix_errno_bfont;
extern Unsigned Unsigned__unix_errno_busy;
extern Unsigned Unsigned__unix_errno_canceled;
extern Unsigned Unsigned__unix_errno_child;
extern Unsigned Unsigned__unix_errno_chrng;
extern Unsigned Unsigned__unix_errno_comm;
extern Unsigned Unsigned__unix_errno_connaborted;
extern Unsigned Unsigned__unix_errno_connrefused;
extern Unsigned Unsigned__unix_errno_connreset;
extern Unsigned Unsigned__unix_errno_deadlk;
extern Unsigned Unsigned__unix_errno_destaddrreq;
extern Unsigned Unsigned__unix_errno_dom;
extern Unsigned Unsigned__unix_errno_dotdot;
extern Unsigned Unsigned__unix_errno_dquot;
extern Unsigned Unsigned__unix_errno_exist;
extern Unsigned Unsigned__unix_errno_fault;
extern Unsigned Unsigned__unix_errno_fbig;
extern Unsigned Unsigned__unix_errno_hostdown;
extern Unsigned Unsigned__unix_errno_hostunreach;
extern Unsigned Unsigned__unix_errno_hwpoison;
extern Unsigned Unsigned__unix_errno_idrm;
extern Unsigned Unsigned__unix_errno_ilseq;
extern Unsigned Unsigned__unix_errno_inprogress;
extern Unsigned Unsigned__unix_errno_intr;
extern Unsigned Unsigned__unix_errno_inval;
extern Unsigned Unsigned__unix_errno_io;
extern Unsigned Unsigned__unix_errno_isconn;
extern Unsigned Unsigned__unix_errno_isdir;
extern Unsigned Unsigned__unix_errno_isnam;
extern Unsigned Unsigned__unix_errno_keyexpired;
extern Unsigned Unsigned__unix_errno_keyrejected;
extern Unsigned Unsigned__unix_errno_keyrevoked;
extern Unsigned Unsigned__unix_errno_l2hlt;
extern Unsigned Unsigned__unix_errno_l2nsync;
extern Unsigned Unsigned__unix_errno_l3hlt;
extern Unsigned Unsigned__unix_errno_l3rst;
extern Unsigned Unsigned__unix_errno_libacc;
extern Unsigned Unsigned__unix_errno_libbad;
extern Unsigned Unsigned__unix_errno_libexec;
extern Unsigned Unsigned__unix_errno_libmax;
extern Unsigned Unsigned__unix_errno_libscn;
extern Unsigned Unsigned__unix_errno_lnrng;
extern Unsigned Unsigned__unix_errno_loop;
extern Unsigned Unsigned__unix_errno_mediumtype;
extern Unsigned Unsigned__unix_errno_mfile;
extern Unsigned Unsigned__unix_errno_mlink;
extern Unsigned Unsigned__unix_errno_msgsize;
extern Unsigned Unsigned__unix_errno_multihop;
extern Unsigned Unsigned__unix_errno_nametoolong;
extern Unsigned Unsigned__unix_errno_navail;
extern Unsigned Unsigned__unix_errno_netdown;
extern Unsigned Unsigned__unix_errno_netreset;
extern Unsigned Unsigned__unix_errno_netunreach;
extern Unsigned Unsigned__unix_errno_nfile;
extern Unsigned Unsigned__unix_errno_noano;
extern Unsigned Unsigned__unix_errno_nobufs;
extern Unsigned Unsigned__unix_errno_nocsi;
extern Unsigned Unsigned__unix_errno_nodata;
extern Unsigned Unsigned__unix_errno_nodev;
extern Unsigned Unsigned__unix_errno_noent;
extern Unsigned Unsigned__unix_errno_noexec;
extern Unsigned Unsigned__unix_errno_nokey;
extern Unsigned Unsigned__unix_errno_nolck;
extern Unsigned Unsigned__unix_errno_nolink;
extern Unsigned Unsigned__unix_errno_nomedium;
extern Unsigned Unsigned__unix_errno_nomem;
extern Unsigned Unsigned__unix_errno_nomsg;
extern Unsigned Unsigned__unix_errno_nonet;
extern Unsigned Unsigned__unix_errno_nopkg;
extern Unsigned Unsigned__unix_errno_noprotoopt;
extern Unsigned Unsigned__unix_errno_nospc;
extern Unsigned Unsigned__unix_errno_nosr;
extern Unsigned Unsigned__unix_errno_nostr;
extern Unsigned Unsigned__unix_errno_nosys;
extern Unsigned Unsigned__unix_errno_notblk;
extern Unsigned Unsigned__unix_errno_notconn;
extern Unsigned Unsigned__unix_errno_notdir;
extern Unsigned Unsigned__unix_errno_notempty;
extern Unsigned Unsigned__unix_errno_notnam;
extern Unsigned Unsigned__unix_errno_notrecoverable;
extern Unsigned Unsigned__unix_errno_notsock;
extern Unsigned Unsigned__unix_errno_notty;
extern Unsigned Unsigned__unix_errno_notuniq;
extern Unsigned Unsigned__unix_errno_nxio;
extern Unsigned Unsigned__unix_errno_opnotsupp;
extern Unsigned Unsigned__unix_errno_overflow;
extern Unsigned Unsigned__unix_errno_ownerdead;
extern Unsigned Unsigned__unix_errno_perm;
extern Unsigned Unsigned__unix_errno_pfnosupport;
extern Unsigned Unsigned__unix_errno_pipe;
extern Unsigned Unsigned__unix_errno_proto;
extern Unsigned Unsigned__unix_errno_protonosupport;
extern Unsigned Unsigned__unix_errno_prototype;
extern Unsigned Unsigned__unix_errno_range;
extern Unsigned Unsigned__unix_errno_remchg;
extern Unsigned Unsigned__unix_errno_remote;
extern Unsigned Unsigned__unix_errno_remoteio;
extern Unsigned Unsigned__unix_errno_restart;
extern Unsigned Unsigned__unix_errno_rfkill;
extern Unsigned Unsigned__unix_errno_rofs;
extern Unsigned Unsigned__unix_errno_shutdown;
extern Unsigned Unsigned__unix_errno_socktnosupport;
extern Unsigned Unsigned__unix_errno_spipe;
extern Unsigned Unsigned__unix_errno_srch;
extern Unsigned Unsigned__unix_errno_srmnt;
extern Unsigned Unsigned__unix_errno_stale;
extern Unsigned Unsigned__unix_errno_strpipe;
extern Unsigned Unsigned__unix_errno_time;
extern Unsigned Unsigned__unix_errno_timedout;
extern Unsigned Unsigned__unix_errno_toomanyrefs;
extern Unsigned Unsigned__unix_errno_txtbsy;
extern Unsigned Unsigned__unix_errno_uclean;
extern Unsigned Unsigned__unix_errno_unatch;
extern Unsigned Unsigned__unix_errno_users;
extern Unsigned Unsigned__unix_errno_xdev;
extern Unsigned Unsigned__unix_errno_xfull;
extern Unsigned Unsigned__unix_errno_xit_failure;
extern Unsigned Unsigned__unix_errno_xit_success;
extern Unsigned Unsigned__unix_errno_asyc_c_h_included;
extern Integer Integer__unix_file_f_dupfd;
extern Integer Integer__unix_file_f_dupfd_cloexec;
extern Integer Integer__unix_file_f_exlck;
extern Integer Integer__unix_file_f_getfd;
extern Integer Integer__unix_file_f_getfl;
extern Integer Integer__unix_file_f_getlk;
extern Integer Integer__unix_file_f_getlk64;
extern Integer Integer__unix_file_f_getown;
extern Integer Integer__unix_file_f_lock;
extern Integer Integer__unix_file_f_ok;
extern Integer Integer__unix_file_f_rdlck;
extern Integer Integer__unix_file_f_setfd;
extern Integer Integer__unix_file_f_setfl;
extern Integer Integer__unix_file_f_setlk;
extern Integer Integer__unix_file_f_setlk64;
extern Integer Integer__unix_file_f_setlkw;
extern Integer Integer__unix_file_f_setlkw64;
extern Integer Integer__unix_file_f_setown;
extern Integer Integer__unix_file_f_shlck;
extern Integer Integer__unix_file_f_test;
extern Integer Integer__unix_file_f_tlock;
extern Integer Integer__unix_file_f_ulock;
extern Integer Integer__unix_file_f_unlck;
extern Integer Integer__unix_file_f_wrlck;
extern Unsigned Unsigned__unix_file_o_accmode;
extern Unsigned Unsigned__unix_file_o_append;
extern Unsigned Unsigned__unix_file_o_async;
extern Unsigned Unsigned__unix_file_o_cloexec;
extern Unsigned Unsigned__unix_file_o_creat;
extern Unsigned Unsigned__unix_file_o_directory;
extern Unsigned Unsigned__unix_file_o_dsync;
extern Unsigned Unsigned__unix_file_o_excl;
extern Unsigned Unsigned__unix_file_o_noctty;
extern Unsigned Unsigned__unix_file_o_nofollow;
extern Unsigned Unsigned__unix_file_o_nonblock;
extern Unsigned Unsigned__unix_file_o_rdonly;
extern Unsigned Unsigned__unix_file_o_rdwr;
extern Unsigned Unsigned__unix_file_o_sync;
extern Unsigned Unsigned__unix_file_o_trunc;
extern Unsigned Unsigned__unix_file_o_wronly;
extern Integer Integer__unix_so_acceptconn;
extern Integer Integer__unix_so_attach_filter;
extern Integer Integer__unix_so_bindtodevice;
extern Integer Integer__unix_so_broadcast;
extern Integer Integer__unix_so_bsdcompat;
extern Integer Integer__unix_so_debug;
extern Integer Integer__unix_so_detach_filter;
extern Integer Integer__unix_so_domain;
extern Integer Integer__unix_so_dontroute;
extern Integer Integer__unix_so_error;
extern Integer Integer__unix_so_keepalive;
extern Integer Integer__unix_so_linger;
extern Integer Integer__unix_so_mark;
extern Integer Integer__unix_so_nofcs;
extern Integer Integer__unix_so_no_check;
extern Integer Integer__unix_so_oobinline;
extern Integer Integer__unix_so_passcred;
extern Integer Integer__unix_so_passsec;
extern Integer Integer__unix_so_peek_off;
extern Integer Integer__unix_so_peercred;
extern Integer Integer__unix_so_peername;
extern Integer Integer__unix_so_peersec;
extern Integer Integer__unix_so_priority;
extern Integer Integer__unix_so_protocol;
extern Integer Integer__unix_so_rcvbuf;
extern Integer Integer__unix_so_rcvbufforce;
extern Integer Integer__unix_so_rcvlowat;
extern Integer Integer__unix_so_rcvtimeo;
extern Integer Integer__unix_so_reuseaddr;
extern Integer Integer__unix_so_rxq_ovfl;
extern Integer Integer__unix_so_security_authentication;
extern Integer Integer__unix_so_security_encryption_network;
extern Integer Integer__unix_so_security_encryption_transport;
extern Integer Integer__unix_so_sndbuf;
extern Integer Integer__unix_so_sndbufforce;
extern Integer Integer__unix_so_sndlowat;
extern Integer Integer__unix_so_sndtimeo;
extern Integer Integer__unix_so_timestamp;
extern Integer Integer__unix_so_timestamping;
extern Integer Integer__unix_so_timestampns;
extern Integer Integer__unix_so_type;
extern Integer Integer__unix_so_wifi_status;
#endif /* STATEMENT_INCLUDED */
