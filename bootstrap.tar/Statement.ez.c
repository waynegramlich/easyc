#include "Statement.ez.h"/*cc2*/
/* # Copyright (c) 2004-2007 by Wayne C. Gramlich. */
/* # All rights reserved. */
#include "Compiler.ez.h"/*D1*/
#include "Declaration.ez.h"/*D1*/
#include "EZCC.ez.h"/*D1*/
#include "Easy_C.ez.h"/*D1*/
#include "Expression.ez.h"/*D1*/
#include "Parse.ez.h"/*D1*/
#include "Token.ez.h"/*D1*/
/* # {Assert_Statement} routines: */
/* #undef lower case macros */
#undef i386
#undef linux
#undef unix
#undef errno
#undef makedev
#undef major
#undef minor
#undef alloca

void Assert_Statement__visit(
  Assert_Statement assert,
  String buffer,
  Compiler compiler)
{
    Expression expression;
    Code_Chunk code_chunk;
    Type type;
    Token location;
    String source_name;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    switch (compiler->phase) {
        case Phase___c_emit:
            expression = assert->expression;
            code_chunk = Expression__c_emit(expression, compiler, 0);
            type = Code_Chunk__type(code_chunk, expression);
            if ((type != Type__null)) {
                if (Type__equal(type, compiler->type_logical)) {
                    location = assert->assert->keyword;
                    source_name = Token__source_name_get(location);
                    /* # Output the code: */
                    (void)String__string_append(buffer, (t__0 = String__form(((String)"\021%p%if (!(%s%)) {\n")), t__1 = Unsigned__f(Compiler__c_pad_get(compiler)), String__divide(String__remainder((t__0), t__1), Code_Chunk__f(code_chunk))));
                    (void)String__string_append(buffer, (t__2 = String__form(((String)"\056%p%    System__assert_fail((String)%e%, %d%);\n")), t__3 = Unsigned__f(Compiler__c_pad_get(compiler)), t__4 = String__f(source_name), String__divide(String__remainder(String__remainder((t__2), t__3), t__4), Unsigned__f(Token__line_number_get(location)))));
                    (void)String__string_append(buffer, (t__5 = String__form(((String)"\005%p%}\n")), String__divide((t__5), Unsigned__f(Compiler__c_pad_get(compiler)))));
                } else {
                    (void)Compiler__log(compiler, Expression__location_get(expression), (t__6 = String__form(((String)"\056assert expression %e% is type %t%, not Logical")), t__7 = Expression__f(expression), String__divide(String__remainder((t__6), t__7), Type__f(type))));
                }
            }
            break;
    }
}

/* # {Break_Empty_Statement} routines: */
void Break_Empty_Statement__visit(
  Break_Empty_Statement break_empty,
  String buffer,
  Compiler compiler)
{
    Array loop_levels;
    Unsigned loop_levels_size;
    Array switch_levels;
    Unsigned switch_levels_size;
    Unsigned loop_level;
    Unsigned switch_level;
    Array break_labels;
    Unsigned break_label;
    Unsigned label_count;
    Pointer_Pointer t__0;
    Pointer_Pointer t__1;
    Pointer_Pointer t__2;
    String t__3;
    switch (compiler->phase) {
        case Phase___c_emit:
            loop_levels = compiler->loop_levels;
            loop_levels_size = Array__size_get(loop_levels);
            switch_levels = compiler->switch_levels;
            switch_levels_size = Array__size_get(switch_levels);
            if ((loop_levels_size == 0)) {

                /* #log :@= log@Messages(compiler.messages, break_empty.break, */
                /* #  "Break must occur within a loop") */
            } else {
                (void)Compiler__pad_append(compiler, buffer);
                loop_level = (t__0 = (Pointer_Pointer)(Array__fetch1(loop_levels, (loop_levels_size-1))), *(Unsigned *)(&t__0));
                if ((switch_levels_size != 0)) {
                    switch_level = (t__1 = (Pointer_Pointer)(Array__fetch1(switch_levels, (switch_levels_size-1))), *(Unsigned *)(&t__1));
                    if ((switch_level > loop_level)) {

                        break_labels = compiler->break_labels;
                        if (!((Array__size_get(break_labels) == loop_levels_size))) {
                            System__assert_fail((String)"\rStatement.ezc", 80);
                        }
                        break_label = (t__2 = (Pointer_Pointer)(Array__fetch1(break_labels, (loop_levels_size-1))), *(Unsigned *)(&t__2));
                        if ((break_label == 0)) {
                            label_count = (compiler->label_count+1);
                            compiler->label_count = label_count;
                            break_label = label_count;
                            Array__store1(break_labels, (loop_levels_size-1), (void *)(break_label));
                        }
                        (void)String__string_append(buffer, (t__3 = String__form(((String)"\021goto break__%d%;\n")), String__divide((t__3), Unsigned__f(break_label))));
                    } else {
                        (void)String__buffer_append(((String)"\007break;\n"), buffer);
                    }
                } else {
                    (void)String__buffer_append(((String)"\007break;\n"), buffer);
                }
            }
            break;
    }
}

/* # {Break_Level_Statement} routines: */
void Break_Level_Statement__visit(
  Break_Level_Statement break_level,
  String buffer,
  Compiler compiler)
{
    Unsigned number;
    Array break_labels;
    Unsigned break_labels_size;
    Array loop_levels;
    Unsigned loop_levels_size;
    Array switch_levels;
    Unsigned switch_levels_size;
    Unsigned loop_level;
    Unsigned switch_level;
    Unsigned break_label;
    Unsigned label_count;
    String temporary;
    String t__0;
    Pointer_Pointer t__1;
    Pointer_Pointer t__2;
    Pointer_Pointer t__3;
    String t__4;
    String t__5;
    String t__6;
    switch (compiler->phase) {
        case Phase___c_emit:
            number = String__unsigned_convert(break_level->number->value);
            break_labels = compiler->break_labels;
            break_labels_size = Array__size_get(break_labels);
            if ((number == 0)) {
                (void)Compiler__log(compiler, break_level->number, (t__0 = String__form(((String)"\065break must be followed by a positive number, not %qv%")), String__divide((t__0), String__f(break_level->number->value))));
            } else if ((number <= break_labels_size)) {

                (void)Compiler__pad_append(compiler, buffer);
                loop_levels = compiler->loop_levels;
                loop_levels_size = Array__size_get(loop_levels);
                switch_levels = compiler->switch_levels;
                switch_levels_size = Array__size_get(switch_levels);
                if (!((break_labels_size == loop_levels_size))) {
                    System__assert_fail((String)"\rStatement.ezc", 124);
                }
                loop_level = (t__1 = (Pointer_Pointer)(Array__fetch1(loop_levels, (loop_levels_size-1))), *(Unsigned *)(&t__1));
                switch_level = 0;
                if ((switch_levels_size != 0)) {
                    switch_level = (t__2 = (Pointer_Pointer)(Array__fetch1(switch_levels, (switch_levels_size-1))), *(Unsigned *)(&t__2));
                }
                if (((loop_level > switch_level)&&(number == 1))) {
                    (void)String__buffer_append(((String)"\007break;\n"), buffer);
                } else {
                    break_label = (t__3 = (Pointer_Pointer)(Array__fetch1(break_labels, (break_labels_size-number))), *(Unsigned *)(&t__3));
                    if ((break_label == 0)) {
                        label_count = (compiler->label_count+1);
                        compiler->label_count = label_count;
                        break_label = label_count;
                        Array__store1(break_labels, (break_labels_size-number), (void *)(break_label));
                    }
                    temporary = compiler->temporary;
                    (void)String__string_append(buffer, (t__4 = String__form(((String)"\021goto break__%d%;\n")), String__divide((t__4), Unsigned__f(break_label))));
                }
            } else {
                (void)Compiler__log(compiler, break_level->number, (t__5 = String__form(((String)"\066Currently nested in %d% loops, break %d% will not work")), t__6 = Unsigned__f(break_labels_size), String__divide(String__remainder((t__5), t__6), Unsigned__f(number))));
            }
            break;
    }
}

/* # {Call_Statement} routines: */
void Call_Statement__visit(
  Call_Statement call,
  String buffer,
  Compiler compiler)
{
    Code_Chunk code_chunk;
    switch (compiler->phase) {
        case Phase___c_emit:
            (void)Compiler__pad_append(compiler, buffer);
            (void)String__buffer_append(((String)"\006(void)"), buffer);
            compiler->cast_suppress = Logical__true;
            code_chunk = Expression__c_emit(call->expression, compiler, 0);
            compiler->cast_suppress = Logical__false;
            (void)Code_Chunk__buffer_append(code_chunk, buffer);
            (void)String__buffer_append(((String)"\002;\n"), buffer);
            break;
    }
}

/* # {Continue_Empty_Statement} routines: */
void Continue_Empty_Statement__visit(
  Continue_Empty_Statement continue_empty,
  String buffer,
  Compiler compiler)
{
    if (!(Logical__false)) {
        System__assert_fail((String)"\rStatement.ezc", 185);
    }
}

/* # {Continue_Level_Statement} routines: */
void Continue_Level_Statement__visit(
  Continue_Level_Statement continue_level,
  String buffer,
  Compiler compiler)
{
    if (!(Logical__false)) {
        System__assert_fail((String)"\rStatement.ezc", 199);
    }
}

/* # {If_Statement} routines: */
void If_Statement__visit(
  If_Statement if___k,
  String buffer,
  Compiler compiler)
{
    Array if_clauses;
    Unsigned size;
    Unsigned index;
    If_Clause if_clause;
    Array statements;
    If_Part if_part;
    Expression expression;
    Code_Chunk code_chunk;
    Else_If_Part else_if_part;
    Else_Part else_part;
    switch (compiler->phase) {
        case Phase___c_emit:
            if_clauses = if___k->if_clauses;
            size = Array__size_get(if_clauses);
            index = 0;
            while ((index < size)) {
                if_clause = ((If_Clause)Array__fetch1(if_clauses, index));
                (void)Compiler__pad_append(compiler, buffer);
                statements = compiler->statements;
                switch (if_clause->kind) {
                    case If_Clause_Kind___if_part:
                        if_part = ((if_clause->kind == If_Clause_Kind___if_part) ? if_clause->kind__union.if_part : (If_Part)System__variant_object_fail((String)"\rStatement.ezc", 224));
                        (void)String__buffer_append(((String)"\004if ("), buffer);
                        expression = if_part->expression;
                        code_chunk = Expression__c_emit(expression, compiler, 0);
                        (void)Code_Chunk__buffer_append(code_chunk, buffer);
                        (void)String__buffer_append(((String)"\004) {\n"), buffer);
                        statements = if_part->statements;
                        break;
                    case If_Clause_Kind___else_if_part:
                        else_if_part = ((if_clause->kind == If_Clause_Kind___else_if_part) ? if_clause->kind__union.else_if_part : (Else_If_Part)System__variant_object_fail((String)"\rStatement.ezc", 232));
                        (void)String__buffer_append(((String)"\013} else if ("), buffer);
                        expression = else_if_part->expression;
                        code_chunk = Expression__c_emit(expression, compiler, 0);
                        (void)Code_Chunk__buffer_append(code_chunk, buffer);
                        (void)String__buffer_append(((String)"\004) {\n"), buffer);
                        statements = else_if_part->statements;
                        break;
                    case If_Clause_Kind___else_part:
                        else_part = ((if_clause->kind == If_Clause_Kind___else_part) ? if_clause->kind__union.else_part : (Else_Part)System__variant_object_fail((String)"\rStatement.ezc", 240));
                        (void)String__buffer_append(((String)"\011} else {\n"), buffer);
                        statements = else_part->statements;
                        break;
                }
                (void)Compiler__level_begin(compiler);
                (void)Array__visit(statements, buffer, compiler, ((void (*)(void *, String, Compiler))(Statement__visit)));
                (void)Compiler__level_end(compiler);
                index = (index+1);
            }
            (void)Compiler__pad_append(compiler, buffer);
            (void)String__buffer_append(((String)"\002}\n"), buffer);
            break;
    }
}

/* # {Return_Statement} routines: */
void Return_Statement__visit(
  Return_Statement return___k,
  String buffer,
  Compiler compiler)
{
    Routine_Declaration routine;
    Type routine_return_type;
    Return_Clause_Expression return_clause_expression;
    Expression expression;
    Code_Chunk code_chunk;
    Type return_type;
    Return_Clause_Empty return_clause_empty;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    switch (compiler->phase) {
        case Phase___c_emit:
            (void)Compiler__pad_append(compiler, buffer);
            (void)String__buffer_append(((String)"\006return"), buffer);
            routine = compiler->current_routine;
            routine_return_type = Routine_Declaration__return_type(routine);
            switch (return___k->kind) {
                case Return_Clause_Kind___expression:
                    return_clause_expression = ((return___k->kind == Return_Clause_Kind___expression) ? return___k->kind__union.expression : (Return_Clause_Expression)System__variant_object_fail((String)"\rStatement.ezc", 271));
                    if ((routine_return_type == Type__null)) {
                        (void)Compiler__log(compiler, return_clause_expression->end_of_line, ((String)"\065Returning a value from a routine that returns nothing"));
                    } else {
                        (void)String__buffer_append(((String)"\001 "), buffer);
                        expression = return_clause_expression->expression;
                        code_chunk = Expression__c_emit(expression, compiler, 0);
                        return_type = Code_Chunk__type(code_chunk, expression);
                        if ((return_type == Type__null)) {
                            (void)Compiler__log(compiler, Expression__location_get(expression), (t__0 = String__form(((String)"\043Expression %e% does not have a type")), String__divide((t__0), Expression__f(expression))));
                        } else if (Type__equal(return_type, routine_return_type)) {
                            (void)Code_Chunk__buffer_append(code_chunk, buffer);
                        } else {
                            (void)Compiler__log(compiler, Expression__location_get(expression), (t__1 = String__form(((String)"\056Returning '%e%' (type %t%) instead of type %t%")), t__2 = Expression__f(expression), t__3 = Type__f(return_type), String__divide(String__remainder(String__remainder((t__1), t__2), t__3), Type__f(routine_return_type))));
                        }
                    }
                    break;
                case Return_Clause_Kind___empty:
                    return_clause_empty = ((return___k->kind == Return_Clause_Kind___empty) ? return___k->kind__union.empty : (Return_Clause_Empty)System__variant_object_fail((String)"\rStatement.ezc", 292));
                    if ((routine_return_type != Type__null)) {
                        (void)Compiler__log(compiler, return_clause_empty->end_of_line, (t__4 = String__form(((String)"\053Routine needs to return a value of type %t%")), String__divide((t__4), Type__f(routine_return_type))));
                    }
                    break;
            }
            (void)String__buffer_append(((String)"\002;\n"), buffer);
            break;
    }
}

/* # {Set_Statement} routines: */
void Set_Statement__visit(
  Set_Statement set,
  String buffer,
  Compiler compiler)
{
    Expression expression;
    Code_Chunk code_chunk;
    switch (compiler->phase) {
        case Phase___c_emit:
            (void)Compiler__pad_append(compiler, buffer);
            expression = set->expression;
            code_chunk = Expression__c_emit(expression, compiler, 0);
            (void)Code_Chunk__buffer_append(code_chunk, buffer);
            (void)String__buffer_append(((String)"\002;\n"), buffer);
            break;
    }
}

/* # {Statement} routines: */
String Statement__f(
  Statement statement)
{
    String value;
    Traverser traverser;
    value = Format__field_next();
    traverser = Traverser__create(value, Array__new());
    (void)Statement__traverse(statement, traverser);
    return value;
}

void Statement__format(
  Statement statement,
  String buffer)
{
    Unsigned anchor;
    Unsigned size;
    Unsigned index;
    Character character;
    Traverser traverser;
    anchor = String__format_begin(buffer);
    size = String__size_get(buffer);
    index = (anchor+1);
    character = ((Character)' ');
    while (((index < size)&&(character != ((Character)'%')))) {
        character = String__fetch1(buffer, index);
        index = (index+1);
    }
    traverser = Traverser__create(buffer, Array__new());
    (void)Statement__traverse(statement, traverser);
    (void)String__format_end(buffer, anchor);
}

Token Statement__location_get(
  Statement statement)
{
    Token location;
    Error error;
    Array tokens;
    If_Statement if___k;
    Array if_clauses;
    If_Clause if_clause;
    Return_Statement return___k;
    location = Token__null;
    switch (statement->kind) {
        case Statement_Kind___assert:
            location = ((statement->kind == Statement_Kind___assert) ? statement->kind__union.assert : (Assert_Statement)System__variant_object_fail((String)"\rStatement.ezc", 369))->assert->keyword;
            break;
        case Statement_Kind___break_empty:
            location = ((statement->kind == Statement_Kind___break_empty) ? statement->kind__union.break_empty : (Break_Empty_Statement)System__variant_object_fail((String)"\rStatement.ezc", 371))->end_of_line;
            break;
        case Statement_Kind___break_level:
            location = ((statement->kind == Statement_Kind___break_level) ? statement->kind__union.break_level : (Break_Level_Statement)System__variant_object_fail((String)"\rStatement.ezc", 373))->end_of_line;
            break;
        case Statement_Kind___call:
            location = ((statement->kind == Statement_Kind___call) ? statement->kind__union.call : (Call_Statement)System__variant_object_fail((String)"\rStatement.ezc", 375))->call->keyword;
            break;
        case Statement_Kind___continue_empty:
            location = ((statement->kind == Statement_Kind___continue_empty) ? statement->kind__union.continue_empty : (Continue_Empty_Statement)System__variant_object_fail((String)"\rStatement.ezc", 377))->end_of_line;
            break;
        case Statement_Kind___continue_level:
            location = ((statement->kind == Statement_Kind___continue_level) ? statement->kind__union.continue_level : (Continue_Level_Statement)System__variant_object_fail((String)"\rStatement.ezc", 379))->end_of_line;
            break;
        case Statement_Kind___do_nothing:
            location = ((statement->kind == Statement_Kind___do_nothing) ? statement->kind__union.do_nothing : (Do_Nothing_Statement)System__variant_object_fail((String)"\rStatement.ezc", 381))->do_nothing->keyword;
            break;
        case Statement_Kind___end_of_line:
            location = ((statement->kind == Statement_Kind___end_of_line) ? statement->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\rStatement.ezc", 383));
            break;
        case Statement_Kind___error:
            error = ((statement->kind == Statement_Kind___error) ? statement->kind__union.error : (Error)System__variant_object_fail((String)"\rStatement.ezc", 385));
            tokens = error->tokens;
            if ((Array__size_get(tokens) != 0)) {
                location = ((Token)Array__fetch1(tokens, 0));
            }
            break;
        case Statement_Kind___if:
            if___k = ((statement->kind == Statement_Kind___if) ? statement->kind__union.if___k : (If_Statement)System__variant_object_fail((String)"\rStatement.ezc", 390));
            if_clauses = if___k->if_clauses;
            if ((Array__size_get(if_clauses) != 0)) {
                if_clause = ((If_Clause)Array__fetch1(if_clauses, 0));
                switch (if_clause->kind) {
                    case If_Clause_Kind___if_part:
                        location = ((if_clause->kind == If_Clause_Kind___if_part) ? if_clause->kind__union.if_part : (If_Part)System__variant_object_fail((String)"\rStatement.ezc", 397))->if___k->keyword;
                        break;
                    case If_Clause_Kind___else_if_part:
                        location = ((if_clause->kind == If_Clause_Kind___else_if_part) ? if_clause->kind__union.else_if_part : (Else_If_Part)System__variant_object_fail((String)"\rStatement.ezc", 399))->else_if->keyword;
                        break;
                    case If_Clause_Kind___else_part:
                        location = ((if_clause->kind == If_Clause_Kind___else_part) ? if_clause->kind__union.else_part : (Else_Part)System__variant_object_fail((String)"\rStatement.ezc", 401))->else___k->keyword;
                        break;
                }
            }
            break;
        case Statement_Kind___note:
            location = ((statement->kind == Statement_Kind___note) ? statement->kind__union.note : (Note)System__variant_object_fail((String)"\rStatement.ezc", 403))->comment;
            break;
        case Statement_Kind___return:
            return___k = ((statement->kind == Statement_Kind___return) ? statement->kind__union.return___k : (Return_Statement)System__variant_object_fail((String)"\rStatement.ezc", 405));
            switch (return___k->kind) {
                case Return_Clause_Kind___expression:
                    location = ((return___k->kind == Return_Clause_Kind___expression) ? return___k->kind__union.expression : (Return_Clause_Expression)System__variant_object_fail((String)"\rStatement.ezc", 408))->return___k->keyword;
                    break;
                case Return_Clause_Kind___empty:
                    location = ((return___k->kind == Return_Clause_Kind___empty) ? return___k->kind__union.empty : (Return_Clause_Empty)System__variant_object_fail((String)"\rStatement.ezc", 410))->return___k->keyword;
                    break;
            }
            break;
        case Statement_Kind___set:
            location = ((statement->kind == Statement_Kind___set) ? statement->kind__union.set : (Set_Statement)System__variant_object_fail((String)"\rStatement.ezc", 412))->set;
            break;
        case Statement_Kind___switch:
            location = ((statement->kind == Statement_Kind___switch) ? statement->kind__union.switch___k : (Switch_Statement)System__variant_object_fail((String)"\rStatement.ezc", 414))->switch___k->keyword;
            break;
        case Statement_Kind___while:
            location = ((statement->kind == Statement_Kind___while) ? statement->kind__union.while___k : (While_Statement)System__variant_object_fail((String)"\rStatement.ezc", 416))->while___k->keyword;
            break;
    }
    return location;
}

void Statement__visit(
  Statement statement,
  String buffer,
  Compiler compiler)
{
    Token location;
    Logical tracing;
    String temporary;
    Unsigned line_number;
    Logical previous_tracing;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    location = Statement__location_get(statement);
    (void)Compiler__location_push(compiler, ((String)"\011statement"), location);
    tracing = Logical__false;
    temporary = compiler->temporary;
    line_number = Token__line_number_get(location);
    previous_tracing = compiler->tracing;
    compiler->tracing = (line_number == compiler->trace_line);
    if (tracing) {
        (void)String__put((t__2 = String__form(((String)"\036Statement: Line:%d% Trace:%l%\n")), t__3 = Unsigned__f(line_number), String__divide(String__remainder((t__2), t__3), Logical__f(compiler->tracing))), Out_Stream__error);
    }
    switch (statement->kind) {
        case Statement_Kind___assert:
            (void)Assert_Statement__visit(((statement->kind == Statement_Kind___assert) ? statement->kind__union.assert : (Assert_Statement)System__variant_object_fail((String)"\rStatement.ezc", 447)), buffer, compiler);
            break;
        case Statement_Kind___break_empty:
            (void)Break_Empty_Statement__visit(((statement->kind == Statement_Kind___break_empty) ? statement->kind__union.break_empty : (Break_Empty_Statement)System__variant_object_fail((String)"\rStatement.ezc", 449)), buffer, compiler);
            break;
        case Statement_Kind___break_level:
            (void)Break_Level_Statement__visit(((statement->kind == Statement_Kind___break_level) ? statement->kind__union.break_level : (Break_Level_Statement)System__variant_object_fail((String)"\rStatement.ezc", 451)), buffer, compiler);
            break;
        case Statement_Kind___call:
            (void)Call_Statement__visit(((statement->kind == Statement_Kind___call) ? statement->kind__union.call : (Call_Statement)System__variant_object_fail((String)"\rStatement.ezc", 453)), buffer, compiler);
            break;
        case Statement_Kind___continue_empty:
            (void)Continue_Empty_Statement__visit(((statement->kind == Statement_Kind___continue_empty) ? statement->kind__union.continue_empty : (Continue_Empty_Statement)System__variant_object_fail((String)"\rStatement.ezc", 455)), buffer, compiler);
            break;
        case Statement_Kind___continue_level:
            (void)Continue_Level_Statement__visit(((statement->kind == Statement_Kind___continue_level) ? statement->kind__union.continue_level : (Continue_Level_Statement)System__variant_object_fail((String)"\rStatement.ezc", 457)), buffer, compiler);
            break;
        case Statement_Kind___do_nothing:
            (void)Compiler__pad_append(compiler, buffer);
            (void)String__buffer_append(((String)"\021/* do_nothing */\n"), buffer);
            break;
        case Statement_Kind___end_of_line:
            (void)String__buffer_append(((String)"\001\n"), buffer);
            break;
        case Statement_Kind___error:
            /* do_nothing */
            break;
        case Statement_Kind___if:
            (void)If_Statement__visit(((statement->kind == Statement_Kind___if) ? statement->kind__union.if___k : (If_Statement)System__variant_object_fail((String)"\rStatement.ezc", 466)), buffer, compiler);
            break;
        case Statement_Kind___note:
            (void)Note__visit(((statement->kind == Statement_Kind___note) ? statement->kind__union.note : (Note)System__variant_object_fail((String)"\rStatement.ezc", 468)), buffer, compiler);
            break;
        case Statement_Kind___return:
            (void)Return_Statement__visit(((statement->kind == Statement_Kind___return) ? statement->kind__union.return___k : (Return_Statement)System__variant_object_fail((String)"\rStatement.ezc", 470)), buffer, compiler);
            break;
        case Statement_Kind___set:
            (void)Set_Statement__visit(((statement->kind == Statement_Kind___set) ? statement->kind__union.set : (Set_Statement)System__variant_object_fail((String)"\rStatement.ezc", 472)), buffer, compiler);
            break;
        case Statement_Kind___switch:
            (void)Switch_Statement__visit(((statement->kind == Statement_Kind___switch) ? statement->kind__union.switch___k : (Switch_Statement)System__variant_object_fail((String)"\rStatement.ezc", 474)), buffer, compiler);
            break;
        case Statement_Kind___while:
            (void)While_Statement__visit(((statement->kind == Statement_Kind___while) ? statement->kind__union.while___k : (While_Statement)System__variant_object_fail((String)"\rStatement.ezc", 476)), buffer, compiler);
            break;
    }
    compiler->tracing = previous_tracing;
    if (tracing) {
        (void)String__put(((String)"\024<=visit@statement()\n"), Out_Stream__error);
    }
    (void)Compiler__location_pop(compiler);
}

/* # {Switch_Statement} routines: */
void Switch_Statement__visit(
  Switch_Statement switch___k,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Code_Chunk code_chunk;
    Type type;
    String type_name;
    Define_Declaration define;
    Enumeration_Clause enumeration;
    Array item_names;
    Enumeration_Prefix_Clause enumeration_prefix;
    Array used_cases;
    Array switch_levels;
    Unsigned switch_levels_size;
    Logical all_cases_required;
    Logical have_default;
    Array switch_clauses;
    Unsigned size;
    Unsigned index;
    Switch_Clause switch_clause;
    Switch_Case switch_case;
    Expression cases;
    Token case_name;
    Typed_Name_Object typed_name_object;
    List_Expression list;
    Array operators;
    Array expressions;
    Unsigned expressions_size;
    Unsigned expressions_index;
    Expression expression;
    Code_Chunk case_code_chunk;
    Switch_Default switch_default;
    Unsigned used_cases_size;
    Unsigned used_cases_index;
    Token used_case1;
    Token used_case2;
    Integer zero;
    Unsigned item_names_size;
    Token location;
    Unsigned item_names_index;
    Token used_case;
    String item_name;
    Integer compare;
    Array used_chunks;
    Switch_All_Cases_Required xxx;
    Logical do_constant;
    List_Expression case_list;
    Code_Chunk case_chunk;
    Type case_type;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    temporary = compiler->temporary;
    switch (compiler->phase) {
        case Phase___c_emit:
            code_chunk = Expression__c_emit(switch___k->expression, compiler, 0);
            type = Code_Chunk__type(code_chunk, switch___k->expression);
            if ((type != Type__null)) {
                type_name = Type__base_name(type);
                define = ((Define_Declaration)Hash_Table__lookup(compiler->define_table, ((void *)(type_name))));
                if ((define == Define_Declaration__null)) {
                    (void)Compiler__log(compiler, switch___k->switch___k->keyword, (t__0 = String__form(((String)"\030Type %t% is not declared")), String__divide((t__0), Type__f(type))));
                } else if (Define_Declaration__is_enumeration(define)) {

                    enumeration = Define_Declaration__enumeration_get(define);
                    item_names = Array__new();
                    if ((enumeration == Enumeration_Clause__null)) {
                        enumeration_prefix = Define_Declaration__enumeration_prefix_get(define);
                        item_names = Enumeration_Prefix_Clause__item_names(enumeration_prefix);
                    } else {
                        item_names = Enumeration_Clause__item_names(enumeration);
                    }
                    used_cases = Array__new();
                    (void)Array__sort(item_names, ((Integer (*)(void *, void *))(String__compare)));
                    (void)Compiler__pad_append(compiler, buffer);
                    (void)String__buffer_append(((String)"\010switch ("), buffer);
                    (void)Code_Chunk__buffer_append(code_chunk, buffer);
                    (void)String__buffer_append(((String)"\004) {\n"), buffer);
                    switch_levels = compiler->switch_levels;
                    switch_levels_size = Array__size_get(switch_levels);
                    (void)Array__append(switch_levels, ((CAST)(compiler->level)).xpointer);
                    (void)Compiler__level_begin(compiler);
                    all_cases_required = Logical__false;
                    have_default = Logical__false;
                    switch_clauses = switch___k->switch_clauses;
                    size = Array__size_get(switch_clauses);
                    index = 0;
                    while ((index < size)) {
                        switch_clause = ((Switch_Clause)Array__fetch1(switch_clauses, index));
                        switch (switch_clause->kind) {
                            case Switch_Clause_Kind___all_cases_required:
                                all_cases_required = Logical__true;
                                break;
                            case Switch_Clause_Kind___case:
                                switch_case = ((switch_clause->kind == Switch_Clause_Kind___case) ? switch_clause->kind__union.case___k : (Switch_Case)System__variant_object_fail((String)"\rStatement.ezc", 540));
                                cases = switch_case->cases;
                                switch (cases->kind) {
                                    case Expression_Kind___symbol:

                                        case_name = ((cases->kind == Expression_Kind___symbol) ? cases->kind__union.symbol : (Token)System__variant_object_fail((String)"\rStatement.ezc", 545));
                                        typed_name_object = Compiler__type_name_lookup(compiler, case_name->value, type, Token__null);
                                        if ((typed_name_object == Typed_Name_Object__null)) {
                                            (void)Compiler__log(compiler, case_name, (t__1 = String__form(((String)"\035Case %s% is not valid for %t%")), t__2 = String__f(case_name->value), String__divide(String__remainder((t__1), t__2), Type__f(type))));
                                        } else {
                                            (void)Compiler__pad_append(compiler, buffer);
                                            (void)Array__append(used_cases, ((void *)(case_name)));
                                            (void)String__string_append(buffer, (t__3 = String__form(((String)"\020case %s%___%s%:\n")), t__4 = String__f(type_name), String__divide(String__remainder((t__3), t__4), String__f(case_name->value))));
                                        }
                                        break;
                                    case Expression_Kind___list:

                                        list = ((cases->kind == Expression_Kind___list) ? cases->kind__union.list : (List_Expression)System__variant_object_fail((String)"\rStatement.ezc", 561));
                                        operators = list->operators;
                                        if (!((Array__size_get(operators) != 0))) {
                                            System__assert_fail((String)"\rStatement.ezc", 563);
                                        }
                                        switch (((Token)Array__fetch1(operators, 0))->lexeme) {
                                            case Lexeme___comma:
                                                expressions = list->expressions;
                                                expressions_size = Array__size_get(expressions);
                                                expressions_index = 0;
                                                while ((expressions_index < expressions_size)) {
                                                    expression = ((Expression)Array__fetch1(expressions, expressions_index));
                                                    switch (expression->kind) {
                                                        case Expression_Kind___symbol:
                                                            case_name = ((expression->kind == Expression_Kind___symbol) ? expression->kind__union.symbol : (Token)System__variant_object_fail((String)"\rStatement.ezc", 574));
                                                            (void)Compiler__pad_append(compiler, buffer);
                                                            (void)Array__append(used_cases, ((void *)(case_name)));
                                                            (void)String__string_append(buffer, (t__5 = String__form(((String)"\020case %s%___%s%:\n")), t__6 = String__f(type_name), String__divide(String__remainder((t__5), t__6), String__f(case_name->value))));
                                                            break;
                                                        default:
                                                            (void)Compiler__log(compiler, Expression__location_get(expression), (t__7 = String__form(((String)"\021%e% is not symbol")), String__divide((t__7), Expression__f(expression))));
                                                            break;
                                                    }
                                                    expressions_index = (expressions_index+1);
                                                }
                                                break;
                                            default:
                                                case_code_chunk = Expression__constant_evaluate(cases, compiler, 0);
                                                if ((case_code_chunk == Code_Chunk__null)) {
                                                    (void)Compiler__pad_append(compiler, buffer);
                                                    (void)String__string_append(buffer, (t__8 = String__form(((String)"\011case %c%\n")), String__divide((t__8), Code_Chunk__f(case_code_chunk))));
                                                } else {
                                                    (void)Compiler__log(compiler, Expression__location_get(cases), (t__9 = String__form(((String)"\025Case %e% is not valid")), String__divide((t__9), Expression__f(cases))));
                                                }
                                                break;
                                        }
                                        break;
                                    default:

                                        case_code_chunk = Expression__constant_evaluate(cases, compiler, 0);
                                        if ((case_code_chunk == Code_Chunk__null)) {
                                            (void)Compiler__pad_append(compiler, buffer);
                                            (void)String__string_append(buffer, (t__10 = String__form(((String)"\011case %c%\n")), String__divide((t__10), Code_Chunk__f(case_code_chunk))));
                                        } else {
                                            (void)Compiler__log(compiler, Expression__location_get(cases), (t__11 = String__form(((String)"\025Case %e% is not valid")), String__divide((t__11), Expression__f(cases))));
                                        }
                                        break;
                                }
                                (void)Compiler__level_begin(compiler);
                                (void)Array__visit(switch_case->statements, buffer, compiler, ((void (*)(void *, String, Compiler))(Statement__visit)));
                                (void)Compiler__pad_append(compiler, buffer);
                                (void)String__buffer_append(((String)"\007break;\n"), buffer);
                                (void)Compiler__level_end(compiler);
                                break;
                            case Switch_Clause_Kind___default:
                                switch_default = ((switch_clause->kind == Switch_Clause_Kind___default) ? switch_clause->kind__union.default___k : (Switch_Default)System__variant_object_fail((String)"\rStatement.ezc", 618));
                                have_default = Logical__true;
                                (void)Compiler__pad_append(compiler, buffer);
                                (void)String__buffer_append(((String)"\011default:\n"), buffer);
                                (void)Compiler__level_begin(compiler);
                                (void)Array__visit(switch_default->statements, buffer, compiler, ((void (*)(void *, String, Compiler))(Statement__visit)));
                                (void)Compiler__pad_append(compiler, buffer);
                                (void)String__buffer_append(((String)"\007break;\n"), buffer);
                                (void)Compiler__level_end(compiler);
                                break;
                            case Switch_Clause_Kind___note:
                                (void)Compiler__pad_append(compiler, buffer);
                                (void)String__buffer_append(((String)"\003/* "), buffer);
                                (void)String__buffer_append(((switch_clause->kind == Switch_Clause_Kind___note) ? switch_clause->kind__union.note : (Note)System__variant_object_fail((String)"\rStatement.ezc", 631))->comment->value, buffer);
                                (void)String__buffer_append(((String)"\003*/\n"), buffer);
                                break;
                            case Switch_Clause_Kind___end_of_line:
                                (void)String__buffer_append(((String)"\001\n"), buffer);
                                break;
                            case Switch_Clause_Kind___error:
                                /* do_nothing */
                                break;
                        }
                        if ((index >= size)) {
                            break;
                        }
                        index = (index+1);
                    }
                    (void)Compiler__level_end(compiler);
                    /* # Do some error checking: */
                    (void)Array__sort(used_cases, ((Integer (*)(void *, void *))(Token__compare)));
                    used_cases_size = Array__size_get(used_cases);
                    used_cases_index = 1;
                    while ((index < size)) {
                        used_case1 = ((Token)Array__fetch1(used_cases, (used_cases_index-1)));
                        used_case2 = ((Token)Array__fetch1(used_cases, used_cases_index));
                        if (String__equal(used_case1->value, used_case2->value)) {

                            (void)Compiler__log(compiler, used_case2, (t__12 = String__form(((String)"\042Duplicate case name %qv% in switch")), String__divide((t__12), String__f(used_case2->value))));
                            (void)Compiler__log(compiler, used_case1, (t__13 = String__form(((String)"\037Previous case name %qv% is here")), String__divide((t__13), String__f(used_case1->value))));
                        }
                        used_cases_index = (used_cases_index+1);
                    }
                    /* # Search for missing cases when 'all_cases_required' is set: */
                    zero = 0;
                    item_names_size = Array__size_get(item_names);
                    if ((all_cases_required&&(used_cases_size != item_names_size))) {
                        location = switch___k->switch___k->keyword;
                        used_cases_index = 0;
                        item_names_index = 0;
                        while (((item_names_index < item_names_size)&&(used_cases_index < used_cases_size))) {

                            used_case = ((Token)Array__fetch1(used_cases, used_cases_index));
                            item_name = ((String)Array__fetch1(item_names, item_names_index));
                            compare = String__compare(used_case->value, item_name);
                            if ((compare == zero)) {
                                used_cases_index = (used_cases_index+1);
                                item_names_index = (item_names_index+1);
                            } else if ((compare < zero)) {
                                (void)Compiler__log(compiler, used_case, (t__14 = String__form(((String)"\045Illegal case %qv% in switch statement")), String__divide((t__14), String__f(used_case->value))));
                                used_cases_index = (used_cases_index+1);
                            } else {
                                (void)Compiler__log(compiler, location, (t__15 = String__form(((String)"\045Missing case %qv% in switch statement")), String__divide((t__15), String__f(item_name))));
                                item_names_index = (item_names_index+1);
                            }
                        }
                        while ((item_names_index < item_names_size)) {
                            item_name = ((String)Array__fetch1(item_names, item_names_index));
                            (void)Compiler__log(compiler, location, (t__16 = String__form(((String)"\045Missing case %qv% in switch statement")), String__divide((t__16), String__f(item_name))));
                            item_names_index = (item_names_index+1);
                        }
                    }
                    (void)Compiler__pad_append(compiler, buffer);
                    (void)String__buffer_append(((String)"\002}\n"), buffer);
                    (void)Array__trim(switch_levels, switch_levels_size);
                } else if ((Type__is_scalar(type)&&!Type__is_float_scalar(type))) {


                    (void)Compiler__pad_append(compiler, buffer);
                    used_chunks = Array__new();
                    (void)String__buffer_append(((String)"\010switch ("), buffer);
                    (void)Code_Chunk__buffer_append(code_chunk, buffer);
                    (void)String__buffer_append(((String)"\004) {\n"), buffer);
                    switch_levels = compiler->switch_levels;
                    switch_levels_size = Array__size_get(switch_levels);
                    (void)Array__append(switch_levels, ((CAST)(compiler->level)).xpointer);
                    (void)Compiler__level_begin(compiler);
                    have_default = Logical__false;
                    switch_clauses = switch___k->switch_clauses;
                    size = Array__size_get(switch_clauses);
                    index = 0;
                    while ((index < size)) {
                        switch_clause = ((Switch_Clause)Array__fetch1(switch_clauses, index));
                        switch (switch_clause->kind) {
                            case Switch_Clause_Kind___all_cases_required:
                                xxx = ((switch_clause->kind == Switch_Clause_Kind___all_cases_required) ? switch_clause->kind__union.all_cases_required : (Switch_All_Cases_Required)System__variant_object_fail((String)"\rStatement.ezc", 721));
                                (void)Compiler__log(compiler, xxx->all_cases_required->keyword, ((String)"\060all_cases_required not allowed for scalar switch"));
                                break;
                            case Switch_Clause_Kind___case:
                                switch_case = ((switch_clause->kind == Switch_Clause_Kind___case) ? switch_clause->kind__union.case___k : (Switch_Case)System__variant_object_fail((String)"\rStatement.ezc", 725));
                                cases = switch_case->cases;
                                do_constant = Logical__false;
                                switch (cases->kind) {
                                    case Expression_Kind___list:
                                        case_list = ((cases->kind == Expression_Kind___list) ? cases->kind__union.list : (List_Expression)System__variant_object_fail((String)"\rStatement.ezc", 730));
                                        operators = case_list->operators;
                                        if (!((Array__size_get(operators) != 0))) {
                                            System__assert_fail((String)"\rStatement.ezc", 732);
                                        }
                                        switch (((Token)Array__fetch1(operators, 0))->lexeme) {
                                            case Lexeme___comma:
                                                expressions = case_list->expressions;
                                                expressions_size = Array__size_get(expressions);
                                                expressions_index = 0;
                                                while ((expressions_index < expressions_size)) {
                                                    expression = ((Expression)Array__fetch1(expressions, expressions_index));
                                                    case_chunk = Expression__constant_evaluate(expression, compiler, 0);
                                                    if ((case_chunk == Code_Chunk__null)) {
                                                        (void)Compiler__log(compiler, Expression__location_get(expression), (t__17 = String__form(((String)"\025%e% is not a constant")), String__divide((t__17), Expression__f(expression))));
                                                    } else if ((Code_Chunk__type(case_chunk, expression) != type)) {
                                                        (void)Compiler__log(compiler, Expression__location_get(expression), (t__18 = String__form(((String)"\024Type of %e% is wrong")), String__divide((t__18), Expression__f(expression))));
                                                    } else {
                                                        (void)Compiler__pad_append(compiler, buffer);
                                                        (void)Array__append(used_chunks, ((void *)(case_chunk)));
                                                        (void)String__string_append(buffer, (t__19 = String__form(((String)"\012case %c%:\n")), String__divide((t__19), Code_Chunk__f(case_chunk))));
                                                    }
                                                    expressions_index = (expressions_index+1);
                                                }
                                                break;
                                            default:
                                                do_constant = Logical__true;
                                                break;
                                        }
                                        break;
                                    default:
                                        do_constant = Logical__true;
                                        break;
                                }
                                if (do_constant) {
                                    case_chunk = Expression__constant_evaluate(cases, compiler, 0);
                                    if ((case_chunk == Code_Chunk__null)) {

                                        (void)Compiler__log(compiler, Expression__location_get(cases), (t__20 = String__form(((String)"\036case value %e% is not a const.")), String__divide((t__20), Expression__f(cases))));
                                    } else {
                                        case_type = Code_Chunk__type(case_chunk, cases);
                                        if (Type__equal(case_type, type)) {

                                            (void)Compiler__pad_append(compiler, buffer);
                                            (void)Array__append(used_chunks, ((void *)(case_chunk)));
                                            (void)String__string_append(buffer, (t__21 = String__form(((String)"\012case %c%:\n")), String__divide((t__21), Code_Chunk__f(case_chunk))));
                                        } else {

                                            (void)Compiler__log(compiler, Expression__location_get(cases), (t__22 = String__form(((String)"\031%e% has type %t%, not %t%")), t__23 = Expression__f(cases), t__24 = Type__f(case_type), String__divide(String__remainder(String__remainder((t__22), t__23), t__24), Type__f(type))));
                                        }
                                    }
                                }
                                (void)Compiler__level_begin(compiler);
                                (void)Array__visit(switch_case->statements, buffer, compiler, ((void (*)(void *, String, Compiler))(Statement__visit)));
                                (void)Compiler__pad_append(compiler, buffer);
                                (void)String__buffer_append(((String)"\007break;\n"), buffer);
                                (void)Compiler__level_end(compiler);
                                break;
                            case Switch_Clause_Kind___default:
                                switch_default = ((switch_clause->kind == Switch_Clause_Kind___default) ? switch_clause->kind__union.default___k : (Switch_Default)System__variant_object_fail((String)"\rStatement.ezc", 798));
                                have_default = Logical__true;
                                (void)Compiler__pad_append(compiler, buffer);
                                (void)String__buffer_append(((String)"\011default:\n"), buffer);
                                (void)Compiler__level_begin(compiler);
                                (void)Array__visit(switch_default->statements, buffer, compiler, ((void (*)(void *, String, Compiler))(Statement__visit)));
                                (void)Compiler__pad_append(compiler, buffer);
                                (void)String__buffer_append(((String)"\007break;\n"), buffer);
                                (void)Compiler__level_end(compiler);
                                break;
                            case Switch_Clause_Kind___note:
                                (void)Compiler__pad_append(compiler, buffer);
                                (void)String__buffer_append(((String)"\003/* "), buffer);
                                (void)String__buffer_append(((switch_clause->kind == Switch_Clause_Kind___note) ? switch_clause->kind__union.note : (Note)System__variant_object_fail((String)"\rStatement.ezc", 811))->comment->value, buffer);
                                (void)String__buffer_append(((String)"\003*/\n"), buffer);
                                break;
                            case Switch_Clause_Kind___end_of_line:
                                (void)String__buffer_append(((String)"\001\n"), buffer);
                                break;
                            case Switch_Clause_Kind___error:
                                /* do_nothing */
                                break;
                        }
                        if ((index >= size)) {
                            break;
                        }
                        index = (index+1);
                    }
                    (void)Compiler__level_end(compiler);
                    (void)Compiler__pad_append(compiler, buffer);
                    (void)String__buffer_append(((String)"\002}\n"), buffer);
                    (void)Array__trim(switch_levels, switch_levels_size);
                } else {
                    (void)Compiler__log(compiler, Expression__location_get(switch___k->expression), (t__25 = String__form(((String)"\062Type %t% is not an enumeration or non-float scalar")), String__divide((t__25), Type__f(type))));
                }
            }
            break;
    }
}

/* # {while_statement} routines: */
void While_Statement__visit(
  While_Statement while___k,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Array break_labels;
    Array continue_labels;
    Array loop_levels;
    Code_Chunk code_chunk;
    Unsigned size;
    Unsigned continue_label;
    Unsigned break_label;
    Pointer_Pointer t__0;
    String t__1;
    Pointer_Pointer t__2;
    String t__3;
    switch (compiler->phase) {
        case Phase___c_emit:
            temporary = compiler->temporary;
            break_labels = compiler->break_labels;
            continue_labels = compiler->continue_labels;
            loop_levels = compiler->loop_levels;
            (void)Compiler__pad_append(compiler, buffer);
            (void)String__buffer_append(((String)"\007while ("), buffer);
            code_chunk = Expression__c_emit(while___k->expression, compiler, 0);
            (void)Code_Chunk__buffer_append(code_chunk, buffer);
            (void)String__buffer_append(((String)"\004) {\n"), buffer);
            size = Array__size_get(break_labels);
            if (!(((Array__size_get(continue_labels) == size)&&(Array__size_get(loop_levels) == size)))) {
                System__assert_fail((String)"\rStatement.ezc", 861);
            }
            (void)Array__append(break_labels, ((CAST)(0)).xpointer);
            (void)Array__append(continue_labels, ((CAST)(0)).xpointer);
            (void)Array__append(loop_levels, ((CAST)(compiler->level)).xpointer);
            (void)Compiler__level_begin(compiler);
            (void)Array__visit(while___k->statements, buffer, compiler, ((void (*)(void *, String, Compiler))(Statement__visit)));
            continue_label = (t__0 = (Pointer_Pointer)(Array__fetch1(continue_labels, size)), *(Unsigned *)(&t__0));
            if ((continue_label != 0)) {
                (void)Compiler__pad_append(compiler, buffer);
                (void)String__string_append(buffer, (t__1 = String__form(((String)"\020continue__%d%:;\n")), String__divide((t__1), Unsigned__f(continue_label))));
            }
            (void)Compiler__level_end(compiler);
            (void)Compiler__pad_append(compiler, buffer);
            (void)String__buffer_append(((String)"\002}\n"), buffer);
            break_label = (t__2 = (Pointer_Pointer)(Array__fetch1(break_labels, size)), *(Unsigned *)(&t__2));
            if ((break_label != 0)) {
                (void)Compiler__pad_append(compiler, buffer);
                (void)String__string_append(buffer, (t__3 = String__form(((String)"\015break__%d%:;\n")), String__divide((t__3), Unsigned__f(break_label))));
            }
            (void)Array__trim(break_labels, size);
            (void)Array__trim(continue_labels, size);
            (void)Array__trim(loop_levels, size);
            break;
    }
}


