#ifndef COMPILER_INCLUDED
#define COMPILER_INCLUDED 1

/* Declare all enum's and typedef's first: */
/* h_emit1 */
typedef struct Collection__Struct *Collection;
enum Compile_Phase__Enum {
    Compile_Phase___ezc_read_library_type_find,
    Compile_Phase___ezc_read,
    Compile_Phase___ezg_read,
    Compile_Phase___h_generate,
    Compile_Phase___c_generate,
    Compile_Phase___c_compile,
    Compile_Phase___link,
};
typedef enum Compile_Phase__Enum Compile_Phase;
typedef struct Compiler__Struct *Compiler;
enum Phase__Enum {
    Phase___prefix_scan,
    Phase___ezh_emit,
    Phase___h_includes_emit,
    Phase___h_typedefs_emit,
    Phase___h_structs_emit,
    Phase___h_externs_emit,
    Phase___c_emit,
    Phase___c_defines_emit,
    Phase___link_emit,
    Phase___link_scan,
    Phase___ezh_scan,
    Phase___generate_emit,
    Phase___source_find,
};
typedef enum Phase__Enum Phase;
typedef struct Variable__Struct *Variable;
typedef struct Source__Struct *Source;
/* h_emit2 */
/* h_emit3 */

/* Include other libraries exactly once: */
#ifndef EASY_C_INCLUDED
#include "Easy_C.ez.h"/*D2*/
#endif /* EASY_C_INCLUDED */
#ifndef EZCC_INCLUDED
#include "EZCC.ez.h"/*D2*/
#endif /* EZCC_INCLUDED */
#ifndef DECLARATION_INCLUDED
#include "Declaration.ez.h"/*D2*/
#endif /* DECLARATION_INCLUDED */
#ifndef PARSE_INCLUDED
#include "Parse.ez.h"/*D2*/
#endif /* PARSE_INCLUDED */
#ifndef TOKEN_INCLUDED
#include "Token.ez.h"/*D2*/
#endif /* TOKEN_INCLUDED */
#ifndef UNIX_INCLUDED
#include "Unix.ez.h"/*D2*/
#endif /* UNIX_INCLUDED */

/* Define the structures: */
struct Collection__Struct {
    String name;
    Array sources;
    Unsigned version_major;
    Unsigned version_minor;
};
extern struct Collection__Struct Collection__Initial;/*D1*/
struct Compiler__Struct {
    Array break_labels;
    String buffer;
    Unsigned c_indent;
    Array collections;
    Hash_Table collection_table;
    Array continue_labels;
    Routine_Declaration current_routine;
    Logical cast_suppress;
    Hash_Table define_table;
    Array defines;
    Array defines_prefixes;
    Array define_datas;
    Array error_kinds;
    Array error_tokens;
    Array enumeration_prefixes;
    File file;
    Hash_Table file_table;
    Array files;
    Array global_libraries;
    Array includes;
    Array interface_bases;
    Unsigned label_count;
    Unsigned level;
    Array library_bases;
    Array loads;
    Array loop_levels;
    Messages messages;
    String middlefix;
    Options options;
    Parser parser;
    Phase phase;
    Hash_Table scalar_table;
    Array scanned_types;
    Array searches;
    String search_options;
    String other_typedefs;
    Hash_Table simple_table;
    String simple_typedefs;
    Source source;
    Array sources;
    Hash_Table source_table;
    Array statements;
    Array switch_levels;
    Array temporaries;
    String temporary;
    String temporary2;
    Token token;
    Tokenizer tokenizer;
    Unsigned trace_line;
    Logical tracing;
    Traverser traverser;
    Type type_byte;
    Type type_character;
    Type type_double;
    Type type_easy_c;
    Type type_float;
    Type type_integer;
    Type type_long_integer;
    Type type_long_unsigned;
    Type type_logical;
    Type type_quad;
    Type type_pointer_pointer;
    Type type_short;
    Type type_string;
    Type type_unsigned;
    Typed_Name typed_name;
    Hash_Table xtyped_name_object_table;
    Array variables;
    Hash_Table variable_table;
    Logical undefs_generated;
};
extern struct Compiler__Struct Compiler__Initial;/*D1*/
struct Variable__Struct {
    String name;
    Type type;
    Unsigned level;
};
extern struct Variable__Struct Variable__Initial;/*D1*/
struct Source__Struct {
    String base_name;
    Collection collection;
    Collection_Declaration collection_declaration;
    Array defines;
    File ezc;
    File ezg;
    Array global_libraries;
    Array interfaces;
    Array libraries;
    Array requires;
};
extern struct Source__Struct Source__Initial;/*D1*/

/* Declare the routine prototypes: */
extern Collection Collection__null;/*D10*/
extern Collection Collection__new(void);/*D11*/
extern void Collection__erase(Collection);/*D12*/
extern Compile_Phase Compile_Phase__ezc_read_library_type_find;/*D3*/
extern Compile_Phase Compile_Phase__ezc_read;/*D3*/
extern Compile_Phase Compile_Phase__ezg_read;/*D3*/
extern Compile_Phase Compile_Phase__h_generate;/*D3*/
extern Compile_Phase Compile_Phase__c_generate;/*D3*/
extern Compile_Phase Compile_Phase__c_compile;/*D3*/
extern Compile_Phase Compile_Phase__link;/*D3*/
extern Compile_Phase Compile_Phase__null;/*D6*/
extern String Compile_Phase__string_convert(Compile_Phase);/*D7*/
extern void Compile_Phase__erase(Compile_Phase);/*D8*/
extern Compiler Compiler__null;/*D10*/
extern Compiler Compiler__new(void);/*D11*/
extern void Compiler__erase(Compiler);/*D12*/
extern Phase Phase__prefix_scan;/*D3*/
extern Phase Phase__ezh_emit;/*D3*/
extern Phase Phase__h_includes_emit;/*D3*/
extern Phase Phase__h_typedefs_emit;/*D3*/
extern Phase Phase__h_structs_emit;/*D3*/
extern Phase Phase__h_externs_emit;/*D3*/
extern Phase Phase__c_emit;/*D3*/
extern Phase Phase__c_defines_emit;/*D3*/
extern Phase Phase__link_emit;/*D3*/
extern Phase Phase__link_scan;/*D3*/
extern Phase Phase__ezh_scan;/*D3*/
extern Phase Phase__generate_emit;/*D3*/
extern Phase Phase__source_find;/*D3*/
extern Phase Phase__null;/*D6*/
extern String Phase__string_convert(Phase);/*D7*/
extern void Phase__erase(Phase);/*D8*/
extern Variable Variable__null;/*D10*/
extern Variable Variable__new(void);/*D11*/
extern void Variable__erase(Variable);/*D12*/
extern Source Source__null;/*D10*/
extern Source Source__new(void);/*D11*/
extern void Source__erase(Source);/*D12*/
extern void Array__visit(Array, String, Compiler, void (*)(void *, String, Compiler));
extern Collection Collection__create(String, Source);
extern void Collection__buffer_append(Collection, String);
extern String Compile_Phase__f(Compile_Phase);
extern Collection Compiler__collection_register(Compiler, Collection_Declaration, Source);
extern void Compiler__define_register(Compiler, Define_Declaration);
extern Unsigned Compiler__defines_check(Compiler);
extern void Compiler__location_push(Compiler, String, Token);
extern void Compiler__location_pop(Compiler);
extern Logical Compiler__messages_dump(Compiler);
extern Logical Compiler__phase(Compiler, String, Unsigned (*)(Source, Compiler));
extern void Compiler__simple_type_insert(Compiler, String, Type);
extern Type Compiler__simple_type_lookup(Compiler, String);
extern Unsigned Compiler__source_register(Compiler, String, Token);
extern Typed_Name_Object Compiler__type_name_lookup(Compiler, String, Type, Token);
extern Typed_Name_Object Compiler__type_name_routine_lookup(Compiler, String, Type, Token);
extern Typed_Name_Object Compiler__typed_name_lookup(Compiler, Typed_Name, Token);
extern Logical Compiler__typed_name_insert(Compiler, Typed_Name, Typed_Name_Object, Token, String);
extern void Compiler__trace(Compiler, Token);
extern Compiler Compiler__one_and_only(void);
extern Compiler Compiler__create(Options, Messages);
extern Logical Compiler__enter(Compiler, String, Logical);
extern Unsigned Compiler__c_pad_get(Compiler);
extern void Compiler__pad_append(Compiler, String);
extern Logical Compiler__leave(Compiler, String, Logical);
extern void Compiler__log(Compiler, Token, String);
extern Type Compiler__type_lookup(Compiler, String, Token);
extern void Compiler__level_begin(Compiler);
extern void Compiler__level_end(Compiler);
extern void Compiler__scalar_insert(Compiler, String, Type, Token);
extern Type Compiler__scalar_lookup(Compiler, String);
extern void Compiler__undefs_append(Compiler, String);
extern String Compiler__variable_temporary(Compiler, Type);
extern Variable Compiler__variable_insert(Compiler, String, Type, Logical);
extern Variable Compiler__variable_lookup(Compiler, String);
extern void Compiler__variables_clear(Compiler);
extern String Phase__f(Phase);
extern void Phase__xxxformat(Phase, String);
extern void Source__buffer_append(Source, String);
extern Unsigned Source__c_compile(Source, Compiler);
extern Unsigned Source__c_emit(Source, Compiler);
extern Source Source__create(String, Compiler);
extern Unsigned Source__ezg_generate(Source, Compiler);
extern Unsigned Source__h_emit(Source, Compiler);
extern Unsigned Source__link_scan(Source, Compiler);
extern Unsigned Source__prefix_scan(Source, Compiler);
extern Logical Source__should_compile(Source, Compiler);
extern void Source__show(Source);
extern void Source__type_arm(Source);
extern void Source__type_disarm(Source);
extern Unsigned Source__typed_name_object_find(Source, Compiler);
extern void Variable__show(Variable, String);
extern Variable Variable__create(String, Type);
extern Collection Collection__null;;/*D13*/
extern Collection Collection__new(void);
extern Compile_Phase Compile_Phase__ezc_read_library_type_find;;/*D13*/
extern Compile_Phase Compile_Phase__ezc_read;;/*D13*/
extern Compile_Phase Compile_Phase__ezg_read;;/*D13*/
extern Compile_Phase Compile_Phase__h_generate;;/*D13*/
extern Compile_Phase Compile_Phase__c_generate;;/*D13*/
extern Compile_Phase Compile_Phase__c_compile;;/*D13*/
extern Compile_Phase Compile_Phase__link;;/*D13*/
extern String Compile_Phase__string_convert(Compile_Phase);
extern Compile_Phase Compile_Phase__null;;/*D13*/
extern Compile_Phase Compile_Phase__new(void);
extern Compiler Compiler__null;;/*D13*/
extern Compiler Compiler__new(void);
extern Phase Phase__prefix_scan;;/*D13*/
extern Phase Phase__ezh_emit;;/*D13*/
extern Phase Phase__h_includes_emit;;/*D13*/
extern Phase Phase__h_typedefs_emit;;/*D13*/
extern Phase Phase__h_structs_emit;;/*D13*/
extern Phase Phase__h_externs_emit;;/*D13*/
extern Phase Phase__c_emit;;/*D13*/
extern Phase Phase__c_defines_emit;;/*D13*/
extern Phase Phase__link_emit;;/*D13*/
extern Phase Phase__link_scan;;/*D13*/
extern Phase Phase__ezh_scan;;/*D13*/
extern Phase Phase__generate_emit;;/*D13*/
extern Phase Phase__source_find;;/*D13*/
extern String Phase__string_convert(Phase);
extern Phase Phase__null;;/*D13*/
extern Phase Phase__new(void);
extern Variable Variable__null;;/*D13*/
extern Variable Variable__new(void);
extern Source Source__null;;/*D13*/
extern Source Source__new(void);

/* Declare extracted #define values: */
extern Unsigned Unsigned__unix_errno_2big;
extern Unsigned Unsigned__unix_errno_acces;
extern Unsigned Unsigned__unix_errno_addrinuse;
extern Unsigned Unsigned__unix_errno_addrnotavail;
extern Unsigned Unsigned__unix_errno_adv;
extern Unsigned Unsigned__unix_errno_afnosupport;
extern Unsigned Unsigned__unix_errno_again;
extern Unsigned Unsigned__unix_errno_already;
extern Unsigned Unsigned__unix_errno_asy_c_included;
extern Unsigned Unsigned__unix_errno_bade;
extern Unsigned Unsigned__unix_errno_badf;
extern Unsigned Unsigned__unix_errno_badfd;
extern Unsigned Unsigned__unix_errno_badmsg;
extern Unsigned Unsigned__unix_errno_badr;
extern Unsigned Unsigned__unix_errno_badrqc;
extern Unsigned Unsigned__unix_errno_badslt;
extern Unsigned Unsigned__unix_errno_bfont;
extern Unsigned Unsigned__unix_errno_busy;
extern Unsigned Unsigned__unix_errno_canceled;
extern Unsigned Unsigned__unix_errno_child;
extern Unsigned Unsigned__unix_errno_chrng;
extern Unsigned Unsigned__unix_errno_comm;
extern Unsigned Unsigned__unix_errno_connaborted;
extern Unsigned Unsigned__unix_errno_connrefused;
extern Unsigned Unsigned__unix_errno_connreset;
extern Unsigned Unsigned__unix_errno_deadlk;
extern Unsigned Unsigned__unix_errno_destaddrreq;
extern Unsigned Unsigned__unix_errno_dom;
extern Unsigned Unsigned__unix_errno_dotdot;
extern Unsigned Unsigned__unix_errno_dquot;
extern Unsigned Unsigned__unix_errno_exist;
extern Unsigned Unsigned__unix_errno_fault;
extern Unsigned Unsigned__unix_errno_fbig;
extern Unsigned Unsigned__unix_errno_hostdown;
extern Unsigned Unsigned__unix_errno_hostunreach;
extern Unsigned Unsigned__unix_errno_hwpoison;
extern Unsigned Unsigned__unix_errno_idrm;
extern Unsigned Unsigned__unix_errno_ilseq;
extern Unsigned Unsigned__unix_errno_inprogress;
extern Unsigned Unsigned__unix_errno_intr;
extern Unsigned Unsigned__unix_errno_inval;
extern Unsigned Unsigned__unix_errno_io;
extern Unsigned Unsigned__unix_errno_isconn;
extern Unsigned Unsigned__unix_errno_isdir;
extern Unsigned Unsigned__unix_errno_isnam;
extern Unsigned Unsigned__unix_errno_keyexpired;
extern Unsigned Unsigned__unix_errno_keyrejected;
extern Unsigned Unsigned__unix_errno_keyrevoked;
extern Unsigned Unsigned__unix_errno_l2hlt;
extern Unsigned Unsigned__unix_errno_l2nsync;
extern Unsigned Unsigned__unix_errno_l3hlt;
extern Unsigned Unsigned__unix_errno_l3rst;
extern Unsigned Unsigned__unix_errno_libacc;
extern Unsigned Unsigned__unix_errno_libbad;
extern Unsigned Unsigned__unix_errno_libexec;
extern Unsigned Unsigned__unix_errno_libmax;
extern Unsigned Unsigned__unix_errno_libscn;
extern Unsigned Unsigned__unix_errno_lnrng;
extern Unsigned Unsigned__unix_errno_loop;
extern Unsigned Unsigned__unix_errno_mediumtype;
extern Unsigned Unsigned__unix_errno_mfile;
extern Unsigned Unsigned__unix_errno_mlink;
extern Unsigned Unsigned__unix_errno_msgsize;
extern Unsigned Unsigned__unix_errno_multihop;
extern Unsigned Unsigned__unix_errno_nametoolong;
extern Unsigned Unsigned__unix_errno_navail;
extern Unsigned Unsigned__unix_errno_netdown;
extern Unsigned Unsigned__unix_errno_netreset;
extern Unsigned Unsigned__unix_errno_netunreach;
extern Unsigned Unsigned__unix_errno_nfile;
extern Unsigned Unsigned__unix_errno_noano;
extern Unsigned Unsigned__unix_errno_nobufs;
extern Unsigned Unsigned__unix_errno_nocsi;
extern Unsigned Unsigned__unix_errno_nodata;
extern Unsigned Unsigned__unix_errno_nodev;
extern Unsigned Unsigned__unix_errno_noent;
extern Unsigned Unsigned__unix_errno_noexec;
extern Unsigned Unsigned__unix_errno_nokey;
extern Unsigned Unsigned__unix_errno_nolck;
extern Unsigned Unsigned__unix_errno_nolink;
extern Unsigned Unsigned__unix_errno_nomedium;
extern Unsigned Unsigned__unix_errno_nomem;
extern Unsigned Unsigned__unix_errno_nomsg;
extern Unsigned Unsigned__unix_errno_nonet;
extern Unsigned Unsigned__unix_errno_nopkg;
extern Unsigned Unsigned__unix_errno_noprotoopt;
extern Unsigned Unsigned__unix_errno_nospc;
extern Unsigned Unsigned__unix_errno_nosr;
extern Unsigned Unsigned__unix_errno_nostr;
extern Unsigned Unsigned__unix_errno_nosys;
extern Unsigned Unsigned__unix_errno_notblk;
extern Unsigned Unsigned__unix_errno_notconn;
extern Unsigned Unsigned__unix_errno_notdir;
extern Unsigned Unsigned__unix_errno_notempty;
extern Unsigned Unsigned__unix_errno_notnam;
extern Unsigned Unsigned__unix_errno_notrecoverable;
extern Unsigned Unsigned__unix_errno_notsock;
extern Unsigned Unsigned__unix_errno_notty;
extern Unsigned Unsigned__unix_errno_notuniq;
extern Unsigned Unsigned__unix_errno_nxio;
extern Unsigned Unsigned__unix_errno_opnotsupp;
extern Unsigned Unsigned__unix_errno_overflow;
extern Unsigned Unsigned__unix_errno_ownerdead;
extern Unsigned Unsigned__unix_errno_perm;
extern Unsigned Unsigned__unix_errno_pfnosupport;
extern Unsigned Unsigned__unix_errno_pipe;
extern Unsigned Unsigned__unix_errno_proto;
extern Unsigned Unsigned__unix_errno_protonosupport;
extern Unsigned Unsigned__unix_errno_prototype;
extern Unsigned Unsigned__unix_errno_range;
extern Unsigned Unsigned__unix_errno_remchg;
extern Unsigned Unsigned__unix_errno_remote;
extern Unsigned Unsigned__unix_errno_remoteio;
extern Unsigned Unsigned__unix_errno_restart;
extern Unsigned Unsigned__unix_errno_rfkill;
extern Unsigned Unsigned__unix_errno_rofs;
extern Unsigned Unsigned__unix_errno_shutdown;
extern Unsigned Unsigned__unix_errno_socktnosupport;
extern Unsigned Unsigned__unix_errno_spipe;
extern Unsigned Unsigned__unix_errno_srch;
extern Unsigned Unsigned__unix_errno_srmnt;
extern Unsigned Unsigned__unix_errno_stale;
extern Unsigned Unsigned__unix_errno_strpipe;
extern Unsigned Unsigned__unix_errno_time;
extern Unsigned Unsigned__unix_errno_timedout;
extern Unsigned Unsigned__unix_errno_toomanyrefs;
extern Unsigned Unsigned__unix_errno_txtbsy;
extern Unsigned Unsigned__unix_errno_uclean;
extern Unsigned Unsigned__unix_errno_unatch;
extern Unsigned Unsigned__unix_errno_users;
extern Unsigned Unsigned__unix_errno_xdev;
extern Unsigned Unsigned__unix_errno_xfull;
extern Unsigned Unsigned__unix_errno_xit_failure;
extern Unsigned Unsigned__unix_errno_xit_success;
extern Unsigned Unsigned__unix_errno_asyc_c_h_included;
extern Integer Integer__unix_file_f_dupfd;
extern Integer Integer__unix_file_f_dupfd_cloexec;
extern Integer Integer__unix_file_f_exlck;
extern Integer Integer__unix_file_f_getfd;
extern Integer Integer__unix_file_f_getfl;
extern Integer Integer__unix_file_f_getlk;
extern Integer Integer__unix_file_f_getlk64;
extern Integer Integer__unix_file_f_getown;
extern Integer Integer__unix_file_f_lock;
extern Integer Integer__unix_file_f_ok;
extern Integer Integer__unix_file_f_rdlck;
extern Integer Integer__unix_file_f_setfd;
extern Integer Integer__unix_file_f_setfl;
extern Integer Integer__unix_file_f_setlk;
extern Integer Integer__unix_file_f_setlk64;
extern Integer Integer__unix_file_f_setlkw;
extern Integer Integer__unix_file_f_setlkw64;
extern Integer Integer__unix_file_f_setown;
extern Integer Integer__unix_file_f_shlck;
extern Integer Integer__unix_file_f_test;
extern Integer Integer__unix_file_f_tlock;
extern Integer Integer__unix_file_f_ulock;
extern Integer Integer__unix_file_f_unlck;
extern Integer Integer__unix_file_f_wrlck;
extern Unsigned Unsigned__unix_file_o_accmode;
extern Unsigned Unsigned__unix_file_o_append;
extern Unsigned Unsigned__unix_file_o_async;
extern Unsigned Unsigned__unix_file_o_cloexec;
extern Unsigned Unsigned__unix_file_o_creat;
extern Unsigned Unsigned__unix_file_o_directory;
extern Unsigned Unsigned__unix_file_o_dsync;
extern Unsigned Unsigned__unix_file_o_excl;
extern Unsigned Unsigned__unix_file_o_noctty;
extern Unsigned Unsigned__unix_file_o_nofollow;
extern Unsigned Unsigned__unix_file_o_nonblock;
extern Unsigned Unsigned__unix_file_o_rdonly;
extern Unsigned Unsigned__unix_file_o_rdwr;
extern Unsigned Unsigned__unix_file_o_sync;
extern Unsigned Unsigned__unix_file_o_trunc;
extern Unsigned Unsigned__unix_file_o_wronly;
#endif /* COMPILER_INCLUDED */
