#include "EZCC.ez.h"/*cc2*/
/* # Copyright (c) 2004-2011 by Wayne C. Gramlich. */
/* # All rights reserved. */
#include "Compiler.ez.h"/*D1*/
#include "Easy_C.ez.h"/*D1*/
#include "Parse.ez.h"/*D1*/
#include "Token.ez.h"/*D1*/
#include "Unix.ez.h"/*D1*/
/* # Parse tree for #defines: */
/* # {Easy_C} routines: */
/* #undef lower case macros */
#undef i386
#undef linux
#undef unix
#undef errno
#undef makedev
#undef major
#undef minor
#undef alloca

Integer Easy_C__main(
  Array arguments)
{
    Options options;
    Logical compile_only;
    String compiler_executable;
    String linker_executable;
    Logical debug;
    String executable_name;
    String interface_extract;
    String search_options;
    String suffix;
    Unsigned trace_line;
    Array source_bases;
    Messages messages;
    String temporary;
    Unsigned errors;
    Compiler compiler;
    Tokenizer tokenizer;
    Array library_bases;
    Array interface_bases;
    Array sources;
    Unsigned size;
    Unsigned index;
    Source source;
    String first_source_base;
    String main_file_name;
    String main_file;
    String link_command;
    Collection collection0;
    Logical library_generate;
    String library_full_name;
    String library_partial_name;
    String excutable_name;
    Array scanned_types;
    Array loads;
    Collection collection;
    Type scanned_type;
    Array require_bases;
    String middlefix;
    String require_base;
    File require_file;
    String compile_command;
    Array collections;
    Out_Stream main_stream;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    String t__37;
    String t__38;
    String t__39;
    (void)System__fail_routine_set(Easy_C__compiler_fail);
    options = Options__extract(arguments);
    if ((options == Options__null)) {
        return 1;
    }
    options->debug = Logical__true;
    compile_only = options->compile_only;
    compiler_executable = options->compiler_executable;
    linker_executable = options->linker_executable;
    debug = options->debug;
    executable_name = options->executable_name;
    interface_extract = options->interface_extract;
    search_options = options->search_options;
    suffix = options->suffix;
    trace_line = options->trace_line;
    source_bases = options->source_bases;
    messages = Messages__create(Out_Stream__error);
    temporary = String__new();
    errors = 0;
    compiler = Compiler__create(options, messages);
    tokenizer = compiler->tokenizer;
    library_bases = compiler->library_bases;
    interface_bases = compiler->interface_bases;
    if ((interface_extract != String__null)) {
        return Easy_C__framus(interface_extract, compiler, options, messages);
    }
    sources = compiler->sources;
    size = Array__size_get(source_bases);
    index = 0;
    while ((index < size)) {
        (void)Compiler__source_register(compiler, ((String)Array__fetch1(source_bases, index)), Token__null);
        index = (index+1);
    }
    if (Compiler__messages_dump(compiler)) {
        return 1;
    }
    if (0) {
        index = 0;
        size = Array__size_get(sources);
        while ((index < size)) {
            source = ((Source)Array__fetch1(sources, index));
            (void)String__d((t__2 = String__form(((String)"\020Source[%d%]:%v%\n")), t__3 = Unsigned__f(index), String__divide(String__remainder((t__2), t__3), String__f(source->base_name))));
            (void)Source__show(source);
            index = (index+1);
        }
    }
    (void)Compiler__defines_check(compiler);
    if (Compiler__messages_dump(compiler)) {
        return 1;
    }
    if (Compiler__phase(compiler, ((String)"\0025a"), Source__prefix_scan)) {
        return 1;
    }
    if (Compiler__phase(compiler, ((String)"\0025b"), Source__ezg_generate)) {
        return 1;
    }
    if (Compiler__phase(compiler, ((String)"\0017"), Source__typed_name_object_find)) {
        return 1;
    }
    if (Compiler__phase(compiler, ((String)"\0018"), Source__h_emit)) {
        return 1;
    }
    if (Compiler__phase(compiler, ((String)"\0019"), Source__c_emit)) {
        return 1;
    }
    size = Array__size_get(sources);
    index = 0;
    while ((index < size)) {
        source = ((Source)Array__fetch1(sources, index));
        (void)Source__c_compile(source, compiler);
        index = (index+1);
    }
    if (Compiler__messages_dump(compiler)) {
        return 1;
    }
    first_source_base = ((String)Array__fetch1(source_bases, 0));
    main_file_name = String__read_only_copy((t__6 = String__form(((String)"\015/tmp/%s%%s%.c")), t__7 = String__f(first_source_base), String__divide(String__remainder((t__6), t__7), String__f(compiler->middlefix))));
    main_file = String__new();
    (void)String__string_append(main_file, ((String)"\045typedef struct Array__Struct *Array;\n"));
    (void)String__string_append(main_file, ((String)"\050typedef struct String__Struct *String;\n\n"));
    (void)String__string_append(main_file, ((String)"\037extern Array Array__new(void);\n"));
    (void)String__string_append(main_file, ((String)"\041extern String String__new(void);\n"));
    (void)String__string_append(main_file, ((String)"\061extern void String__unix_append(String, char *);\n"));
    (void)String__string_append(main_file, ((String)"\046extern Array__append(Array, String);\n\n"));
    (void)String__string_append(main_file, ((String)"\040extern int Easy_C__main(Array);\n"));
    (void)String__string_append(main_file, ((String)"\012int main(\n"));
    (void)String__string_append(main_file, ((String)"\014  int argc,\n"));
    (void)String__string_append(main_file, ((String)"\017  char **argv)\n"));
    (void)String__string_append(main_file, ((String)"\002{\n"));
    (void)String__string_append(main_file, ((String)"\017    int index;\n"));
    (void)String__string_append(main_file, ((String)"\017    int phase;\n"));
    (void)String__string_append(main_file, ((String)"\025    Array arguments;\n"));
    (void)String__string_append(main_file, ((String)"\026    String argument;\n\n"));
    (void)String__string_append(main_file, ((String)"\036    arguments = Array__new();\n"));
    (void)String__string_append(main_file, ((String)"\055    for (index = 0; index < argc; index++) {\n"));
    (void)String__string_append(main_file, ((String)"\033\targument = String__new();\n"));
    (void)String__string_append(main_file, ((String)"\055\tString__unix_append(argument, argv[index]);\n"));
    (void)String__string_append(main_file, ((String)"\045\tArray__append(arguments, argument);\n"));
    (void)String__string_append(main_file, ((String)"\006    }\n"));
    link_command = String__new();
    (void)String__string_append(link_command, linker_executable);
    collection0 = ((Source)Array__fetch1(sources, 0))->collection;
    library_generate = (collection0 != Collection__null);
    library_full_name = String__null;
    library_partial_name = String__null;
    if (library_generate) {
        library_full_name = String__read_only_copy((t__11 = String__form(((String)"\021lib%s%.so.%d%.%d%")), t__12 = String__f(collection0->name), t__13 = Unsigned__f(collection0->version_major), String__divide(String__remainder(String__remainder((t__11), t__12), t__13), Unsigned__f(collection0->version_minor))));
        library_partial_name = String__read_only_copy((t__16 = String__form(((String)"\015lib%s%.so.%d%")), t__17 = String__f(collection0->name), String__divide(String__remainder((t__16), t__17), Unsigned__f(collection0->version_major))));
        (void)String__string_append(link_command, (t__18 = String__form(((String)"\030 -shared -Wl,-soname,%s%")), String__divide((t__18), String__f(library_partial_name))));
    }
    excutable_name = options->executable_name;
    if (options->debug) {
        (void)String__string_append(link_command, ((String)"\003 -g"));
    }
    if (options->optimize) {
        (void)String__string_append(link_command, ((String)"\004 -O2"));
    }
    (void)String__string_append(link_command, ((String)"\004 -o "));
    if ((String__size_get(executable_name) == 0)) {
        if (library_generate) {
            (void)String__string_append(link_command, (t__19 = String__form(((String)"\004%s% ")), String__divide((t__19), String__f(library_full_name))));
        } else {
            (void)String__string_append(link_command, (t__20 = String__form(((String)"\007%s%%s% ")), t__21 = String__f(first_source_base), String__divide(String__remainder((t__20), t__21), String__f(compiler->middlefix))));
        }
    } else {
        (void)String__string_append(link_command, (t__22 = String__form(((String)"\004%s% ")), String__divide((t__22), String__f(executable_name))));
    }
    if ((!options->plain_main&&!library_generate)) {
        (void)String__string_append(link_command, main_file_name);
    }
    scanned_types = Array__new();
    loads = Array__new();
    index = 0;
    size = Array__size_get(sources);
    while ((index < size)) {
        source = ((Source)Array__fetch1(sources, index));
        collection = source->collection;
        if (library_generate) {
            if ((collection == collection0)) {
                (void)String__string_append(link_command, (t__23 = String__form(((String)"\006 %s%.o")), String__divide((t__23), String__f(source->base_name))));
            }
        } else if ((collection == Collection__null)) {
            (void)Source__link_scan(source, compiler);
            (void)Array__array_append(scanned_types, compiler->scanned_types);
            (void)Array__array_append(loads, compiler->loads);
            (void)Array__trim(compiler->scanned_types, 0);
            (void)Array__trim(compiler->loads, 0);
            (void)String__string_append(link_command, (t__24 = String__form(((String)"\011 %s%%s%.o")), t__25 = String__f(source->base_name), String__divide(String__remainder((t__24), t__25), String__f(compiler->middlefix))));
        }
        index = (index+1);
    }
    (void)String__string_append(main_file, ((String)"\001\n"));
    (void)Array__sort(scanned_types, ((Integer (*)(void *, void *))(Type__compare)));
    (void)Array__unique(scanned_types, ((Logical (*)(void *, void *))(Type__equal)));
    (void)Array__sort(loads, ((Integer (*)(void *, void *))(String__compare)));
    (void)Array__unique(loads, ((Logical (*)(void *, void *))(String__equal)));
    size = Array__size_get(scanned_types);
    index = 0;
    while ((index < size)) {
        scanned_type = ((Type)Array__fetch1(scanned_types, index));
        (void)String__string_append(main_file, (t__26 = String__form(((String)"\027    %s%__Initialize();\n")), String__divide((t__26), String__f(Type__base_name(scanned_type)))));
        index = (index+1);
    }
    require_bases = options->require_bases;
    (void)Array__sort(require_bases, ((Integer (*)(void *, void *))(String__compare)));
    (void)Array__unique(require_bases, ((Logical (*)(void *, void *))(String__equal)));
    size = Array__size_get(require_bases);
    if ((size != 0)) {
        middlefix = compiler->middlefix;
        index = 0;
        while ((index < size)) {
            require_base = ((String)Array__fetch1(require_bases, index));
            require_file = File__read(require_base, ((String)"\000"), ((String)"\002.c"), compiler);
            if ((require_file != File__null)) {

                compile_command = String__new();
                (void)String__string_append(compile_command, options->compiler_executable);
                if (options->debug) {
                    (void)String__string_append(compile_command, ((String)"\003 -g"));
                }
                if (options->optimize) {
                    (void)String__string_append(compile_command, ((String)"\004 -O2"));
                }
                (void)String__string_append(compile_command, (t__27 = String__form(((String)"\035 -c -o %s%%s%.o %s% %s%/%s%.c")), t__28 = String__f(require_base), t__29 = String__f(middlefix), t__30 = String__f(search_options), t__31 = String__f(require_file->directory), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__27), t__28), t__29), t__30), t__31), String__f(require_base))));
                (void)String__d((t__33 = String__form(((String)"\004%s%\n")), String__divide((t__33), String__f(compile_command))));
                (void)System__execute(compile_command);
            }
            (void)String__string_append(link_command, (t__34 = String__form(((String)"\011 %s%%s%.o")), t__35 = String__f(require_base), String__divide(String__remainder((t__34), t__35), String__f(middlefix))));
            index = (index+1);
        }
    }
    if (options->profile) {
        (void)String__string_append(link_command, ((String)"\005 -pg "));
    }
    if (!library_generate) {
        collections = compiler->collections;
        size = Array__size_get(collections);
        if ((size != 0)) {
            (void)String__string_append(link_command, options->linker_options);
            index = 0;
            while ((index < size)) {
                collection = ((Collection)Array__fetch1(collections, index));
                (void)String__string_append(link_command, (t__36 = String__form(((String)"\006 -l%s%")), String__divide((t__36), String__f(collection->name))));
                index = (index+1);
            }
        }
    }
    size = Array__size_get(loads);
    index = 0;
    while ((index < size)) {
        (void)String__string_append(link_command, (t__37 = String__form(((String)"\004 %s%")), String__divide((t__37), String__f(((String)Array__fetch1(loads, index))))));
        index = (index+1);
    }
    (void)String__string_append(main_file, ((String)"\044    return Easy_C__main(arguments);\n"));
    (void)String__string_append(main_file, ((String)"\002}\n"));
    if (!library_generate) {
        main_stream = Out_Stream__open(main_file_name);
        if (!((main_stream != Out_Stream__null))) {
            System__assert_fail((String)"\10EZCC.ezc", 487);
        }
        (void)String__put(main_file, main_stream);
        (void)Out_Stream__close(main_stream);
    }
    (void)String__d((t__39 = String__form(((String)"\022link command: %v%\n")), String__divide((t__39), String__f(link_command))));
    (void)System__execute(link_command);
    if (Compiler__messages_dump(compiler)) {
        return 1;
    }
    return 0;
}

void Easy_C__compiler_fail(
  String kind,
  String file_name,
  Unsigned line_number)
{
    Compiler compiler;
    Messages messages;
    Array error_kinds;
    Array error_tokens;
    Unsigned error_kinds_size;
    Unsigned error_tokens_size;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    compiler = Compiler__one_and_only();
    messages = compiler->messages;
    error_kinds = compiler->error_kinds;
    error_tokens = compiler->error_tokens;
    error_kinds_size = Array__size_get(error_kinds);
    error_tokens_size = Array__size_get(error_tokens);
    if (((error_kinds_size != 0)&&(error_tokens_size != 0))) {
        (void)Messages__log(messages, ((Token)Array__fetch1(error_tokens, (error_tokens_size-1))), (t__0 = String__form(((String)"\104Processing a %s% caused a %s% failure in %v% at line %d% (phase %s%)")), t__1 = String__f(((String)Array__fetch1(error_kinds, (error_kinds_size-1)))), t__2 = String__f(kind), t__3 = String__f(file_name), t__4 = Unsigned__f(line_number), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__0), t__1), t__2), t__3), t__4), Phase__f(compiler->phase))));
    }
    (void)Messages__dump(messages, Out_Stream__error);
    (void)String__d((t__8 = String__form(((String)"\037%s% failure in %v% at line %d%\n")), t__9 = String__f(kind), t__10 = String__f(file_name), String__divide(String__remainder(String__remainder((t__8), t__9), t__10), Unsigned__f(line_number))));
    (void)Out_Stream__flush(Out_Stream__error);
    (void)System__abort();
}

Integer Easy_C__framus(
  String interface_extract,
  Compiler compiler,
  Options options,
  Messages messages)
{
    String compiler_executable;
    Tokenizer tokenizer;
    String search_options;
    In_Stream c_stream;
    String c_contents;
    Array c_tokens;
    Array indents;
    Token token;
    Parser parser;
    C_Root c_root;
    In_Stream define_stream;
    String define_contents;
    Array define_tokens;
    Array error_list;
    Array error_indices;
    Unsigned error_list_size;
    Lexeme lexeme;
    Unsigned s;
    Unsigned i;
    Unsigned ex;
    Define_Root define_root;
    String extract_file;
    Array c_declarations;
    Unsigned size;
    Unsigned index;
    C_Declaration c_declaration;
    C_Struct struct___k;
    String struct_name;
    Comma_Separated xarguments;
    C_Type return_type;
    String routine_name;
    C_Extern extern___k;
    C_Extern1 extern1;
    C_Extern2 extern2;
    Unsigned xarguments_size;
    Unsigned xarguments_index;
    C_Argument xargument;
    String name;
    String return_type_name;
    String lower_struct_name;
    Array fields;
    Unsigned fields_size;
    Unsigned fields_index;
    C_Field field;
    C_Field1 field1;
    C_Field2 field2;
    String interface_lower_case;
    Array defines;
    Array define_lines;
    Define define;
    String lower_case;
    Define_Line define_line;
    String file_name;
    Out_Stream extract_stream;
    Unsigned define_lines_size;
    Unsigned define_lines_index;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    Pointer_Pointer t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    String t__37;
    String t__38;
    String t__39;
    String t__40;
    String t__41;
    String t__42;
    String t__43;
    String t__44;
    String t__45;
    String t__46;
    String t__47;
    String t__48;
    String t__49;
    String t__50;
    String t__51;
    String t__52;
    String t__53;
    String t__54;
    String t__55;
    String t__56;
    String t__57;
    String t__58;
    String t__59;
    String t__60;
    String t__61;
    String t__62;
    String t__63;
    String t__64;
    String t__65;
    String t__66;
    String t__67;
    String t__68;
    String t__69;
    String t__70;
    String t__71;
    String t__72;
    String t__73;
    String t__74;
    String t__75;
    String t__76;
    String t__77;
    String t__78;
    String t__79;
    String t__80;
    String t__81;
    compiler_executable = options->compiler_executable;
    tokenizer = compiler->tokenizer;
    search_options = options->search_options;
    c_stream = In_Stream__pipe_read((t__0 = String__form(((String)"\034%s% -E %s%.x.h | grep -v '#'")), t__1 = String__f(compiler_executable), String__divide(String__remainder((t__0), t__1), String__f(interface_extract))));
    c_contents = In_Stream__all_read(c_stream, String__null);
    (void)In_Stream__close(c_stream);
    c_tokens = Array__new();
    indents = Array__new();
    (void)Array__append(indents, ((CAST)(0)).xpointer);
    tokenizer->contents = c_contents;
    tokenizer->tokens = c_tokens;
    tokenizer->index = 0;
    tokenizer->indents = indents;
    while (Logical__true) {
        token = Tokenizer__next(tokenizer);
        switch (token->lexeme) {
            case Lexeme___end_of_file:
                (void)Array__append(c_tokens, ((void *)(token)));
                goto break__1;
                break;
            case Lexeme___open_indent:
            case Lexeme___end_of_line:
            case Lexeme___close_indent:
                /* do_nothing */
                break;
            default:
                (void)Array__append(c_tokens, ((void *)(token)));
                break;
        }
    }
    break__1:;
    parser = Parser__create(c_tokens, messages);
    c_root = C_Root__parse(parser);
    define_stream = In_Stream__pipe_read((t__2 = String__form(((String)"\115%s% -dM -E %s% -I. %s%.x.h | sed s,#,,g | sed /[0-9]EE/d | sed /[0-9]D[DLF]/d")), t__3 = String__f(compiler_executable), t__4 = String__f(search_options), String__divide(String__remainder(String__remainder((t__2), t__3), t__4), String__f(interface_extract))));
    define_contents = In_Stream__all_read(define_stream, String__null);
    (void)In_Stream__close(define_stream);
    define_tokens = Array__new();
    indents = Array__new();
    (void)Array__append(indents, ((CAST)(0)).xpointer);
    tokenizer->contents = define_contents;
    tokenizer->tokens = define_tokens;
    tokenizer->index = 0;
    tokenizer->indents = indents;
    error_list = messages->errors;
    error_indices = Array__new();
    error_list_size = Array__size_get(error_list);
    lexeme = Lexeme__at_sign;
    while ((lexeme != Lexeme__end_of_file)) {
        token = Tokenizer__next(tokenizer);
        lexeme = token->lexeme;
        (void)Array__append(define_tokens, ((void *)(token)));
        if ((Array__size_get(error_list) != error_list_size)) {
            error_list_size = Array__size_get(error_list);
            (void)Array__append(error_indices, ((CAST)(Array__size_get(define_tokens))).xpointer);
        }
    }
    s = Array__size_get(error_indices);
    i = 0;
    while ((i < s)) {
        ex = (t__5 = (Pointer_Pointer)(Array__fetch1(error_indices, i)), *(Unsigned *)(&t__5));
        (void)String__d((t__10 = String__form(((String)"\042[-2]:%v% [-1]:%v% [0]:%v% [+1]%v%\n")), t__11 = Token__f(((Token)Array__fetch1(define_tokens, (ex-2)))), t__12 = Token__f(((Token)Array__fetch1(define_tokens, (ex-1)))), t__13 = Token__f(((Token)Array__fetch1(define_tokens, ex))), String__divide(String__remainder(String__remainder(String__remainder((t__10), t__11), t__12), t__13), Token__f(((Token)Array__fetch1(define_tokens, (ex+1)))))));
        i = (i+1);
    }
    parser = Parser__create(define_tokens, messages);
    define_root = Define_Root__parse(parser);
    extract_file = String__new();
    (void)String__string_append(extract_file, ((String)"\020library Easy_C\n\n"));
    (void)String__string_append(extract_file, (t__14 = String__form(((String)"\017include %s%_C\n\n")), String__divide((t__14), String__f(interface_extract))));
    c_declarations = c_root->c_declarations;
    size = Array__size_get(c_declarations);
    index = 0;
    while ((index < size)) {
        c_declaration = ((C_Declaration)Array__fetch1(c_declarations, index));
        switch (c_declaration->kind) {
            case C_Declaration_Kind___struct:
                struct___k = ((c_declaration->kind == C_Declaration_Kind___struct) ? c_declaration->kind__union.struct___k : (C_Struct)System__variant_object_fail((String)"\10EZCC.ezc", 631));
                struct_name = String__new();
                (void)String__string_append(struct_name, struct___k->name->value);
                String__store1(struct_name, 0, Character__upper_case(String__fetch1(struct_name, 0)));
                if ((String__fetch1(struct_name, 0) != ((Character)'_'))) {
                    (void)String__string_append(extract_file, (t__15 = String__form(((String)"\013define %s%\n")), String__divide((t__15), String__f(struct_name))));
                    (void)String__string_append(extract_file, ((String)"\016    external\n\n"));
                }
                break;
        }
        index = (index+1);
    }
    xarguments = Comma_Separated__new();
    return_type = C_Type__null;
    routine_name = String__null;
    index = 0;
    while ((index < size)) {
        c_declaration = ((C_Declaration)Array__fetch1(c_declarations, index));
        switch (c_declaration->kind) {
            case C_Declaration_Kind___extern:
                extern___k = ((c_declaration->kind == C_Declaration_Kind___extern) ? c_declaration->kind__union.extern___k : (C_Extern)System__variant_object_fail((String)"\10EZCC.ezc", 651));
                switch (extern___k->kind) {
                    case C_Extern_Kind___extern1:
                        extern1 = ((extern___k->kind == C_Extern_Kind___extern1) ? extern___k->kind__union.extern1 : (C_Extern1)System__variant_object_fail((String)"\10EZCC.ezc", 654));
                        return_type = extern1->return_type;
                        routine_name = extern1->name->value;
                        xarguments = extern1->arguments;
                        break;
                    case C_Extern_Kind___extern2:
                        extern2 = ((extern___k->kind == C_Extern_Kind___extern2) ? extern___k->kind__union.extern2 : (C_Extern2)System__variant_object_fail((String)"\10EZCC.ezc", 659));
                        return_type = extern2->return_type;
                        routine_name = extern2->name->value;
                        xarguments = extern2->arguments;
                        break;
                }
                (void)String__string_append(extract_file, (t__16 = String__form(((String)"\020routine %s%@%s%\n")), t__17 = String__f(routine_name), String__divide(String__remainder((t__16), t__17), String__f(interface_extract))));
                xarguments_size = Comma_Separated__size_get(xarguments);
                xarguments_index = 0;
                while ((xarguments_index < xarguments_size)) {
                    xargument = ((C_Argument)Comma_Separated__fetch1(xarguments, xarguments_index));
                    name = String__new();
                    (void)String__string_append(name, xargument->name->value);
                    while (((String__size_get(name) != 0)&&(String__fetch1(name, 0) == ((Character)'_')))) {
                        (void)String__character_delete(name, 0);
                    }
                    (void)String__string_append(extract_file, (t__18 = String__form(((String)"\022    takes %s% %s%\n")), t__19 = String__f(name), String__divide(String__remainder((t__18), t__19), String__f(xargument->type->type))));
                    xarguments_index = (xarguments_index+1);
                }
                return_type_name = return_type->type;
                if (String__equal(return_type_name, ((String)"\000"))) {
                    (void)String__string_append(extract_file, ((String)"\024    returns_nothing\n"));
                } else {
                    (void)String__string_append(extract_file, (t__20 = String__form(((String)"\020    returns %s%\n")), String__divide((t__20), String__f(return_type_name))));
                }
                (void)String__string_append(extract_file, (t__21 = String__form(((String)"\022    external %s%\n\n")), String__divide((t__21), String__f(routine_name))));
                break;
        }
        index = (index+1);
    }
    struct_name = String__new();
    size = Array__size_get(c_declarations);
    index = 0;
    while ((index < size)) {
        c_declaration = ((C_Declaration)Array__fetch1(c_declarations, index));
        switch (c_declaration->kind) {
            case C_Declaration_Kind___struct:
                struct___k = ((c_declaration->kind == C_Declaration_Kind___struct) ? c_declaration->kind__union.struct___k : (C_Struct)System__variant_object_fail((String)"\10EZCC.ezc", 701));
                (void)String__trim(struct_name, 0);
                (void)String__string_append(struct_name, struct___k->name->value);
                String__store1(struct_name, 0, Character__upper_case(String__fetch1(struct_name, 0)));
                lower_struct_name = String__new();
                (void)String__lower_case_append(lower_struct_name, struct_name);
                if ((String__fetch1(struct_name, 0) != ((Character)'_'))) {
                    fields = struct___k->fields;
                    fields_size = Array__size_get(fields);
                    fields_index = 0;
                    while ((fields_index < fields_size)) {
                        field = ((C_Field)Array__fetch1(fields, fields_index));
                        switch (field->kind) {
                            case C_Field_Kind___field1:
                                field1 = ((field->kind == C_Field_Kind___field1) ? field->kind__union.field1 : (C_Field1)System__variant_object_fail((String)"\10EZCC.ezc", 716));
                                break;
                            case C_Field_Kind___field2:
                                field2 = ((field->kind == C_Field_Kind___field2) ? field->kind__union.field2 : (C_Field2)System__variant_object_fail((String)"\10EZCC.ezc", 718));
                                /* # Do the get routine first: */
                                (void)String__string_append(extract_file, (t__22 = String__form(((String)"\024routine %s%_get@%s%\n")), t__23 = String__f(field2->name->value), String__divide(String__remainder((t__22), t__23), String__f(struct_name))));
                                (void)String__string_append(extract_file, (t__24 = String__form(((String)"\022    takes %s% %s%\n")), t__25 = String__f(lower_struct_name), String__divide(String__remainder((t__24), t__25), String__f(struct_name))));
                                (void)String__string_append(extract_file, (t__26 = String__form(((String)"\020    returns %s%\n")), String__divide((t__26), String__f(field2->type->type))));
                                (void)String__string_append(extract_file, (t__27 = String__form(((String)"\033    external %s%__%s%_get\n\n")), t__28 = String__f(struct_name), String__divide(String__remainder((t__27), t__28), String__f(field2->name->value))));
                                /* # Do the set routine next: */
                                (void)String__string_append(extract_file, (t__29 = String__form(((String)"\024routine %s%_set@%s%\n")), t__30 = String__f(field2->name->value), String__divide(String__remainder((t__29), t__30), String__f(struct_name))));
                                (void)String__string_append(extract_file, (t__31 = String__form(((String)"\022    takes %s% %s%\n")), t__32 = String__f(lower_struct_name), String__divide(String__remainder((t__31), t__32), String__f(struct_name))));
                                (void)String__string_append(extract_file, (t__33 = String__form(((String)"\022    takes %s% %s%\n")), t__34 = String__f(field2->name->value), String__divide(String__remainder((t__33), t__34), String__f(field2->type->type))));
                                (void)String__string_append(extract_file, ((String)"\024    returns_nothing\n"));
                                (void)String__string_append(extract_file, (t__35 = String__form(((String)"\033    external %s%__%s%_set\n\n")), t__36 = String__f(struct_name), String__divide(String__remainder((t__35), t__36), String__f(field2->name->value))));
                                break;
                        }
                        fields_index = (fields_index+1);
                    }
                }
                break;
        }
        index = (index+1);
    }
    interface_lower_case = String__new();
    (void)String__lower_case_append(interface_lower_case, interface_extract);
    defines = define_root->defines;
    define_lines = Array__new();
    size = Array__size_get(defines);
    index = 0;
    while ((index < size)) {
        define = ((Define)Array__fetch1(defines, index));
        switch (define->kind) {
            case Define_Kind___define_line:
                (void)Array__append(define_lines, ((void *)(((define->kind == Define_Kind___define_line) ? define->kind__union.define_line : (Define_Line)System__variant_object_fail((String)"\10EZCC.ezc", 770)))));
                break;
        }
        index = (index+1);
    }
    (void)Array__sort(define_lines, ((Integer (*)(void *, void *))(Define_Line__compare)));
    size = Array__size_get(define_lines);
    lower_case = String__new();
    index = 0;
    while ((index < size)) {
        define_line = ((Define_Line)Array__fetch1(define_lines, index));
        (void)String__trim(lower_case, 0);
        (void)String__lower_case_append(lower_case, define_line->name->value);
        if ((String__fetch1(lower_case, 0) != ((Character)'_'))) {
            (void)String__string_append(extract_file, (t__37 = String__form(((String)"\041external %s%_%s%@Unsigned\t# =%s%\n")), t__38 = String__f(interface_lower_case), t__39 = String__f(lower_case), String__divide(String__remainder(String__remainder((t__37), t__38), t__39), String__f(define_line->number->value))));
        }
        index = (index+1);
    }
    file_name = String__new();
    (void)String__string_append(file_name, (t__40 = String__form(((String)"\007%s%.ezc")), String__divide((t__40), String__f(interface_extract))));
    extract_stream = Out_Stream__open(file_name);
    if (!((extract_stream != Out_Stream__null))) {
        System__assert_fail((String)"\10EZCC.ezc", 792);
    }
    (void)String__put(extract_file, extract_stream);
    (void)Out_Stream__close(extract_stream);
    (void)String__trim(extract_file, 0);
    (void)String__string_append(extract_file, (t__41 = String__form(((String)"\034#include \"%s%.x.h\"/*EZCC1*/\n")), String__divide((t__41), String__f(interface_extract))));
    (void)String__string_append(extract_file, ((String)"\036#include \"EasyC_C.h\"/*EZCC2*/\n"));
    struct_name = String__new();
    lower_struct_name = String__new();
    size = Array__size_get(c_declarations);
    index = 0;
    while ((index < size)) {
        c_declaration = ((C_Declaration)Array__fetch1(c_declarations, index));
        switch (c_declaration->kind) {
            case C_Declaration_Kind___struct:
                struct___k = ((c_declaration->kind == C_Declaration_Kind___struct) ? c_declaration->kind__union.struct___k : (C_Struct)System__variant_object_fail((String)"\10EZCC.ezc", 812));
                (void)String__trim(struct_name, 0);
                (void)String__string_append(struct_name, struct___k->name->value);
                String__store1(struct_name, 0, Character__upper_case(String__fetch1(struct_name, 0)));
                (void)String__trim(lower_struct_name, 0);
                (void)String__lower_case_append(lower_struct_name, struct_name);
                if ((String__fetch1(struct_name, 0) != ((Character)'_'))) {
                    (void)String__string_append(extract_file, (t__42 = String__form(((String)"\031typedef struct %s% *%s%;\n")), t__43 = String__f(lower_struct_name), String__divide(String__remainder((t__42), t__43), String__f(struct_name))));
                }
                break;
        }
        index = (index+1);
    }
    (void)String__string_append(extract_file, ((String)"\001\n"));
    (void)String__trim(file_name, 0);
    (void)String__string_append(file_name, (t__44 = String__form(((String)"\007%s%_C.h")), String__divide((t__44), String__f(interface_extract))));
    extract_stream = Out_Stream__open(file_name);
    if (!((extract_stream != Out_Stream__null))) {
        System__assert_fail((String)"\10EZCC.ezc", 829);
    }
    (void)String__put(extract_file, extract_stream);
    (void)Out_Stream__close(extract_stream);
    (void)String__trim(extract_file, 0);
    (void)String__string_append(extract_file, (t__45 = String__form(((String)"\035#include \"%s%_C.h\"/*EZCC3*/\n\n")), String__divide((t__45), String__f(interface_extract))));
    size = Array__size_get(c_declarations);
    index = 0;
    while ((index < size)) {
        c_declaration = ((C_Declaration)Array__fetch1(c_declarations, index));
        switch (c_declaration->kind) {
            case C_Declaration_Kind___struct:
                struct___k = ((c_declaration->kind == C_Declaration_Kind___struct) ? c_declaration->kind__union.struct___k : (C_Struct)System__variant_object_fail((String)"\10EZCC.ezc", 847));
                (void)String__trim(struct_name, 0);
                (void)String__string_append(struct_name, struct___k->name->value);
                String__store1(struct_name, 0, Character__upper_case(String__fetch1(struct_name, 0)));
                (void)String__trim(lower_struct_name, 0);
                (void)String__lower_case_append(lower_struct_name, struct_name);
                if ((String__fetch1(struct_name, 0) != ((Character)'_'))) {

                    (void)String__string_append(extract_file, (t__46 = String__form(((String)"\020%s% %s%__null;\n\n")), t__47 = String__f(struct_name), String__divide(String__remainder((t__46), t__47), String__f(struct_name))));
                    /* # Output new routine: */
                    (void)String__string_append(extract_file, (t__48 = String__form(((String)"\023%s% %s%__new(void)\n")), t__49 = String__f(struct_name), String__divide(String__remainder((t__48), t__49), String__f(struct_name))));
                    (void)String__string_append(extract_file, ((String)"\002{\n"));
                    (void)String__string_append(extract_file, (t__50 = String__form(((String)"\015    %s% %s%;\n")), t__51 = String__f(struct_name), String__divide(String__remainder((t__50), t__51), String__f(lower_struct_name))));
                    (void)String__string_append(extract_file, ((String)"\050    extern void *malloc(unsigned int);\n\n"));
                    (void)String__string_append(extract_file, (t__52 = String__form(((String)"\045    %s% = (%s%)malloc(sizeof(*%s%));\n")), t__53 = String__f(lower_struct_name), t__54 = String__f(struct_name), String__divide(String__remainder(String__remainder((t__52), t__53), t__54), String__f(lower_struct_name))));
                    (void)String__string_append(extract_file, (t__55 = String__form(((String)"\020    return %s%;\n")), String__divide((t__55), String__f(lower_struct_name))));
                    (void)String__string_append(extract_file, ((String)"\003}\n\n"));
                    define_lines_size = Array__size_get(define_lines);
                    define_lines_index = 0;
                    while ((define_lines_index < define_lines_size)) {
                        define_line = ((Define_Line)Array__fetch1(define_lines, define_lines_index));
                        (void)String__trim(lower_case, 0);
                        name = define_line->name->value;
                        (void)String__lower_case_append(lower_case, name);
                        if (((String__fetch1(lower_case, 0) != ((Character)'_'))&&Character__is_upper_case(String__fetch1(name, 0)))) {
                            (void)String__string_append(extract_file, (t__56 = String__form(((String)"\034Unsigned Unsigned__%s%_%s%;\n")), t__57 = String__f(interface_lower_case), String__divide(String__remainder((t__56), t__57), String__f(lower_case))));
                        }
                        define_lines_index = (define_lines_index+1);
                    }
                    /* # Output Initialize routine: */
                    (void)String__string_append(extract_file, (t__58 = String__form(((String)"\033void %s%__Initialize(void)\n")), String__divide((t__58), String__f(struct_name))));
                    (void)String__string_append(extract_file, ((String)"\002{\n"));
                    (void)String__string_append(extract_file, (t__59 = String__form(((String)"\033void %s%__Initialize(void)\n")), String__divide((t__59), String__f(struct_name))));
                    (void)String__string_append(extract_file, (t__60 = String__form(((String)"\034    %s%__null = %s%__new();\n")), t__61 = String__f(struct_name), String__divide(String__remainder((t__60), t__61), String__f(struct_name))));
                    define_lines_index = 0;
                    while ((define_lines_index < define_lines_size)) {
                        define_line = ((Define_Line)Array__fetch1(define_lines, define_lines_index));
                        (void)String__trim(lower_case, 0);
                        name = define_line->name->value;
                        (void)String__lower_case_append(lower_case, name);
                        if (((String__fetch1(lower_case, 0) != ((Character)'_'))&&Character__is_upper_case(String__fetch1(name, 0)))) {
                            (void)String__string_append(extract_file, (t__62 = String__form(((String)"\035    Unsigned__%s%_%s% = %s%;\n")), t__63 = String__f(interface_lower_case), t__64 = String__f(lower_case), String__divide(String__remainder(String__remainder((t__62), t__63), t__64), String__f(define_line->name->value))));
                        }
                        define_lines_index = (define_lines_index+1);
                    }
                    (void)String__string_append(extract_file, ((String)"\003}\n\n"));
                    /* # Output the get and set routines: */
                    fields = struct___k->fields;
                    fields_size = Array__size_get(fields);
                    fields_index = 0;
                    while ((fields_index < fields_size)) {
                        field = ((C_Field)Array__fetch1(fields, fields_index));
                        switch (field->kind) {
                            case C_Field_Kind___field1:
                                field1 = ((field->kind == C_Field_Kind___field1) ? field->kind__union.field1 : (C_Field1)System__variant_object_fail((String)"\10EZCC.ezc", 933));
                                break;
                            case C_Field_Kind___field2:
                                field2 = ((field->kind == C_Field_Kind___field2) ? field->kind__union.field2 : (C_Field2)System__variant_object_fail((String)"\10EZCC.ezc", 935));
                                /* # Do the get routine first: */
                                (void)String__string_append(extract_file, (t__65 = String__form(((String)"\032%s% %s%__%s%_get(%s% %s%)\n")), t__66 = String__f(field2->type->type), t__67 = String__f(struct_name), t__68 = String__f(field2->name->value), t__69 = String__f(struct_name), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__65), t__66), t__67), t__68), t__69), String__f(lower_struct_name))));
                                (void)String__string_append(extract_file, ((String)"\002{\n"));
                                (void)String__string_append(extract_file, (t__70 = String__form(((String)"\025    return %s%->%s%;\n")), t__71 = String__f(lower_struct_name), String__divide(String__remainder((t__70), t__71), String__f(field2->name->value))));
                                (void)String__string_append(extract_file, ((String)"\003}\n\n"));
                                /* # Do the set routine next: */
                                (void)String__string_append(extract_file, (t__72 = String__form(((String)"\053extern void %s%__%s%_set(%s% %s%, %s% %s%)\n")), t__73 = String__f(struct_name), t__74 = String__f(field2->name->value), t__75 = String__f(struct_name), t__76 = String__f(lower_struct_name), t__77 = String__f(field2->type->type), String__divide(String__remainder(String__remainder(String__remainder(String__remainder(String__remainder((t__72), t__73), t__74), t__75), t__76), t__77), String__f(field2->name->value))));
                                (void)String__string_append(extract_file, ((String)"\002{\n"));
                                (void)String__string_append(extract_file, (t__78 = String__form(((String)"\024    %s%->%s% = %s%;\n")), t__79 = String__f(lower_struct_name), t__80 = String__f(field2->name->value), String__divide(String__remainder(String__remainder((t__78), t__79), t__80), String__f(field2->name->value))));
                                (void)String__string_append(extract_file, ((String)"\003}\n\n"));
                                break;
                        }
                        fields_index = (fields_index+1);
                    }
                }
                break;
        }
        index = (index+1);
    }
    (void)String__trim(file_name, 0);
    (void)String__string_append(file_name, (t__81 = String__form(((String)"\007%s%_C.c")), String__divide((t__81), String__f(interface_extract))));
    extract_stream = Out_Stream__open(file_name);
    if (!((extract_stream != Out_Stream__null))) {
        System__assert_fail((String)"\10EZCC.ezc", 973);
    }
    (void)String__put(extract_file, extract_stream);
    (void)Out_Stream__close(extract_stream);
    return 0;
}

C_Error C_Error__parse(
  Parser parser)
{
    C_Error c_error;
    Array tokens;
    Array parser_tokens;
    Unsigned index;
    Token token;
    c_error = C_Error__new();
    tokens = c_error->tokens;
    parser_tokens = parser->tokens;
    index = parser->index;
    while (Logical__true) {
        token = ((Token)Array__fetch1(parser_tokens, index));
        switch (token->lexeme) {
            case Lexeme___semicolon:

                c_error->semicolon = token;
                index = (index+1);
                goto break__1;
                break;
            case Lexeme___end_of_file:
                index = (index-1);
                goto break__1;
                break;
            default:
                (void)Array__append(tokens, ((void *)(token)));
                break;
        }
        index = (index+1);
    }
    break__1:;
    parser->index = index;
    return c_error;
}

C_Type C_Type__parse(
  Parser parser)
{
    String type;
    C_Type c_type;
    Array tokens;
    Unsigned index;
    Token token;
    String name;
    type = String__null;
    c_type = C_Type__null;
    tokens = parser->tokens;
    index = parser->index;
    token = ((Token)Array__fetch1(tokens, index));
    if ((token->lexeme != Lexeme__symbol)) {
        return C_Type__null;
    }
    name = token->value;
    index = (index+1);
    while ((String__equal(name, ((String)"\007__const"))||String__equal(name, ((String)"\005const")))) {
        token = ((Token)Array__fetch1(tokens, index));
        index = (index+1);
        if ((token->lexeme != Lexeme__symbol)) {
            return C_Type__null;
        }
        name = token->value;
    }
    if (String__equal(name, ((String)"\010unsigned"))) {

        type = ((String)"\010Unsigned");
        token = ((Token)Array__fetch1(tokens, index));
        if ((token->lexeme == Lexeme__symbol)) {
            name = token->value;
            index = (index+1);
            if (String__equal(name, ((String)"\003int"))) {

                type = ((String)"\007Integer");
            } else if (String__equal(name, ((String)"\004char"))) {

                type = ((String)"\011Character");
            }
        }
    } else if (String__equal(name, ((String)"\003int"))) {

        type = ((String)"\007Integer");
    } else if (String__equal(name, ((String)"\004void"))) {

        type = ((String)"\000");
    } else if (String__equal(name, ((String)"\004char"))) {
        type = ((String)"\011Character");
    } else if (String__equal(name, ((String)"\005float"))) {
        type = ((String)"\005Float");
    } else if (String__equal(name, ((String)"\006double"))) {
        type = ((String)"\006Double");
    } else if (String__equal(name, ((String)"\006struct"))) {
        token = ((Token)Array__fetch1(tokens, index));
        index = (index+1);
        if ((token->lexeme != Lexeme__symbol)) {
            return C_Type__null;
        }
        type = String__new();
        (void)String__string_append(type, token->value);
        String__store1(type, 0, Character__upper_case(String__fetch1(type, 0)));
        token = ((Token)Array__fetch1(tokens, index));
        if ((token->lexeme == Lexeme__multiply)) {
            index = (index+1);
        }
    } else {
        type = ((String)Hash_Table__lookup(parser->c_typedefs, ((void *)(name))));
    }
    if ((type != String__null)) {
        c_type = C_Type__new();
        c_type->type = type;
        parser->index = index;
    }
    return c_type;
}

void C_Type__traverse(
  C_Type c_type,
  Traverser traverser)
{
    /* do_nothing */;
}

C_Typedef C_Typedef__parse(
  Parser parser)
{
    Unsigned index;
    Keyword typedef___k;
    C_Type type;
    Token name;
    Token semicolon;
    C_Typedef c_typedef;
    index = parser->index;
    typedef___k = Keyword__parse(parser, ((String)"\007typedef"));
    if ((typedef___k == Keyword__null)) {
        parser->index = index;
        return C_Typedef__null;
    }
    type = C_Type__parse(parser);
    if ((type == C_Type__null)) {
        parser->index = index;
        return C_Typedef__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return C_Typedef__null;
    }
    semicolon = Token__parse(parser, Lexeme__semicolon);
    if ((semicolon == Token__null)) {
        parser->index = index;
        return C_Typedef__null;
    }
    c_typedef = C_Typedef__new();
    c_typedef->typedef___k = typedef___k;
    c_typedef->type = type;
    c_typedef->name = name;
    c_typedef->semicolon = semicolon;
    (void)Hash_Table__insert(parser->c_typedefs, ((void *)(name->value)), ((void *)(type->type)));
    return c_typedef;
}

Integer Define_Line__compare(
  Define_Line define_line1,
  Define_Line define_line2)
{
    return String__compare(define_line1->name->value, define_line2->name->value);
}

/* # {Options} routines: */
Options Options__extract(
  Array arguments)
{
    Options options;
    Array linker_searches;
    Array searches;
    Logical errors;
    Array source_bases;
    Unsigned size;
    Unsigned index;
    String argument;
    Unsigned argument_size;
    Character letter;
    String letters;
    Unsigned letters_size;
    Unsigned letters_index;
    String previous_value;
    String value;
    Unsigned trace_line;
    String executable_directory;
    String current_working_directory;
    String search_options;
    String search;
    String linker_options;
    String linker_search;
    String compiler_executable;
    String linker_executable;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    options = Options__new();
    options->command_name = String__null;
    options->compile_only = 0;
    options->compiler_executable = String__null;
    options->debug = 0;
    options->executable_name = String__null;
    options->executable_directory = String__null;
    options->interface_extract = String__null;
    options->linker_executable = String__null;
    options->linker_options = String__new();
    options->linker_searches = Array__new();
    options->optimize = 0;
    options->plain_main = 0;
    options->profile = 0;
    options->require_bases = Array__new();
    options->search_options = String__null;
    options->searches = Array__new();
    options->source_bases = Array__new();
    options->suffix = String__null;
    options->trace_line = 0;
    options->verbose = 0;
    linker_searches = options->linker_searches;
    searches = options->searches;
    errors = Logical__false;
    source_bases = options->source_bases;
    size = Array__size_get(arguments);
    if ((size <= 1)) {
        (void)String__d(((String)"\043Usage: [-[c]]* [-[CIoS] arg]* base\n"));
        errors = Logical__true;
    } else {
        options->command_name = ((String)Array__fetch1(arguments, 0));
    }
    index = 1;
    while ((index < size)) {

        argument = ((String)Array__fetch1(arguments, index));
        argument_size = String__size_get(argument);
        if (((argument_size == 2)&&(String__fetch1(argument, 0) == ((Character)'-')))) {

            letter = String__fetch1(argument, 1);
            /* # Figure out whether we have a simple option, or an option */
            /* # with a following value: */
            letters = ((String)"\007CILoSTX");
            letters_size = String__size_get(letters);
            letters_index = 0;
            while (((letters_index < letters_size)&&(letter != String__fetch1(letters, letters_index)))) {
                letters_index = (letters_index+1);
            }
            if ((letters_index < letters_size)) {

                previous_value = String__null;
                value = String__null;
                index = (index+1);
                if ((index >= size)) {
                    (void)String__d((t__1 = String__form(((String)"\023No value after %v%\n")), String__divide((t__1), String__f(argument))));
                    errors = Logical__true;
                } else {
                    value = ((String)Array__fetch1(arguments, index));
                }
                if ((letter == ((Character)'C'))) {

                    previous_value = options->compiler_executable;
                    options->compiler_executable = value;
                } else if ((letter == ((Character)'I'))) {

                    (void)Array__append(searches, ((void *)(value)));
                } else if ((letter == ((Character)'l'))) {

                    previous_value = options->linker_executable;
                    if (!((String__size_get(value) != 0))) {
                        System__assert_fail((String)"\10EZCC.ezc", 1218);
                    }
                    options->linker_executable = value;
                } else if ((letter == ((Character)'L'))) {

                    (void)Array__append(linker_searches, ((void *)(value)));
                } else if ((letter == ((Character)'o'))) {

                    previous_value = options->executable_name;
                    options->executable_name = value;
                } else if ((letter == ((Character)'S'))) {

                    previous_value = options->suffix;
                    options->suffix = value;
                } else if ((letter == ((Character)'T'))) {

                    trace_line = options->trace_line;
                    if ((trace_line != 0)) {
                        previous_value = String__read_only_copy((t__3 = String__form(((String)"\003%d%")), String__divide((t__3), Unsigned__f(trace_line))));
                    }
                    options->trace_line = String__unsigned_convert(value);
                } else if ((letter == ((Character)'X'))) {

                    previous_value = options->interface_extract;
                    options->interface_extract = value;
                } else {

                    if (!(Logical__false)) {
                        System__assert_fail((String)"\10EZCC.ezc", 1244);
                    }
                }
                /* # Check for duplication options: */
                if ((previous_value != String__null)) {
                    (void)String__d((t__5 = String__form(((String)"\047Duplicate %v% option replaces previous\n")), String__divide((t__5), String__f(argument))));
                    errors = Logical__true;
                }
            } else if ((letter == ((Character)'c'))) {

                options->compile_only = Logical__true;
            } else if ((letter == ((Character)'d'))) {

                options->debug = Logical__true;
            } else if ((letter == ((Character)'M'))) {

                options->plain_main = Logical__true;
            } else if ((letter == ((Character)'O'))) {

                options->optimize = Logical__true;
            } else if ((letter == ((Character)'p'))) {

                options->profile = Logical__true;
            } else if ((letter == ((Character)'v'))) {

                options->verbose = Logical__true;
            } else {
                (void)String__d((t__7 = String__form(((String)"\045Unrecognized command line option %v%\n")), String__divide((t__7), String__f(argument))));
                errors = Logical__true;
            }
        } else if (((argument_size != 0)&&(String__fetch1(argument, 0) == ((Character)'-')))) {
            (void)String__d((t__9 = String__form(((String)"\045Unrecognized command line option %v%\n")), String__divide((t__9), String__f(argument))));
            errors = Logical__true;
        } else {

            (void)Array__append(source_bases, ((void *)(argument)));
        }
        index = (index+1);
    }
    executable_directory = String__new();
    if (!(!Unix__executable_directory_lookup(options->command_name, executable_directory))) {
        System__assert_fail((String)"\10EZCC.ezc", 1284);
    }
    options->executable_directory = executable_directory;
    current_working_directory = String__new();
    (void)Unix__real_path(((String)"\001."), current_working_directory);
    if (!String__equal(current_working_directory, executable_directory)) {

        /* # That means we want to explicity search the {executable_directory} */
        /* # to find standard libraries such as "Easy_C" and "Math": */
        (void)Array__append(searches, ((void *)(executable_directory)));
    }
    search_options = String__new();
    size = Array__size_get(searches);
    index = 0;
    while ((index < size)) {
        search = ((String)Array__fetch1(searches, index));
        if (options->verbose) {
            (void)String__d((t__12 = String__form(((String)"\023searches[%d%]: %v%\n")), t__13 = Unsigned__f(index), String__divide(String__remainder((t__12), t__13), String__f(((String)Array__fetch1(searches, index))))));
        }
        (void)String__string_append(search_options, (t__14 = String__form(((String)"\006-I%s% ")), String__divide((t__14), String__f(search))));
        index = (index+1);
    }
    (void)Array__append(searches, ((void *)(((String)"\001."))));
    (void)String__string_append(search_options, ((String)"\004-I. "));
    options->search_options = search_options;
    linker_options = options->linker_options;
    size = Array__size_get(linker_searches);
    index = 0;
    while ((index < size)) {
        linker_search = ((String)Array__fetch1(linker_searches, index));
        (void)String__string_append(linker_options, (t__15 = String__form(((String)"\006 -L%s%")), String__divide((t__15), String__f(linker_search))));
        index = (index+1);
    }
    compiler_executable = options->compiler_executable;
    if ((options->linker_executable == String__null)) {

        if ((compiler_executable == String__null)) {

            options->compiler_executable = ((String)"\003gcc");
            options->linker_executable = ((String)"\003gcc");
        } else {

            options->linker_executable = compiler_executable;
        }
    } else {

        if ((compiler_executable == String__null)) {

            options->compiler_executable = ((String)"\003gcc");
        }
        /* #else */
        /* #    # Have both -C and -l: */
        /* #    do_nothing */
    }
    linker_executable = options->linker_executable;
    if (!((linker_executable != String__null))) {
        System__assert_fail((String)"\10EZCC.ezc", 1348);
    }
    if (!((String__size_get(linker_executable) != 0))) {
        System__assert_fail((String)"\10EZCC.ezc", 1349);
    }
    if (errors) {
        options = Options__null;
    }
    return options;
}

C_Root C_Root__parse(
  Parser parser)
{
    Unsigned index;
    Array c_declarations;
    Token end_of_file;
    C_Root c_root;
    index = parser->index;
    c_declarations = Array__parse(parser, ((void * (*)(Parser))(C_Declaration__parse)), ((void *)(C_Declaration__null)), Lexeme__end_of_file);
    if ((Array__size_get(c_declarations) == 0)) {
        parser->index = index;
        return C_Root__null;
    }
    end_of_file = Token__parse(parser, Lexeme__end_of_file);
    if ((end_of_file == Token__null)) {
        parser->index = index;
        return C_Root__null;
    }
    c_root = C_Root__new();
    c_root->c_declarations = c_declarations;
    c_root->end_of_file = end_of_file;
    return c_root;
}

void C_Root__traverse(
  C_Root c_root,
  Traverser traverser)
{
    (void)Array__traverse(c_root->c_declarations, traverser, ((void (*)(void *, Traverser))(C_Declaration__traverse)));
    (void)Token__traverse(c_root->end_of_file, traverser);
}



String C_Declaration_Kind__string_convert(
  C_Declaration_Kind c_declaration_kind)
{
    switch (c_declaration_kind) {
        case C_Declaration_Kind___typedef:
            return ((String)"\007typedef");
            break;
        case C_Declaration_Kind___struct:
            return ((String)"\006struct");
            break;
        case C_Declaration_Kind___extern:
            return ((String)"\006extern");
            break;
        case C_Declaration_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

C_Declaration C_Declaration__parse(
  Parser parser)
{
    C_Declaration c_declaration;
    C_Typedef typedef___k;
    C_Struct struct___k;
    C_Extern extern___k;
    C_Error error;
    c_declaration = C_Declaration__new();
    typedef___k = C_Typedef__parse(parser);
    if ((typedef___k != C_Typedef__null)) {
        c_declaration->kind = C_Declaration_Kind___typedef; c_declaration->kind__union.typedef___k = typedef___k;
        return c_declaration;
    }
    struct___k = C_Struct__parse(parser);
    if ((struct___k != C_Struct__null)) {
        c_declaration->kind = C_Declaration_Kind___struct; c_declaration->kind__union.struct___k = struct___k;
        return c_declaration;
    }
    extern___k = C_Extern__parse(parser);
    if ((extern___k != C_Extern__null)) {
        c_declaration->kind = C_Declaration_Kind___extern; c_declaration->kind__union.extern___k = extern___k;
        return c_declaration;
    }
    error = C_Error__parse(parser);
    if ((error != C_Error__null)) {
        c_declaration->kind = C_Declaration_Kind___error; c_declaration->kind__union.error = error;
        return c_declaration;
    }
    return C_Declaration__null;
}

void C_Declaration__traverse(
  C_Declaration c_declaration,
  Traverser traverser)
{
    switch (c_declaration->kind) {
        case C_Declaration_Kind___typedef:
            (void)C_Typedef__traverse(((c_declaration->kind == C_Declaration_Kind___typedef) ? c_declaration->kind__union.typedef___k : (C_Typedef)System__variant_object_fail((String)"\13EZCC.ez.ezg", 101)), traverser);
            break;
        case C_Declaration_Kind___struct:
            (void)C_Struct__traverse(((c_declaration->kind == C_Declaration_Kind___struct) ? c_declaration->kind__union.struct___k : (C_Struct)System__variant_object_fail((String)"\13EZCC.ez.ezg", 103)), traverser);
            break;
        case C_Declaration_Kind___extern:
            (void)C_Extern__traverse(((c_declaration->kind == C_Declaration_Kind___extern) ? c_declaration->kind__union.extern___k : (C_Extern)System__variant_object_fail((String)"\13EZCC.ez.ezg", 105)), traverser);
            break;
        case C_Declaration_Kind___error:
            (void)C_Error__traverse(((c_declaration->kind == C_Declaration_Kind___error) ? c_declaration->kind__union.error : (C_Error)System__variant_object_fail((String)"\13EZCC.ez.ezg", 107)), traverser);
            break;
    }
}


C_Struct C_Struct__parse(
  Parser parser)
{
    Unsigned index;
    Keyword struct___k;
    Token name;
    Token open_brace;
    Array fields;
    Token close_brace;
    Token semicolon;
    C_Struct c_struct;
    index = parser->index;
    struct___k = Keyword__parse(parser, ((String)"\006struct"));
    if ((struct___k == Keyword__null)) {
        parser->index = index;
        return C_Struct__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return C_Struct__null;
    }
    open_brace = Token__parse(parser, Lexeme__open_brace);
    if ((open_brace == Token__null)) {
        parser->index = index;
        return C_Struct__null;
    }
    fields = Array__parse(parser, ((void * (*)(Parser))(C_Field__parse)), ((void *)(C_Field__null)), Lexeme__close_brace);
    if ((Array__size_get(fields) == 0)) {
        parser->index = index;
        return C_Struct__null;
    }
    close_brace = Token__parse(parser, Lexeme__close_brace);
    if ((close_brace == Token__null)) {
        parser->index = index;
        return C_Struct__null;
    }
    semicolon = Token__parse(parser, Lexeme__semicolon);
    if ((semicolon == Token__null)) {
        parser->index = index;
        return C_Struct__null;
    }
    c_struct = C_Struct__new();
    c_struct->struct___k = struct___k;
    c_struct->name = name;
    c_struct->open_brace = open_brace;
    c_struct->fields = fields;
    c_struct->close_brace = close_brace;
    c_struct->semicolon = semicolon;
    return c_struct;
}

void C_Struct__traverse(
  C_Struct c_struct,
  Traverser traverser)
{
    (void)Keyword__traverse(c_struct->struct___k, traverser);
    (void)Token__traverse(c_struct->name, traverser);
    (void)Token__traverse(c_struct->open_brace, traverser);
    (void)Array__traverse(c_struct->fields, traverser, ((void (*)(void *, Traverser))(C_Field__traverse)));
    (void)Token__traverse(c_struct->close_brace, traverser);
    (void)Token__traverse(c_struct->semicolon, traverser);
}



String C_Extern_Kind__string_convert(
  C_Extern_Kind c_extern_kind)
{
    switch (c_extern_kind) {
        case C_Extern_Kind___extern1:
            return ((String)"\007extern1");
            break;
        case C_Extern_Kind___extern2:
            return ((String)"\007extern2");
            break;
    }
    return ((String)"\000");
}

C_Extern C_Extern__parse(
  Parser parser)
{
    C_Extern c_extern;
    C_Extern1 extern1;
    C_Extern2 extern2;
    c_extern = C_Extern__new();
    extern1 = C_Extern1__parse(parser);
    if ((extern1 != C_Extern1__null)) {
        c_extern->kind = C_Extern_Kind___extern1; c_extern->kind__union.extern1 = extern1;
        return c_extern;
    }
    extern2 = C_Extern2__parse(parser);
    if ((extern2 != C_Extern2__null)) {
        c_extern->kind = C_Extern_Kind___extern2; c_extern->kind__union.extern2 = extern2;
        return c_extern;
    }
    return C_Extern__null;
}

void C_Extern__traverse(
  C_Extern c_extern,
  Traverser traverser)
{
    switch (c_extern->kind) {
        case C_Extern_Kind___extern1:
            (void)C_Extern1__traverse(((c_extern->kind == C_Extern_Kind___extern1) ? c_extern->kind__union.extern1 : (C_Extern1)System__variant_object_fail((String)"\13EZCC.ez.ezg", 226)), traverser);
            break;
        case C_Extern_Kind___extern2:
            (void)C_Extern2__traverse(((c_extern->kind == C_Extern_Kind___extern2) ? c_extern->kind__union.extern2 : (C_Extern2)System__variant_object_fail((String)"\13EZCC.ez.ezg", 228)), traverser);
            break;
    }
}


C_Extern1 C_Extern1__parse(
  Parser parser)
{
    Unsigned index;
    Keyword extern___k;
    C_Type return_type;
    Token name;
    Token open_parenthesis;
    Comma_Separated arguments;
    Token close_parenthesis;
    Token attribute;
    C_Nest1 nest;
    Token semicolon;
    C_Extern1 c_extern1;
    index = parser->index;
    extern___k = Keyword__parse(parser, ((String)"\006extern"));
    if ((extern___k == Keyword__null)) {
        parser->index = index;
        return C_Extern1__null;
    }
    return_type = C_Type__parse(parser);
    if ((return_type == C_Type__null)) {
        parser->index = index;
        return C_Extern1__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return C_Extern1__null;
    }
    open_parenthesis = Token__parse(parser, Lexeme__open_parenthesis);
    if ((open_parenthesis == Token__null)) {
        parser->index = index;
        return C_Extern1__null;
    }
    arguments = Comma_Separated__parse(parser, ((void * (*)(Parser))(C_Argument__parse)), ((void *)(C_Argument__null)), Lexeme__close_parenthesis);
    if ((Comma_Separated__size_get(arguments) == 0)) {
        parser->index = index;
        return C_Extern1__null;
    }
    close_parenthesis = Token__parse(parser, Lexeme__close_parenthesis);
    if ((close_parenthesis == Token__null)) {
        parser->index = index;
        return C_Extern1__null;
    }
    attribute = Token__parse(parser, Lexeme__symbol);
    if ((attribute == Token__null)) {
        parser->index = index;
        return C_Extern1__null;
    }
    nest = C_Nest1__parse(parser);
    if ((nest == C_Nest1__null)) {
        parser->index = index;
        return C_Extern1__null;
    }
    semicolon = Token__parse(parser, Lexeme__semicolon);
    if ((semicolon == Token__null)) {
        parser->index = index;
        return C_Extern1__null;
    }
    c_extern1 = C_Extern1__new();
    c_extern1->extern___k = extern___k;
    c_extern1->return_type = return_type;
    c_extern1->name = name;
    c_extern1->open_parenthesis = open_parenthesis;
    c_extern1->arguments = arguments;
    c_extern1->close_parenthesis = close_parenthesis;
    c_extern1->attribute = attribute;
    c_extern1->nest = nest;
    c_extern1->semicolon = semicolon;
    return c_extern1;
}

void C_Extern1__traverse(
  C_Extern1 c_extern1,
  Traverser traverser)
{
    (void)Keyword__traverse(c_extern1->extern___k, traverser);
    (void)C_Type__traverse(c_extern1->return_type, traverser);
    (void)Token__traverse(c_extern1->name, traverser);
    (void)Token__traverse(c_extern1->open_parenthesis, traverser);
    (void)Comma_Separated__traverse(c_extern1->arguments, traverser, ((void (*)(void *, Traverser))(C_Argument__traverse)));
    (void)Token__traverse(c_extern1->close_parenthesis, traverser);
    (void)Token__traverse(c_extern1->attribute, traverser);
    (void)C_Nest1__traverse(c_extern1->nest, traverser);
    (void)Token__traverse(c_extern1->semicolon, traverser);
}


C_Extern2 C_Extern2__parse(
  Parser parser)
{
    Unsigned index;
    Keyword extern___k;
    C_Type return_type;
    Token name;
    Token open_parenthesis;
    Comma_Separated arguments;
    Token close_parenthesis;
    Token semicolon;
    C_Extern2 c_extern2;
    index = parser->index;
    extern___k = Keyword__parse(parser, ((String)"\006extern"));
    if ((extern___k == Keyword__null)) {
        parser->index = index;
        return C_Extern2__null;
    }
    return_type = C_Type__parse(parser);
    if ((return_type == C_Type__null)) {
        parser->index = index;
        return C_Extern2__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return C_Extern2__null;
    }
    open_parenthesis = Token__parse(parser, Lexeme__open_parenthesis);
    if ((open_parenthesis == Token__null)) {
        parser->index = index;
        return C_Extern2__null;
    }
    arguments = Comma_Separated__parse(parser, ((void * (*)(Parser))(C_Argument__parse)), ((void *)(C_Argument__null)), Lexeme__close_parenthesis);
    if ((Comma_Separated__size_get(arguments) == 0)) {
        parser->index = index;
        return C_Extern2__null;
    }
    close_parenthesis = Token__parse(parser, Lexeme__close_parenthesis);
    if ((close_parenthesis == Token__null)) {
        parser->index = index;
        return C_Extern2__null;
    }
    semicolon = Token__parse(parser, Lexeme__semicolon);
    if ((semicolon == Token__null)) {
        parser->index = index;
        return C_Extern2__null;
    }
    c_extern2 = C_Extern2__new();
    c_extern2->extern___k = extern___k;
    c_extern2->return_type = return_type;
    c_extern2->name = name;
    c_extern2->open_parenthesis = open_parenthesis;
    c_extern2->arguments = arguments;
    c_extern2->close_parenthesis = close_parenthesis;
    c_extern2->semicolon = semicolon;
    return c_extern2;
}

void C_Extern2__traverse(
  C_Extern2 c_extern2,
  Traverser traverser)
{
    (void)Keyword__traverse(c_extern2->extern___k, traverser);
    (void)C_Type__traverse(c_extern2->return_type, traverser);
    (void)Token__traverse(c_extern2->name, traverser);
    (void)Token__traverse(c_extern2->open_parenthesis, traverser);
    (void)Comma_Separated__traverse(c_extern2->arguments, traverser, ((void (*)(void *, Traverser))(C_Argument__traverse)));
    (void)Token__traverse(c_extern2->close_parenthesis, traverser);
    (void)Token__traverse(c_extern2->semicolon, traverser);
}


void C_Typedef__traverse(
  C_Typedef c_typedef,
  Traverser traverser)
{
    (void)Keyword__traverse(c_typedef->typedef___k, traverser);
    (void)C_Type__traverse(c_typedef->type, traverser);
    (void)Token__traverse(c_typedef->name, traverser);
    (void)Token__traverse(c_typedef->semicolon, traverser);
}



String C_Field_Kind__string_convert(
  C_Field_Kind c_field_kind)
{
    switch (c_field_kind) {
        case C_Field_Kind___field1:
            return ((String)"\006field1");
            break;
        case C_Field_Kind___field2:
            return ((String)"\006field2");
            break;
    }
    return ((String)"\000");
}

C_Field C_Field__parse(
  Parser parser)
{
    C_Field c_field;
    C_Field1 field1;
    C_Field2 field2;
    c_field = C_Field__new();
    field1 = C_Field1__parse(parser);
    if ((field1 != C_Field1__null)) {
        c_field->kind = C_Field_Kind___field1; c_field->kind__union.field1 = field1;
        return c_field;
    }
    field2 = C_Field2__parse(parser);
    if ((field2 != C_Field2__null)) {
        c_field->kind = C_Field_Kind___field2; c_field->kind__union.field2 = field2;
        return c_field;
    }
    return C_Field__null;
}

void C_Field__traverse(
  C_Field c_field,
  Traverser traverser)
{
    switch (c_field->kind) {
        case C_Field_Kind___field1:
            (void)C_Field1__traverse(((c_field->kind == C_Field_Kind___field1) ? c_field->kind__union.field1 : (C_Field1)System__variant_object_fail((String)"\13EZCC.ez.ezg", 458)), traverser);
            break;
        case C_Field_Kind___field2:
            (void)C_Field2__traverse(((c_field->kind == C_Field_Kind___field2) ? c_field->kind__union.field2 : (C_Field2)System__variant_object_fail((String)"\13EZCC.ez.ezg", 460)), traverser);
            break;
    }
}


C_Field1 C_Field1__parse(
  Parser parser)
{
    Unsigned index;
    C_Type type;
    Token name;
    Token open_bracket;
    Token number;
    Token close_bracket;
    Token semicolon;
    C_Field1 c_field1;
    index = parser->index;
    type = C_Type__parse(parser);
    if ((type == C_Type__null)) {
        parser->index = index;
        return C_Field1__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return C_Field1__null;
    }
    open_bracket = Token__parse(parser, Lexeme__open_bracket);
    if ((open_bracket == Token__null)) {
        parser->index = index;
        return C_Field1__null;
    }
    number = Token__parse(parser, Lexeme__number);
    if ((number == Token__null)) {
        parser->index = index;
        return C_Field1__null;
    }
    close_bracket = Token__parse(parser, Lexeme__close_bracket);
    if ((close_bracket == Token__null)) {
        parser->index = index;
        return C_Field1__null;
    }
    semicolon = Token__parse(parser, Lexeme__semicolon);
    if ((semicolon == Token__null)) {
        parser->index = index;
        return C_Field1__null;
    }
    c_field1 = C_Field1__new();
    c_field1->type = type;
    c_field1->name = name;
    c_field1->open_bracket = open_bracket;
    c_field1->number = number;
    c_field1->close_bracket = close_bracket;
    c_field1->semicolon = semicolon;
    return c_field1;
}

void C_Field1__traverse(
  C_Field1 c_field1,
  Traverser traverser)
{
    (void)C_Type__traverse(c_field1->type, traverser);
    (void)Token__traverse(c_field1->name, traverser);
    (void)Token__traverse(c_field1->open_bracket, traverser);
    (void)Token__traverse(c_field1->number, traverser);
    (void)Token__traverse(c_field1->close_bracket, traverser);
    (void)Token__traverse(c_field1->semicolon, traverser);
}


C_Field2 C_Field2__parse(
  Parser parser)
{
    Unsigned index;
    C_Type type;
    Token name;
    Token semicolon;
    C_Field2 c_field2;
    index = parser->index;
    type = C_Type__parse(parser);
    if ((type == C_Type__null)) {
        parser->index = index;
        return C_Field2__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return C_Field2__null;
    }
    semicolon = Token__parse(parser, Lexeme__semicolon);
    if ((semicolon == Token__null)) {
        parser->index = index;
        return C_Field2__null;
    }
    c_field2 = C_Field2__new();
    c_field2->type = type;
    c_field2->name = name;
    c_field2->semicolon = semicolon;
    return c_field2;
}

void C_Field2__traverse(
  C_Field2 c_field2,
  Traverser traverser)
{
    (void)C_Type__traverse(c_field2->type, traverser);
    (void)Token__traverse(c_field2->name, traverser);
    (void)Token__traverse(c_field2->semicolon, traverser);
}


void C_Error__traverse(
  C_Error c_error,
  Traverser traverser)
{
    (void)Array__traverse(c_error->tokens, traverser, ((void (*)(void *, Traverser))(Token__traverse)));
    (void)Token__traverse(c_error->semicolon, traverser);
}


C_Argument C_Argument__parse(
  Parser parser)
{
    Unsigned index;
    C_Type type;
    Token name;
    C_Argument c_argument;
    index = parser->index;
    type = C_Type__parse(parser);
    if ((type == C_Type__null)) {
        parser->index = index;
        return C_Argument__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return C_Argument__null;
    }
    c_argument = C_Argument__new();
    c_argument->type = type;
    c_argument->name = name;
    return c_argument;
}

void C_Argument__traverse(
  C_Argument c_argument,
  Traverser traverser)
{
    (void)C_Type__traverse(c_argument->type, traverser);
    (void)Token__traverse(c_argument->name, traverser);
}



C_Nest1 C_Nest1__parse(
  Parser parser)
{
    Unsigned index;
    Token open_parenthesis;
    C_Nest2 nest;
    Token close_parenthesis;
    C_Nest1 c_nest1;
    index = parser->index;
    open_parenthesis = Token__parse(parser, Lexeme__open_parenthesis);
    if ((open_parenthesis == Token__null)) {
        parser->index = index;
        return C_Nest1__null;
    }
    nest = C_Nest2__parse(parser);
    if ((nest == C_Nest2__null)) {
        parser->index = index;
        return C_Nest1__null;
    }
    close_parenthesis = Token__parse(parser, Lexeme__close_parenthesis);
    if ((close_parenthesis == Token__null)) {
        parser->index = index;
        return C_Nest1__null;
    }
    c_nest1 = C_Nest1__new();
    c_nest1->open_parenthesis = open_parenthesis;
    c_nest1->nest = nest;
    c_nest1->close_parenthesis = close_parenthesis;
    return c_nest1;
}

void C_Nest1__traverse(
  C_Nest1 c_nest1,
  Traverser traverser)
{
    (void)Token__traverse(c_nest1->open_parenthesis, traverser);
    (void)C_Nest2__traverse(c_nest1->nest, traverser);
    (void)Token__traverse(c_nest1->close_parenthesis, traverser);
}


C_Nest2 C_Nest2__parse(
  Parser parser)
{
    Unsigned index;
    Token open_parenthesis;
    Token nothrow;
    Token close_parenthesis;
    C_Nest2 c_nest2;
    index = parser->index;
    open_parenthesis = Token__parse(parser, Lexeme__open_parenthesis);
    if ((open_parenthesis == Token__null)) {
        parser->index = index;
        return C_Nest2__null;
    }
    nothrow = Token__parse(parser, Lexeme__symbol);
    if ((nothrow == Token__null)) {
        parser->index = index;
        return C_Nest2__null;
    }
    close_parenthesis = Token__parse(parser, Lexeme__close_parenthesis);
    if ((close_parenthesis == Token__null)) {
        parser->index = index;
        return C_Nest2__null;
    }
    c_nest2 = C_Nest2__new();
    c_nest2->open_parenthesis = open_parenthesis;
    c_nest2->nothrow = nothrow;
    c_nest2->close_parenthesis = close_parenthesis;
    return c_nest2;
}

void C_Nest2__traverse(
  C_Nest2 c_nest2,
  Traverser traverser)
{
    (void)Token__traverse(c_nest2->open_parenthesis, traverser);
    (void)Token__traverse(c_nest2->nothrow, traverser);
    (void)Token__traverse(c_nest2->close_parenthesis, traverser);
}


Define_Root Define_Root__parse(
  Parser parser)
{
    Unsigned index;
    Array defines;
    Token end_of_file;
    Define_Root define_root;
    index = parser->index;
    defines = Array__parse(parser, ((void * (*)(Parser))(Define__parse)), ((void *)(Define__null)), Lexeme__end_of_file);
    if ((Array__size_get(defines) == 0)) {
        parser->index = index;
        return Define_Root__null;
    }
    end_of_file = Token__parse(parser, Lexeme__end_of_file);
    if ((end_of_file == Token__null)) {
        parser->index = index;
        return Define_Root__null;
    }
    define_root = Define_Root__new();
    define_root->defines = defines;
    define_root->end_of_file = end_of_file;
    return define_root;
}

void Define_Root__traverse(
  Define_Root define_root,
  Traverser traverser)
{
    (void)Array__traverse(define_root->defines, traverser, ((void (*)(void *, Traverser))(Define__traverse)));
    (void)Token__traverse(define_root->end_of_file, traverser);
}



String Define_Kind__string_convert(
  Define_Kind define_kind)
{
    switch (define_kind) {
        case Define_Kind___end_of_line:
            return ((String)"\013end_of_line");
            break;
        case Define_Kind___define_line:
            return ((String)"\013define_line");
            break;
        case Define_Kind___error:
            return ((String)"\005error");
            break;
    }
    return ((String)"\000");
}

Define Define__parse(
  Parser parser)
{
    Define define;
    Token end_of_line;
    Define_Line define_line;
    Error error;
    define = Define__new();
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line != Token__null)) {
        define->kind = Define_Kind___end_of_line; define->kind__union.end_of_line = end_of_line;
        return define;
    }
    define_line = Define_Line__parse(parser);
    if ((define_line != Define_Line__null)) {
        define->kind = Define_Kind___define_line; define->kind__union.define_line = define_line;
        return define;
    }
    error = Error__parse(parser);
    if ((error != Error__null)) {
        define->kind = Define_Kind___error; define->kind__union.error = error;
        return define;
    }
    return Define__null;
}

void Define__traverse(
  Define define,
  Traverser traverser)
{
    switch (define->kind) {
        case Define_Kind___end_of_line:
            (void)Token__traverse(((define->kind == Define_Kind___end_of_line) ? define->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\13EZCC.ez.ezg", 817)), traverser);
            break;
        case Define_Kind___define_line:
            (void)Define_Line__traverse(((define->kind == Define_Kind___define_line) ? define->kind__union.define_line : (Define_Line)System__variant_object_fail((String)"\13EZCC.ez.ezg", 819)), traverser);
            break;
        case Define_Kind___error:
            (void)Error__traverse(((define->kind == Define_Kind___error) ? define->kind__union.error : (Error)System__variant_object_fail((String)"\13EZCC.ez.ezg", 821)), traverser);
            break;
    }
}


Define_Line Define_Line__parse(
  Parser parser)
{
    Unsigned index;
    Keyword define;
    Token name;
    Token number;
    Token end_of_line;
    Define_Line define_line;
    index = parser->index;
    define = Keyword__parse(parser, ((String)"\006define"));
    if ((define == Keyword__null)) {
        parser->index = index;
        return Define_Line__null;
    }
    name = Token__parse(parser, Lexeme__symbol);
    if ((name == Token__null)) {
        parser->index = index;
        return Define_Line__null;
    }
    number = Token__parse(parser, Lexeme__number);
    if ((number == Token__null)) {
        parser->index = index;
        return Define_Line__null;
    }
    end_of_line = Token__parse(parser, Lexeme__end_of_line);
    if ((end_of_line == Token__null)) {
        parser->index = index;
        return Define_Line__null;
    }
    define_line = Define_Line__new();
    define_line->define = define;
    define_line->name = name;
    define_line->number = number;
    define_line->end_of_line = end_of_line;
    return define_line;
}

void Define_Line__traverse(
  Define_Line define_line,
  Traverser traverser)
{
    (void)Keyword__traverse(define_line->define, traverser);
    (void)Token__traverse(define_line->name, traverser);
    (void)Token__traverse(define_line->number, traverser);
    (void)Token__traverse(define_line->end_of_line, traverser);
}



/* {C_Root} stuff: */

struct C_Root__Struct C_Root__Initial = {
    (Array)0,
    &Token__Initial,
};

C_Root C_Root__null = &C_Root__Initial;
void C_Root__erase(
  C_Root c_root)
{
    if (c_root->c_declarations == 0) {
	c_root->c_declarations = Array__new();
    } else {
	Array__erase(c_root->c_declarations);
    }
    c_root->end_of_file = Token__null;
}

C_Root C_Root__new(void)
{
    C_Root c_root;
    extern void *malloc(size_t);

    c_root = (C_Root)malloc(sizeof(*c_root));
    c_root->c_declarations = Array__new();
    c_root->end_of_file = Token__null;
    return c_root;
}

void C_Root__Initialize(void)
{
    C_Root__erase(C_Root__null);
}

/* {C_Declaration} stuff: */

C_Declaration_Kind C_Declaration_Kind__typedef = C_Declaration_Kind___typedef;
C_Declaration_Kind C_Declaration_Kind__struct = C_Declaration_Kind___struct;
C_Declaration_Kind C_Declaration_Kind__extern = C_Declaration_Kind___extern;
C_Declaration_Kind C_Declaration_Kind__error = C_Declaration_Kind___error;
struct C_Declaration__Struct C_Declaration__Initial = {
};

C_Declaration C_Declaration__null = &C_Declaration__Initial;
void C_Declaration__erase(
  C_Declaration c_declaration)
{
}

C_Declaration C_Declaration__new(void)
{
    C_Declaration c_declaration;
    extern void *malloc(size_t);

    c_declaration = (C_Declaration)malloc(sizeof(*c_declaration));
    return c_declaration;
}

void C_Declaration__Initialize(void)
{
    C_Declaration__erase(C_Declaration__null);
}

/* {C_Struct} stuff: */

struct C_Struct__Struct C_Struct__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    (Array)0,
    &Token__Initial,
    &Token__Initial,
};

C_Struct C_Struct__null = &C_Struct__Initial;
void C_Struct__erase(
  C_Struct c_struct)
{
    c_struct->struct___k = Keyword__null;
    c_struct->name = Token__null;
    c_struct->open_brace = Token__null;
    if (c_struct->fields == 0) {
	c_struct->fields = Array__new();
    } else {
	Array__erase(c_struct->fields);
    }
    c_struct->close_brace = Token__null;
    c_struct->semicolon = Token__null;
}

C_Struct C_Struct__new(void)
{
    C_Struct c_struct;
    extern void *malloc(size_t);

    c_struct = (C_Struct)malloc(sizeof(*c_struct));
    c_struct->struct___k = Keyword__null;
    c_struct->name = Token__null;
    c_struct->open_brace = Token__null;
    c_struct->fields = Array__new();
    c_struct->close_brace = Token__null;
    c_struct->semicolon = Token__null;
    return c_struct;
}

void C_Struct__Initialize(void)
{
    C_Struct__erase(C_Struct__null);
}

/* {C_Extern} stuff: */

C_Extern_Kind C_Extern_Kind__extern1 = C_Extern_Kind___extern1;
C_Extern_Kind C_Extern_Kind__extern2 = C_Extern_Kind___extern2;
struct C_Extern__Struct C_Extern__Initial = {
};

C_Extern C_Extern__null = &C_Extern__Initial;
void C_Extern__erase(
  C_Extern c_extern)
{
}

C_Extern C_Extern__new(void)
{
    C_Extern c_extern;
    extern void *malloc(size_t);

    c_extern = (C_Extern)malloc(sizeof(*c_extern));
    return c_extern;
}

void C_Extern__Initialize(void)
{
    C_Extern__erase(C_Extern__null);
}

/* {C_Extern1} stuff: */

struct C_Extern1__Struct C_Extern1__Initial = {
    &Keyword__Initial,
    &C_Type__Initial,
    &Token__Initial,
    &Token__Initial,
    (Comma_Separated)0,
    &Token__Initial,
    &Token__Initial,
    &C_Nest1__Initial,
    &Token__Initial,
};

C_Extern1 C_Extern1__null = &C_Extern1__Initial;
void C_Extern1__erase(
  C_Extern1 c_extern1)
{
    c_extern1->extern___k = Keyword__null;
    c_extern1->return_type = C_Type__null;
    c_extern1->name = Token__null;
    c_extern1->open_parenthesis = Token__null;
    if (c_extern1->arguments == 0) {
	c_extern1->arguments = Comma_Separated__new();
    } else {
	Comma_Separated__erase(c_extern1->arguments);
    }
    c_extern1->close_parenthesis = Token__null;
    c_extern1->attribute = Token__null;
    c_extern1->nest = C_Nest1__null;
    c_extern1->semicolon = Token__null;
}

C_Extern1 C_Extern1__new(void)
{
    C_Extern1 c_extern1;
    extern void *malloc(size_t);

    c_extern1 = (C_Extern1)malloc(sizeof(*c_extern1));
    c_extern1->extern___k = Keyword__null;
    c_extern1->return_type = C_Type__null;
    c_extern1->name = Token__null;
    c_extern1->open_parenthesis = Token__null;
    c_extern1->arguments = Comma_Separated__new();
    c_extern1->close_parenthesis = Token__null;
    c_extern1->attribute = Token__null;
    c_extern1->nest = C_Nest1__null;
    c_extern1->semicolon = Token__null;
    return c_extern1;
}

void C_Extern1__Initialize(void)
{
    C_Extern1__erase(C_Extern1__null);
}

/* {C_Extern2} stuff: */

struct C_Extern2__Struct C_Extern2__Initial = {
    &Keyword__Initial,
    &C_Type__Initial,
    &Token__Initial,
    &Token__Initial,
    (Comma_Separated)0,
    &Token__Initial,
    &Token__Initial,
};

C_Extern2 C_Extern2__null = &C_Extern2__Initial;
void C_Extern2__erase(
  C_Extern2 c_extern2)
{
    c_extern2->extern___k = Keyword__null;
    c_extern2->return_type = C_Type__null;
    c_extern2->name = Token__null;
    c_extern2->open_parenthesis = Token__null;
    if (c_extern2->arguments == 0) {
	c_extern2->arguments = Comma_Separated__new();
    } else {
	Comma_Separated__erase(c_extern2->arguments);
    }
    c_extern2->close_parenthesis = Token__null;
    c_extern2->semicolon = Token__null;
}

C_Extern2 C_Extern2__new(void)
{
    C_Extern2 c_extern2;
    extern void *malloc(size_t);

    c_extern2 = (C_Extern2)malloc(sizeof(*c_extern2));
    c_extern2->extern___k = Keyword__null;
    c_extern2->return_type = C_Type__null;
    c_extern2->name = Token__null;
    c_extern2->open_parenthesis = Token__null;
    c_extern2->arguments = Comma_Separated__new();
    c_extern2->close_parenthesis = Token__null;
    c_extern2->semicolon = Token__null;
    return c_extern2;
}

void C_Extern2__Initialize(void)
{
    C_Extern2__erase(C_Extern2__null);
}

/* {C_Typedef} stuff: */

struct C_Typedef__Struct C_Typedef__Initial = {
    &Keyword__Initial,
    &C_Type__Initial,
    &Token__Initial,
    &Token__Initial,
};

C_Typedef C_Typedef__null = &C_Typedef__Initial;
void C_Typedef__erase(
  C_Typedef c_typedef)
{
    c_typedef->typedef___k = Keyword__null;
    c_typedef->type = C_Type__null;
    c_typedef->name = Token__null;
    c_typedef->semicolon = Token__null;
}

C_Typedef C_Typedef__new(void)
{
    C_Typedef c_typedef;
    extern void *malloc(size_t);

    c_typedef = (C_Typedef)malloc(sizeof(*c_typedef));
    c_typedef->typedef___k = Keyword__null;
    c_typedef->type = C_Type__null;
    c_typedef->name = Token__null;
    c_typedef->semicolon = Token__null;
    return c_typedef;
}

void C_Typedef__Initialize(void)
{
    C_Typedef__erase(C_Typedef__null);
}

/* {C_Field} stuff: */

C_Field_Kind C_Field_Kind__field1 = C_Field_Kind___field1;
C_Field_Kind C_Field_Kind__field2 = C_Field_Kind___field2;
struct C_Field__Struct C_Field__Initial = {
};

C_Field C_Field__null = &C_Field__Initial;
void C_Field__erase(
  C_Field c_field)
{
}

C_Field C_Field__new(void)
{
    C_Field c_field;
    extern void *malloc(size_t);

    c_field = (C_Field)malloc(sizeof(*c_field));
    return c_field;
}

void C_Field__Initialize(void)
{
    C_Field__erase(C_Field__null);
}

/* {C_Field1} stuff: */

struct C_Field1__Struct C_Field1__Initial = {
    &C_Type__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
};

C_Field1 C_Field1__null = &C_Field1__Initial;
void C_Field1__erase(
  C_Field1 c_field1)
{
    c_field1->type = C_Type__null;
    c_field1->name = Token__null;
    c_field1->open_bracket = Token__null;
    c_field1->number = Token__null;
    c_field1->close_bracket = Token__null;
    c_field1->semicolon = Token__null;
}

C_Field1 C_Field1__new(void)
{
    C_Field1 c_field1;
    extern void *malloc(size_t);

    c_field1 = (C_Field1)malloc(sizeof(*c_field1));
    c_field1->type = C_Type__null;
    c_field1->name = Token__null;
    c_field1->open_bracket = Token__null;
    c_field1->number = Token__null;
    c_field1->close_bracket = Token__null;
    c_field1->semicolon = Token__null;
    return c_field1;
}

void C_Field1__Initialize(void)
{
    C_Field1__erase(C_Field1__null);
}

/* {C_Field2} stuff: */

struct C_Field2__Struct C_Field2__Initial = {
    &C_Type__Initial,
    &Token__Initial,
    &Token__Initial,
};

C_Field2 C_Field2__null = &C_Field2__Initial;
void C_Field2__erase(
  C_Field2 c_field2)
{
    c_field2->type = C_Type__null;
    c_field2->name = Token__null;
    c_field2->semicolon = Token__null;
}

C_Field2 C_Field2__new(void)
{
    C_Field2 c_field2;
    extern void *malloc(size_t);

    c_field2 = (C_Field2)malloc(sizeof(*c_field2));
    c_field2->type = C_Type__null;
    c_field2->name = Token__null;
    c_field2->semicolon = Token__null;
    return c_field2;
}

void C_Field2__Initialize(void)
{
    C_Field2__erase(C_Field2__null);
}

/* {C_Error} stuff: */

struct C_Error__Struct C_Error__Initial = {
    (Array)0,
    &Token__Initial,
};

C_Error C_Error__null = &C_Error__Initial;
void C_Error__erase(
  C_Error c_error)
{
    if (c_error->tokens == 0) {
	c_error->tokens = Array__new();
    } else {
	Array__erase(c_error->tokens);
    }
    c_error->semicolon = Token__null;
}

C_Error C_Error__new(void)
{
    C_Error c_error;
    extern void *malloc(size_t);

    c_error = (C_Error)malloc(sizeof(*c_error));
    c_error->tokens = Array__new();
    c_error->semicolon = Token__null;
    return c_error;
}

void C_Error__Initialize(void)
{
    C_Error__erase(C_Error__null);
}

/* {C_Argument} stuff: */

struct C_Argument__Struct C_Argument__Initial = {
    &C_Type__Initial,
    &Token__Initial,
};

C_Argument C_Argument__null = &C_Argument__Initial;
void C_Argument__erase(
  C_Argument c_argument)
{
    c_argument->type = C_Type__null;
    c_argument->name = Token__null;
}

C_Argument C_Argument__new(void)
{
    C_Argument c_argument;
    extern void *malloc(size_t);

    c_argument = (C_Argument)malloc(sizeof(*c_argument));
    c_argument->type = C_Type__null;
    c_argument->name = Token__null;
    return c_argument;
}

void C_Argument__Initialize(void)
{
    C_Argument__erase(C_Argument__null);
}

/* {C_Type} stuff: */

struct C_Type__Struct C_Type__Initial = {
    &String__Initial,
};

C_Type C_Type__null = &C_Type__Initial;
void C_Type__erase(
  C_Type c_type)
{
    c_type->type = String__null;
}

C_Type C_Type__new(void)
{
    C_Type c_type;
    extern void *malloc(size_t);

    c_type = (C_Type)malloc(sizeof(*c_type));
    c_type->type = String__null;
    return c_type;
}

void C_Type__Initialize(void)
{
    C_Type__erase(C_Type__null);
}

/* {C_Nest1} stuff: */

struct C_Nest1__Struct C_Nest1__Initial = {
    &Token__Initial,
    &C_Nest2__Initial,
    &Token__Initial,
};

C_Nest1 C_Nest1__null = &C_Nest1__Initial;
void C_Nest1__erase(
  C_Nest1 c_nest1)
{
    c_nest1->open_parenthesis = Token__null;
    c_nest1->nest = C_Nest2__null;
    c_nest1->close_parenthesis = Token__null;
}

C_Nest1 C_Nest1__new(void)
{
    C_Nest1 c_nest1;
    extern void *malloc(size_t);

    c_nest1 = (C_Nest1)malloc(sizeof(*c_nest1));
    c_nest1->open_parenthesis = Token__null;
    c_nest1->nest = C_Nest2__null;
    c_nest1->close_parenthesis = Token__null;
    return c_nest1;
}

void C_Nest1__Initialize(void)
{
    C_Nest1__erase(C_Nest1__null);
}

/* {C_Nest2} stuff: */

struct C_Nest2__Struct C_Nest2__Initial = {
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
};

C_Nest2 C_Nest2__null = &C_Nest2__Initial;
void C_Nest2__erase(
  C_Nest2 c_nest2)
{
    c_nest2->open_parenthesis = Token__null;
    c_nest2->nothrow = Token__null;
    c_nest2->close_parenthesis = Token__null;
}

C_Nest2 C_Nest2__new(void)
{
    C_Nest2 c_nest2;
    extern void *malloc(size_t);

    c_nest2 = (C_Nest2)malloc(sizeof(*c_nest2));
    c_nest2->open_parenthesis = Token__null;
    c_nest2->nothrow = Token__null;
    c_nest2->close_parenthesis = Token__null;
    return c_nest2;
}

void C_Nest2__Initialize(void)
{
    C_Nest2__erase(C_Nest2__null);
}

/* {Define_Root} stuff: */

struct Define_Root__Struct Define_Root__Initial = {
    (Array)0,
    &Token__Initial,
};

Define_Root Define_Root__null = &Define_Root__Initial;
void Define_Root__erase(
  Define_Root define_root)
{
    if (define_root->defines == 0) {
	define_root->defines = Array__new();
    } else {
	Array__erase(define_root->defines);
    }
    define_root->end_of_file = Token__null;
}

Define_Root Define_Root__new(void)
{
    Define_Root define_root;
    extern void *malloc(size_t);

    define_root = (Define_Root)malloc(sizeof(*define_root));
    define_root->defines = Array__new();
    define_root->end_of_file = Token__null;
    return define_root;
}

void Define_Root__Initialize(void)
{
    Define_Root__erase(Define_Root__null);
}

/* {Define} stuff: */

Define_Kind Define_Kind__end_of_line = Define_Kind___end_of_line;
Define_Kind Define_Kind__define_line = Define_Kind___define_line;
Define_Kind Define_Kind__error = Define_Kind___error;
struct Define__Struct Define__Initial = {
};

Define Define__null = &Define__Initial;
void Define__erase(
  Define define)
{
}

Define Define__new(void)
{
    Define define;
    extern void *malloc(size_t);

    define = (Define)malloc(sizeof(*define));
    return define;
}

void Define__Initialize(void)
{
    Define__erase(Define__null);
}

/* {Define_Line} stuff: */

struct Define_Line__Struct Define_Line__Initial = {
    &Keyword__Initial,
    &Token__Initial,
    &Token__Initial,
    &Token__Initial,
};

Define_Line Define_Line__null = &Define_Line__Initial;
void Define_Line__erase(
  Define_Line define_line)
{
    define_line->define = Keyword__null;
    define_line->name = Token__null;
    define_line->number = Token__null;
    define_line->end_of_line = Token__null;
}

Define_Line Define_Line__new(void)
{
    Define_Line define_line;
    extern void *malloc(size_t);

    define_line = (Define_Line)malloc(sizeof(*define_line));
    define_line->define = Keyword__null;
    define_line->name = Token__null;
    define_line->number = Token__null;
    define_line->end_of_line = Token__null;
    return define_line;
}

void Define_Line__Initialize(void)
{
    Define_Line__erase(Define_Line__null);
}

/* {Options} stuff: */

struct Options__Struct Options__Initial = {
    &String__Initial,
    0,
    &String__Initial,
    0,
    &String__Initial,
    &String__Initial,
    &String__Initial,
    &String__Initial,
    (Array)0,
    &String__Initial,
    0,
    0,
    0,
    (Array)0,
    &String__Initial,
    (Array)0,
    (Array)0,
    &String__Initial,
    0,
    0,
};

Options Options__null = &Options__Initial;
void Options__erase(
  Options options)
{
    options->command_name = String__null;
    options->compile_only = 0;
    options->compiler_executable = String__null;
    options->debug = 0;
    options->executable_name = String__null;
    options->executable_directory = String__null;
    options->interface_extract = String__null;
    options->linker_executable = String__null;
    if (options->linker_searches == 0) {
	options->linker_searches = Array__new();
    } else {
	Array__erase(options->linker_searches);
    }
    options->linker_options = String__null;
    options->optimize = 0;
    options->plain_main = 0;
    options->profile = 0;
    if (options->require_bases == 0) {
	options->require_bases = Array__new();
    } else {
	Array__erase(options->require_bases);
    }
    options->search_options = String__null;
    if (options->searches == 0) {
	options->searches = Array__new();
    } else {
	Array__erase(options->searches);
    }
    if (options->source_bases == 0) {
	options->source_bases = Array__new();
    } else {
	Array__erase(options->source_bases);
    }
    options->suffix = String__null;
    options->trace_line = 0;
    options->verbose = 0;
}

Options Options__new(void)
{
    Options options;
    extern void *malloc(size_t);

    options = (Options)malloc(sizeof(*options));
    options->command_name = String__null;
    options->compile_only = Logical__null;
    options->compiler_executable = String__null;
    options->debug = Logical__null;
    options->executable_name = String__null;
    options->executable_directory = String__null;
    options->interface_extract = String__null;
    options->linker_executable = String__null;
    options->linker_searches = Array__new();
    options->linker_options = String__null;
    options->optimize = Logical__null;
    options->plain_main = Logical__null;
    options->profile = Logical__null;
    options->require_bases = Array__new();
    options->search_options = String__null;
    options->searches = Array__new();
    options->source_bases = Array__new();
    options->suffix = String__null;
    options->trace_line = Unsigned__null;
    options->verbose = Logical__null;
    return options;
}

void Options__Initialize(void)
{
    Options__erase(Options__null);
}


