#ifndef EZCC_INCLUDED
#define EZCC_INCLUDED 1

/* Declare all enum's and typedef's first: */
/* h_emit1 */
typedef struct C_Root__Struct *C_Root;
typedef struct C_Declaration__Struct *C_Declaration;
typedef struct C_Struct__Struct *C_Struct;
typedef struct C_Extern__Struct *C_Extern;
typedef struct C_Extern1__Struct *C_Extern1;
typedef struct C_Extern2__Struct *C_Extern2;
typedef struct C_Typedef__Struct *C_Typedef;
typedef struct C_Field__Struct *C_Field;
typedef struct C_Field1__Struct *C_Field1;
typedef struct C_Field2__Struct *C_Field2;
typedef struct C_Error__Struct *C_Error;
typedef struct C_Argument__Struct *C_Argument;
typedef struct C_Type__Struct *C_Type;
typedef struct C_Nest1__Struct *C_Nest1;
typedef struct C_Nest2__Struct *C_Nest2;
typedef struct Define_Root__Struct *Define_Root;
typedef struct Define__Struct *Define;
typedef struct Define_Line__Struct *Define_Line;
typedef struct Options__Struct *Options;
/* h_emit2 */
enum C_Declaration_Kind__Enum {
    C_Declaration_Kind___typedef,
    C_Declaration_Kind___struct,
    C_Declaration_Kind___extern,
    C_Declaration_Kind___error,
};
typedef enum C_Declaration_Kind__Enum C_Declaration_Kind;
enum C_Extern_Kind__Enum {
    C_Extern_Kind___extern1,
    C_Extern_Kind___extern2,
};
typedef enum C_Extern_Kind__Enum C_Extern_Kind;
enum C_Field_Kind__Enum {
    C_Field_Kind___field1,
    C_Field_Kind___field2,
};
typedef enum C_Field_Kind__Enum C_Field_Kind;
enum Define_Kind__Enum {
    Define_Kind___end_of_line,
    Define_Kind___define_line,
    Define_Kind___error,
};
typedef enum Define_Kind__Enum Define_Kind;
/* h_emit3 */

/* Include other libraries exactly once: */
#ifndef COMPILER_INCLUDED
#include "Compiler.ez.h"/*D2*/
#endif /* COMPILER_INCLUDED */
#ifndef EASY_C_INCLUDED
#include "Easy_C.ez.h"/*D2*/
#endif /* EASY_C_INCLUDED */
#ifndef PARSE_INCLUDED
#include "Parse.ez.h"/*D2*/
#endif /* PARSE_INCLUDED */
#ifndef TOKEN_INCLUDED
#include "Token.ez.h"/*D2*/
#endif /* TOKEN_INCLUDED */
#ifndef UNIX_INCLUDED
#include "Unix.ez.h"/*D2*/
#endif /* UNIX_INCLUDED */

/* Define the structures: */
struct C_Root__Struct {
    Array c_declarations;
    Token end_of_file;
};
extern struct C_Root__Struct C_Root__Initial;/*D1*/
struct C_Declaration__Struct {
    C_Declaration_Kind kind;
    union {
	C_Typedef typedef___k;/*u*/
	C_Struct struct___k;/*u*/
	C_Extern extern___k;/*u*/
	C_Error error;/*u*/
    } kind__union;
};
extern struct C_Declaration__Struct C_Declaration__Initial;/*D1*/
struct C_Struct__Struct {
    Keyword struct___k;
    Token name;
    Token open_brace;
    Array fields;
    Token close_brace;
    Token semicolon;
};
extern struct C_Struct__Struct C_Struct__Initial;/*D1*/
struct C_Extern__Struct {
    C_Extern_Kind kind;
    union {
	C_Extern1 extern1;/*u*/
	C_Extern2 extern2;/*u*/
    } kind__union;
};
extern struct C_Extern__Struct C_Extern__Initial;/*D1*/
struct C_Extern1__Struct {
    Keyword extern___k;
    C_Type return_type;
    Token name;
    Token open_parenthesis;
    Comma_Separated arguments;
    Token close_parenthesis;
    Token attribute;
    C_Nest1 nest;
    Token semicolon;
};
extern struct C_Extern1__Struct C_Extern1__Initial;/*D1*/
struct C_Extern2__Struct {
    Keyword extern___k;
    C_Type return_type;
    Token name;
    Token open_parenthesis;
    Comma_Separated arguments;
    Token close_parenthesis;
    Token semicolon;
};
extern struct C_Extern2__Struct C_Extern2__Initial;/*D1*/
struct C_Typedef__Struct {
    Keyword typedef___k;
    C_Type type;
    Token name;
    Token semicolon;
};
extern struct C_Typedef__Struct C_Typedef__Initial;/*D1*/
struct C_Field__Struct {
    C_Field_Kind kind;
    union {
	C_Field1 field1;/*u*/
	C_Field2 field2;/*u*/
    } kind__union;
};
extern struct C_Field__Struct C_Field__Initial;/*D1*/
struct C_Field1__Struct {
    C_Type type;
    Token name;
    Token open_bracket;
    Token number;
    Token close_bracket;
    Token semicolon;
};
extern struct C_Field1__Struct C_Field1__Initial;/*D1*/
struct C_Field2__Struct {
    C_Type type;
    Token name;
    Token semicolon;
};
extern struct C_Field2__Struct C_Field2__Initial;/*D1*/
struct C_Error__Struct {
    Array tokens;
    Token semicolon;
};
extern struct C_Error__Struct C_Error__Initial;/*D1*/
struct C_Argument__Struct {
    C_Type type;
    Token name;
};
extern struct C_Argument__Struct C_Argument__Initial;/*D1*/
struct C_Type__Struct {
    String type;
};
extern struct C_Type__Struct C_Type__Initial;/*D1*/
struct C_Nest1__Struct {
    Token open_parenthesis;
    C_Nest2 nest;
    Token close_parenthesis;
};
extern struct C_Nest1__Struct C_Nest1__Initial;/*D1*/
struct C_Nest2__Struct {
    Token open_parenthesis;
    Token nothrow;
    Token close_parenthesis;
};
extern struct C_Nest2__Struct C_Nest2__Initial;/*D1*/
struct Define_Root__Struct {
    Array defines;
    Token end_of_file;
};
extern struct Define_Root__Struct Define_Root__Initial;/*D1*/
struct Define__Struct {
    Define_Kind kind;
    union {
	Token end_of_line;/*u*/
	Define_Line define_line;/*u*/
	Error error;/*u*/
    } kind__union;
};
extern struct Define__Struct Define__Initial;/*D1*/
struct Define_Line__Struct {
    Keyword define;
    Token name;
    Token number;
    Token end_of_line;
};
extern struct Define_Line__Struct Define_Line__Initial;/*D1*/
struct Options__Struct {
    String command_name;
    Logical compile_only;
    String compiler_executable;
    Logical debug;
    String executable_name;
    String executable_directory;
    String interface_extract;
    String linker_executable;
    Array linker_searches;
    String linker_options;
    Logical optimize;
    Logical plain_main;
    Logical profile;
    Array require_bases;
    String search_options;
    Array searches;
    Array source_bases;
    String suffix;
    Unsigned trace_line;
    Logical verbose;
};
extern struct Options__Struct Options__Initial;/*D1*/

/* Declare the routine prototypes: */
extern C_Root C_Root__null;/*D10*/
extern C_Root C_Root__new(void);/*D11*/
extern void C_Root__erase(C_Root);/*D12*/
extern C_Declaration_Kind C_Declaration_Kind__typedef;/*D9*/
extern C_Declaration_Kind C_Declaration_Kind__struct;/*D9*/
extern C_Declaration_Kind C_Declaration_Kind__extern;/*D9*/
extern C_Declaration_Kind C_Declaration_Kind__error;/*D9*/
extern C_Declaration C_Declaration__null;/*D10*/
extern C_Declaration C_Declaration__new(void);/*D11*/
extern void C_Declaration__erase(C_Declaration);/*D12*/
extern C_Struct C_Struct__null;/*D10*/
extern C_Struct C_Struct__new(void);/*D11*/
extern void C_Struct__erase(C_Struct);/*D12*/
extern C_Extern_Kind C_Extern_Kind__extern1;/*D9*/
extern C_Extern_Kind C_Extern_Kind__extern2;/*D9*/
extern C_Extern C_Extern__null;/*D10*/
extern C_Extern C_Extern__new(void);/*D11*/
extern void C_Extern__erase(C_Extern);/*D12*/
extern C_Extern1 C_Extern1__null;/*D10*/
extern C_Extern1 C_Extern1__new(void);/*D11*/
extern void C_Extern1__erase(C_Extern1);/*D12*/
extern C_Extern2 C_Extern2__null;/*D10*/
extern C_Extern2 C_Extern2__new(void);/*D11*/
extern void C_Extern2__erase(C_Extern2);/*D12*/
extern C_Typedef C_Typedef__null;/*D10*/
extern C_Typedef C_Typedef__new(void);/*D11*/
extern void C_Typedef__erase(C_Typedef);/*D12*/
extern C_Field_Kind C_Field_Kind__field1;/*D9*/
extern C_Field_Kind C_Field_Kind__field2;/*D9*/
extern C_Field C_Field__null;/*D10*/
extern C_Field C_Field__new(void);/*D11*/
extern void C_Field__erase(C_Field);/*D12*/
extern C_Field1 C_Field1__null;/*D10*/
extern C_Field1 C_Field1__new(void);/*D11*/
extern void C_Field1__erase(C_Field1);/*D12*/
extern C_Field2 C_Field2__null;/*D10*/
extern C_Field2 C_Field2__new(void);/*D11*/
extern void C_Field2__erase(C_Field2);/*D12*/
extern C_Error C_Error__null;/*D10*/
extern C_Error C_Error__new(void);/*D11*/
extern void C_Error__erase(C_Error);/*D12*/
extern C_Argument C_Argument__null;/*D10*/
extern C_Argument C_Argument__new(void);/*D11*/
extern void C_Argument__erase(C_Argument);/*D12*/
extern C_Type C_Type__null;/*D10*/
extern C_Type C_Type__new(void);/*D11*/
extern void C_Type__erase(C_Type);/*D12*/
extern C_Nest1 C_Nest1__null;/*D10*/
extern C_Nest1 C_Nest1__new(void);/*D11*/
extern void C_Nest1__erase(C_Nest1);/*D12*/
extern C_Nest2 C_Nest2__null;/*D10*/
extern C_Nest2 C_Nest2__new(void);/*D11*/
extern void C_Nest2__erase(C_Nest2);/*D12*/
extern Define_Root Define_Root__null;/*D10*/
extern Define_Root Define_Root__new(void);/*D11*/
extern void Define_Root__erase(Define_Root);/*D12*/
extern Define_Kind Define_Kind__end_of_line;/*D9*/
extern Define_Kind Define_Kind__define_line;/*D9*/
extern Define_Kind Define_Kind__error;/*D9*/
extern Define Define__null;/*D10*/
extern Define Define__new(void);/*D11*/
extern void Define__erase(Define);/*D12*/
extern Define_Line Define_Line__null;/*D10*/
extern Define_Line Define_Line__new(void);/*D11*/
extern void Define_Line__erase(Define_Line);/*D12*/
extern Options Options__null;/*D10*/
extern Options Options__new(void);/*D11*/
extern void Options__erase(Options);/*D12*/
extern Integer Easy_C__main(Array);
extern void Easy_C__compiler_fail(String, String, Unsigned);
extern Integer Easy_C__framus(String, Compiler, Options, Messages);
extern C_Error C_Error__parse(Parser);
extern C_Type C_Type__parse(Parser);
extern void C_Type__traverse(C_Type, Traverser);
extern C_Typedef C_Typedef__parse(Parser);
extern Integer Define_Line__compare(Define_Line, Define_Line);
extern Options Options__extract(Array);
extern C_Root C_Root__parse(Parser);
extern void C_Root__traverse(C_Root, Traverser);
extern C_Root C_Root__null;;/*D13*/
extern C_Root C_Root__new(void);
extern C_Declaration_Kind C_Declaration_Kind__typedef;/*D3*/
extern C_Declaration_Kind C_Declaration_Kind__struct;/*D3*/
extern C_Declaration_Kind C_Declaration_Kind__extern;/*D3*/
extern C_Declaration_Kind C_Declaration_Kind__error;/*D3*/
extern C_Declaration_Kind C_Declaration_Kind__null;/*D6*/
extern String C_Declaration_Kind__string_convert(C_Declaration_Kind);/*D7*/
extern void C_Declaration_Kind__erase(C_Declaration_Kind);/*D8*/
extern C_Declaration_Kind C_Declaration_Kind__typedef;;/*D13*/
extern C_Declaration_Kind C_Declaration_Kind__struct;;/*D13*/
extern C_Declaration_Kind C_Declaration_Kind__extern;;/*D13*/
extern C_Declaration_Kind C_Declaration_Kind__error;;/*D13*/
extern String C_Declaration_Kind__string_convert(C_Declaration_Kind);
extern C_Declaration C_Declaration__parse(Parser);
extern void C_Declaration__traverse(C_Declaration, Traverser);
extern C_Declaration C_Declaration__null;;/*D13*/
extern C_Declaration C_Declaration__new(void);
extern C_Struct C_Struct__parse(Parser);
extern void C_Struct__traverse(C_Struct, Traverser);
extern C_Struct C_Struct__null;;/*D13*/
extern C_Struct C_Struct__new(void);
extern C_Extern_Kind C_Extern_Kind__extern1;/*D3*/
extern C_Extern_Kind C_Extern_Kind__extern2;/*D3*/
extern C_Extern_Kind C_Extern_Kind__null;/*D6*/
extern String C_Extern_Kind__string_convert(C_Extern_Kind);/*D7*/
extern void C_Extern_Kind__erase(C_Extern_Kind);/*D8*/
extern C_Extern_Kind C_Extern_Kind__extern1;;/*D13*/
extern C_Extern_Kind C_Extern_Kind__extern2;;/*D13*/
extern String C_Extern_Kind__string_convert(C_Extern_Kind);
extern C_Extern C_Extern__parse(Parser);
extern void C_Extern__traverse(C_Extern, Traverser);
extern C_Extern C_Extern__null;;/*D13*/
extern C_Extern C_Extern__new(void);
extern C_Extern1 C_Extern1__parse(Parser);
extern void C_Extern1__traverse(C_Extern1, Traverser);
extern C_Extern1 C_Extern1__null;;/*D13*/
extern C_Extern1 C_Extern1__new(void);
extern C_Extern2 C_Extern2__parse(Parser);
extern void C_Extern2__traverse(C_Extern2, Traverser);
extern C_Extern2 C_Extern2__null;;/*D13*/
extern C_Extern2 C_Extern2__new(void);
extern void C_Typedef__traverse(C_Typedef, Traverser);
extern C_Typedef C_Typedef__null;;/*D13*/
extern C_Typedef C_Typedef__new(void);
extern C_Field_Kind C_Field_Kind__field1;/*D3*/
extern C_Field_Kind C_Field_Kind__field2;/*D3*/
extern C_Field_Kind C_Field_Kind__null;/*D6*/
extern String C_Field_Kind__string_convert(C_Field_Kind);/*D7*/
extern void C_Field_Kind__erase(C_Field_Kind);/*D8*/
extern C_Field_Kind C_Field_Kind__field1;;/*D13*/
extern C_Field_Kind C_Field_Kind__field2;;/*D13*/
extern String C_Field_Kind__string_convert(C_Field_Kind);
extern C_Field C_Field__parse(Parser);
extern void C_Field__traverse(C_Field, Traverser);
extern C_Field C_Field__null;;/*D13*/
extern C_Field C_Field__new(void);
extern C_Field1 C_Field1__parse(Parser);
extern void C_Field1__traverse(C_Field1, Traverser);
extern C_Field1 C_Field1__null;;/*D13*/
extern C_Field1 C_Field1__new(void);
extern C_Field2 C_Field2__parse(Parser);
extern void C_Field2__traverse(C_Field2, Traverser);
extern C_Field2 C_Field2__null;;/*D13*/
extern C_Field2 C_Field2__new(void);
extern void C_Error__traverse(C_Error, Traverser);
extern C_Error C_Error__null;;/*D13*/
extern C_Error C_Error__new(void);
extern C_Argument C_Argument__parse(Parser);
extern void C_Argument__traverse(C_Argument, Traverser);
extern C_Argument C_Argument__null;;/*D13*/
extern C_Argument C_Argument__new(void);
extern C_Type C_Type__null;;/*D13*/
extern C_Type C_Type__new(void);
extern C_Nest1 C_Nest1__parse(Parser);
extern void C_Nest1__traverse(C_Nest1, Traverser);
extern C_Nest1 C_Nest1__null;;/*D13*/
extern C_Nest1 C_Nest1__new(void);
extern C_Nest2 C_Nest2__parse(Parser);
extern void C_Nest2__traverse(C_Nest2, Traverser);
extern C_Nest2 C_Nest2__null;;/*D13*/
extern C_Nest2 C_Nest2__new(void);
extern Define_Root Define_Root__parse(Parser);
extern void Define_Root__traverse(Define_Root, Traverser);
extern Define_Root Define_Root__null;;/*D13*/
extern Define_Root Define_Root__new(void);
extern Define_Kind Define_Kind__end_of_line;/*D3*/
extern Define_Kind Define_Kind__define_line;/*D3*/
extern Define_Kind Define_Kind__error;/*D3*/
extern Define_Kind Define_Kind__null;/*D6*/
extern String Define_Kind__string_convert(Define_Kind);/*D7*/
extern void Define_Kind__erase(Define_Kind);/*D8*/
extern Define_Kind Define_Kind__end_of_line;;/*D13*/
extern Define_Kind Define_Kind__define_line;;/*D13*/
extern Define_Kind Define_Kind__error;;/*D13*/
extern String Define_Kind__string_convert(Define_Kind);
extern Define Define__parse(Parser);
extern void Define__traverse(Define, Traverser);
extern Define Define__null;;/*D13*/
extern Define Define__new(void);
extern Define_Line Define_Line__parse(Parser);
extern void Define_Line__traverse(Define_Line, Traverser);
extern Define_Line Define_Line__null;;/*D13*/
extern Define_Line Define_Line__new(void);
extern Options Options__null;;/*D13*/
extern Options Options__new(void);

/* Declare extracted #define values: */
extern Unsigned Unsigned__unix_errno_2big;
extern Unsigned Unsigned__unix_errno_acces;
extern Unsigned Unsigned__unix_errno_addrinuse;
extern Unsigned Unsigned__unix_errno_addrnotavail;
extern Unsigned Unsigned__unix_errno_adv;
extern Unsigned Unsigned__unix_errno_afnosupport;
extern Unsigned Unsigned__unix_errno_again;
extern Unsigned Unsigned__unix_errno_already;
extern Unsigned Unsigned__unix_errno_asy_c_included;
extern Unsigned Unsigned__unix_errno_bade;
extern Unsigned Unsigned__unix_errno_badf;
extern Unsigned Unsigned__unix_errno_badfd;
extern Unsigned Unsigned__unix_errno_badmsg;
extern Unsigned Unsigned__unix_errno_badr;
extern Unsigned Unsigned__unix_errno_badrqc;
extern Unsigned Unsigned__unix_errno_badslt;
extern Unsigned Unsigned__unix_errno_bfont;
extern Unsigned Unsigned__unix_errno_busy;
extern Unsigned Unsigned__unix_errno_canceled;
extern Unsigned Unsigned__unix_errno_child;
extern Unsigned Unsigned__unix_errno_chrng;
extern Unsigned Unsigned__unix_errno_comm;
extern Unsigned Unsigned__unix_errno_connaborted;
extern Unsigned Unsigned__unix_errno_connrefused;
extern Unsigned Unsigned__unix_errno_connreset;
extern Unsigned Unsigned__unix_errno_deadlk;
extern Unsigned Unsigned__unix_errno_destaddrreq;
extern Unsigned Unsigned__unix_errno_dom;
extern Unsigned Unsigned__unix_errno_dotdot;
extern Unsigned Unsigned__unix_errno_dquot;
extern Unsigned Unsigned__unix_errno_exist;
extern Unsigned Unsigned__unix_errno_fault;
extern Unsigned Unsigned__unix_errno_fbig;
extern Unsigned Unsigned__unix_errno_hostdown;
extern Unsigned Unsigned__unix_errno_hostunreach;
extern Unsigned Unsigned__unix_errno_hwpoison;
extern Unsigned Unsigned__unix_errno_idrm;
extern Unsigned Unsigned__unix_errno_ilseq;
extern Unsigned Unsigned__unix_errno_inprogress;
extern Unsigned Unsigned__unix_errno_intr;
extern Unsigned Unsigned__unix_errno_inval;
extern Unsigned Unsigned__unix_errno_io;
extern Unsigned Unsigned__unix_errno_isconn;
extern Unsigned Unsigned__unix_errno_isdir;
extern Unsigned Unsigned__unix_errno_isnam;
extern Unsigned Unsigned__unix_errno_keyexpired;
extern Unsigned Unsigned__unix_errno_keyrejected;
extern Unsigned Unsigned__unix_errno_keyrevoked;
extern Unsigned Unsigned__unix_errno_l2hlt;
extern Unsigned Unsigned__unix_errno_l2nsync;
extern Unsigned Unsigned__unix_errno_l3hlt;
extern Unsigned Unsigned__unix_errno_l3rst;
extern Unsigned Unsigned__unix_errno_libacc;
extern Unsigned Unsigned__unix_errno_libbad;
extern Unsigned Unsigned__unix_errno_libexec;
extern Unsigned Unsigned__unix_errno_libmax;
extern Unsigned Unsigned__unix_errno_libscn;
extern Unsigned Unsigned__unix_errno_lnrng;
extern Unsigned Unsigned__unix_errno_loop;
extern Unsigned Unsigned__unix_errno_mediumtype;
extern Unsigned Unsigned__unix_errno_mfile;
extern Unsigned Unsigned__unix_errno_mlink;
extern Unsigned Unsigned__unix_errno_msgsize;
extern Unsigned Unsigned__unix_errno_multihop;
extern Unsigned Unsigned__unix_errno_nametoolong;
extern Unsigned Unsigned__unix_errno_navail;
extern Unsigned Unsigned__unix_errno_netdown;
extern Unsigned Unsigned__unix_errno_netreset;
extern Unsigned Unsigned__unix_errno_netunreach;
extern Unsigned Unsigned__unix_errno_nfile;
extern Unsigned Unsigned__unix_errno_noano;
extern Unsigned Unsigned__unix_errno_nobufs;
extern Unsigned Unsigned__unix_errno_nocsi;
extern Unsigned Unsigned__unix_errno_nodata;
extern Unsigned Unsigned__unix_errno_nodev;
extern Unsigned Unsigned__unix_errno_noent;
extern Unsigned Unsigned__unix_errno_noexec;
extern Unsigned Unsigned__unix_errno_nokey;
extern Unsigned Unsigned__unix_errno_nolck;
extern Unsigned Unsigned__unix_errno_nolink;
extern Unsigned Unsigned__unix_errno_nomedium;
extern Unsigned Unsigned__unix_errno_nomem;
extern Unsigned Unsigned__unix_errno_nomsg;
extern Unsigned Unsigned__unix_errno_nonet;
extern Unsigned Unsigned__unix_errno_nopkg;
extern Unsigned Unsigned__unix_errno_noprotoopt;
extern Unsigned Unsigned__unix_errno_nospc;
extern Unsigned Unsigned__unix_errno_nosr;
extern Unsigned Unsigned__unix_errno_nostr;
extern Unsigned Unsigned__unix_errno_nosys;
extern Unsigned Unsigned__unix_errno_notblk;
extern Unsigned Unsigned__unix_errno_notconn;
extern Unsigned Unsigned__unix_errno_notdir;
extern Unsigned Unsigned__unix_errno_notempty;
extern Unsigned Unsigned__unix_errno_notnam;
extern Unsigned Unsigned__unix_errno_notrecoverable;
extern Unsigned Unsigned__unix_errno_notsock;
extern Unsigned Unsigned__unix_errno_notty;
extern Unsigned Unsigned__unix_errno_notuniq;
extern Unsigned Unsigned__unix_errno_nxio;
extern Unsigned Unsigned__unix_errno_opnotsupp;
extern Unsigned Unsigned__unix_errno_overflow;
extern Unsigned Unsigned__unix_errno_ownerdead;
extern Unsigned Unsigned__unix_errno_perm;
extern Unsigned Unsigned__unix_errno_pfnosupport;
extern Unsigned Unsigned__unix_errno_pipe;
extern Unsigned Unsigned__unix_errno_proto;
extern Unsigned Unsigned__unix_errno_protonosupport;
extern Unsigned Unsigned__unix_errno_prototype;
extern Unsigned Unsigned__unix_errno_range;
extern Unsigned Unsigned__unix_errno_remchg;
extern Unsigned Unsigned__unix_errno_remote;
extern Unsigned Unsigned__unix_errno_remoteio;
extern Unsigned Unsigned__unix_errno_restart;
extern Unsigned Unsigned__unix_errno_rfkill;
extern Unsigned Unsigned__unix_errno_rofs;
extern Unsigned Unsigned__unix_errno_shutdown;
extern Unsigned Unsigned__unix_errno_socktnosupport;
extern Unsigned Unsigned__unix_errno_spipe;
extern Unsigned Unsigned__unix_errno_srch;
extern Unsigned Unsigned__unix_errno_srmnt;
extern Unsigned Unsigned__unix_errno_stale;
extern Unsigned Unsigned__unix_errno_strpipe;
extern Unsigned Unsigned__unix_errno_time;
extern Unsigned Unsigned__unix_errno_timedout;
extern Unsigned Unsigned__unix_errno_toomanyrefs;
extern Unsigned Unsigned__unix_errno_txtbsy;
extern Unsigned Unsigned__unix_errno_uclean;
extern Unsigned Unsigned__unix_errno_unatch;
extern Unsigned Unsigned__unix_errno_users;
extern Unsigned Unsigned__unix_errno_xdev;
extern Unsigned Unsigned__unix_errno_xfull;
extern Unsigned Unsigned__unix_errno_xit_failure;
extern Unsigned Unsigned__unix_errno_xit_success;
extern Unsigned Unsigned__unix_errno_asyc_c_h_included;
extern Integer Integer__unix_file_f_dupfd;
extern Integer Integer__unix_file_f_dupfd_cloexec;
extern Integer Integer__unix_file_f_exlck;
extern Integer Integer__unix_file_f_getfd;
extern Integer Integer__unix_file_f_getfl;
extern Integer Integer__unix_file_f_getlk;
extern Integer Integer__unix_file_f_getlk64;
extern Integer Integer__unix_file_f_getown;
extern Integer Integer__unix_file_f_lock;
extern Integer Integer__unix_file_f_ok;
extern Integer Integer__unix_file_f_rdlck;
extern Integer Integer__unix_file_f_setfd;
extern Integer Integer__unix_file_f_setfl;
extern Integer Integer__unix_file_f_setlk;
extern Integer Integer__unix_file_f_setlk64;
extern Integer Integer__unix_file_f_setlkw;
extern Integer Integer__unix_file_f_setlkw64;
extern Integer Integer__unix_file_f_setown;
extern Integer Integer__unix_file_f_shlck;
extern Integer Integer__unix_file_f_test;
extern Integer Integer__unix_file_f_tlock;
extern Integer Integer__unix_file_f_ulock;
extern Integer Integer__unix_file_f_unlck;
extern Integer Integer__unix_file_f_wrlck;
extern Unsigned Unsigned__unix_file_o_accmode;
extern Unsigned Unsigned__unix_file_o_append;
extern Unsigned Unsigned__unix_file_o_async;
extern Unsigned Unsigned__unix_file_o_cloexec;
extern Unsigned Unsigned__unix_file_o_creat;
extern Unsigned Unsigned__unix_file_o_directory;
extern Unsigned Unsigned__unix_file_o_dsync;
extern Unsigned Unsigned__unix_file_o_excl;
extern Unsigned Unsigned__unix_file_o_noctty;
extern Unsigned Unsigned__unix_file_o_nofollow;
extern Unsigned Unsigned__unix_file_o_nonblock;
extern Unsigned Unsigned__unix_file_o_rdonly;
extern Unsigned Unsigned__unix_file_o_rdwr;
extern Unsigned Unsigned__unix_file_o_sync;
extern Unsigned Unsigned__unix_file_o_trunc;
extern Unsigned Unsigned__unix_file_o_wronly;
#endif /* EZCC_INCLUDED */
