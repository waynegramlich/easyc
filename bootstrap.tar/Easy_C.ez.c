#include "Easy_C.ez.h"/*cc2*/
/* # Copyright (c) 2007-2010 by Wayne C. Gramlich */
/* # All rights reserved. */
#include "Easy_C_C.h"/*D3*/
/* # {Array} stuff: */
/* #undef lower case macros */
#undef i386
#undef linux
#undef unix
#undef errno
#undef makedev
#undef major
#undef minor
#undef alloca

void Array__array_append(
  Array to_array,
  Array from_array)
{
    Unsigned from_size;
    void *element;
    Unsigned to_size;
    from_size = Array__size_get(from_array);
    if ((from_size != 0)) {
        element = ((void *)Array__fetch1(from_array, 0));
        to_size = Array__size_get(to_array);
        (void)Array__range_insert(to_array, to_size, from_size, ((void *)(element)));
        (void)Array__transfer(to_array, to_size, from_array, 0, from_size);
    }
}

/* #routine copy@Array[Element] */
/* #    takes array Array[Element] */
/* #    takes copy_routine [Element <= Element] */
/* #    returns Array[Element] */
/* # */
/* #    # This routine will return a copy of {array} using {copy_routine} */
/* #    # to copy each element in {array}. */
/* # */
/* #    result :@= new@Array[Element]() */
/* #    size :@= array.size */
/* #    index :@= 0 */
/* #    while index < size */
/* #	call append@(result, copy_routine(array[index])) */
/* #	index := index + 1 */
/* #    return result */
Array Array__copy_shallow(
  Array array)
{
    Array result;
    Unsigned size;
    Unsigned index;
    result = Array__new();
    size = Array__size_get(array);
    index = 0;
    while ((index < size)) {
        (void)Array__append(result, ((void *)(((void *)Array__fetch1(array, index)))));
        index = (index+1);
    }
    return result;
}

void Array__delete(
  Array array,
  Unsigned index)
{
    (void)Array__range_delete(array, index, 1);
}

Logical Array__equal(
  Array array1,
  Array array2,
  Logical (*element_equal)(void *, void *))
{
    Unsigned size1;
    Unsigned size2;
    Logical result;
    Unsigned index;
    size1 = Array__size_get(array1);
    size2 = Array__size_get(array2);
    result = (size1 == size2);
    if (result) {
        index = 0;
        while ((index < size1)) {
            if (!element_equal(((void *)Array__fetch1(array1, index)), ((void *)Array__fetch1(array2, index)))) {
                result = Logical__false;
                break;
            }
            index = (index+1);
        }
    }
    return result;
}

String Array__f(
  Array array,
  String (*f_routine)(void *))
{
    String value;
    String control;
    String prefix;
    Unsigned size;
    Unsigned index;
    void *element;
    String form1;
    String form2;
    value = Format__field_next();
    control = String__read_only_copy(value);
    (void)String__trim(value, 0);
    (void)String__string_append(value, ((String)"\001["));
    prefix = ((String)"\000");
    size = Array__size_get(array);
    index = 0;
    while ((index < size)) {
        element = ((void *)Array__fetch1(array, index));
        (void)String__string_append(value, prefix);
        prefix = ((String)"\002, ");
        /* #FIXME: excecution order; should be!!! */
        /* # string_append@(value, divide@(form@(control), f_routine(element))) */
        form1 = String__form(control);
        form2 = f_routine(element);
        (void)String__string_append(value, String__divide(form1, form2));
        index = (index+1);
    }
    (void)String__string_append(value, ((String)"\001]"));
    return value;
}

Unsigned Array__hash(
  Array array,
  Unsigned (*element_hash)(void *))
{
    Unsigned result;
    Unsigned size;
    Unsigned index;
    result = 0;
    size = Array__size_get(array);
    index = 0;
    while ((index < size)) {
        result = (result+element_hash(((void *)Array__fetch1(array, index))));
        index = (index+1);
    }
    return result;
}

void Array__insert(
  Array array,
  Unsigned index,
  void *element)
{
    (void)Array__range_insert(array, index, 1, ((void *)(element)));
}

void * Array__lop(
  Array array)
{
    void *result;
    if (!((Array__size_get(array) != 0))) {
        System__assert_fail((String)"\nEasy_C.ezc", 201);
    }
    result = ((void *)Array__fetch1(array, 0));
    (void)Array__delete(array, 0);
    return result;
}

void * Array__pop(
  Array array)
{
    Unsigned size;
    void *result;
    size = Array__size_get(array);
    if (!((size != 0))) {
        System__assert_fail((String)"\nEasy_C.ezc", 224);
    }
    size = (size-1);
    result = ((void *)Array__fetch1(array, size));
    (void)Array__trim(array, size);
    return result;
}

void Array__print(
  Array array,
  Out_Stream out_stream,
  void (*element_print)(void *, Out_Stream))
{
    String prefix;
    Unsigned size;
    Unsigned index;
    void *element;
    (void)String__put(((String)"\001["), out_stream);
    prefix = ((String)"\000");
    size = Array__size_get(array);
    index = 0;
    while ((index < size)) {
        (void)String__put(prefix, out_stream);
        prefix = ((String)"\002, ");
        element = ((void *)Array__fetch1(array, index));
        (void)element_print(element, out_stream);
        index = (index+1);
    }
    (void)String__put(((String)"\001]"), out_stream);
}

void Array__put(
  Array array,
  Out_Stream out_stream,
  void (*element_put)(void *, Out_Stream))
{
    Unsigned size;
    Unsigned index;
    size = Array__size_get(array);
    index = 0;
    while ((index < size)) {
        (void)element_put(((void *)Array__fetch1(array, index)), out_stream);
        index = (index+1);
    }
}

void Array__reverse(
  Array array)
{
    Unsigned size;
    Unsigned index1;
    Unsigned index2;
    void *element;
    size = Array__size_get(array);
    if ((size != 0)) {
        index1 = 0;
        index2 = (size-1);
        while ((index1 < index2)) {
            element = ((void *)Array__fetch1(array, index1));
            Array__store1(array, index1, ((void *)Array__fetch1(array, index2)));
            Array__store1(array, index2, element);
            index1 = (index1+1);
            index2 = (index2-1);
        }
    }
}

void Array__sort(
  Array array,
  Integer (*compare_routine)(void *, void *))
{
    Unsigned size;
    Unsigned power;
    Unsigned temp;
    Unsigned index;
    Unsigned element1;
    Unsigned element2;
    Integer zero;
    Unsigned step1;
    Unsigned step2;
    Unsigned index2;
    Unsigned index1a;
    Unsigned index1b;
    Unsigned offset;
    Unsigned count1a;
    Unsigned count1b;
    Unsigned element_temp;
    size = Array__size_get(array);
    power = 0;
    temp = 1;
    while ((temp < size)) {
        power = (power+1);
        temp = (temp<<1);
    }
    index = 0;
    while ((index < size)) {
        (void)Array__append(array, ((void *)(((void *)Array__fetch1(array, index)))));
        index = (index+1);
    }
    element1 = 0;
    element2 = 0;
    if (((power&1) == 1)) {
        element1 = size;
        element2 = 0;
    } else {
        element1 = 0;
        element2 = size;
    }
    zero = 0;
    step1 = 1;
    step2 = 2;
    index = power;
    while ((index != 0)) {
        index2 = element2;
        index1a = element1;
        index1b = (element1+step1);
        offset = 0;
        while ((offset < size)) {
            count1a = step1;
            count1b = step1;
            temp = (size-offset);
            if ((temp < step1)) {
                count1a = temp;
                count1b = 0;
            } else {
                temp = (temp-step1);
                if ((temp < step1)) {
                    count1b = temp;
                }
            }
            while (((count1a != 0)&&(count1b != 0))) {
                if ((compare_routine(((void *)Array__fetch1(array, index1a)), ((void *)Array__fetch1(array, index1b))) < zero)) {
                    Array__store1(array, index2, ((void *)Array__fetch1(array, index1a)));
                    index1a = (index1a+1);
                    count1a = (count1a-1);
                } else {
                    Array__store1(array, index2, ((void *)Array__fetch1(array, index1b)));
                    index1b = (index1b+1);
                    count1b = (count1b-1);
                }
                index2 = (index2+1);
            }
            while ((count1a != 0)) {
                Array__store1(array, index2, ((void *)Array__fetch1(array, index1a)));
                index1a = (index1a+1);
                count1a = (count1a-1);
                index2 = (index2+1);
            }
            while ((count1b != 0)) {
                Array__store1(array, index2, ((void *)Array__fetch1(array, index1b)));
                index1b = (index1b+1);
                count1b = (count1b-1);
                index2 = (index2+1);
            }
            index1a = (index1a+step1);
            index1b = (index1b+step1);
            offset = (offset+step2);
        }
        element_temp = element1;
        element1 = element2;
        element2 = element_temp;
        step1 = (step1<<1);
        step2 = (step2<<1);
        index = (index-1);
    }
    (void)Array__trim(array, size);
}

void Array__unique(
  Array array,
  Logical (*equal_routine)(void *, void *))
{
    Unsigned size;
    Unsigned to_index;
    Unsigned from_index;
    void *element1;
    void *element2;
    size = Array__size_get(array);
    if ((size > 1)) {
        to_index = 1;
        from_index = 1;
        while ((from_index < size)) {
            element1 = ((void *)Array__fetch1(array, (to_index-1)));
            element2 = ((void *)Array__fetch1(array, from_index));
            if (!equal_routine(element1, element2)) {
                Array__store1(array, to_index, element2);
                to_index = (to_index+1);
            }
            from_index = (from_index+1);
        }
        (void)Array__trim(array, to_index);
    }
}

void Array__xvisit(
  Array array,
  void (*visit_routine)(void *))
{
    Unsigned size;
    Unsigned index;
    size = Array__size_get(array);
    index = 0;
    while ((index < size)) {
        (void)visit_routine(((void *)Array__fetch1(array, index)));
        index = (index+1);
    }
}

/* # {Byte} Stuff: */
String Byte__f(
  Byte number)
{
    return Unsigned__f(((Unsigned)(number)));
}

/* # {Character} stuff: */
void Character__buffer_append(
  Character character,
  String buffer)
{
    (void)String__character_append(buffer, character);
}

Integer Character__compare(
  Character character1,
  Character character2)
{
    Integer result;
    result = Integer__zero;
    if ((character1 < character2)) {
        result = Integer__negative_one;
    } else if ((character1 > character2)) {
        result = Integer__one;
    }
    return result;
}

Unsigned Character__decimal_convert(
  Character character)
{
    Unsigned result;
    result = 0xffffffff;
    if (((((Character)'0') <= character)&&(character <= ((Character)'9')))) {
        result = ((Unsigned)((character-((Character)'0'))));
    }
    return result;
}

void Character__erase(
  Character character)
{
    /* do_nothing */;
}

String Character__f(
  Character character)
{
    Logical c_mode;
    Logical visual_mode;
    String value;
    Unsigned size;
    Unsigned index;
    Character mode_character;
    c_mode = Logical__false;
    visual_mode = Logical__false;
    value = Format__field_next();
    size = String__size_get(value);
    index = 0;
    while ((index < size)) {
        mode_character = String__fetch1(value, index);
        if ((mode_character == ((Character)'a'))) {
            c_mode = Logical__true;
        } else if ((mode_character == ((Character)'l'))) {
            character = Character__lower_case(character);
        } else if ((mode_character == ((Character)'u'))) {
            character = Character__upper_case(character);
        } else if ((mode_character == ((Character)'v'))) {
            visual_mode = Logical__true;
        }
        index = (index+1);
    }
    (void)String__trim(value, 0);
    if (c_mode) {
        (void)String__character_append(value, ((Character)'\047'));
        (void)String__c_character_append(value, character);
        (void)String__character_append(value, ((Character)'\047'));
    } else if (visual_mode) {
        (void)String__character_append(value, ((Character)'\047'));
        if (String__visual_character_append(value, Logical__false, character)) {
            (void)String__character_append(value, ((Character)'\134'));
        }
        (void)String__character_append(value, ((Character)'\047'));
    } else {
        (void)String__character_append(value, character);
    }
    return value;
}

Unsigned Character__hexadecimal_convert(
  Character character)
{
    Unsigned result;
    result = 0;
    if (((((Character)'0') <= character)&&(character <= ((Character)'9')))) {
        result = ((Unsigned)((character-((Character)'0'))));
    } else if (((((Character)'a') <= character)&&(character <= ((Character)'f')))) {

        result = (((Unsigned)(character))-97+10);
    } else if (((((Character)'A') <= character)&&(character <= ((Character)'F')))) {
        result = (((Unsigned)(character))-65+10);
    } else {
        if (!(Logical__false)) {
            System__assert_fail((String)"\nEasy_C.ezc", 691);
        }
    }
    return result;
}

Logical Character__is_alpha_numeric(
  Character character)
{
    return (((((Character)'a') <= character)&&(character <= ((Character)'z')))||((((Character)'A') <= character)&&(character <= ((Character)'Z')))||((((Character)'0') <= character)&&(character <= ((Character)'9'))));
}

Logical Character__is_decimal_digit(
  Character character)
{
    return ((((Character)'0') <= character)&&(character <= ((Character)'9')));
}

Logical Character__is_letter(
  Character character)
{
    return (((((Character)'a') <= character)&&(character <= ((Character)'z')))||((((Character)'A') <= character)&&(character <= ((Character)'Z'))));
}

Logical Character__is_white_space(
  Character character)
{
    return ((character == ((Character)' '))||(character <= ((Character)'\011')));
}

Logical Character__is_hex_digit(
  Character character)
{
    return (((((Character)'0') <= character)&&(character <= ((Character)'9')))||((((Character)'a') <= character)&&(character <= ((Character)'f')))||((((Character)'A') <= character)&&(character <= ((Character)'F'))));
}

Logical Character__is_lower_case(
  Character character)
{
    return ((((Character)'a') <= character)&&(character <= ((Character)'z')));
}

Logical Character__is_printing(
  Character character)
{
    return ((((Character)' ') <= character)&&(character <= ((Character)'~')));
}

Logical Character__is_upper_case(
  Character character)
{
    return ((((Character)'A') <= character)&&(character <= ((Character)'Z')));
}

Character Character__lower_case(
  Character character)
{
    if (Character__is_upper_case(character)) {

        character = (character+((Character)' '));
    }
    return character;
}

Character Character__upper_case(
  Character character)
{
    if (Character__is_lower_case(character)) {

        character = (character-((Character)' '));
    }
    return character;
}

/* # {Double} stuff: */
Integer Double__compare(
  Double double1,
  Double double2)
{
    Integer result;
    result = 0;
    if ((double1 < double2)) {
        result = -1;
    } else if ((double1 > double2)) {
        result = 1;
    }
    return result;
}

String Double__f(
  Double x)
{
    Logical decimal;
    Unsigned precision;
    Logical have_precision;
    Character format;
    String value;
    Unsigned number;
    Unsigned size;
    Unsigned index;
    Character character;
    Double round;
    String t__0;
    decimal = 0;
    precision = 0xffffffff;
    have_precision = 0;
    format = ((Character)'f');
    value = Format__field_next();
    number = 0;
    size = String__size_get(value);
    index = 0;
    while ((index < size)) {
        character = String__fetch1(value, index);
        if (Character__is_decimal_digit(character)) {
            have_precision = 1;
            number = ((number*10)+Character__decimal_convert(character));
        } else if (((character == ((Character)'f'))||(character == ((Character)'e'))||(character == ((Character)'g')))) {
            format = character;
            if (have_precision) {
                precision = number;
            }
            have_precision = 0;
            number = 0;
        } else if ((character == ((Character)'d'))) {
            decimal = 1;
        }
        index = (index+1);
    }
    (void)String__trim(value, 0);
    if (decimal) {
        round = 0.5;
        if ((x < 0.0)) {
            round = -0.5;
        }
        (void)String__string_append(value, (t__0 = String__form(((String)"\003%d%")), String__divide((t__0), Integer__f(((Integer)((x+round)))))));
    } else {
        (void)Double__f_helper(x, precision, format, value);
    }
    return value;
}

/* # {Easy_C} stuff: */
void Easy_C__fail(
  String file_name,
  Unsigned line_number,
  String message)
{
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    (void)String__d((t__3 = String__form(((String)"\030File:%v%, Line:%d%: %s%\n")), t__4 = String__f(file_name), t__5 = Unsigned__f(line_number), String__divide(String__remainder(String__remainder((t__3), t__4), t__5), String__f(message))));
    (void)System__abort();
}

/* # {Float} stuff: */
Integer Float__compare(
  Float float1,
  Float float2)
{
    Integer result;
    result = 0;
    if ((float1 < float2)) {
        result = -1;
    } else if ((float1 > float2)) {
        result = 1;
    }
    return result;
}

String Float__f(
  Float number)
{
    return Double__f(((Double)(number)));
}

/* # {Format} routines: */
Format_Frame Format__frame_allocate(
  Format format)
{
    Format_Frame frame;
    Array available_frames;
    frame = Format_Frame__null;
    available_frames = format->available_frames;
    if ((Array__size_get(available_frames) == 0)) {
        frame = Format_Frame__create();
        format->frame_count = (format->frame_count+1);
    } else {
        frame = ((Format_Frame)Array__pop(available_frames));
        frame->index = 0;
    }
    (void)Array__append(format->frames, ((void *)(frame)));
    return frame;
}

void Format__frame_release(
  Format format,
  Format_Frame frame)
{
    Array fields;
    Unsigned size;
    Unsigned index;
    if (!((frame == ((Format_Frame)Array__pop(format->frames))))) {
        System__assert_fail((String)"\nEasy_C.ezc", 1158);
    }
    fields = frame->fields;
    size = Array__size_get(fields);
    index = 0;
    while ((index < size)) {
        (void)Format__field_release(format, ((Format_Field)Array__fetch1(fields, index)));
        index = (index+1);
    }
    (void)Array__trim(fields, 0);
    frame->index = 0;
    (void)Array__append(format->available_frames, ((void *)(frame)));
}

Format_Field Format__field_allocate(
  Format format)
{
    Array available_fields;
    Unsigned size;
    Format_Field field;
    available_fields = format->available_fields;
    size = Array__size_get(available_fields);
    field = Format_Field__null;
    if ((size == 0)) {
        field = Format_Field__new();
        field->before = String__new();
        field->control = String__new();
        field->value = String__new();
        format->field_count = (format->field_count+1);
    } else {
        field = ((Format_Field)Array__pop(available_fields));
        (void)String__trim(field->before, 0);
        (void)String__trim(field->control, 0);
        (void)String__trim(field->value, 0);
    }
    return field;
}

String Format__field_next(void)
{
    Format format;
    Array frames;
    Unsigned frames_size;
    Format_Frame frame;
    Array fields;
    Unsigned index;
    Unsigned fields_size;
    Format_Field field;
    String value;
    format = Format__one_and_only();
    frames = format->frames;
    frames_size = Array__size_get(frames);
    if (!((frames_size != 0))) {
        System__assert_fail((String)"\nEasy_C.ezc", 1206);
    }
    frame = ((Format_Frame)Array__fetch1(frames, (frames_size-1)));
    fields = frame->fields;
    index = frame->index;
    fields_size = Array__size_get(fields);
    if (!((index < fields_size))) {
        System__assert_fail((String)"\nEasy_C.ezc", 1212);
    }
    field = ((Format_Field)Array__fetch1(fields, index));
    frame->index = (index+1);
    value = field->value;
    (void)String__string_append(value, field->control);
    return value;
}

void Format__field_release(
  Format format,
  Format_Field field)
{
    (void)Array__append(format->available_fields, ((void *)(field)));
}

Format Format__one_and_only(void)
{
    Format format;
    format = Format__null;
    if (!format->initialized) {
        format->initialized = Logical__true;
        format->available_frames = Array__new();
        format->frames = Array__new();
        format->frame_count = 0;
        format->field_count = 0;
    }
    return format;
}

/* # {Format_Frame} routines: */
Format_Frame Format_Frame__create(void)
{
    Format_Frame frame;
    frame = Format_Frame__new();
    frame->result = String__new();
    frame->index = 0;
    return frame;
}

/* # {Format_Field} routines: */
/* # {Hash_Table} stuff: */
/* # A data structure for associating {key} with a {value}. */
Hash_Table_Pair Hash_Table_Pair__create(
  void *key,
  void *value,
  Unsigned hash)
{
    Hash_Table_Pair pair;
    pair = Hash_Table_Pair__new();
    pair->key = key;
    pair->value = value;
    pair->hash = hash;
    return pair;
}

/* # One row from in a {Hash_Table}.  {mask} specifies the mask */
/* # used to sort pairs with. */
Hash_Table_Row Hash_Table_Row__create(
  Unsigned index)
{
    Hash_Table_Row row;
    row = Hash_Table_Row__new();
    row->index = index;
    row->mask = 0;
    row->pairs = Array__new();
    return row;
}

/* # A dynamic hash table that grows in size as needed. */
/* # Invariants: */
/* # 1) rows.size = 2**power */
/* # 2) mask = 2**power - 1 */
/* # 3) For each pair in hash_table.rows[I], pair.hash & hash_table.mask = I */
Hash_Table Hash_Table__create(
  void *value_empty,
  Unsigned (*key_hash)(void *),
  Logical (*key_equal)(void *, void *),
  void (*key_show)(void *, String),
  void (*value_show)(void *, String))
{
    Array rows;
    Hash_Table hash_table;
    rows = Array__new();
    (void)Array__append(rows, ((void *)(Hash_Table_Row__create(0))));
    (void)Array__append(rows, ((void *)(Hash_Table_Row__create(1))));
    hash_table = Hash_Table__new();
    hash_table->buffer = String__new();
    hash_table->key_equal = key_equal;
    hash_table->key_hash = key_hash;
    hash_table->key_show = key_show;
    hash_table->mask = 1;
    hash_table->null_pair = Hash_Table_Pair__new();
    hash_table->power = 1;
    hash_table->rows = rows;
    hash_table->size = 0;
    hash_table->trace_level = 0;
    hash_table->value_empty = value_empty;
    hash_table->value_show = value_show;
    if (!((hash_table->mask < Array__size_get(hash_table->rows)))) {
        System__assert_fail((String)"\nEasy_C.ezc", 1382);
    }
    return hash_table;
}

Logical Hash_Table__delete(
  Hash_Table hash_table,
  void *key)
{
    Logical result;
    Logical (*key_equal)(void *, void *);
    Unsigned hash;
    Hash_Table_Row row;
    Array pairs;
    Unsigned size;
    Unsigned index;
    Hash_Table_Pair pair;
    result = Logical__false;
    key_equal = hash_table->key_equal;
    hash = hash_table->key_hash(((void *)(key)));
    row = Hash_Table__row_lookup(hash_table, ((void *)(key)), hash);
    pairs = row->pairs;
    size = Array__size_get(pairs);
    index = 0;
    while ((index < size)) {
        pair = ((Hash_Table_Pair)Array__fetch1(pairs, index));
        if (((pair->hash == hash)&&key_equal(((void *)(pair->key)), ((void *)(key))))) {
            (void)Array__delete(pairs, index);
            result = Logical__true;
            break;
        }
        index = (index+1);
    }
    return result;
}

void * Hash_Table__lookup(
  Hash_Table hash_table,
  void *key)
{
    Unsigned trace_level;
    void *value;
    Logical (*key_equal)(void *, void *);
    Unsigned hash;
    Hash_Table_Row row;
    Array pairs;
    Unsigned size;
    Unsigned index;
    Hash_Table_Pair pair;
    String buffer;
    trace_level = hash_table->trace_level;
    value = hash_table->value_empty;
    key_equal = hash_table->key_equal;
    hash = hash_table->key_hash(((void *)(key)));
    row = Hash_Table__row_lookup(hash_table, ((void *)(key)), hash);
    pairs = row->pairs;
    size = Array__size_get(pairs);
    index = 0;
    while ((index < size)) {
        pair = ((Hash_Table_Pair)Array__fetch1(pairs, index));
        if (((pair->hash == hash)&&key_equal(((void *)(pair->key)), ((void *)(key))))) {
            value = pair->value;
            trace_level = (trace_level+1);
            break;
        }
        index = (index+1);
    }
    if ((trace_level >= 2)) {
        buffer = hash_table->buffer;
        (void)String__trim(buffer, 0);
        (void)String__buffer_append(((String)"\025lookup@Hash_Table(*, "), buffer);
        (void)hash_table->key_show(((void *)(key)), buffer);
        (void)String__buffer_append(((String)"\005) => "), buffer);
        (void)hash_table->value_show(((void *)(value)), buffer);
        (void)String__buffer_append(((String)"\001\n"), buffer);
        (void)String__put(buffer, Out_Stream__error);
    }
    return value;
}

/* #FIXME: insert should call replace!!! */
Logical Hash_Table__insert(
  Hash_Table hash_table,
  void *key,
  void *value)
{
    Unsigned trace_level;
    Logical result;
    Logical (*key_equal)(void *, void *);
    Unsigned hash;
    Hash_Table_Row row;
    Array pairs;
    Unsigned pairs_size;
    Unsigned index;
    Hash_Table_Pair pair;
    Unsigned size;
    Array rows;
    Unsigned rows_size;
    String buffer;
    trace_level = hash_table->trace_level;
    result = Logical__false;
    key_equal = hash_table->key_equal;
    hash = hash_table->key_hash(((void *)(key)));
    row = Hash_Table__row_lookup(hash_table, ((void *)(key)), hash);
    pairs = row->pairs;
    pairs_size = Array__size_get(pairs);
    index = 0;
    while ((index < pairs_size)) {
        pair = ((Hash_Table_Pair)Array__fetch1(pairs, index));
        if (((pair->hash == hash)&&key_equal(((void *)(pair->key)), ((void *)(key))))) {
            pair->value = value;
            result = Logical__true;
            break;
        }
        index = (index+1);
    }
    if (!result) {
        pair = Hash_Table_Pair__create(((void *)(key)), ((void *)(value)), hash);
        (void)Array__append(pairs, ((void *)(pair)));
        size = hash_table->size;
        hash_table->size = (size+1);
        /* # See whether we need to grow the table: */
        rows = hash_table->rows;
        rows_size = Array__size_get(rows);
        if ((size > (rows_size>>1))) {

            index = 0;
            while ((index < rows_size)) {
                (void)Array__append(rows, ((void *)(Hash_Table_Row__create(Array__size_get(rows)))));
                index = (index+1);
            }
        }
        hash_table->mask = (Array__size_get(hash_table->rows)-1);
        if (!((hash_table->mask < Array__size_get(hash_table->rows)))) {
            System__assert_fail((String)"\nEasy_C.ezc", 1522);
        }
    }
    if ((trace_level >= 1)) {
        buffer = hash_table->buffer;
        (void)String__trim(buffer, 0);
        (void)String__buffer_append(((String)"\025insert@Hash_Table(*, "), buffer);
        (void)hash_table->key_show(((void *)(key)), buffer);
        (void)String__buffer_append(((String)"\002, "), buffer);
        (void)hash_table->value_show(((void *)(value)), buffer);
        (void)String__buffer_append(((String)"\005) => "), buffer);
        if (result) {
            (void)String__buffer_append(((String)"\004true"), buffer);
        } else {
            (void)String__buffer_append(((String)"\005false"), buffer);
        }
        /* #call buffer_append@String(" size:", buffer) */
        /* #call buffer_append@Unsigned(hash_table.size, buffer) */
        /* #call buffer_append@String(" rows.size:", buffer) */
        /* #call buffer_append@Unsigned(hash_table.rows.size, buffer) */
        /* #call buffer_append@String(" row.index:", buffer) */
        /* #call buffer_append@Unsigned(row.index, buffer) */
        (void)String__buffer_append(((String)"\001\n"), buffer);
        (void)String__put(buffer, Out_Stream__error);
    }
    return result;
}

Logical Hash_Table__is_in(
  Hash_Table hash_table,
  void *key)
{
    Logical result;
    Logical (*key_equal)(void *, void *);
    Unsigned hash;
    Hash_Table_Row row;
    Array pairs;
    Unsigned size;
    Unsigned index;
    Hash_Table_Pair pair;
    result = Logical__false;
    key_equal = hash_table->key_equal;
    hash = hash_table->key_hash(((void *)(key)));
    row = Hash_Table__row_lookup(hash_table, ((void *)(key)), hash);
    pairs = row->pairs;
    size = Array__size_get(pairs);
    index = 0;
    while ((index < size)) {
        pair = ((Hash_Table_Pair)Array__fetch1(pairs, index));
        if (((pair->hash == hash)&&key_equal(((void *)(pair->key)), ((void *)(key))))) {
            result = Logical__true;
            break;
        }
        index = (index+1);
    }
    return result;
}

void * Hash_Table__key_lookup(
  Hash_Table hash_table,
  void *key)
{
    void *result;
    Logical (*key_equal)(void *, void *);
    Unsigned hash;
    Hash_Table_Row row;
    Array pairs;
    Unsigned size;
    Unsigned index;
    Hash_Table_Pair pair;
    result = key;
    key_equal = hash_table->key_equal;
    hash = hash_table->key_hash(((void *)(key)));
    row = Hash_Table__row_lookup(hash_table, ((void *)(key)), hash);
    pairs = row->pairs;
    size = Array__size_get(pairs);
    index = 0;
    while ((index < size)) {
        pair = ((Hash_Table_Pair)Array__fetch1(pairs, index));
        if (((pair->hash == hash)&&key_equal(((void *)(pair->key)), ((void *)(key))))) {
            result = pair->key;
            break;
        }
        index = (index+1);
    }
    return result;
}

void * Hash_Table__replace(
  Hash_Table hash_table,
  void *key,
  void *value)
{
    Unsigned trace_level;
    void *previous_value;
    Hash_Table_Pair null_pair;
    Logical (*key_equal)(void *, void *);
    Unsigned hash;
    Hash_Table_Row row;
    Hash_Table_Pair pair;
    Array pairs;
    Unsigned pairs_size;
    Unsigned index;
    Logical new_pair;
    Unsigned size;
    Array rows;
    Unsigned rows_size;
    String buffer;
    trace_level = hash_table->trace_level;
    previous_value = hash_table->value_empty;
    null_pair = hash_table->null_pair;
    key_equal = hash_table->key_equal;
    hash = hash_table->key_hash(((void *)(key)));
    row = Hash_Table__row_lookup(hash_table, ((void *)(key)), hash);
    pair = hash_table->null_pair;
    pairs = row->pairs;
    pairs_size = Array__size_get(pairs);
    index = 0;
    while ((index < pairs_size)) {
        pair = ((Hash_Table_Pair)Array__fetch1(pairs, index));
        if (((pair->hash == hash)&&key_equal(((void *)(pair->key)), ((void *)(key))))) {
            previous_value = pair->value;
            break;
        }
        pair = null_pair;
        index = (index+1);
    }
    new_pair = Logical__false;
    if ((pair == null_pair)) {

        pair = Hash_Table_Pair__create(((void *)(key)), ((void *)(value)), hash);
        new_pair = Logical__true;
    } else {
        pair->key = key;
        pair->value = value;
        if (!((pair->hash == hash))) {
            System__assert_fail((String)"\nEasy_C.ezc", 1646);
        }
    }
    if (new_pair) {
        (void)Array__append(pairs, ((void *)(pair)));
        size = hash_table->size;
        hash_table->size = (size+1);
        /* # See whether we need to grow the table: */
        rows = hash_table->rows;
        rows_size = Array__size_get(rows);
        if ((size > (rows_size>>1))) {

            index = 0;
            while ((index < rows_size)) {
                (void)Array__append(rows, ((void *)(Hash_Table_Row__create(Array__size_get(rows)))));
                index = (index+1);
            }
        }
        hash_table->mask = (Array__size_get(hash_table->rows)-1);
        if (!((hash_table->mask < Array__size_get(hash_table->rows)))) {
            System__assert_fail((String)"\nEasy_C.ezc", 1664);
        }
    }
    if ((trace_level >= 1)) {
        buffer = hash_table->buffer;
        (void)String__trim(buffer, 0);
        (void)String__buffer_append(((String)"\025insert@Hash_Table(*, "), buffer);
        (void)hash_table->key_show(((void *)(key)), buffer);
        (void)String__buffer_append(((String)"\002, "), buffer);
        (void)hash_table->value_show(((void *)(value)), buffer);
        (void)String__buffer_append(((String)"\005) => "), buffer);
        (void)hash_table->value_show(((void *)(previous_value)), buffer);
        /* #call buffer_append@String(" size:", buffer) */
        /* #call buffer_append@Unsigned(hash_table.size, buffer) */
        /* #call buffer_append@String(" rows.size:", buffer) */
        /* #call buffer_append@Unsigned(hash_table.rows.size, buffer) */
        /* #call buffer_append@String(" row.index:", buffer) */
        /* #call buffer_append@Unsigned(row.index, buffer) */
        (void)String__buffer_append(((String)"\001\n"), buffer);
        (void)String__put(buffer, Out_Stream__error);
    }
    return previous_value;
}

void Hash_Table__show(
  Hash_Table hash_table,
  Out_Stream out_stream)
{
    String buffer;
    void (*value_show)(void *, String);
    void (*key_show)(void *, String);
    Array rows;
    Unsigned size;
    Unsigned index;
    Hash_Table_Row row;
    Array pairs;
    Unsigned pairs_size;
    Unsigned pairs_index;
    Hash_Table_Pair pair;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    buffer = String__new();
    value_show = hash_table->value_show;
    key_show = hash_table->key_show;
    rows = hash_table->rows;
    size = Array__size_get(rows);
    index = 0;
    while ((index < size)) {
        row = ((Hash_Table_Row)Array__fetch1(rows, index));
        (void)String__string_append(buffer, (t__0 = String__form(((String)"\035Row[%d% index:%d% mask:%d%]: ")), t__1 = Unsigned__f(index), t__2 = Unsigned__f(row->index), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), Unsigned__f(row->mask))));
        pairs = row->pairs;
        pairs_size = Array__size_get(pairs);
        pairs_index = 0;
        while ((pairs_index < pairs_size)) {
            pair = ((Hash_Table_Pair)Array__fetch1(pairs, pairs_index));
            (void)String__string_append(buffer, (t__3 = String__form(((String)"\012(hash:%x% ")), String__divide((t__3), Unsigned__f(pair->hash))));
            (void)key_show(((void *)(pair->key)), buffer);
            (void)String__string_append(buffer, ((String)"\001 "));
            (void)value_show(((void *)(pair->value)), buffer);
            (void)String__string_append(buffer, ((String)"\001)"));
            pairs_index = (pairs_index+1);
        }
        (void)String__character_append(buffer, ((Character)'\012'));
        index = (index+1);
    }
    (void)String__put(buffer, out_stream);
}

Hash_Table_Row Hash_Table__row_lookup(
  Hash_Table hash_table,
  void *key,
  Unsigned hash)
{
    Array rows;
    Unsigned table_mask;
    Hash_Table_Row row;
    Unsigned row_mask;
    Unsigned row_index;
    Array pairs;
    Unsigned size;
    Unsigned index;
    Hash_Table_Pair pair;
    Unsigned pair_index;
    hash = hash_table->key_hash(((void *)(key)));
    rows = hash_table->rows;
    table_mask = hash_table->mask;
    row = ((Hash_Table_Row)Array__fetch1(rows, (hash&table_mask)));
    if ((row->mask != table_mask)) {

        /* # visit each row that matches {hash} and resort: */
        row_mask = table_mask;
        while ((row_mask != 0)) {
            row_index = (hash&row_mask);
            row = ((Hash_Table_Row)Array__fetch1(rows, row_index));
            if ((row->mask != table_mask)) {

                pairs = row->pairs;
                size = Array__size_get(pairs);
                index = 0;
                while ((index < size)) {
                    pair = ((Hash_Table_Pair)Array__fetch1(pairs, index));
                    pair_index = (table_mask&pair->hash);
                    if ((pair_index != row_index)) {

                        (void)Array__append(((Hash_Table_Row)Array__fetch1(rows, pair_index))->pairs, ((void *)(pair)));
                        Array__store1(pairs, index, (void *)(((Hash_Table_Pair)Array__fetch1(pairs, (size-1)))));
                        size = (size-1);
                        (void)Array__trim(pairs, size);
                    } else {

                        index = (index+1);
                    }
                }
                /* # We are finished rearranging the current row: */
                row->mask = table_mask;
            }
            /* # Move onto next row: */
            row_mask = (row_mask>>1);
        }
    }
    return ((Hash_Table_Row)Array__fetch1(rows, (hash&table_mask)));
}

/* # {In_Stream} stuff: */
String In_Stream__all_read(
  In_Stream in_stream,
  String contents)
{
    Unsigned offset;
    Logical done;
    Unsigned amount_read;
    if ((contents == String__null)) {
        contents = String__new();
    }
    offset = 0;
    done = Logical__false;
    while (!done) {
        (void)String__range_nulls_insert(contents, offset, 1024);
        amount_read = String__read(contents, offset, 1024, in_stream);
        if ((amount_read == 1024)) {

            offset = (offset+1024);
        } else {

            (void)String__trim(contents, (offset+amount_read));
            done = Logical__true;
        }
    }
    return contents;
}

Unsigned In_Stream__byte_get(
  In_Stream in_stream)
{
    return ((Unsigned)(In_Stream__character_read(in_stream)));
}

void In_Stream__erase(
  In_Stream in_stream)
{
    /* do_nothing */;
}

String In_Stream__line_read(
  In_Stream in_stream,
  String line)
{
    Character end_of_file;
    Character character;
    if ((line == String__null)) {
        line = String__new();
    } else {
        (void)String__trim(line, 0);
    }
    end_of_file = ((Character)(0xffffffff));
    character = ((Character)' ');
    while (((character != ((Character)'\012'))&&(character != end_of_file))) {
        character = In_Stream__character_read(in_stream);
        if (((character != ((Character)'\012'))&&(character != ((Character)'\015'))&&(character != end_of_file))) {
            (void)String__character_append(line, character);
        }
    }
    return line;
}

Unsigned In_Stream__little_endian_short_get(
  In_Stream in_stream)
{
    Unsigned low_byte;
    Unsigned high_byte;
    Unsigned result;
    low_byte = In_Stream__byte_get(in_stream);
    high_byte = In_Stream__byte_get(in_stream);
    result = 0xffffffff;
    if ((high_byte != 0xffffffff)) {
        result = (((high_byte<<8))|low_byte);
    }
    return result;
}

Logical In_Stream__xml_attribute_read(
  In_Stream in_stream,
  String attribute_name,
  String attribute_value)
{
    Logical first;
    Character character;
    Character quote;
    (void)String__trim(attribute_name, 0);
    (void)String__trim(attribute_value, 0);
    first = Logical__true;
    character = ((Character)'\000');
    while (Logical__true) {
        if (first) {
            first = Logical__false;
            character = In_Stream__xml_space_skip(in_stream);
            if (((character == ((Character)'>'))||(character == ((Character)'/')))) {
                (void)In_Stream__character_unread(in_stream, character);
                return Logical__true;
            }
        } else {
            character = In_Stream__character_read(in_stream);
        }
        if ((!Character__is_alpha_numeric(character)&&(character != ((Character)'_')))) {
            break;
        }
        (void)String__character_append(attribute_name, character);
    }
    if ((character != ((Character)'='))) {
        character = In_Stream__xml_space_skip(in_stream);
    }
    if ((character != ((Character)'='))) {
        return Logical__true;
    }
    quote = In_Stream__xml_space_skip(in_stream);
    if (((quote != ((Character)'\047'))&&(quote != ((Character)'"')))) {
        return Logical__true;
    }
    while (Logical__true) {
        character = In_Stream__character_read(in_stream);
        if ((character == quote)) {
            break;
        }
        (void)String__character_append(attribute_value, character);
    }
    return Logical__false;
}

Character In_Stream__xml_space_skip(
  In_Stream in_stream)
{
    Character character;
    character = ((Character)'\000');
    while (Logical__true) {
        character = In_Stream__character_read(in_stream);
        if (((character != ((Character)' '))&&(character != ((Character)'\011'))&&(character != ((Character)'\012'))&&(character != ((Character)'\015')))) {
            break;
        }
    }
    return character;
}

Logical In_Stream__xml_tag_read(
  In_Stream in_stream,
  String tag_name)
{
    Character character;
    if ((In_Stream__xml_space_skip(in_stream) != ((Character)'<'))) {
        return Logical__true;
    }
    (void)String__trim(tag_name, 0);
    while (Logical__true) {
        character = In_Stream__character_read(in_stream);
        if (((character == ((Character)' '))||(character == ((Character)'\011'))||(character == ((Character)'>')))) {
            (void)In_Stream__character_unread(in_stream, character);
            break;
        }
        (void)String__character_append(tag_name, character);
    }
    return Logical__false;
}

Logical In_Stream__xml_tag_end(
  In_Stream in_stream,
  Logical single_tag)
{
    Logical result;
    Character character;
    result = Logical__true;
    character = In_Stream__xml_space_skip(in_stream);
    if (single_tag) {
        if ((character == ((Character)'/'))) {
            result = (In_Stream__character_read(in_stream) != ((Character)'>'));
        }
    } else {
        result = (character != ((Character)'>'));
    }
    return result;
}

Logical In_Stream__xml_tag_match(
  In_Stream in_stream,
  String tag_name)
{
    Unsigned size;
    Unsigned index;
    Character character;
    if ((In_Stream__xml_space_skip(in_stream) != ((Character)'<'))) {
        return Logical__true;
    }
    size = String__size_get(tag_name);
    index = 0;
    while ((index < size)) {
        character = In_Stream__character_read(in_stream);
        if ((character != String__fetch1(tag_name, index))) {
            return Logical__true;
        }
        index = (index+1);
    }
    return Logical__false;
}

/* # {Integer} stuff: */
Integer Integer__compare(
  Integer integer1,
  Integer integer2)
{
    Integer result;
    result = 0;
    if ((integer1 < integer2)) {
        result = -1;
    } else if ((integer1 > integer2)) {
        result = 1;
    }
    return result;
}

void Integer__erase(
  Integer number)
{
    /* do_nothing */;
}

String Integer__f(
  Integer number)
{
    Logical comma_separated;
    Character fill_character;
    Logical sign_force;
    Unsigned left_width;
    Integer radix;
    Unsigned right_width;
    String prefix;
    Logical upper_case;
    String value;
    Unsigned size;
    Unsigned index;
    Unsigned constant;
    Character character;
    comma_separated = Logical__false;
    fill_character = ((Character)' ');
    sign_force = Logical__false;
    left_width = 0;
    radix = 10;
    right_width = 0;
    prefix = ((String)"\000");
    upper_case = Logical__false;
    value = Format__field_next();
    size = String__size_get(value);
    index = 0;
    constant = 0;
    while ((index < size)) {
        character = String__fetch1(value, index);
        if (Character__is_decimal_digit(character)) {

            constant = ((constant*10)+Character__decimal_convert(character));
        } else if ((character == ((Character)'\047'))) {

            if ((((index+2) < size)&&(String__fetch1(value, (index+2)) == ((Character)'\047')))) {
                constant = ((Unsigned)(String__fetch1(value, (index+1))));
                index = (index+2);
            }
        } else if ((character == ((Character)'c'))) {

            comma_separated = Logical__true;
        } else if ((character == ((Character)'d'))) {

            radix = 10;
        } else if ((character == ((Character)'h'))) {

            radix = 16;
        } else if ((character == ((Character)'f'))) {

            fill_character = ((Character)((constant&0xff)));
            constant = 0;
        } else if ((character == ((Character)'l'))) {

            left_width = constant;
            constant = 0;
        } else if ((character == ((Character)'o'))) {

            prefix = ((String)"\0010");
            radix = 8;
        } else if ((character == ((Character)'r'))) {

            right_width = constant;
            constant = 0;
        } else if ((character == ((Character)'s'))) {

            sign_force = Logical__true;
        } else if ((character == ((Character)'u'))) {

            upper_case = Logical__true;
        } else if ((character == ((Character)'x'))) {

            prefix = ((String)"\0020x");
            radix = 16;
        } else if ((character == ((Character)'y'))) {

            radix = 16;
        }
        /* # else */
        /* #    assert false@Logical */
        index = (index+1);
    }
    (void)String__trim(value, 0);
    if ((number < 0)) {
        number = -number;
        (void)String__character_append(value, ((Character)'-'));
    } else if (sign_force) {
        (void)String__character_append(value, ((Character)'+'));
    }
    (void)Integer__f_helper(number, radix, value);
    if (comma_separated) {
        size = String__size_get(value);
        index = 3;
        while ((index < size)) {
            (void)String__character_insert(value, (size-index), ((Character)','));
            index = (index+3);
        }
    }
    if ((fill_character == ((Character)' '))) {
        (void)String__range_insert(value, 0, prefix, 0, String__size_get(prefix));
    }
    prefix = ((String)"\000");
    while ((String__size_get(value) < right_width)) {
        (void)String__character_prepend(value, fill_character);
    }
    while ((String__size_get(value) < left_width)) {
        (void)String__character_append(value, fill_character);
    }
    if ((String__size_get(prefix) != 0)) {
        (void)String__range_insert(value, 0, prefix, 0, String__size_get(prefix));
    }
    if (upper_case) {
        (void)String__upper_case(value);
    }
    return value;
}

void Integer__f_helper(
  Integer number,
  Integer radix,
  String value)
{
    Integer digit;
    digit = 0;
    if ((number < 0)) {

        digit = -((number%radix));
        number = -((number/radix));
        if (!((number >= 0))) {
            System__assert_fail((String)"\nEasy_C.ezc", 2266);
        }
        (void)Integer__f_helper(number, radix, value);
    } else if ((number >= radix)) {
        digit = (number%radix);
        (void)Integer__f_helper((number/radix), radix, value);
    } else {
        digit = number;
    }
    (void)String__character_append(value, String__fetch1(((String)"\0200123456789abcdef"), ((Unsigned)(digit))));
}

/* # {Logical} stuff: */
void Logical__erase(
  Logical number)
{
    /* do_nothing */;
}

String Logical__f(
  Logical logical)
{
    Logical decimal_format;
    String value;
    Unsigned size;
    Unsigned index;
    Character character;
    decimal_format = Logical__false;
    value = Format__field_next();
    size = String__size_get(value);
    index = 0;
    while ((index < size)) {
        character = String__fetch1(value, index);
        if ((character == ((Character)'d'))) {
            decimal_format = Logical__true;
        }
        index = (index+1);
    }
    (void)String__trim(value, 0);
    if (decimal_format) {
        if (logical) {
            (void)String__string_append(value, ((String)"\0011"));
        } else {
            (void)String__string_append(value, ((String)"\0010"));
        }
    } else {
        if (logical) {
            (void)String__string_append(value, ((String)"\004true"));
        } else {
            (void)String__string_append(value, ((String)"\005false"));
        }
    }
    return value;
}

/* # {Long_Integer} stuff: */
Integer Long_Integer__compare(
  Long_Integer number1,
  Long_Integer number2)
{
    Integer result;
    result = 0;
    if ((number1 < number2)) {
        result = -1;
    } else if ((number1 > number2)) {
        result = 1;
    }
    return result;
}

void Long_Integer__erase(
  Long_Integer number)
{
    /* do_nothing */;
}

String Long_Integer__f(
  Long_Integer number)
{
    Logical comma_separated;
    Character fill_character;
    Logical sign_force;
    Unsigned left_width;
    Long_Integer radix;
    Unsigned right_width;
    String prefix;
    Logical upper_case;
    String value;
    Unsigned size;
    Unsigned index;
    Unsigned constant;
    Character character;
    comma_separated = Logical__false;
    fill_character = ((Character)' ');
    sign_force = Logical__false;
    left_width = 0;
    radix = 10ll;
    right_width = 0;
    prefix = ((String)"\000");
    upper_case = Logical__false;
    value = Format__field_next();
    size = String__size_get(value);
    index = 0;
    constant = 0;
    while ((index < size)) {
        character = String__fetch1(value, index);
        if (Character__is_decimal_digit(character)) {

            constant = ((constant*10)+Character__decimal_convert(character));
        } else if ((character == ((Character)'\047'))) {

            if ((((index+2) < size)&&(String__fetch1(value, (index+2)) == ((Character)'\047')))) {
                constant = ((Unsigned)(String__fetch1(value, (index+1))));
                index = (index+2);
            }
        } else if ((character == ((Character)'c'))) {

            comma_separated = Logical__true;
        } else if ((character == ((Character)'d'))) {

            radix = 10ll;
        } else if ((character == ((Character)'h'))) {

            radix = 16ll;
        } else if ((character == ((Character)'f'))) {

            fill_character = ((Character)((constant&0xff)));
            constant = 0;
        } else if ((character == ((Character)'l'))) {

            left_width = constant;
            constant = 0;
        } else if ((character == ((Character)'o'))) {

            prefix = ((String)"\0010");
            radix = 8ll;
        } else if ((character == ((Character)'r'))) {

            right_width = constant;
            constant = 0;
        } else if ((character == ((Character)'s'))) {

            sign_force = Logical__true;
        } else if ((character == ((Character)'u'))) {

            upper_case = Logical__true;
        } else if ((character == ((Character)'x'))) {

            prefix = ((String)"\0020x");
            radix = 16ll;
        }
        /* # else */
        /* #    assert false@Logical */
        index = (index+1);
    }
    (void)String__trim(value, 0);
    if ((number < 0ll)) {
        number = -number;
        (void)String__character_append(value, ((Character)'-'));
    } else if (sign_force) {
        (void)String__character_append(value, ((Character)'+'));
    }
    (void)Long_Integer__f_helper(number, radix, value);
    if (comma_separated) {
        size = String__size_get(value);
        index = 3;
        while ((index < size)) {
            (void)String__character_insert(value, (size-index), ((Character)','));
            index = (index+3);
        }
    }
    if ((fill_character == ((Character)' '))) {
        (void)String__range_insert(value, 0, prefix, 0, String__size_get(prefix));
    }
    prefix = ((String)"\000");
    while ((String__size_get(value) < right_width)) {
        (void)String__character_prepend(value, fill_character);
    }
    while ((String__size_get(value) < left_width)) {
        (void)String__character_append(value, fill_character);
    }
    if ((String__size_get(prefix) != 0)) {
        (void)String__range_insert(value, 0, prefix, 0, String__size_get(prefix));
    }
    if (upper_case) {
        (void)String__upper_case(value);
    }
    return value;
}

void Long_Integer__f_helper(
  Long_Integer number,
  Long_Integer radix,
  String value)
{
    if (!((number >= 0ll))) {
        System__assert_fail((String)"\nEasy_C.ezc", 2571);
    }
    if ((number >= radix)) {
        (void)Long_Integer__f_helper((number/radix), radix, value);
        number = (number%radix);
    }
    (void)String__character_append(value, String__fetch1(((String)"\0200123456789abcdef"), ((Unsigned)(number))));
}

/* # {Long_Unsigned} stuff: */
Integer Long_Unsigned__compare(
  Long_Unsigned number1,
  Long_Unsigned number2)
{
    Integer result;
    result = 0;
    if ((number1 < number2)) {
        result = -1;
    } else if ((number1 > number2)) {
        result = 1;
    }
    return result;
}

void Long_Unsigned__erase(
  Long_Unsigned number)
{
    /* do_nothing */;
}

String Long_Unsigned__f(
  Long_Unsigned number)
{
    Logical comma_separated;
    Character fill_character;
    Logical sign_force;
    Unsigned left_width;
    Long_Unsigned radix;
    Unsigned right_width;
    String prefix;
    Logical upper_case;
    String value;
    Unsigned size;
    Unsigned index;
    Unsigned constant;
    Character character;
    comma_separated = Logical__false;
    fill_character = ((Character)' ');
    sign_force = Logical__false;
    left_width = 0;
    radix = 10ull;
    right_width = 0;
    prefix = ((String)"\000");
    upper_case = Logical__false;
    value = Format__field_next();
    size = String__size_get(value);
    index = 0;
    constant = 0;
    while ((index < size)) {
        character = String__fetch1(value, index);
        if (Character__is_decimal_digit(character)) {

            constant = ((constant*10)+Character__decimal_convert(character));
        } else if ((character == ((Character)'\047'))) {

            if ((((index+2) < size)&&(String__fetch1(value, (index+2)) == ((Character)'\047')))) {
                constant = ((Unsigned)(String__fetch1(value, (index+1))));
                index = (index+2);
            }
        } else if ((character == ((Character)'c'))) {

            comma_separated = Logical__true;
        } else if ((character == ((Character)'d'))) {

            radix = 10ull;
        } else if ((character == ((Character)'h'))) {

            radix = 16ull;
        } else if ((character == ((Character)'f'))) {

            fill_character = ((Character)((constant&0xff)));
            constant = 0;
        } else if ((character == ((Character)'l'))) {

            left_width = constant;
            constant = 0;
        } else if ((character == ((Character)'o'))) {

            prefix = ((String)"\0010");
            radix = 8ull;
        } else if ((character == ((Character)'r'))) {

            right_width = constant;
            constant = 0;
        } else if ((character == ((Character)'s'))) {

            sign_force = Logical__true;
        } else if ((character == ((Character)'u'))) {

            upper_case = Logical__true;
        } else if ((character == ((Character)'x'))) {

            prefix = ((String)"\0020x");
            radix = 16ull;
        }
        /* # else */
        /* #    assert false@Logical */
        index = (index+1);
    }
    (void)String__trim(value, 0);
    if ((number < 0ull)) {
        number = -number;
        (void)String__character_append(value, ((Character)'-'));
    } else if (sign_force) {
        (void)String__character_append(value, ((Character)'+'));
    }
    (void)Long_Unsigned__f_helper(number, radix, value);
    if (comma_separated) {
        size = String__size_get(value);
        index = 3;
        while ((index < size)) {
            (void)String__character_insert(value, (size-index), ((Character)','));
            index = (index+3);
        }
    }
    if ((fill_character == ((Character)' '))) {
        (void)String__range_insert(value, 0, prefix, 0, String__size_get(prefix));
    }
    prefix = ((String)"\000");
    while ((String__size_get(value) < right_width)) {
        (void)String__character_prepend(value, fill_character);
    }
    while ((String__size_get(value) < left_width)) {
        (void)String__character_append(value, fill_character);
    }
    if ((String__size_get(prefix) != 0)) {
        (void)String__range_insert(value, 0, prefix, 0, String__size_get(prefix));
    }
    if (upper_case) {
        (void)String__upper_case(value);
    }
    return value;
}

void Long_Unsigned__f_helper(
  Long_Unsigned number,
  Long_Unsigned radix,
  String value)
{
    if (!((number >= 0ull))) {
        System__assert_fail((String)"\nEasy_C.ezc", 2807);
    }
    if ((number >= radix)) {
        (void)Long_Unsigned__f_helper((number/radix), radix, value);
        number = (number%radix);
    }
    (void)String__character_append(value, String__fetch1(((String)"\0200123456789abcdef"), ((Unsigned)(number))));
}

/* # {Out_Stream} stuff: */
void Out_Stream__big_endian_short_put(
  Out_Stream out_stream,
  Unsigned short_value)
{
    (void)Out_Stream__byte_put(out_stream, (((short_value>>8))&0xff));
    (void)Out_Stream__byte_put(out_stream, (short_value&0xff));
}

void Out_Stream__byte_put(
  Out_Stream out_stream,
  Unsigned byte_value)
{
    (void)Character__put(((Character)(byte_value)), out_stream);
}

void Out_Stream__little_endian_short_put(
  Out_Stream out_stream,
  Unsigned short_value)
{
    (void)Out_Stream__byte_put(out_stream, (short_value&0xff));
    (void)Out_Stream__byte_put(out_stream, (((short_value>>8))&0xff));
}

void Out_Stream__erase(
  Out_Stream in_stream)
{
    /* do_nothing */;
}

/* # {Short} stuff: */
String Short__f(
  Short number)
{
    return Integer__f(((Integer)(number)));
}

/* # {String} stuff: */
void String__buffer_append(
  String string,
  String buffer)
{
    (void)String__string_append(buffer, string);
}

void String__c_character_append(
  String string,
  Character character)
{
    Logical backslash_or_quote;
    backslash_or_quote = ((character == ((Character)'\134'))||(character == ((Character)'"'))||(character == ((Character)'\047')));
    if ((Character__is_printing(character)&&!backslash_or_quote)) {
        (void)String__character_append(string, character);
    } else {
        (void)String__character_append(string, ((Character)'\134'));
        if (backslash_or_quote) {
            (void)String__character_append(string, character);
        } else if ((character == ((Character)'\012'))) {
            (void)String__character_append(string, ((Character)'n'));
        } else if ((character == ((Character)'\011'))) {
            (void)String__character_append(string, ((Character)'t'));
        } else if ((character == ((Character)'\015'))) {
            (void)String__character_append(string, ((Character)'r'));
        } else {
            (void)Unsigned__f_helper(((Unsigned)(character)), 8, string);
        }
    }
}

void String__character_append(
  String string,
  Character character)
{
    Unsigned size;
    size = String__size_get(string);
    (void)String__range_nulls_insert(string, size, 1);
    String__store1(string, size, character);
}

void String__character_delete(
  String string,
  Unsigned offset)
{
    if (!((offset < String__size_get(string)))) {
        System__assert_fail((String)"\nEasy_C.ezc", 3115);
    }
    (void)String__range_delete(string, offset, 1);
}

void String__character_insert(
  String string,
  Unsigned offset,
  Character character)
{
    (void)String__range_nulls_insert(string, offset, 1);
    String__store1(string, offset, character);
}

void String__character_gap_insert(
  String string,
  Character character)
{
    Unsigned offset;
    offset = String__front_size_get(string);
    (void)String__range_nulls_insert(string, offset, 1);
    String__store1(string, offset, character);
    (void)String__gap_set(string, (offset+1));
}

void String__character_prepend(
  String string,
  Character character)
{
    (void)String__character_insert(string, 0, character);
}

Integer String__compare(
  String string1,
  String string2)
{
    return String__range_compare(string1, 0, String__size_get(string1), string2, 0, String__size_get(string2));
}

void String__d(
  String string)
{
    Unsigned size;
    Unsigned index;
    size = String__size_get(string);
    index = 0;
    while ((index < size)) {
        (void)Character__put(String__fetch1(string, index), Out_Stream__error);
        index = (index+1);
    }
}

String String__divide(
  String left,
  String right)
{
    Format format;
    Array frames;
    Unsigned frames_size;
    Format_Frame frame;
    String result;
    Array fields;
    Unsigned size;
    Unsigned index;
    Format_Field field;
    String temporary;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    format = Format__one_and_only();
    frames = format->frames;
    frames_size = Array__size_get(frames);
    if (!((frames_size != 0))) {
        System__assert_fail((String)"\nEasy_C.ezc", 3204);
    }
    frame = ((Format_Frame)Array__fetch1(frames, (frames_size-1)));
    result = frame->result;
    (void)String__trim(result, 0);
    fields = frame->fields;
    size = Array__size_get(fields);
    index = 0;
    while ((index < size)) {
        field = ((Format_Field)Array__fetch1(fields, index));
        (void)String__string_append(result, field->before);
        (void)String__string_append(result, field->value);
        index = (index+1);
    }
    (void)Format__frame_release(format, frame);
    if ((Array__size_get(format->frames) == 0)) {
        temporary = String__new();
        if ((Array__size_get(format->available_frames) != format->frame_count)) {
            (void)String__d((t__2 = String__form(((String)"\013%d% != %d%\n")), t__3 = Unsigned__f(Array__size_get(format->available_frames)), String__divide(String__remainder((t__2), t__3), Unsigned__f(format->frame_count))));
            if (!(Logical__false)) {
                System__assert_fail((String)"\nEasy_C.ezc", 3227);
            }
        }
        if (!((Array__size_get(format->available_fields) == format->field_count))) {
            System__assert_fail((String)"\nEasy_C.ezc", 3228);
        }
    }
    return result;
}

Logical String__equal(
  String string1,
  String string2)
{
    return (String__compare(string1, string2) == Integer__zero);
}

String String__f(
  String string)
{
    Logical lower_mode;
    Logical upper_mode;
    Logical c_keyword_mode;
    Logical c_mode;
    Logical ezc_string;
    Logical visual_mode;
    String value;
    Unsigned size;
    Logical white_space_mode;
    Unsigned index;
    Character mode_character;
    Logical c_keyword;
    Logical in_white_space;
    Logical backslash_mode;
    Character character;
    String t__0;
    String t__1;
    lower_mode = 0;
    upper_mode = 0;
    c_keyword_mode = 0;
    c_mode = 0;
    ezc_string = 0;
    visual_mode = 0;
    value = Format__field_next();
    size = String__size_get(value);
    white_space_mode = 0;
    index = 0;
    while ((index < size)) {
        mode_character = String__fetch1(value, index);
        if ((mode_character == ((Character)'a'))) {
            c_mode = 1;
        } else if ((mode_character == ((Character)'e'))) {
            ezc_string = 1;
        } else if ((mode_character == ((Character)'k'))) {
            c_keyword_mode = 1;
        } else if ((mode_character == ((Character)'l'))) {
            lower_mode = 1;
        } else if ((mode_character == ((Character)'u'))) {
            upper_mode = 1;
        } else if ((mode_character == ((Character)'v'))) {
            visual_mode = 1;
        } else if ((mode_character == ((Character)'w'))) {
            white_space_mode = 1;
        }
        index = (index+1);
    }
    (void)String__trim(value, 0);
    c_keyword = 0;
    if (c_keyword_mode) {
        if (lower_mode) {
            c_keyword = String__is_c_keyword((t__1 = String__form(((String)"\003%l%")), String__divide((t__1), String__f(string))));
        } else {
            c_keyword = String__is_c_keyword(string);
        }
    }
    if ((ezc_string||c_mode||visual_mode)) {
        (void)String__character_append(value, ((Character)'"'));
    }
    if (ezc_string) {
        (void)String__c_character_append(value, ((Character)(String__size_get(string))));
    }
    in_white_space = 0;
    backslash_mode = 0;
    size = String__size_get(string);
    index = 0;
    while ((index < size)) {
        character = String__fetch1(string, index);
        if (lower_mode) {
            character = Character__lower_case(character);
        } else if (upper_mode) {
            character = Character__upper_case(character);
        }
        if ((white_space_mode&&((Character__is_white_space(character)||(character == ((Character)'\012')))))) {
            character = ((Character)' ');
        }
        if (c_mode) {
            (void)String__c_character_append(value, character);
        } else if (visual_mode) {
            backslash_mode = String__visual_character_append(value, backslash_mode, character);
        } else if (white_space_mode) {
            if ((character == ((Character)' '))) {
                if (!in_white_space) {
                    (void)String__character_append(value, ((Character)' '));
                    in_white_space = 1;
                }
            } else {
                in_white_space = 0;
                (void)String__character_append(value, character);
            }
        } else {
            (void)String__character_append(value, character);
        }
        index = (index+1);
    }
    if (backslash_mode) {
        (void)String__character_append(value, ((Character)'\134'));
    }
    if ((ezc_string||c_mode||visual_mode)) {
        (void)String__character_append(value, ((Character)'"'));
    }
    if (c_keyword) {
        (void)String__string_append(value, ((String)"\004___k"));
    }
    return value;
}

void String__flush(
  String buffer,
  Out_Stream out_stream)
{
    (void)String__put(buffer, out_stream);
    (void)Out_Stream__flush(out_stream);
    (void)String__trim(buffer, 0);
}

String String__form(
  String text)
{
    Format format;
    Format_Frame frame;
    Unsigned size;
    Unsigned index;
    Format_Field field;
    String before;
    Character character;
    String control;
    format = Format__one_and_only();
    frame = Format__frame_allocate(format);
    size = String__size_get(text);
    index = 0;
    while ((index < size)) {
        field = Format__field_allocate(format);
        (void)Array__append(frame->fields, ((void *)(field)));
        /* # Grab a filler: */
        before = field->before;
        while ((index < size)) {
            character = String__fetch1(text, index);
            if ((character == ((Character)'%'))) {
                if ((((index+1) < size)&&(String__fetch1(text, (index+1)) == ((Character)'%')))) {

                    index = (index+1);
                } else {
                    break;
                }
            }
            (void)String__character_append(before, character);
            index = (index+1);
        }
        /* # Grab a field: */
        control = field->control;
        if ((index < size)) {
            character = String__fetch1(text, index);
            if ((character == ((Character)'%'))) {
                (void)String__character_append(control, ((Character)'%'));
                index = (index+1);
                while ((index < size)) {
                    character = String__fetch1(text, index);
                    (void)String__character_append(control, character);
                    index = (index+1);
                    if ((character == ((Character)'%'))) {
                        break;
                    }
                }
            }
        }
    }
    return text;
}

Unsigned String__format_begin(
  String buffer)
{
    Logical found;
    Unsigned size;
    Unsigned anchor;
    Unsigned index;
    Character character;
    found = Logical__false;
    size = String__size_get(buffer);
    anchor = size;
    index = String__front_size_get(buffer);
    while (((index < size)&&!found)) {
        character = String__fetch1(buffer, index);
        if ((character == ((Character)'%'))) {

            anchor = index;
            index = (index+1);
            if ((index < size)) {
                character = String__fetch1(buffer, index);
                if ((character == ((Character)'%'))) {

                    (void)String__character_delete(buffer, index);
                    size = (size-1);
                    anchor = size;
                } else {

                    /* # Look for the closing "%": */
                    while (((index < size)&&!found)) {
                        character = String__fetch1(buffer, index);
                        if ((character == ((Character)'%'))) {
                            found = Logical__true;
                        }
                        index = (index+1);
                    }
                }
            }
        } else {
            index = (index+1);
        }
    }
    if (!found) {
        anchor = size;
    }
    (void)String__gap_set(buffer, anchor);
    return anchor;
}

void String__format_end(
  String buffer,
  Unsigned anchor)
{
    Unsigned size;
    Unsigned front;
    Unsigned index;
    size = String__size_get(buffer);
    front = String__front_size_get(buffer);
    index = front;
    if ((String__fetch1(buffer, index) == ((Character)'%'))) {

        anchor = index;
        index = (index+1);
        while (((index < size)&&(String__fetch1(buffer, index) != ((Character)'%')))) {
            index = (index+1);
        }
        if ((String__fetch1(buffer, index) == ((Character)'%'))) {
            index = (index+1);
            (void)String__range_delete(buffer, anchor, (index-front));
        }
    }
}

void String__format_prepare(
  String buffer,
  String format)
{
    (void)String__trim(buffer, 0);
    (void)String__string_append(buffer, format);
    (void)String__gap_set(buffer, 0);
}

Unsigned String__hash(
  String string)
{
    Unsigned hash;
    Unsigned size;
    Unsigned index;
    hash = 0;
    size = String__size_get(string);
    index = 0;
    while ((index < size)) {
        hash = (hash+((Unsigned)(String__fetch1(string, index))));
        index = (index+1);
    }
    return hash;
}

Integer String__integer_convert(
  String string)
{
    Unsigned number;
    Unsigned size;
    Unsigned index;
    Logical negative;
    Integer result;
    number = 0;
    size = String__size_get(string);
    index = 0;
    negative = Logical__false;
    if ((String__fetch1(string, 0) == ((Character)'-'))) {
        negative = Logical__true;
        index = 1;
    }
    while ((index < size)) {
        number = ((number*10)+Character__decimal_convert(String__fetch1(string, index)));
        index = (index+1);
    }
    result = ((Integer)(number));
    if (negative) {
        result = -result;
    }
    return result;
}

Logical String__is_c_keyword(
  String string)
{
    Logical result;
    Character character;
    Unsigned code;
    result = Logical__false;
    if ((String__size_get(string) != 0)) {
        character = String__fetch1(string, 0);
        code = ((Unsigned)(character));
        /* # 'a' = 97 */
        /* # 'b' = 98 */
        /* # 'c' = 99 */
        /* # 'd' = 100 */
        /* # 'e' = 101 */
        /* # 'f' = 102 */
        /* # 'g' = 103 */
        /* # 'i' = 105 */
        /* # 'l' = 108 */
        /* # 'm' = 109 */
        /* # 't' = 116 */
        /* # 'r' = 114 */
        /* # 's' = 115 */
        /* # 't' = 116 */
        /* # 'u' = 117 */
        /* # 'v' = 118 */
        /* # 'w' = 119 */
        if (((97 <= code)&&(code <= 119))) {

            if ((code <= 108)) {

                if ((code <= 101)) {

                    if ((code == 97)) {

                        result = (String__equal(string, ((String)"\003asm"))||String__equal(string, ((String)"\004auto")));
                    } else if ((code == 98)) {

                        result = String__equal(string, ((String)"\005break"));
                    } else if ((code == 99)) {

                        result = (String__equal(string, ((String)"\004case"))||String__equal(string, ((String)"\004char"))||String__equal(string, ((String)"\005const"))||String__equal(string, ((String)"\010continue")));
                    } else if ((code == 100)) {

                        result = (String__equal(string, ((String)"\007default"))||String__equal(string, ((String)"\002do"))||String__equal(string, ((String)"\006double")));
                    } else {

                        result = (String__equal(string, ((String)"\004else"))||String__equal(string, ((String)"\004enum"))||String__equal(string, ((String)"\006extern")));
                    }
                } else {

                    if ((code == 102)) {

                        result = (String__equal(string, ((String)"\005float"))||String__equal(string, ((String)"\003for")));
                    } else if ((code == 103)) {

                        result = String__equal(string, ((String)"\004goto"));
                    } else if ((code == 105)) {

                        result = (String__equal(string, ((String)"\002if"))||String__equal(string, ((String)"\006inline"))||String__equal(string, ((String)"\003int")));
                    } else if ((code == 108)) {

                        result = String__equal(string, ((String)"\004long"));
                    }
                }
            } else {

                if ((code <= 116)) {

                    if ((code == 114)) {

                        result = (String__equal(string, ((String)"\010register"))||String__equal(string, ((String)"\006return"))||String__equal(string, ((String)"\010restrict")));
                    } else if ((code == 115)) {

                        result = (String__equal(string, ((String)"\005short"))||String__equal(string, ((String)"\006signed"))||String__equal(string, ((String)"\006sizeof"))||String__equal(string, ((String)"\006static"))||String__equal(string, ((String)"\006struct"))||String__equal(string, ((String)"\006switch")));
                    } else if ((code == 116)) {

                        result = (String__equal(string, ((String)"\006typeof"))||String__equal(string, ((String)"\007typedef")));
                    }
                } else {

                    if ((code == 117)) {

                        result = (String__equal(string, ((String)"\005union"))||String__equal(string, ((String)"\010unsigned")));
                    } else if ((code == 118)) {

                        result = (String__equal(string, ((String)"\004void"))||String__equal(string, ((String)"\010volitile")));
                    } else {

                        result = String__equal(string, ((String)"\005while"));
                    }
                }
            }
        }
    }
    return result;
}

Character String__lop(
  String string)
{
    Character character;
    character = String__fetch1(string, 0);
    (void)String__range_delete(string, 0, 1);
    return character;
}

void String__lower_case(
  String string)
{
    Unsigned size;
    Unsigned index;
    size = String__size_get(string);
    index = 0;
    while ((index < size)) {
        String__store1(string, index, Character__lower_case(String__fetch1(string, index)));
        index = (index+1);
    }
}

void String__lower_case_append(
  String to_string,
  String from_string)
{
    Unsigned size;
    Unsigned index;
    if ((to_string == String__null)) {
        to_string = String__new();
    }
    size = String__size_get(from_string);
    index = 0;
    while ((index < size)) {
        (void)String__character_append(to_string, Character__lower_case(String__fetch1(from_string, index)));
        index = (index+1);
    }
}

void String__p(
  String string)
{
    Unsigned size;
    Unsigned index;
    size = String__size_get(string);
    index = 0;
    while ((index < size)) {
        (void)Character__put(String__fetch1(string, index), Out_Stream__standard);
        index = (index+1);
    }
}

Unsigned String__partial_match(
  String string,
  String pattern)
{
    Unsigned pattern_size;
    Unsigned string_size;
    Unsigned index;
    Character string_character;
    Character pattern_character;
    pattern_size = String__size_get(pattern);
    string_size = String__size_get(string);
    index = 0;
    while (((index < pattern_size)&&(index < string_size))) {
        string_character = String__fetch1(string, index);
        pattern_character = String__fetch1(pattern, index);
        if ((string_character != pattern_character)) {
            break;
        }
        index = (index+1);
    }
    return index;
}

void String__put(
  String string,
  Out_Stream out_stream)
{
    Unsigned size;
    Unsigned index;
    size = String__size_get(string);
    index = 0;
    while ((index < size)) {
        (void)Character__put(String__fetch1(string, index), out_stream);
        index = (index+1);
    }
}

void String__range_append(
  String to_string,
  String from_string,
  Unsigned from_offset,
  Unsigned count)
{
    Unsigned to_size;
    to_size = String__size_get(to_string);
    (void)String__range_nulls_insert(to_string, to_size, count);
    (void)String__range_copy(to_string, to_size, from_string, from_offset, count);
}

Integer String__range_compare(
  String string1,
  Unsigned offset1,
  Unsigned count1,
  String string2,
  Unsigned offset2,
  Unsigned count2)
{
    Integer result;
    Unsigned index;
    result = Integer__zero;
    index = 0;
    while (((result == Integer__zero)&&(count1 != 0)&&(count2 != 0))) {
        result = Character__compare(String__fetch1(string1, offset1), String__fetch1(string2, offset2));
        offset1 = (offset1+1);
        offset2 = (offset2+1);
        count1 = (count1-1);
        count2 = (count2-1);
    }
    if ((result == Integer__zero)) {
        if ((count1 != 0)) {
            result = Integer__one;
        } else if ((count2 != 0)) {
            result = Integer__negative_one;
        }
    }
    return result;
}

void String__range_copy(
  String to_string,
  Unsigned to_offset,
  String from_string,
  Unsigned from_offset,
  Unsigned count)
{
    while ((count != 0)) {
        String__store1(to_string, to_offset, String__fetch1(from_string, from_offset));
        count = (count-1);
        to_offset = (to_offset+1);
        from_offset = (from_offset+1);
    }
}

Logical String__range_equal(
  String string1,
  Unsigned offset1,
  Unsigned count1,
  String string2,
  Unsigned offset2,
  Unsigned count2)
{
    return (String__range_compare(string1, offset1, count1, string2, offset2, count2) == 0);
}

void String__range_insert(
  String to_string,
  Unsigned to_offset,
  String from_string,
  Unsigned from_offset,
  Unsigned count)
{
    (void)String__range_nulls_insert(to_string, to_offset, count);
    (void)String__range_copy(to_string, to_offset, from_string, from_offset, count);
}

String String__remainder(
  String left,
  String right)
{
    return left;
}

void String__string_append(
  String to_string,
  String from_string)
{
    Unsigned from_size;
    Unsigned to_size;
    from_size = String__size_get(from_string);
    to_size = String__size_get(to_string);
    (void)String__range_nulls_insert(to_string, to_size, from_size);
    (void)String__range_copy(to_string, to_size, from_string, 0, from_size);
}

void String__string_gap_insert(
  String to_string,
  String from_string)
{
    Unsigned offset;
    Unsigned size;
    offset = String__front_size_get(to_string);
    size = String__size_get(from_string);
    (void)String__range_nulls_insert(to_string, offset, size);
    (void)String__range_copy(to_string, offset, from_string, 0, size);
    (void)String__gap_set(to_string, (offset+size));
}

void String__string_insert(
  String to_string,
  Unsigned to_offset,
  String from_string)
{
    Unsigned from_size;
    Unsigned to_size;
    from_size = String__size_get(from_string);
    to_size = String__size_get(to_string);
    (void)String__range_nulls_insert(to_string, to_offset, from_size);
    (void)String__range_copy(to_string, to_offset, from_string, 0, from_size);
}

void String__string_prepend(
  String to_string,
  String from_string)
{
    (void)String__string_insert(to_string, 0, from_string);
}

Logical String__suffix_match(
  String suffix,
  String full)
{
    Unsigned suffix_size;
    Unsigned full_size;
    Logical result;
    suffix_size = String__size_get(suffix);
    full_size = String__size_get(full);
    result = 0;
    if ((suffix_size < full_size)) {
        result = String__range_equal(full, (full_size-suffix_size), suffix_size, suffix, 0, suffix_size);
    }
    return result;
}

void String__trim(
  String string,
  Unsigned new_size)
{
    Unsigned size;
    size = String__size_get(string);
    if ((new_size < size)) {
        if ((new_size == 0)) {
            (void)String__erase(string);
        } else {
            (void)String__range_delete(string, new_size, (size-new_size));
        }
    }
}

void String__upper_case(
  String string)
{
    Unsigned size;
    Unsigned index;
    size = String__size_get(string);
    index = 0;
    while ((index < size)) {
        String__store1(string, index, Character__upper_case(String__fetch1(string, index)));
        index = (index+1);
    }
}

void String__upper_case_append(
  String to_string,
  String from_string)
{
    Unsigned size;
    Unsigned index;
    if ((to_string == String__null)) {
        to_string = String__new();
    }
    size = String__size_get(from_string);
    index = 0;
    while ((index < size)) {
        (void)String__character_append(to_string, Character__upper_case(String__fetch1(from_string, index)));
        index = (index+1);
    }
}

Unsigned String__unsigned_convert(
  String string)
{
    Unsigned size;
    Unsigned index;
    Character character;
    Unsigned radix;
    Unsigned number;
    Unsigned digit;
    size = String__size_get(string);
    index = 0;
    while ((index < size)) {
        character = String__fetch1(string, index);
        if (((character != ((Character)' '))&&(character != ((Character)'\011')))) {
            break;
        }
        index = (index+1);
    }
    radix = 10;
    if ((((index+2) <= size)&&(String__fetch1(string, index) == ((Character)'0')))) {
        character = String__fetch1(string, (index+1));
        if (((character == ((Character)'x'))||(character == ((Character)'X')))) {
            radix = 16;
            index = (index+2);
        }
    }
    number = 0;
    while ((index < size)) {
        character = String__fetch1(string, index);
        digit = 0;
        if (((((Character)'0') <= character)&&(character <= ((Character)'9')))) {
            digit = ((Unsigned)((character-((Character)'0'))));
        } else if (((((Character)'a') <= character)&&(character <= ((Character)'f')))) {
            digit = (((Unsigned)((character-((Character)'a'))))+10);
        } else if (((((Character)'A') <= character)&&(character <= ((Character)'F')))) {
            digit = (((Unsigned)((character-((Character)'A'))))+10);
        } else {
            break;
        }
        number = ((number*radix)+digit);
        index = (index+1);
    }
    return number;
}

Logical String__visual_character_append(
  String string,
  Logical backslash_mode,
  Character character)
{
    Logical backslash_or_quote;
    backslash_or_quote = ((character == ((Character)'\134'))||(character == ((Character)'"'))||(character == ((Character)'\047')));
    if ((Character__is_printing(character)&&!backslash_or_quote)) {
        if (backslash_mode) {
            backslash_mode = Logical__false;
            (void)String__character_append(string, ((Character)'\134'));
        }
        (void)String__character_append(string, character);
    } else {
        if (backslash_mode) {
            (void)String__character_append(string, ((Character)','));
        } else {
            backslash_mode = Logical__true;
            (void)String__character_append(string, ((Character)'\134'));
        }
        if ((character == ((Character)'\134'))) {
            (void)String__string_append(string, ((String)"\003bsl"));
        } else if ((character == ((Character)'\047'))) {
            (void)String__string_append(string, ((String)"\002sq"));
        } else if ((character == ((Character)'"'))) {
            (void)String__string_append(string, ((String)"\002dq"));
        } else if ((character == ((Character)'\012'))) {
            (void)String__character_append(string, ((Character)'n'));
        } else if ((character == ((Character)'\011'))) {
            (void)String__character_append(string, ((Character)'t'));
        } else if ((character == ((Character)'\015'))) {
            (void)String__string_append(string, ((String)"\002cr"));
        } else {
            (void)Unsigned__f_helper(((Unsigned)(character)), 10, string);
        }
    }
    return backslash_mode;
}

String String__word_lop(
  String string,
  String word)
{
    Character character;
    if ((word == String__null)) {
        word = String__new();
    } else {
        (void)String__trim(word, 0);
    }
    while ((String__size_get(string) != 0)) {
        character = String__fetch1(string, 0);
        if (Character__is_white_space(character)) {
            break;
        } else {
            (void)String__lop(string);
            (void)String__character_append(word, character);
        }
    }
    return word;
}

void String__white_space_lop(
  String string,
  String white_space)
{
    Character character;
    if ((white_space != String__null)) {
        (void)String__trim(white_space, 0);
    }
    while ((String__size_get(string) != 0)) {
        character = String__fetch1(string, 0);
        if (Character__is_white_space(character)) {
            (void)String__lop(string);
            if ((white_space != String__null)) {
                (void)String__character_append(white_space, character);
            }
        } else {
            break;
        }
    }
}

String String__writable_copy(
  String string)
{
    String result;
    result = String__new();
    (void)String__string_append(result, string);
    return result;
}

/* # {System} stuff: */
String System__current_working_directory(
  String file_name_buffer)
{
    if (!(Logical__false)) {
        System__assert_fail((String)"\nEasy_C.ezc", 4291);
    }
    return ((String)"\000");
}

String System__executable_directory(
  String file_name_buffer)
{
    if (!(Logical__false)) {
        System__assert_fail((String)"\nEasy_C.ezc", 4304);
    }
    return ((String)"\000");
}

void System__assert_fail(
  String file_name,
  Unsigned line_number)
{
    (void)System__fail(((String)"\011Assertion"), file_name, line_number);
}

void System__fail(
  String kind,
  String file_name,
  Unsigned line_number)
{
    System system;
    Out_Stream error_stream;
    system = System__null;
    if (system->fail_routine_present) {
        (void)system->fail_routine(kind, file_name, line_number);
    }
    error_stream = Out_Stream__error;
    (void)String__put(kind, error_stream);
    (void)String__put(((String)"\015 failure in '"), error_stream);
    (void)String__put(file_name, error_stream);
    (void)String__put(((String)"\012' at line "), error_stream);
    (void)Unsigned__decimal_put(line_number, error_stream);
    (void)String__put(((String)"\001\n"), error_stream);
    (void)Out_Stream__flush(error_stream);
    (void)System__abort();
}

void System__fail_routine_set(
  void (*fail_routine)(String, String, Unsigned))
{
    System system;
    system = System__null;
    system->fail_routine = fail_routine;
    system->fail_routine_present = Logical__true;
}

String System__file_real_path(
  String original_file_name,
  String new_file_name)
{
    if (!(Logical__false)) {
        System__assert_fail((String)"\nEasy_C.ezc", 4378);
    }
    return ((String)"\000");
}

Unsigned System__variant_scalar_fail(
  String file_name,
  Unsigned line_number)
{
    (void)System__fail(((String)"\007Variant"), file_name, line_number);
    return 0;
}

System System__variant_object_fail(
  String file_name,
  Unsigned line_number)
{
    (void)System__fail(((String)"\007Variant"), file_name, line_number);
    return System__null;
}

System System__one_and_only(void)
{
    return System__null;
}

void System__reset(
  System system)
{
    (void)In_Stream__Initialize();
    (void)Out_Stream__Initialize();
    system->error_out_stream = Out_Stream__error;
    system->standard_out_stream = Out_Stream__standard;
    system->standard_in_stream = In_Stream__standard;
}

/* # {System_Jump_Buffer}: */
/* # {Unsigned} stuff: */
void Unsigned__buffer_append(
  Unsigned number,
  String buffer)
{
    if ((number >= 10)) {
        (void)Unsigned__buffer_append((number/10), buffer);
    }
    (void)String__character_append(buffer, String__fetch1(((String)"\0120123456789"), (number%10)));
}

Integer Unsigned__compare(
  Unsigned number1,
  Unsigned number2)
{
    Integer result;
    result = 0;
    if ((number1 < number2)) {
        result = -1;
    } else if ((number1 > number2)) {
        result = 1;
    }
    return result;
}

void Unsigned__decimal_put(
  Unsigned number,
  Out_Stream out_stream)
{
    if ((number >= 10)) {
        (void)Unsigned__decimal_put((number/10), out_stream);
    }
    (void)Character__put(String__fetch1(((String)"\0120123456789"), (number%10)), out_stream);
}

void Unsigned__erase(
  Unsigned number)
{
    /* do_nothing */;
}

String Unsigned__f(
  Unsigned number)
{
    Logical comma_separated;
    Character fill_character;
    Unsigned left_width;
    Unsigned radix;
    Unsigned right_width;
    Logical pad;
    String prefix;
    Logical upper_case;
    String value;
    Unsigned size;
    Unsigned index;
    Unsigned constant;
    Character character;
    comma_separated = Logical__false;
    fill_character = ((Character)' ');
    left_width = 0;
    radix = 10;
    right_width = 0;
    pad = Logical__false;
    prefix = ((String)"\000");
    upper_case = Logical__false;
    value = Format__field_next();
    size = String__size_get(value);
    index = 0;
    constant = 0;
    while ((index < size)) {
        character = String__fetch1(value, index);
        if (Character__is_decimal_digit(character)) {

            constant = ((constant*10)+Character__decimal_convert(character));
        } else if ((character == ((Character)'\047'))) {

            if ((((index+2) < size)&&(String__fetch1(value, (index+2)) == ((Character)'\047')))) {
                constant = ((Unsigned)(String__fetch1(value, (index+1))));
                index = (index+2);
            }
        } else if ((character == ((Character)'c'))) {

            comma_separated = Logical__true;
        } else if ((character == ((Character)'d'))) {

            radix = 10;
        } else if ((character == ((Character)'h'))) {

            radix = 16;
        } else if ((character == ((Character)'f'))) {

            fill_character = ((Character)((constant&0xff)));
            constant = 0;
        } else if ((character == ((Character)'l'))) {

            left_width = constant;
            constant = 0;
        } else if ((character == ((Character)'o'))) {

            prefix = ((String)"\0010");
            radix = 8;
        } else if ((character == ((Character)'p'))) {

            pad = Logical__true;
            number = (number&0xff);
        } else if ((character == ((Character)'r'))) {

            right_width = constant;
            constant = 0;
        } else if ((character == ((Character)'u'))) {

            upper_case = Logical__true;
        } else if ((character == ((Character)'x'))) {

            prefix = ((String)"\0020x");
            radix = 16;
        } else if ((character == ((Character)'y'))) {

            radix = 16;
        }
        /* # else */
        /* #    assert false@Logical */
        index = (index+1);
    }
    (void)String__trim(value, 0);
    if (pad) {
        while ((number != 0)) {
            (void)String__character_append(value, ((Character)' '));
            number = (number-1);
        }
    } else {
        (void)Unsigned__f_helper(number, radix, value);
        if (comma_separated) {
            size = String__size_get(value);
            index = 3;
            while ((index < size)) {
                (void)String__character_insert(value, (size-index), ((Character)','));
                index = (index+3);
            }
        }
        if ((fill_character == ((Character)' '))) {
            (void)String__range_insert(value, 0, prefix, 0, String__size_get(prefix));
            prefix = ((String)"\000");
        }
        while ((String__size_get(value) < right_width)) {
            (void)String__character_prepend(value, fill_character);
        }
        while ((String__size_get(value) < left_width)) {
            (void)String__character_append(value, fill_character);
        }
        if ((String__size_get(prefix) != 0)) {
            (void)String__range_insert(value, 0, prefix, 0, String__size_get(prefix));
        }
        if (upper_case) {
            (void)String__upper_case(value);
        }
    }
    return value;
}

Unsigned Unsigned__hash(
  Unsigned hash)
{
    return hash;
}

void Unsigned__f_helper(
  Unsigned number,
  Unsigned radix,
  String value)
{
    if ((number >= radix)) {
        (void)Unsigned__f_helper((number/radix), radix, value);
        number = (number%radix);
    }
    (void)String__character_append(value, String__fetch1(((String)"\0200123456789abcdef"), number));
}








/* {Array} stuff: */

/* {Byte} stuff: */

/* {Character} stuff: */

/* {Double} stuff: */

/* {Easy_C} stuff: */

/* {Float} stuff: */

/* {Format} stuff: */

struct Format__Struct Format__Initial = {
    0,
    (Array)0,
    (Array)0,
    (Array)0,
    0,
    0,
};

Format Format__null = &Format__Initial;
void Format__erase(
  Format format)
{
    format->initialized = 0;
    if (format->available_fields == 0) {
	format->available_fields = Array__new();
    } else {
	Array__erase(format->available_fields);
    }
    if (format->available_frames == 0) {
	format->available_frames = Array__new();
    } else {
	Array__erase(format->available_frames);
    }
    if (format->frames == 0) {
	format->frames = Array__new();
    } else {
	Array__erase(format->frames);
    }
    format->frame_count = 0;
    format->field_count = 0;
}

Format Format__new(void)
{
    Format format;
    extern void *malloc(unsigned int);

    format = (Format)malloc(sizeof(*format));
    format->initialized = Logical__null;
    format->available_fields = Array__new();
    format->available_frames = Array__new();
    format->frames = Array__new();
    format->frame_count = Unsigned__null;
    format->field_count = Unsigned__null;
    return format;
}

void Format__Initialize(void)
{
    Format__erase(Format__null);
}

/* {Format_Frame} stuff: */

struct Format_Frame__Struct Format_Frame__Initial = {
    (Array)0,
    0,
    &String__Initial,
};

Format_Frame Format_Frame__null = &Format_Frame__Initial;
void Format_Frame__erase(
  Format_Frame format_frame)
{
    if (format_frame->fields == 0) {
	format_frame->fields = Array__new();
    } else {
	Array__erase(format_frame->fields);
    }
    format_frame->index = 0;
    format_frame->result = String__null;
}

Format_Frame Format_Frame__new(void)
{
    Format_Frame format_frame;
    extern void *malloc(unsigned int);

    format_frame = (Format_Frame)malloc(sizeof(*format_frame));
    format_frame->fields = Array__new();
    format_frame->index = Unsigned__null;
    format_frame->result = String__null;
    return format_frame;
}

void Format_Frame__Initialize(void)
{
    Format_Frame__erase(Format_Frame__null);
}

/* {Format_Field} stuff: */

struct Format_Field__Struct Format_Field__Initial = {
    &String__Initial,
    &String__Initial,
    &String__Initial,
};

Format_Field Format_Field__null = &Format_Field__Initial;
void Format_Field__erase(
  Format_Field format_field)
{
    format_field->before = String__null;
    format_field->control = String__null;
    format_field->value = String__null;
}

Format_Field Format_Field__new(void)
{
    Format_Field format_field;
    extern void *malloc(unsigned int);

    format_field = (Format_Field)malloc(sizeof(*format_field));
    format_field->before = String__null;
    format_field->control = String__null;
    format_field->value = String__null;
    return format_field;
}

void Format_Field__Initialize(void)
{
    Format_Field__erase(Format_Field__null);
}

/* {Hash_Table_Pair} stuff: */

struct Hash_Table_Pair__Struct Hash_Table_Pair__Initial = {
    0,
    0,
    0,
};

Hash_Table_Pair Hash_Table_Pair__null = &Hash_Table_Pair__Initial;
void Hash_Table_Pair__erase(
  Hash_Table_Pair hash_table_pair)
{
    /* key (type Key) is parameterized */    /* value (type Value) is parameterized */    hash_table_pair->hash = 0;
}

Hash_Table_Pair Hash_Table_Pair__new(void)
{
    Hash_Table_Pair hash_table_pair;
    extern void *malloc(unsigned int);

    hash_table_pair = (Hash_Table_Pair)malloc(sizeof(*hash_table_pair));
    hash_table_pair->key = 0;
    hash_table_pair->value = 0;
    hash_table_pair->hash = Unsigned__null;
    return hash_table_pair;
}

void Hash_Table_Pair__Initialize(void)
{
    Hash_Table_Pair__erase(Hash_Table_Pair__null);
}

/* {Hash_Table_Row} stuff: */

struct Hash_Table_Row__Struct Hash_Table_Row__Initial = {
    0,
    0,
    (Array)0,
};

Hash_Table_Row Hash_Table_Row__null = &Hash_Table_Row__Initial;
void Hash_Table_Row__erase(
  Hash_Table_Row hash_table_row)
{
    hash_table_row->index = 0;
    hash_table_row->mask = 0;
    if (hash_table_row->pairs == 0) {
	hash_table_row->pairs = Array__new();
    } else {
	Array__erase(hash_table_row->pairs);
    }
}

Hash_Table_Row Hash_Table_Row__new(void)
{
    Hash_Table_Row hash_table_row;
    extern void *malloc(unsigned int);

    hash_table_row = (Hash_Table_Row)malloc(sizeof(*hash_table_row));
    hash_table_row->index = Unsigned__null;
    hash_table_row->mask = Unsigned__null;
    hash_table_row->pairs = Array__new();
    return hash_table_row;
}

void Hash_Table_Row__Initialize(void)
{
    Hash_Table_Row__erase(Hash_Table_Row__null);
}

/* {Hash_Table} stuff: */

struct Hash_Table__Struct Hash_Table__Initial = {
    &String__Initial,
    0,
    0,
    0,
    0,
    (Hash_Table_Pair)0,
    0,
    (Array)0,
    0,
    0,
    0,
    0,
};

Hash_Table Hash_Table__null = &Hash_Table__Initial;
void Hash_Table__erase(
  Hash_Table hash_table)
{
    hash_table->buffer = String__null;
    hash_table->mask = 0;
    if (hash_table->null_pair == 0) {
	hash_table->null_pair = Hash_Table_Pair__new();
    } else {
	Hash_Table_Pair__erase(hash_table->null_pair);
    }
    hash_table->power = 0;
    if (hash_table->rows == 0) {
	hash_table->rows = Array__new();
    } else {
	Array__erase(hash_table->rows);
    }
    hash_table->size = 0;
    hash_table->trace_level = 0;
    /* value_empty (type Value) is parameterized */}

Hash_Table Hash_Table__new(void)
{
    Hash_Table hash_table;
    extern void *malloc(unsigned int);

    hash_table = (Hash_Table)malloc(sizeof(*hash_table));
    hash_table->buffer = String__null;
    hash_table->key_equal = 0;
    hash_table->key_hash = 0;
    hash_table->key_show = 0;
    hash_table->mask = Unsigned__null;
    hash_table->null_pair = Hash_Table_Pair__new();
    hash_table->power = Unsigned__null;
    hash_table->rows = Array__new();
    hash_table->size = Unsigned__null;
    hash_table->trace_level = Unsigned__null;
    hash_table->value_empty = 0;
    hash_table->value_show = 0;
    return hash_table;
}

void Hash_Table__Initialize(void)
{
    Hash_Table__erase(Hash_Table__null);
}

/* {In_Stream} stuff: */

/* {Integer} stuff: */

/* {Logical} stuff: */

/* {Long_Integer} stuff: */

/* {Long_Unsigned} stuff: */

/* {Out_Stream} stuff: */

/* {Short} stuff: */

/* {String} stuff: */

/* {System} stuff: */

struct System__Struct System__Initial = {
    &Out_Stream__Initial,
    &Out_Stream__Initial,
    &In_Stream__Initial,
    0,
    0,
};

System System__null = &System__Initial;
void System__erase(
  System system)
{
    system->error_out_stream = Out_Stream__null;
    system->standard_out_stream = Out_Stream__null;
    system->standard_in_stream = In_Stream__null;
    system->fail_routine_present = 0;
}

System System__new(void)
{
    System system;
    extern void *malloc(unsigned int);

    system = (System)malloc(sizeof(*system));
    system->error_out_stream = Out_Stream__null;
    system->standard_out_stream = Out_Stream__null;
    system->standard_in_stream = In_Stream__null;
    system->fail_routine = 0;
    system->fail_routine_present = Logical__null;
    return system;
}

void System__Initialize(void)
{
    System__erase(System__null);
}

/* {System_Jump_Buffer} stuff: */

/* {Unsigned} stuff: */


