#include "Declaration.ez.h"/*cc2*/
/* # Copyright (c) 2004-2011 by Wayne C. Gramlich. */
/* # All rights reserved. */
/* # This module will generate code for declarations. */
#include "Compiler.ez.h"/*D1*/
#include "Easy_C.ez.h"/*D1*/
#include "Token.ez.h"/*D1*/
#include "Parse.ez.h"/*D1*/
#include "Statement.ez.h"/*D1*/
/* # {Collection_Declaration} routines: */
/* #undef lower case macros */
#undef i386
#undef linux
#undef unix
#undef errno
#undef makedev
#undef major
#undef minor
#undef alloca

void Collection_Declaration__visit(
  Collection_Declaration collection,
  String buffer,
  Compiler compiler)
{
    Source source;
    String collection_name;
    String t__0;
    switch (compiler->phase) {
        case Phase___c_defines_emit:
        case Phase___c_emit:
        case Phase___ezh_emit:
        case Phase___ezh_scan:
        case Phase___generate_emit:
        case Phase___h_externs_emit:
        case Phase___h_includes_emit:
        case Phase___h_structs_emit:
        case Phase___link_emit:
        case Phase___link_scan:
        case Phase___prefix_scan:
        case Phase___h_typedefs_emit:
            /* do_nothing */
            break;
        case Phase___source_find:
            source = compiler->source;
            if (!((source != Source__null))) {
                System__assert_fail((String)"\17Declaration.ezc", 40);
            }
            collection_name = collection->name->value;
            if ((source->collection == Collection__null)) {
                source->collection = Compiler__collection_register(compiler, collection, source);
                source->collection_declaration = collection;
            } else {
                (void)Messages__log2(compiler->messages, collection->name, source->collection_declaration->name, (t__0 = String__form(((String)"\045Collection %v% defined more than once")), String__divide((t__0), String__f(collection_name))));
            }
            break;
    }
    /* do_nothing */;
}

/* # {Constant_Declaration} routines: */
Logical Constant_Declaration__equal(
  Constant_Declaration constant_declaration1,
  Constant_Declaration constant_declaration2)
{
    Logical result;
    result = 0;
    result = (Typed_Name__equal(constant_declaration1->typed_name, constant_declaration2->typed_name)&&Type__equal(constant_declaration1->type, constant_declaration2->type)&&Expression__equal(constant_declaration1->expression, constant_declaration2->expression));
    return result;
}

void Constant_Declaration__visit(
  Constant_Declaration constant,
  String buffer,
  Compiler compiler)
{
    Token location;
    Typed_Name typed_name;
    Type typed_name_type;
    Token typed_name_name;
    Type type;
    Expression expression;
    Typed_Name_Object typed_name_object;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    location = constant->constant->keyword;
    (void)Compiler__location_push(compiler, ((String)"\024constant declaration"), location);
    typed_name = constant->typed_name;
    typed_name_type = typed_name->type;
    typed_name_name = typed_name->name;
    type = constant->type;
    expression = constant->expression;
    switch (compiler->phase) {
        case Phase___c_defines_emit:
        case Phase___generate_emit:
        case Phase___h_externs_emit:
        case Phase___h_includes_emit:
        case Phase___h_structs_emit:
        case Phase___source_find:
        case Phase___link_emit:
        case Phase___link_scan:
        case Phase___prefix_scan:
            /* do_nothing */
            break;
        case Phase___h_typedefs_emit:

            switch (type->kind) {
                case Type_Kind___simple:
                    if (Type__is_scalar(type)) {
                        (void)String__string_append(buffer, (t__0 = String__form(((String)"\034#define %s%__%s% ((%s%)%s%)\n")), t__1 = String__f(Type__base_name(typed_name_type)), t__2 = String__f(typed_name_name->value), t__3 = String__f(Type__c_base_name(type)), String__divide(String__remainder(String__remainder(String__remainder((t__0), t__1), t__2), t__3), String__f(Expression__macro_evaluate(expression, compiler, String__null)))));
                    } else {
                        (void)Compiler__log(compiler, location, (t__4 = String__form(((String)"\050%t% is not a scalar type like 'Unsigned'")), String__divide((t__4), Type__f(type))));
                    }
                    break;
            }
            break;
        case Phase___c_emit:
            switch (typed_name_type->kind) {
                case Type_Kind___simple:
                    /* do_nothing */
                    break;
                default:
                    (void)Compiler__log(compiler, location, (t__5 = String__form(((String)"\055%t% needs to be a simple type (no parameters)")), String__divide((t__5), Type__f(type))));
                    break;
            }
            switch (type->kind) {
                case Type_Kind___simple:
                    if (!Type__is_scalar(type)) {
                        (void)Compiler__log(compiler, location, (t__6 = String__form(((String)"\047%t% is not a scalar type like 'Integer'")), String__divide((t__6), Type__f(type))));
                    }
                    break;
                default:
                    (void)Compiler__log(compiler, location, (t__7 = String__form(((String)"\062%t% needs to be a simple type like (no parameters)")), String__divide((t__7), Type__f(type))));
                    break;
            }
            break;
        case Phase___ezh_scan:
            typed_name_object = Typed_Name_Object__new();
            typed_name_object->kind = Typed_Name_Object_Kind___constant; typed_name_object->kind__union.constant = constant;
            (void)Compiler__typed_name_insert(compiler, typed_name, typed_name_object, typed_name->name, ((String)"\032visit@Constant_Declaration"));
            break;
        case Phase___ezh_emit:
            (void)Constant_Declaration__traverse(constant, compiler->traverser);
            break;
    }
    (void)Compiler__location_pop(compiler);
}

/* # {Declaration} routines: */
void Declaration__library_visit(
  Library_Declaration library,
  Interface_Declaration interface,
  Global_Library_Declaration global_library,
  String library_name,
  String buffer,
  Compiler compiler)
{
    String middlefix;
    String temporary;
    Messages messages;
    Array library_bases;
    Array interface_bases;
    Options options;
    Array source_bases;
    Unsigned size;
    Unsigned index;
    String upper_library_name;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 148);
    }
    middlefix = compiler->middlefix;
    temporary = compiler->temporary;
    messages = compiler->messages;
    switch (compiler->phase) {
        case Phase___c_emit:
            (void)String__string_append(buffer, (t__0 = String__form(((String)"\032#include \"%s%%s%.h\"/*D1*/\n")), t__1 = String__f(library_name), String__divide(String__remainder((t__0), t__1), String__f(compiler->middlefix))));
            /* #ezh_file :@= read@File(library_name, middlefix, ".ezh", compiler) */
            /* #if ezh_file !== null@File */
            /* #    ezh_tokens :@= ezh_file.tokens */
            /* #    ezh_parser :@= create@Parser(ezh_tokens, messages) */
            /* #    ezh_root :@= parse@Root(ezh_parser) */
            /* #    call visit@(ezh_root, "", compiler, ezh_scan@Phase) */
            break;
        case Phase___link_emit:

            /* #if ezh_file !== null@File */
            /* #    ezh_tokens := ezh_file.tokens */
            /* #    ezh_parser := create@Parser(ezh_tokens, messages) */
            /* #    ezh_root := parse@Root(ezh_parser) */
            /* #    call visit@Root(ezh_root, buffer, compiler, link_scan@Phase) */
            break;
        case Phase___ezh_emit:
            if ((library != Library_Declaration__null)) {
                (void)Library_Declaration__traverse(library, compiler->traverser);
            } else if ((interface != Interface_Declaration__null)) {
                (void)Interface_Declaration__traverse(interface, compiler->traverser);
            }
            /* # Append {library_name} to either {library_bases} or {interface_bases} */
            /* # if it is not already there: */
            library_bases = compiler->library_bases;
            interface_bases = compiler->interface_bases;
            options = compiler->options;
            source_bases = options->source_bases;
            size = Array__size_get(source_bases);
            index = 0;
            while ((index < size)) {
                if (String__equal(((String)Array__fetch1(source_bases, index)), library_name)) {
                    break;
                }
                index = (index+1);
            }
            if ((index >= size)) {

                size = Array__size_get(library_bases);
                index = 0;
                while ((index < size)) {
                    if (String__equal(((String)Array__fetch1(library_bases, index)), library_name)) {
                        break;
                    }
                    index = (index+1);
                }
                if ((index >= size)) {

                    size = Array__size_get(interface_bases);
                    index = 0;
                    while ((index < size)) {
                        if (String__equal(((String)Array__fetch1(interface_bases, index)), library_name)) {
                            break;
                        }
                        index = (index+1);
                    }
                    if ((index >= size)) {

                        /* # {interface_bases}; append to appropriate list: */
                        if ((library != Library_Declaration__null)) {
                            (void)Array__append(library_bases, ((void *)(library_name)));
                        } else if ((interface != Interface_Declaration__null)) {
                            (void)Array__append(interface_bases, ((void *)(library_name)));
                        } else {
                            if (!(Logical__false)) {
                                System__assert_fail((String)"\17Declaration.ezc", 216);
                            }
                        }
                    }
                }
            }
            break;
        case Phase___h_includes_emit:

            upper_library_name = String__new();
            (void)String__upper_case_append(upper_library_name, library_name);
            (void)String__string_append(buffer, (t__2 = String__form(((String)"\025#ifndef %s%_INCLUDED\n")), String__divide((t__2), String__f(upper_library_name))));
            (void)String__string_append(buffer, (t__3 = String__form(((String)"\032#include \"%s%%s%.h\"/*D2*/\n")), t__4 = String__f(library_name), String__divide(String__remainder((t__3), t__4), String__f(compiler->middlefix))));
            (void)String__string_append(buffer, (t__5 = String__form(((String)"\032#endif /* %s%_INCLUDED */\n")), String__divide((t__5), String__f(upper_library_name))));
            break;
    }
}

Token Declaration__location_get(
  Declaration declaration)
{
    Token location;
    Error error;
    location = Token__null;
    switch (declaration->kind) {
        case Declaration_Kind___collection:
            location = ((declaration->kind == Declaration_Kind___collection) ? declaration->kind__union.collection : (Collection_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 243))->end_of_line;
            break;
        case Declaration_Kind___constant:
            location = ((declaration->kind == Declaration_Kind___constant) ? declaration->kind__union.constant : (Constant_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 245))->end_of_line;
            break;
        case Declaration_Kind___define:
            location = ((declaration->kind == Declaration_Kind___define) ? declaration->kind__union.define : (Define_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 247))->end_of_line;
            break;
        case Declaration_Kind___defines_prefix:
            location = ((declaration->kind == Declaration_Kind___defines_prefix) ? declaration->kind__union.defines_prefix : (Defines_Prefix_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 249))->end_of_line;
            break;
        case Declaration_Kind___easy_c:
            location = ((declaration->kind == Declaration_Kind___easy_c) ? declaration->kind__union.easy_c : (Easy_C_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 251))->end_of_line;
            break;
        case Declaration_Kind___end_of_line:
            location = ((declaration->kind == Declaration_Kind___end_of_line) ? declaration->kind__union.end_of_line : (Token)System__variant_object_fail((String)"\17Declaration.ezc", 253));
            break;
        case Declaration_Kind___error:
            error = ((declaration->kind == Declaration_Kind___error) ? declaration->kind__union.error : (Error)System__variant_object_fail((String)"\17Declaration.ezc", 255));
            location = ((Token)Array__fetch1(error->tokens, 0));
            break;
        case Declaration_Kind___external:
            location = ((declaration->kind == Declaration_Kind___external) ? declaration->kind__union.external : (External_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 258))->end_of_line;
            break;
        case Declaration_Kind___external_named:
            location = ((declaration->kind == Declaration_Kind___external_named) ? declaration->kind__union.external_named : (External_Named_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 260))->end_of_line;
            break;
        case Declaration_Kind___global:
            location = ((declaration->kind == Declaration_Kind___global) ? declaration->kind__union.global : (Global_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 262))->end_of_line;
            break;
        case Declaration_Kind___global_library:
            location = ((declaration->kind == Declaration_Kind___global_library) ? declaration->kind__union.global_library : (Global_Library_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 264))->end_of_line;
            break;
        case Declaration_Kind___include_string:
            location = ((declaration->kind == Declaration_Kind___include_string) ? declaration->kind__union.include_string : (Include_String_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 266))->end_of_line;
            break;
        case Declaration_Kind___interface:
            location = ((declaration->kind == Declaration_Kind___interface) ? declaration->kind__union.interface : (Interface_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 268))->end_of_line;
            break;
        case Declaration_Kind___library:
            location = ((declaration->kind == Declaration_Kind___library) ? declaration->kind__union.library : (Library_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 270))->end_of_line;
            break;
        case Declaration_Kind___load:
            location = ((declaration->kind == Declaration_Kind___load) ? declaration->kind__union.load : (Load_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 272))->end_of_line;
            break;
        case Declaration_Kind___note:
            location = ((declaration->kind == Declaration_Kind___note) ? declaration->kind__union.note : (Note)System__variant_object_fail((String)"\17Declaration.ezc", 274))->end_of_line;
            break;
        case Declaration_Kind___require:
            location = ((declaration->kind == Declaration_Kind___require) ? declaration->kind__union.require : (Require_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 276))->end_of_line;
            break;
        case Declaration_Kind___routine:
            location = ((declaration->kind == Declaration_Kind___routine) ? declaration->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 278))->end_of_line;
            break;
    }
    return location;
}

void Declaration__visit(
  Declaration declaration,
  String buffer,
  Compiler compiler)
{
    Logical trace;
    Logical temp;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    (void)Compiler__location_push(compiler, ((String)"\013Declaration"), Declaration__location_get(declaration));
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 292);
    }
    trace = Logical__false;
    if (trace) {
        (void)String__d((t__1 = String__form(((String)"\031=>visit@Declaration(%p%)\n")), String__divide((t__1), Phase__f(compiler->phase))));
    }
    switch (declaration->kind) {
        case Declaration_Kind___collection:
            (void)Collection_Declaration__visit(((declaration->kind == Declaration_Kind___collection) ? declaration->kind__union.collection : (Collection_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 301)), buffer, compiler);
            break;
        case Declaration_Kind___constant:
            (void)Constant_Declaration__visit(((declaration->kind == Declaration_Kind___constant) ? declaration->kind__union.constant : (Constant_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 303)), buffer, compiler);
            break;
        case Declaration_Kind___define:
            (void)Define_Declaration__visit(((declaration->kind == Declaration_Kind___define) ? declaration->kind__union.define : (Define_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 305)), buffer, compiler);
            break;
        case Declaration_Kind___defines_prefix:
            (void)Defines_Prefix_Declaration__visit(((declaration->kind == Declaration_Kind___defines_prefix) ? declaration->kind__union.defines_prefix : (Defines_Prefix_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 307)), buffer, compiler);
            break;
        case Declaration_Kind___easy_c:
            (void)Easy_C_Declaration__visit(((declaration->kind == Declaration_Kind___easy_c) ? declaration->kind__union.easy_c : (Easy_C_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 309)), buffer, compiler);
            break;
        case Declaration_Kind___end_of_line:
            switch (compiler->phase) {
                case Phase___c_emit:
                case Phase___ezh_emit:
                    (void)String__buffer_append(((String)"\001\n"), buffer);
                    break;
            }
            break;
        case Declaration_Kind___error:

            /* do_nothing */
            break;
        case Declaration_Kind___external:
            (void)External_Declaration__visit(((declaration->kind == Declaration_Kind___external) ? declaration->kind__union.external : (External_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 318)), buffer, compiler);
            break;
        case Declaration_Kind___external_named:
            (void)External_Named_Declaration__visit(((declaration->kind == Declaration_Kind___external_named) ? declaration->kind__union.external_named : (External_Named_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 320)), buffer, compiler);
            break;
        case Declaration_Kind___global:
            (void)Global_Declaration__visit(((declaration->kind == Declaration_Kind___global) ? declaration->kind__union.global : (Global_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 322)), buffer, compiler);
            break;
        case Declaration_Kind___global_library:
            (void)Global_Library_Declaration__visit(((declaration->kind == Declaration_Kind___global_library) ? declaration->kind__union.global_library : (Global_Library_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 324)), buffer, compiler);
            break;
        case Declaration_Kind___include_string:
            (void)Include_String_Declaration__visit(((declaration->kind == Declaration_Kind___include_string) ? declaration->kind__union.include_string : (Include_String_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 326)), buffer, compiler);
            break;
        case Declaration_Kind___library:
            (void)Library_Declaration__visit(((declaration->kind == Declaration_Kind___library) ? declaration->kind__union.library : (Library_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 328)), buffer, compiler);
            break;
        case Declaration_Kind___interface:
            (void)Interface_Declaration__visit(((declaration->kind == Declaration_Kind___interface) ? declaration->kind__union.interface : (Interface_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 330)), buffer, compiler);
            break;
        case Declaration_Kind___load:
            (void)Load_Declaration__visit(((declaration->kind == Declaration_Kind___load) ? declaration->kind__union.load : (Load_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 332)), buffer, compiler);
            break;
        case Declaration_Kind___note:
            (void)Note__visit(((declaration->kind == Declaration_Kind___note) ? declaration->kind__union.note : (Note)System__variant_object_fail((String)"\17Declaration.ezc", 334)), buffer, compiler);
            break;
        case Declaration_Kind___require:
            (void)Require_Declaration__visit(((declaration->kind == Declaration_Kind___require) ? declaration->kind__union.require : (Require_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 336)), buffer, compiler);
            break;
        case Declaration_Kind___routine:
            temp = compiler->tracing;
            compiler->tracing = Logical__true;
            (void)Routine_Declaration__visit(((declaration->kind == Declaration_Kind___routine) ? declaration->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 340)), buffer, compiler);
            compiler->tracing = temp;
            break;
    }
    (void)Compiler__location_pop(compiler);
    if (trace) {
        (void)String__d((t__3 = String__form(((String)"\031<=visit@Declaration(%p%)\n")), String__divide((t__3), Phase__f(compiler->phase))));
    }
}

/* # {Define_Declaration} routines: */
Integer Define_Declaration__compare(
  Define_Declaration define1,
  Define_Declaration define2)
{
    return Type__compare(define1->type, define2->type);
}

void Define_Declaration__show(
  Define_Declaration define,
  String buffer)
{
    if ((define == Define_Declaration__null)) {
        (void)String__buffer_append(((String)"\027null@Define_Declaration"), buffer);
    } else {
        (void)Type__string_gap_insert(define->type, buffer);
    }
}

void Define_Declaration__c_defines_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_name;
    String t__0;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 384);
    }
    temporary = compiler->temporary;
    define_type = define->type;
    define_name = Type__base_name(define_type);
    (void)Compiler__undefs_append(compiler, buffer);
    (void)String__string_append(buffer, (t__0 = String__form(((String)"\024/* {%s%} stuff: */\n\n")), String__divide((t__0), String__f(define_name))));
    (void)Define_Declaration__variant_globals_emit(define, buffer, compiler);
    (void)Define_Declaration__null_emit(define, buffer, compiler);
    (void)Define_Declaration__erase_emit(define, buffer, compiler);
    (void)Define_Declaration__new_emit(define, buffer, compiler);
    (void)Define_Declaration__initialize_emit(define, buffer, compiler);
}

void Define_Declaration__h_structs_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    Logical struct_output;
    String temporary;
    Type define_type;
    String define_name;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    Field field;
    String field_name;
    Type field_type;
    String c_type_text;
    Variant_Clause variant;
    String kind_name;
    Type kind_type;
    String kind_type_base;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 413);
    }
    struct_output = Logical__false;
    temporary = compiler->temporary;
    define_type = define->type;
    define_name = Type__base_name(define_type);
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___record:
                if (!struct_output) {
                    (void)String__string_append(buffer, (t__0 = String__form(((String)"\025struct %s%__Struct {\n")), String__divide((t__0), String__f(define_name))));
                    struct_output = Logical__true;
                }
                field_clauses = ((define_clause->kind == Define_Clause_Kind___record) ? define_clause->kind__union.record : (Record_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 431))->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 438));
                            field_name = field->name->value;
                            field_type = field->type;
                            c_type_text = Type__c_type(field_type, define_type, field_name);
                            (void)String__string_append(buffer, (t__1 = String__form(((String)"\011    %k%;\n")), String__divide((t__1), String__f(c_type_text))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                break;
            case Define_Clause_Kind___record_import:

                /* do_nothing */
                break;
            case Define_Clause_Kind___variant:
                variant = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 450));
                if (!struct_output) {
                    (void)String__string_append(buffer, (t__2 = String__form(((String)"\025struct %s%__Struct {\n")), String__divide((t__2), String__f(define_name))));
                    struct_output = Logical__true;
                }
                kind_name = variant->kind_name->value;
                kind_type = variant->kind_type;
                kind_type_base = Type__base_name(kind_type);
                (void)String__string_append(buffer, (t__3 = String__form(((String)"\015    %k% %k%;\n")), t__4 = String__f(kind_type_base), String__divide(String__remainder((t__3), t__4), String__f(kind_name))));
                (void)String__buffer_append(((String)"\014    union {\n"), buffer);
                field_clauses = variant->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 469));
                            field_name = field->name->value;
                            field_type = field->type;
                            /* #foo :@= simple_type_lookup@(compiler, */
                            /* #  base_name@(field_type)) */
                            /* #if foo !== null@Type */
                            /* #	call d@(form@("%t% => %t%\n\") % */
                            /* #	  f@(field_type) / f@(foo)) */
                            (void)String__string_append(buffer, (t__5 = String__form(((String)"\017\t%c% %k%;/*u*/\n")), t__6 = Type__f(field_type), String__divide(String__remainder((t__5), t__6), String__f(field_name))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                (void)String__string_append(buffer, (t__7 = String__form(((String)"\022    } %s%__union;\n")), String__divide((t__7), String__f(kind_name))));
                break;
        }
        index = (index+1);
    }
    if (struct_output) {
        (void)String__buffer_append(((String)"\003};\n"), buffer);
        if (!Type__is_parameterized(define_type)) {
            (void)String__string_append(buffer, (t__8 = String__form(((String)"\056extern struct %s%__Struct %s%__Initial;/*D1*/\n")), t__9 = String__f(define_name), String__divide(String__remainder((t__8), t__9), String__f(define_name))));
        }
    }
}

void Define_Declaration__h_typedefs_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_name;
    Array define_clauses;
    Unsigned size;
    Logical need_top_typedef;
    Unsigned index;
    Define_Clause define_clause;
    Base_Type_Clause base_type;
    Enumeration_Clause enumeration;
    Array item_clauses;
    Unsigned item_clauses_size;
    Unsigned item_clauses_index;
    Item_Clause item_clause;
    String item_name;
    Enumeration_Prefix_Clause enumeration_prefix;
    Array define_datas;
    Unsigned define_datas_size;
    Unsigned define_datas_index;
    Define_Data define_data;
    String type_string;
    Simple_Clause simple;
    Simple_Numeric_Clause simple_numeric;
    String other_typedefs;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 509);
    }
    temporary = compiler->temporary;
    define_type = define->type;
    define_name = Type__base_name(define_type);
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    need_top_typedef = Logical__false;
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___record:
                need_top_typedef = Logical__true;
                break;
            case Define_Clause_Kind___base_type:
                base_type = ((define_clause->kind == Define_Clause_Kind___base_type) ? define_clause->kind__union.base_type : (Base_Type_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 526));
                /* # Output the typedef: */
                (void)String__string_append(buffer, (t__0 = String__form(((String)"\021typedef %s% %s%;\n")), t__1 = String__f(Token__string_convert(base_type->string)), String__divide(String__remainder((t__0), t__1), String__f(define_name))));
                /* # Add to the scalar table: */
                /* #new_type :@= simple_create@Type(define_name) */
                /* #call scalar_insert@(compiler, define_name, new_type) */
                break;
            case Define_Clause_Kind___enumeration:
                enumeration = ((define_clause->kind == Define_Clause_Kind___enumeration) ? define_clause->kind__union.enumeration : (Enumeration_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 538));
                (void)String__string_append(buffer, (t__2 = String__form(((String)"\021enum %s%__Enum {\n")), String__divide((t__2), String__f(define_name))));
                item_clauses = enumeration->item_clauses;
                item_clauses_size = Array__size_get(item_clauses);
                item_clauses_index = 0;
                while ((item_clauses_index < item_clauses_size)) {
                    item_clause = ((Item_Clause)Array__fetch1(item_clauses, item_clauses_index));
                    switch (item_clause->kind) {
                        case Item_Clause_Kind___item:
                            item_name = ((item_clause->kind == Item_Clause_Kind___item) ? item_clause->kind__union.item : (Item)System__variant_object_fail((String)"\17Declaration.ezc", 549))->name->value;
                            (void)String__string_append(buffer, (t__3 = String__form(((String)"\017    %s%___%s%,\n")), t__4 = String__f(define_name), String__divide(String__remainder((t__3), t__4), String__f(item_name))));
                            break;
                    }
                    item_clauses_index = (item_clauses_index+1);
                }
                (void)String__buffer_append(((String)"\003};\n"), buffer);
                (void)String__string_append(buffer, (t__5 = String__form(((String)"\034typedef enum %s%__Enum %k%;\n")), t__6 = String__f(define_name), String__divide(String__remainder((t__5), t__6), String__f(define_name))));
                break;
            case Define_Clause_Kind___enumeration_prefix:
                enumeration_prefix = ((define_clause->kind == Define_Clause_Kind___enumeration_prefix) ? define_clause->kind__union.enumeration_prefix : (Enumeration_Prefix_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 559));
                if (enumeration_prefix->define_datas_initialized) {
                    (void)String__string_append(buffer, (t__7 = String__form(((String)"\021enum %s%__Enum {\n")), String__divide((t__7), String__f(define_name))));
                    define_datas = enumeration_prefix->define_datas;
                    define_datas_size = 0;
                    if (enumeration_prefix->define_datas_initialized) {
                        define_datas_size = Array__size_get(define_datas);
                    }
                    define_datas_index = 0;
                    while ((define_datas_index < define_datas_size)) {
                        define_data = ((Define_Data)Array__fetch1(define_datas, define_datas_index));
                        (void)String__string_append(buffer, (t__8 = String__form(((String)"\017    %s%___%s%,\n")), t__9 = String__f(define_name), String__divide(String__remainder((t__8), t__9), String__f(define_data->new_name))));
                        define_datas_index = (define_datas_index+1);
                    }
                    (void)String__buffer_append(((String)"\003};\n"), buffer);
                    (void)String__string_append(buffer, (t__10 = String__form(((String)"\034typedef enum %s%__Enum %k%;\n")), t__11 = String__f(define_name), String__divide(String__remainder((t__10), t__11), String__f(define_name))));
                }
                break;
            case Define_Clause_Kind___external:
                /* do_nothing */
                break;
            case Define_Clause_Kind___record_import:
                type_string = Token__string_convert(((define_clause->kind == Define_Clause_Kind___record_import) ? define_clause->kind__union.record_import : (Record_Import_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 581))->string);
                (void)String__string_append(buffer, (t__12 = String__form(((String)"\021typedef %s% %s%;\n")), t__13 = String__f(type_string), String__divide(String__remainder((t__12), t__13), String__f(define_name))));
                break;
            case Define_Clause_Kind___registers:
                (void)String__string_append(buffer, (t__14 = String__form(((String)"\021typedef int %s%;\n")), String__divide((t__14), String__f(define_name))));
                break;
            case Define_Clause_Kind___variant:
                need_top_typedef = Logical__true;
                /* #variant :@= define_clause.variant */
                /* #kind_name :@= variant.kind_name.value */
                /* #kind_type :@= variant.kind_type */
                /* #kind_type_base :@= base_name@(kind_type) */
                /* #call string_append@(buffer, */
                /* #  form@("enum %t%__Enum {\n\") / f@(kind_type_base)) */
                /* #field_clauses :@= variant.field_clauses */
                /* #field_clauses_size :@= field_clauses.size */
                /* #field_clauses_index :@= 0 */
                /* #while field_clauses_index < field_clauses_size */
                /* #	field_clause :@= field_clauses[field_clauses_index] */
                /* #	switch field_clause.kind */
                /* #	  case field */
                /* #	    field_name :@= field_clause.field.name.value */
                /* #	    call string_append@(buffer, */
                /* #	      form@("    %t%___%s%,\n\") % */
                /* #	      f@(kind_type_base) / f@(field_name)) */
                /* #	field_clauses_index := field_clauses_index + 1 */
                /* #call buffer_append@("};\n\", buffer) */
                /* #call string_append@(buffer, */
                /* #  form@("typedef enum %s%__Enum %s%;\n\") % */
                /* #  f@(kind_type_base) / f@(kind_type_base)) */
                break;
            case Define_Clause_Kind___simple:
                simple = ((define_clause->kind == Define_Clause_Kind___simple) ? define_clause->kind__union.simple : (Simple_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 616));
                /* # No longer output the typedef: */
                /* #simple_typedefs :@= compiler.simple_typedefs */
                /* #call string_append@(simple_typedefs, */
                /* #  form@("typedef %t% %s%;\n\") % */
                /* #  f@(simple.type) / f@(define_name)) */
                /* #simple_type :@= simple.type */
                /* #if is_scalar@Type(simple_type) */
                /* #	new_type :@= simple_create@Type(define_name) */
                /* #	call scalar_insert@(compiler, define_name, new_type) */
                /* #	#call d@(form@("Inserting %t% into scalar table under %v%\n\") % */
                /* #	#  f@(new_type) / f@(define_name)) */
                break;
            case Define_Clause_Kind___simple_numeric:
                simple_numeric = ((define_clause->kind == Define_Clause_Kind___simple_numeric) ? define_clause->kind__union.simple_numeric : (Simple_Numeric_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 632));
                other_typedefs = compiler->other_typedefs;
                (void)String__string_append(other_typedefs, (t__15 = String__form(((String)"\021typedef %t% %s%;\n")), t__16 = Type__f(simple_numeric->type), String__divide(String__remainder((t__15), t__16), String__f(define_name))));
                /* #previous_definition :@= scalar_lookup@(compiler, define_name) */
                /* #if previous_definition == null@Type */
                /* #	call scalar_insert@(compiler, define_name, simple_numeric.type) */
                /* #else */
                /* #	assert 0f */
                break;
            case Define_Clause_Kind___end_of_line:
            case Define_Clause_Kind___error:
            case Define_Clause_Kind___note:
            case Define_Clause_Kind___generate:
                /* do_nothing */
                break;
        }
        index = (index+1);
    }
    if (need_top_typedef) {
        (void)String__string_append(buffer, (t__17 = String__form(((String)"\041typedef struct %s%__Struct *%k%;\n")), t__18 = String__f(define_name), String__divide(String__remainder((t__17), t__18), String__f(define_name))));
    }
}

void Define_Declaration__initialize_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_name;
    String t__0;
    String t__1;
    String t__2;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 663);
    }
    if ((!Define_Declaration__is_external(define)&&!Define_Declaration__is_registers(define)&&!Define_Declaration__is_simple(define)&&!Define_Declaration__is_base_type(define))) {
        temporary = compiler->temporary;
        define_type = define->type;
        define_name = Type__base_name(define_type);
        (void)String__string_append(buffer, (t__0 = String__form(((String)"\033void %s%__Initialize(void)\n")), String__divide((t__0), String__f(define_name))));
        (void)String__buffer_append(((String)"\002{\n"), buffer);
        if (!Define_Declaration__is_record_import(define)) {
            (void)String__string_append(buffer, (t__1 = String__form(((String)"\033    %s%__erase(%s%__null);\n")), t__2 = String__f(define_name), String__divide(String__remainder((t__1), t__2), String__f(define_name))));
        }
        (void)String__buffer_append(((String)"\003}\n\n"), buffer);
    }
}

Logical Define_Declaration__is_enumeration(
  Define_Declaration define)
{
    Logical result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Logical__false;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___enumeration:
            case Define_Clause_Kind___enumeration_prefix:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Logical Define_Declaration__is_base_type(
  Define_Declaration define)
{
    Logical result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Logical__false;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___base_type:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Logical Define_Declaration__is_external(
  Define_Declaration define)
{
    Logical result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Logical__false;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___external:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Logical Define_Declaration__is_simple_numeric(
  Define_Declaration define)
{
    Logical result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Logical__false;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___simple_numeric:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Logical Define_Declaration__is_simple(
  Define_Declaration define)
{
    Logical result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Logical__false;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___simple:
            case Define_Clause_Kind___simple_numeric:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Logical Define_Declaration__is_record(
  Define_Declaration define)
{
    Logical result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Logical__false;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___record:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Logical Define_Declaration__is_registers(
  Define_Declaration define)
{
    Logical result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Logical__false;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___registers:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Logical Define_Declaration__is_record_import(
  Define_Declaration define)
{
    Logical result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Logical__false;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___record_import:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Logical Define_Declaration__is_variant(
  Define_Declaration define)
{
    Logical result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Logical__false;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___variant:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Type Define_Declaration__record_field_type(
  Define_Declaration define,
  String field_name)
{
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    Field field;
    Array import_field_clauses;
    Unsigned import_field_clauses_size;
    Unsigned import_field_clauses_index;
    Import_Field_Clause import_field_clause;
    Import_Field import_field;
    Variant_Clause variant;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___record:
                field_clauses = ((define_clause->kind == Define_Clause_Kind___record) ? define_clause->kind__union.record : (Record_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 879))->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 886));
                            if (String__equal(field->name->value, field_name)) {
                                return field->type;
                            }
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                break;
            case Define_Clause_Kind___record_import:
                import_field_clauses = ((define_clause->kind == Define_Clause_Kind___record_import) ? define_clause->kind__union.record_import : (Record_Import_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 892))->import_field_clauses;
                import_field_clauses_size = Array__size_get(import_field_clauses);
                import_field_clauses_index = 0;
                while ((import_field_clauses_index < import_field_clauses_size)) {
                    import_field_clause = ((Import_Field_Clause)Array__fetch1(import_field_clauses, import_field_clauses_index));
                    switch (import_field_clause->kind) {
                        case Import_Field_Clause_Kind___import_field:
                            import_field = ((import_field_clause->kind == Import_Field_Clause_Kind___import_field) ? import_field_clause->kind__union.import_field : (Import_Field)System__variant_object_fail((String)"\17Declaration.ezc", 900));
                            if (String__equal(import_field->name->value, field_name)) {
                                return import_field->type;
                            }
                            break;
                    }
                    import_field_clauses_index = (import_field_clauses_index+1);
                }
                break;
            case Define_Clause_Kind___variant:
                variant = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 905));
                if (String__equal(variant->kind_name->value, field_name)) {
                    return variant->kind_type;
                }
                break;
        }
        index = (index+1);
    }
    return Type__null;
}

String Define_Declaration__record_field_name(
  Define_Declaration define,
  String field_name)
{
    String result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    Field field;
    Array import_field_clauses;
    Unsigned import_field_clauses_size;
    Unsigned import_field_clauses_index;
    Import_Field_Clause import_field_clause;
    Import_Field import_field;
    result = String__null;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___record:
                field_clauses = ((define_clause->kind == Define_Clause_Kind___record) ? define_clause->kind__union.record : (Record_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 929))->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 936));
                            if (String__equal(field->name->value, field_name)) {
                                result = field_name;
                                goto break__1;
                            }
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                break;
            case Define_Clause_Kind___record_import:
                import_field_clauses = ((define_clause->kind == Define_Clause_Kind___record_import) ? define_clause->kind__union.record_import : (Record_Import_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 943))->import_field_clauses;
                import_field_clauses_size = Array__size_get(import_field_clauses);
                import_field_clauses_index = 0;
                while ((import_field_clauses_index < import_field_clauses_size)) {
                    import_field_clause = ((Import_Field_Clause)Array__fetch1(import_field_clauses, import_field_clauses_index));
                    switch (import_field_clause->kind) {
                        case Import_Field_Clause_Kind___import_field:
                            import_field = ((import_field_clause->kind == Import_Field_Clause_Kind___import_field) ? import_field_clause->kind__union.import_field : (Import_Field)System__variant_object_fail((String)"\17Declaration.ezc", 951));
                            if (String__equal(import_field->name->value, field_name)) {
                                result = import_field->c_name->value;
                                goto break__1;
                            }
                            break;
                    }
                    import_field_clauses_index = (import_field_clauses_index+1);
                }
                break;
            case Define_Clause_Kind___variant:
                if (String__equal(((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 957))->kind_name->value, field_name)) {
                    result = field_name;
                    goto break__1;
                }
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

String Define_Declaration__register_bit_name(
  Define_Declaration define,
  String field_name)
{
    String result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array register_clauses;
    Unsigned register_clauses_size;
    Unsigned register_clauses_index;
    Register_Clause register_clause;
    Register_Bit bit;
    Register_Byte byte;
    result = String__null;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___registers:
                register_clauses = ((define_clause->kind == Define_Clause_Kind___registers) ? define_clause->kind__union.registers : (Registers_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 981))->register_clauses;
                register_clauses_size = Array__size_get(register_clauses);
                register_clauses_index = 0;
                while ((register_clauses_index < register_clauses_size)) {
                    register_clause = ((Register_Clause)Array__fetch1(register_clauses, register_clauses_index));
                    switch (register_clause->kind) {
                        case Register_Clause_Kind___bit:
                            bit = ((register_clause->kind == Register_Clause_Kind___bit) ? register_clause->kind__union.bit : (Register_Bit)System__variant_object_fail((String)"\17Declaration.ezc", 988));
                            if (String__equal(bit->name->value, field_name)) {
                                result = Token__string_convert(bit->string);
                                goto break__1;
                            }
                            break;
                        case Register_Clause_Kind___byte:
                            byte = ((register_clause->kind == Register_Clause_Kind___byte) ? register_clause->kind__union.byte : (Register_Byte)System__variant_object_fail((String)"\17Declaration.ezc", 993));
                            break;
                    }
                    register_clauses_index = (register_clauses_index+1);
                }
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

String Define_Declaration__register_bit_byte_name(
  Define_Declaration define,
  String field_name)
{
    String result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array register_clauses;
    Unsigned register_clauses_size;
    Unsigned register_clauses_index;
    Register_Clause register_clause;
    Register_Bit bit;
    Register_Byte byte;
    result = String__null;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___registers:
                register_clauses = ((define_clause->kind == Define_Clause_Kind___registers) ? define_clause->kind__union.registers : (Registers_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1016))->register_clauses;
                register_clauses_size = Array__size_get(register_clauses);
                register_clauses_index = 0;
                while ((register_clauses_index < register_clauses_size)) {
                    register_clause = ((Register_Clause)Array__fetch1(register_clauses, register_clauses_index));
                    switch (register_clause->kind) {
                        case Register_Clause_Kind___bit:
                            bit = ((register_clause->kind == Register_Clause_Kind___bit) ? register_clause->kind__union.bit : (Register_Bit)System__variant_object_fail((String)"\17Declaration.ezc", 1023));
                            if (String__equal(bit->name->value, field_name)) {
                                goto break__1;
                            }
                            break;
                        case Register_Clause_Kind___byte:
                            byte = ((register_clause->kind == Register_Clause_Kind___byte) ? register_clause->kind__union.byte : (Register_Byte)System__variant_object_fail((String)"\17Declaration.ezc", 1027));
                            result = Token__string_convert(byte->string);
                            break;
                    }
                    register_clauses_index = (register_clauses_index+1);
                }
                break;
        }
        index = (index+1);
    }
    break__1:;
    if ((index >= size)) {
        result = String__null;
    }
    return result;
}

String Define_Declaration__register_byte_name(
  Define_Declaration define,
  String field_name)
{
    String result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array register_clauses;
    Unsigned register_clauses_size;
    Unsigned register_clauses_index;
    Register_Clause register_clause;
    Register_Byte byte;
    result = String__null;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___registers:
                register_clauses = ((define_clause->kind == Define_Clause_Kind___registers) ? define_clause->kind__union.registers : (Registers_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1053))->register_clauses;
                register_clauses_size = Array__size_get(register_clauses);
                register_clauses_index = 0;
                while ((register_clauses_index < register_clauses_size)) {
                    register_clause = ((Register_Clause)Array__fetch1(register_clauses, register_clauses_index));
                    switch (register_clause->kind) {
                        case Register_Clause_Kind___byte:
                            byte = ((register_clause->kind == Register_Clause_Kind___byte) ? register_clause->kind__union.byte : (Register_Byte)System__variant_object_fail((String)"\17Declaration.ezc", 1060));
                            if (String__equal(byte->name->value, field_name)) {
                                result = Token__string_convert(byte->string);
                                goto break__1;
                            }
                            break;
                    }
                    register_clauses_index = (register_clauses_index+1);
                }
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Type Define_Declaration__variant_field_type(
  Define_Declaration define,
  String field_name)
{
    Type result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    Field field;
    result = Type__null;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___variant:
                field_clauses = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1085))->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1092));
                            if (String__equal(field->name->value, field_name)) {
                                result = field->type;
                                goto break__1;
                            }
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Variant_Clause Define_Declaration__variant_lookup(
  Define_Declaration define,
  String field_name)
{
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Variant_Clause variant;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___variant:
                variant = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1117));
                field_clauses = variant->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            if (String__equal(((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1125))->name->value, field_name)) {
                                return variant;
                            }
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                break;
        }
        index = (index+1);
    }
    return Variant_Clause__null;
}

void Define_Declaration__visit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Hash_Table define_table;
    Type define_type;
    String define_name;
    Define_Declaration previous_define;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Simple_Clause simple;
    Source source;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 1140);
    }
    temporary = compiler->temporary;
    switch (compiler->phase) {
        case Phase___c_emit:
        case Phase___h_includes_emit:
        case Phase___link_emit:
            /* do_nothing */
            break;
        case Phase___c_defines_emit:
            (void)Define_Declaration__c_defines_emit(define, buffer, compiler);
            break;
        /* #case library_type_find*/
        /* #	call define_register@(compiler, define)*/
        case Phase___ezh_emit:
            (void)Define_Declaration__ezh_emit(define, buffer, compiler);
            break;
        case Phase___ezh_scan:
            define_table = compiler->define_table;
            define_type = define->type;
            define_name = Type__base_name(define_type);
            previous_define = ((Define_Declaration)Hash_Table__lookup(define_table, ((void *)(define_name))));
            if ((previous_define == Define_Declaration__null)) {
                (void)Hash_Table__insert(define_table, ((void *)(define_name)), ((void *)(define)));
                define_clauses = define->define_clauses;
                size = Array__size_get(define_clauses);
                index = 0;
                while ((index < size)) {
                    define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
                    switch (define_clause->kind) {
                        case Define_Clause_Kind___simple:
                            simple = ((define_clause->kind == Define_Clause_Kind___simple) ? define_clause->kind__union.simple : (Simple_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1167));
                            (void)Compiler__simple_type_insert(compiler, define_name, simple->type);
                            break;
                    }
                    index = (index+1);
                }
            }
            /* #else */
            /* #    if is_external@(previous_define) && */
            /* #      is_external@(define) */
            /* #	# Everything is OK. */
            /* #	do_nothing */
            /* #    else */
            /* #	call log@(compiler, define.define.keyword, */
            /* #	  form@("Define %t% is previously defined") / */
            /* #	  f@Type(define.type)) */
            /* #	call log@(compiler., previous_define.define.keyword, */
            /* #	  form@("Define %t% is previously defined here") / */
            /* #	  f@Type(previous_define.type)) */
            break;
        case Phase___h_structs_emit:
            (void)Define_Declaration__h_structs_emit(define, buffer, compiler);
            break;
        case Phase___h_typedefs_emit:
            (void)Define_Declaration__h_typedefs_emit(define, buffer, compiler);
            break;
        case Phase___h_externs_emit:
            (void)Define_Declaration__h_externs_emit(define, buffer, compiler);
            break;
        case Phase___link_scan:

            if ((!Define_Declaration__is_enumeration(define)&&!Define_Declaration__is_simple(define)&&!Define_Declaration__is_base_type(define))) {
                (void)Array__append(compiler->scanned_types, ((void *)(define->type)));
            }
            break;
        case Phase___prefix_scan:
            (void)Define_Declaration__prefix_scan(define, buffer, compiler);
            break;
        case Phase___generate_emit:
            (void)Define_Declaration__generate_emit(define, buffer, compiler);
            break;
        case Phase___source_find:
            source = compiler->source;
            (void)Array__append(compiler->defines, ((void *)(define)));
            (void)Array__append(source->defines, ((void *)(define)));
            break;
    }
}

void Define_Declaration__variant_globals_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Variant_Clause variant;
    String kind_name;
    Type kind_type;
    String kind_type_base;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    String field_name;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 1213);
    }
    if (Define_Declaration__is_external(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_enumeration(define)) {
        /* do_nothing */
    } else {

        temporary = compiler->temporary;
        define_clauses = define->define_clauses;
        size = Array__size_get(define_clauses);
        index = 0;
        while ((index < size)) {
            define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
            switch (define_clause->kind) {
                case Define_Clause_Kind___variant:
                    variant = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1229));
                    kind_name = variant->kind_name->value;
                    kind_type = variant->kind_type;
                    kind_type_base = Type__base_name(kind_type);
                    field_clauses = variant->field_clauses;
                    field_clauses_size = Array__size_get(field_clauses);
                    field_clauses_index = 0;
                    while ((field_clauses_index < field_clauses_size)) {
                        field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                        switch (field_clause->kind) {
                            case Field_Clause_Kind___field:
                                field_name = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1240))->name->value;
                                (void)String__string_append(buffer, (t__0 = String__form(((String)"\032%k% %t%__%s% = %s%___%s%;\n")), t__1 = String__f(kind_type_base), t__2 = String__f(kind_type_base), t__3 = String__f(field_name), t__4 = String__f(kind_type_base), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__0), t__1), t__2), t__3), t__4), String__f(field_name))));
                                break;
                        }
                        field_clauses_index = (field_clauses_index+1);
                    }
                    break;
            }
            index = (index+1);
        }
    }
}

void Define_Declaration__null_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_type_base;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array item_clauses;
    Unsigned item_clauses_size;
    Unsigned item_clauses_index;
    Item_Clause item_clause;
    String item_name;
    Enumeration_Prefix_Clause enumeration_prefix;
    Array define_datas;
    Unsigned define_datas_size;
    Unsigned define_datas_index;
    Define_Data define_data;
    String new_name;
    String value;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    Field field;
    String field_name;
    Type field_type;
    String field_type_base;
    Define_Declaration field_define;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 1258);
    }
    temporary = compiler->temporary;
    define_type = define->type;
    define_type_base = Type__base_name(define_type);
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    if (Define_Declaration__is_external(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_enumeration(define)) {
        (void)String__string_append(buffer, (t__0 = String__form(((String)"\030%k% %s%__null = (%k%)0;\n")), t__1 = String__f(define_type_base), t__2 = String__f(define_type_base), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), String__f(define_type_base))));
        index = 0;
        while ((index < size)) {
            define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
            switch (define_clause->kind) {
                case Define_Clause_Kind___enumeration:
                    item_clauses = ((define_clause->kind == Define_Clause_Kind___enumeration) ? define_clause->kind__union.enumeration : (Enumeration_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1278))->item_clauses;
                    item_clauses_size = Array__size_get(item_clauses);
                    item_clauses_index = 0;
                    while ((item_clauses_index < item_clauses_size)) {
                        item_clause = ((Item_Clause)Array__fetch1(item_clauses, item_clauses_index));
                        switch (item_clause->kind) {
                            case Item_Clause_Kind___item:
                                item_name = ((item_clause->kind == Item_Clause_Kind___item) ? item_clause->kind__union.item : (Item)System__variant_object_fail((String)"\17Declaration.ezc", 1285))->name->value;
                                (void)String__string_append(buffer, (t__3 = String__form(((String)"\032%k% %s%__%s% = %s%___%s%;\n")), t__4 = String__f(define_type_base), t__5 = String__f(define_type_base), t__6 = String__f(item_name), t__7 = String__f(define_type_base), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__3), t__4), t__5), t__6), t__7), String__f(item_name))));
                                break;
                        }
                        item_clauses_index = (item_clauses_index+1);
                    }
                    break;
                case Define_Clause_Kind___enumeration_prefix:
                    enumeration_prefix = ((define_clause->kind == Define_Clause_Kind___enumeration_prefix) ? define_clause->kind__union.enumeration_prefix : (Enumeration_Prefix_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1293));
                    define_datas = enumeration_prefix->define_datas;
                    define_datas_size = 0;
                    if (enumeration_prefix->define_datas_initialized) {
                        define_datas_size = Array__size_get(define_datas);
                    }
                    define_datas_index = 0;
                    while ((define_datas_index < define_datas_size)) {
                        define_data = ((Define_Data)Array__fetch1(define_datas, define_datas_index));
                        new_name = define_data->new_name;
                        value = define_data->value;
                        (void)String__string_append(buffer, (t__8 = String__form(((String)"\032%s% %s%__%s% = %s%___%s%;\n")), t__9 = String__f(define_type_base), t__10 = String__f(define_type_base), t__11 = String__f(new_name), t__12 = String__f(define_type_base), String__divide(String__remainder(String__remainder(String__remainder(String__remainder((t__8), t__9), t__10), t__11), t__12), String__f(new_name))));
                        (void)String__string_append(buffer, (t__13 = String__form(((String)"\036Unsigned Unsigned__%s% = %s%;\n")), t__14 = String__f(new_name), String__divide(String__remainder((t__13), t__14), String__f(value))));
                        define_datas_index = (define_datas_index+1);
                    }
                    break;
            }
            index = (index+1);
        }
    } else if ((Define_Declaration__is_record(define)||Define_Declaration__is_variant(define))) {

        /* # Output the null object: */
        (void)String__string_append(buffer, (t__15 = String__form(((String)"\044struct %s%__Struct %s%__Initial = {\n")), t__16 = String__f(define_type_base), String__divide(String__remainder((t__15), t__16), String__f(define_type_base))));
        index = 0;
        while ((index < size)) {
            define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
            switch (define_clause->kind) {
                case Define_Clause_Kind___record:
                    field_clauses = ((define_clause->kind == Define_Clause_Kind___record) ? define_clause->kind__union.record : (Record_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1324))->field_clauses;
                    field_clauses_size = Array__size_get(field_clauses);
                    field_clauses_index = 0;
                    while ((field_clauses_index < field_clauses_size)) {
                        field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                        switch (field_clause->kind) {
                            case Field_Clause_Kind___field:
                                field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1331));
                                field_name = field->name->value;
                                field_type = field->type;
                                field_type_base = Type__base_name(field_type);
                                field_define = ((Define_Declaration)Hash_Table__lookup(compiler->define_table, ((void *)(field_type_base))));
                                if (Type__is_parameter(field_type, define_type)) {

                                    (void)String__buffer_append(((String)"\005    0"), buffer);
                                } else if (Type__is_routine(field_type)) {
                                    (void)String__buffer_append(((String)"\005    0"), buffer);
                                } else if ((field_define == Define_Declaration__null)) {
                                    (void)Compiler__log(compiler, field->name, (t__17 = String__form(((String)"\035Field type %t% is not defined")), String__divide((t__17), Type__f(field_type))));
                                } else if (Type__is_scalar(field_type)) {
                                    (void)String__buffer_append(((String)"\005    0"), buffer);
                                } else if (Define_Declaration__is_enumeration(field_define)) {
                                    (void)String__string_append(buffer, (t__18 = String__form(((String)"\012    (%k%)0")), String__divide((t__18), String__f(field_type_base))));
                                } else if (Type__is_parameterized(field_type)) {
                                    (void)String__string_append(buffer, (t__19 = String__form(((String)"\012    (%k%)0")), String__divide((t__19), String__f(field_type_base))));
                                } else {
                                    (void)String__string_append(buffer, (t__20 = String__form(((String)"\021    &%s%__Initial")), String__divide((t__20), String__f(field_type_base))));
                                }
                                (void)String__buffer_append(((String)"\002,\n"), buffer);
                                break;
                        }
                        field_clauses_index = (field_clauses_index+1);
                    }
                    break;
                case Define_Clause_Kind___variant:
                    /* do_nothing */
                    break;
            }
            index = (index+1);
        }
        (void)String__buffer_append(((String)"\004};\n\n"), buffer);
        (void)String__string_append(buffer, (t__21 = String__form(((String)"\037%k% %s%__null = &%s%__Initial;\n")), t__22 = String__f(define_type_base), t__23 = String__f(define_type_base), String__divide(String__remainder(String__remainder((t__21), t__22), t__23), String__f(define_type_base))));
    } else if (Define_Declaration__is_record_import(define)) {

        (void)String__string_append(buffer, (t__24 = String__form(((String)"\017%k% %s%__null;\n")), t__25 = String__f(define_type_base), String__divide(String__remainder((t__24), t__25), String__f(define_type_base))));
    } else if (Define_Declaration__is_registers(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_simple(define)) {
        if (Define_Declaration__is_simple_numeric(define)) {
            (void)String__string_append(buffer, (t__26 = String__form(((String)"\030%k% %s%__null = (%t%)0;\n")), t__27 = String__f(define_type_base), t__28 = String__f(define_type_base), String__divide(String__remainder(String__remainder((t__26), t__27), t__28), String__f(define_type_base))));
        }
    } else if (Define_Declaration__is_base_type(define)) {
        (void)String__string_append(buffer, (t__29 = String__form(((String)"\017%k% %s%__null;\n")), t__30 = String__f(define_type_base), String__divide(String__remainder((t__29), t__30), String__f(define_type_base))));
    } else {
        (void)Compiler__log(compiler, define->define->keyword, ((String)"\070No record, enumeration, variant, or record_import clause"));
    }
}

void Define_Declaration__erase_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_name;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array field_clauses;
    Unsigned fields_size;
    Unsigned fields_index;
    Field_Clause field_clause;
    Field field;
    String field_name;
    Type field_type;
    String field_type_name;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 1396);
    }
    temporary = compiler->temporary;
    define_type = define->type;
    define_name = Type__base_name(define_type);
    if ((Define_Declaration__is_external(define)||Define_Declaration__is_record_import(define))) {
        /* do_nothing */
    } else if (Define_Declaration__is_enumeration(define)) {

        (void)String__string_append(buffer, (t__0 = String__form(((String)"\021void %s%__erase(\n")), String__divide((t__0), String__f(define_name))));
        (void)String__string_append(buffer, (t__1 = String__form(((String)"\014  %k% %lk%)\n")), t__2 = String__f(define_name), String__divide(String__remainder((t__1), t__2), String__f(define_name))));
        (void)String__buffer_append(((String)"\002{\n"), buffer);
        (void)String__buffer_append(((String)"\025    /* do nothing */\n"), buffer);
        (void)String__buffer_append(((String)"\003}\n\n"), buffer);
    } else if ((Define_Declaration__is_record(define)||Define_Declaration__is_variant(define))) {


        /* #FIXME: The header of the erase routine can be refactored!!! */
        /* # Output the erase routine: */
        (void)String__string_append(buffer, (t__3 = String__form(((String)"\021void %s%__erase(\n")), String__divide((t__3), String__f(define_name))));
        (void)String__string_append(buffer, (t__4 = String__form(((String)"\014  %k% %lk%)\n")), t__5 = String__f(define_name), String__divide(String__remainder((t__4), t__5), String__f(define_name))));
        (void)String__buffer_append(((String)"\002{\n"), buffer);
        define_clauses = define->define_clauses;
        size = Array__size_get(define_clauses);
        index = 0;
        while ((index < size)) {
            define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
            switch (define_clause->kind) {
                case Define_Clause_Kind___record:
                    field_clauses = ((define_clause->kind == Define_Clause_Kind___record) ? define_clause->kind__union.record : (Record_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1434))->field_clauses;
                    fields_size = Array__size_get(field_clauses);
                    fields_index = 0;
                    while ((fields_index < fields_size)) {
                        field_clause = ((Field_Clause)Array__fetch1(field_clauses, fields_index));
                        switch (field_clause->kind) {
                            case Field_Clause_Kind___field:
                                field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1441));
                                field_name = field->name->value;
                                field_type = field->type;
                                field_type_name = Type__base_name(field_type);
                                switch (field_type->kind) {
                                    case Type_Kind___simple:
                                        if (Type__is_parameter(field_type, define_type)) {
                                            (void)String__string_append(buffer, (t__6 = String__form(((String)"\051    /* %s% (type %t%) is parameterized */")), t__7 = String__f(field_name), String__divide(String__remainder((t__6), t__7), Type__f(field_type))));
                                        } else {
                                            if (Type__is_float_scalar(field_type)) {
                                                (void)String__string_append(buffer, (t__8 = String__form(((String)"\025    %lk%->%k% = 0.0;\n")), t__9 = String__f(define_name), String__divide(String__remainder((t__8), t__9), String__f(field_name))));
                                            } else if (Type__is_scalar(field_type)) {
                                                (void)String__string_append(buffer, (t__10 = String__form(((String)"\023    %lk%->%k% = 0;\n")), t__11 = String__f(define_name), String__divide(String__remainder((t__10), t__11), String__f(field_name))));
                                            } else {
                                                (void)String__string_append(buffer, (t__12 = String__form(((String)"\034    %lk%->%lk% = %s%__null;\n")), t__13 = String__f(define_name), t__14 = String__f(field_name), String__divide(String__remainder(String__remainder((t__12), t__13), t__14), String__f(field_type_name))));
                                            }
                                        }
                                        break;
                                    case Type_Kind___parameterized:
                                        (void)String__string_append(buffer, (t__15 = String__form(((String)"\032    if (%lk%->%k% == 0) {\n")), t__16 = String__f(define_name), String__divide(String__remainder((t__15), t__16), String__f(field_name))));
                                        (void)String__string_append(buffer, (t__17 = String__form(((String)"\031\t%lk%->%k% = %s%__new();\n")), t__18 = String__f(define_name), t__19 = String__f(field_name), String__divide(String__remainder(String__remainder((t__17), t__18), t__19), String__f(field_type_name))));
                                        (void)String__buffer_append(((String)"\015    } else {\n"), buffer);
                                        (void)String__string_append(buffer, (t__20 = String__form(((String)"\030\t%s%__erase(%lk%->%k%);\n")), t__21 = String__f(field_type_name), t__22 = String__f(define_name), String__divide(String__remainder(String__remainder((t__20), t__21), t__22), String__f(field_name))));
                                        (void)String__buffer_append(((String)"\006    }\n"), buffer);
                                        break;
                                    case Type_Kind___routine:
                                        (void)String__buffer_append(buffer, (t__23 = String__form(((String)"\020\t%lk%->%k% = 0;\n")), t__24 = String__f(define_name), String__divide(String__remainder((t__23), t__24), String__f(field_name))));
                                        break;
                                }
                                break;
                        }
                        fields_index = (fields_index+1);
                    }
                    break;
                case Define_Clause_Kind___variant:

                    /* do_nothing */
                    break;
            }
            index = (index+1);
        }
        (void)String__buffer_append(((String)"\003}\n\n"), buffer);
    } else if (Define_Declaration__is_registers(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_simple(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_base_type(define)) {
        /* do_nothing */
    } else {
        (void)Compiler__log(compiler, define->define->keyword, ((String)"\101There is no enumeration, record, variant, or record_import clause"));
    }
}

void Define_Declaration__new_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_name;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    Field field;
    String field_name;
    Type field_type;
    String field_type_base;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 1512);
    }
    if (Define_Declaration__is_external(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_enumeration(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_registers(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_simple(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_base_type(define)) {
        /* do_nothing */
    } else {

        temporary = compiler->temporary;
        define_type = define->type;
        define_name = Type__base_name(define_type);
        (void)String__string_append(buffer, (t__0 = String__form(((String)"\023%k% %s%__new(void)\n")), t__1 = String__f(define_name), String__divide(String__remainder((t__0), t__1), String__f(define_name))));
        (void)String__buffer_append(((String)"\002{\n"), buffer);
        (void)String__string_append(buffer, (t__2 = String__form(((String)"\016    %k% %lk%;\n")), t__3 = String__f(define_name), String__divide(String__remainder((t__2), t__3), String__f(define_name))));
        (void)String__buffer_append(((String)"\041    extern void *malloc(size_t);\n"), buffer);
        (void)String__buffer_append(((String)"\001\n"), buffer);
        (void)String__string_append(buffer, (t__4 = String__form(((String)"\047    %lk% = (%k%)malloc(sizeof(*%lk%));\n")), t__5 = String__f(define_name), t__6 = String__f(define_name), String__divide(String__remainder(String__remainder((t__4), t__5), t__6), String__f(define_name))));
        /* # Initialize fields: */
        define_clauses = define->define_clauses;
        size = Array__size_get(define_clauses);
        index = 0;
        while ((index < size)) {
            define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
            switch (define_clause->kind) {
                case Define_Clause_Kind___record:
                    field_clauses = ((define_clause->kind == Define_Clause_Kind___record) ? define_clause->kind__union.record : (Record_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1553))->field_clauses;
                    field_clauses_size = Array__size_get(field_clauses);
                    field_clauses_index = 0;
                    while ((field_clauses_index < field_clauses_size)) {
                        field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                        switch (field_clause->kind) {
                            case Field_Clause_Kind___field:
                                field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1560));
                                field_name = field->name->value;
                                field_type = field->type;
                                field_type_base = Type__base_name(field_type);
                                switch (field_type->kind) {
                                    case Type_Kind___simple:
                                        if (Type__is_parameter(field_type, define->type)) {
                                            (void)String__string_append(buffer, (t__7 = String__form(((String)"\023    %lk%->%k% = 0;\n")), t__8 = String__f(define_name), String__divide(String__remainder((t__7), t__8), String__f(field_name))));
                                        } else {
                                            (void)String__string_append(buffer, (t__9 = String__form(((String)"\034    %lk%->%k% = %cb%__null;\n")), t__10 = String__f(define_name), t__11 = String__f(field_name), String__divide(String__remainder(String__remainder((t__9), t__10), t__11), Type__f(field_type))));
                                        }
                                        break;
                                    case Type_Kind___parameterized:

                                        (void)String__string_append(buffer, (t__12 = String__form(((String)"\034    %lk%->%k% = %s%__new();\n")), t__13 = String__f(define_name), t__14 = String__f(field_name), String__divide(String__remainder(String__remainder((t__12), t__13), t__14), String__f(field_type_base))));
                                        break;
                                    case Type_Kind___routine:
                                        (void)String__string_append(buffer, (t__15 = String__form(((String)"\023    %lk%->%k% = 0;\n")), t__16 = String__f(define_name), String__divide(String__remainder((t__15), t__16), String__f(field_name))));
                                        break;
                                }
                                break;
                        }
                        field_clauses_index = (field_clauses_index+1);
                    }
                    break;
                case Define_Clause_Kind___variant:

                    /* do_nothing */
                    break;
                case Define_Clause_Kind___record_import:

                    /* do_nothing */
                    break;
            }
            index = (index+1);
        }
        (void)String__string_append(buffer, (t__17 = String__form(((String)"\021    return %lk%;\n")), String__divide((t__17), String__f(define_name))));
        (void)String__buffer_append(((String)"\003}\n\n"), buffer);
    }
}

void Define_Declaration__ezh_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_name;
    Array define_clauses;
    Unsigned size;
    Traverser traverser;
    Unsigned index;
    Define_Clause define_clause;
    Array item_clauses;
    Unsigned item_clauses_size;
    Unsigned item_clauses_index;
    Item_Clause item_clause;
    String item_name;
    Enumeration_Prefix_Clause enumeration_prefix;
    Array define_datas;
    Unsigned define_datas_size;
    Unsigned define_datas_index;
    Define_Data define_data;
    String new_name;
    Variant_Clause variant;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 1607);
    }
    temporary = compiler->temporary;
    define_type = define->type;
    define_name = Type__base_name(define_type);
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    traverser = compiler->traverser;
    traverser->buffer = buffer;
    (void)Define_Declaration__traverse(define, traverser);
    if (Define_Declaration__is_external(define)) {
        /* do_nothing */
    } else if (Define_Declaration__is_simple(define)) {
        (void)String__string_append(buffer, (t__0 = String__form(((String)"\047external null@%t% %t% = %c%__null\t#D2\n\n")), t__1 = Type__f(define_type), t__2 = Type__f(define_type), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), Type__f(define_type))));
    } else if (Define_Declaration__is_enumeration(define)) {

        index = 0;
        while ((index < size)) {
            define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
            switch (define_clause->kind) {
                case Define_Clause_Kind___enumeration:

                    item_clauses = ((define_clause->kind == Define_Clause_Kind___enumeration) ? define_clause->kind__union.enumeration : (Enumeration_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1639))->item_clauses;
                    item_clauses_size = Array__size_get(item_clauses);
                    item_clauses_index = 0;
                    while ((item_clauses_index < item_clauses_size)) {
                        item_clause = ((Item_Clause)Array__fetch1(item_clauses, item_clauses_index));
                        switch (item_clause->kind) {
                            case Item_Clause_Kind___item:
                                item_name = ((item_clause->kind == Item_Clause_Kind___item) ? item_clause->kind__union.item : (Item)System__variant_object_fail((String)"\17Declaration.ezc", 1646))->name->value;
                                (void)String__string_append(buffer, (t__3 = String__form(((String)"\031external %s%@%s% %s%\t#D3\n")), t__4 = String__f(item_name), t__5 = String__f(define_name), String__divide(String__remainder(String__remainder((t__3), t__4), t__5), String__f(define_name))));
                                break;
                        }
                        item_clauses_index = (item_clauses_index+1);
                    }
                    break;
                case Define_Clause_Kind___enumeration_prefix:

                    enumeration_prefix = ((define_clause->kind == Define_Clause_Kind___enumeration_prefix) ? define_clause->kind__union.enumeration_prefix : (Enumeration_Prefix_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1653));
                    define_datas = enumeration_prefix->define_datas;
                    define_datas_size = Array__size_get(define_datas);
                    /* #call d@(form@("define_datas_size=%d%\n\") / */
                    /* #  f@(define_datas_size)) */
                    define_datas_index = 0;
                    while ((define_datas_index < define_datas_size)) {
                        define_data = ((Define_Data)Array__fetch1(define_datas, define_datas_index));
                        new_name = define_data->new_name;
                        (void)String__string_append(buffer, (t__6 = String__form(((String)"\031external %s%@%s% %s%\t#D4\n")), t__7 = String__f(new_name), t__8 = String__f(define_name), String__divide(String__remainder(String__remainder((t__6), t__7), t__8), String__f(define_name))));
                        (void)String__string_append(buffer, (t__9 = String__form(((String)"\043external %s%@Unsigned Unsigned\t#D5\n")), String__divide((t__9), String__f(new_name))));
                        define_datas_index = (define_datas_index+1);
                    }
                    break;
            }
            index = (index+1);
        }
        (void)String__string_append(buffer, (t__10 = String__form(((String)"\033routine string_convert@%s%\n")), String__divide((t__10), String__f(define_name))));
        (void)String__string_append(buffer, (t__11 = String__form(((String)"\023    takes %ls% %s%\n")), t__12 = String__f(define_name), String__divide(String__remainder((t__11), t__12), String__f(define_name))));
        (void)String__buffer_append(((String)"\023    returns String\n"), buffer);
        (void)String__string_append(buffer, (t__13 = String__form(((String)"\041    external %s%__string_convert\n")), String__divide((t__13), String__f(define_name))));
        (void)String__buffer_append(((String)"\001\n"), buffer);
        (void)String__string_append(buffer, (t__14 = String__form(((String)"\067    # This routine returns a {String} version of %ls%.\n")), String__divide((t__14), String__f(define_name))));
        (void)String__buffer_append(((String)"\002\n\n"), buffer);
    } else {

        /* # routine prototypes: */
        /* # null object: */
        (void)String__string_append(buffer, (t__15 = String__form(((String)"\033external null@%s% %s%\t#D6\n\n")), t__16 = String__f(define_name), String__divide(String__remainder((t__15), t__16), String__f(define_name))));
        /* # new routine: */
        (void)String__string_append(buffer, (t__17 = String__form(((String)"\020routine new@%t%\n")), String__divide((t__17), Type__f(define_type))));
        (void)String__buffer_append(((String)"\022    takes_nothing\n"), buffer);
        (void)String__string_append(buffer, (t__18 = String__form(((String)"\020    returns %t%\n")), String__divide((t__18), Type__f(define_type))));
        (void)String__string_append(buffer, (t__19 = String__form(((String)"\026    external %s%__new\n")), String__divide((t__19), String__f(define_name))));
        (void)String__buffer_append(((String)"\001\n"), buffer);
        (void)String__string_append(buffer, (t__20 = String__form(((String)"\066    # This routine allocates and returns a new {%s%}.\n")), String__divide((t__20), String__f(define_name))));
        (void)String__buffer_append(((String)"\002\n\n"), buffer);
        /* # erase routine: */
        (void)String__string_append(buffer, (t__21 = String__form(((String)"\022routine erase@%t%\n")), String__divide((t__21), Type__f(define_type))));
        (void)String__string_append(buffer, (t__22 = String__form(((String)"\025    takes object %t%\n")), String__divide((t__22), Type__f(define_type))));
        (void)String__buffer_append(((String)"\024    returns_nothing\n"), buffer);
        (void)String__string_append(buffer, (t__23 = String__form(((String)"\030    external %s%__erase\n")), String__divide((t__23), String__f(define_name))));
        (void)String__buffer_append(((String)"\001\n"), buffer);
        (void)String__buffer_append(((String)"\047    # This routine will erase {object}\n"), buffer);
        (void)String__buffer_append(((String)"\002\n\n"), buffer);
        /* #put@("  <=ezh emit\n\", debug_stream) */
    }
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___variant:
                variant = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1736));
                (void)String__string_append(buffer, (t__24 = String__form(((String)"\013define %t%\n")), String__divide((t__24), Type__f(variant->kind_type))));
                (void)String__buffer_append(((String)"\020    enumeration\n"), buffer);
                field_clauses = variant->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            (void)String__string_append(buffer, (t__25 = String__form(((String)"\005\t%s%\n")), String__divide((t__25), String__f(((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1750))->name->value))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                (void)String__buffer_append(((String)"\001\n"), buffer);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            (void)String__string_append(buffer, (t__26 = String__form(((String)"\031external %s%@%t% %t%\t#D7\n")), t__27 = String__f(((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1761))->name->value), t__28 = Type__f(variant->kind_type), String__divide(String__remainder(String__remainder((t__26), t__27), t__28), Type__f(variant->kind_type))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                (void)String__buffer_append(((String)"\001\n"), buffer);
                break;
        }
        index = (index+1);
    }
}

void Define_Declaration__h_externs_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_name;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array item_clauses;
    Unsigned item_clauses_size;
    Unsigned item_clauses_index;
    Item_Clause item_clause;
    Enumeration_Prefix_Clause enumeration_prefix;
    Array define_datas;
    Unsigned define_datas_size;
    Unsigned define_datas_index;
    Define_Data define_data;
    String new_name;
    Variant_Clause variant;
    String kind_name;
    Type kind_type;
    String kind_type_base;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    String field_name;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    temporary = compiler->temporary;
    define_type = define->type;
    define_name = Type__base_name(define_type);
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    if ((Define_Declaration__is_external(define)||Define_Declaration__is_registers(define))) {

        /* do_nothing */
    } else if ((Define_Declaration__is_simple(define)||Define_Declaration__is_base_type(define))) {

        /* #  form@("extern %k% %t%__null;//D2//\n\") % */
        /* #  f@(define_type) / f@(define_type)) */
    } else if (Define_Declaration__is_enumeration(define)) {

        index = 0;
        while ((index < size)) {
            define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
            switch (define_clause->kind) {
                case Define_Clause_Kind___enumeration:
                    item_clauses = ((define_clause->kind == Define_Clause_Kind___enumeration) ? define_clause->kind__union.enumeration : (Enumeration_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1799))->item_clauses;
                    item_clauses_size = Array__size_get(item_clauses);
                    item_clauses_index = 0;
                    while ((item_clauses_index < item_clauses_size)) {
                        item_clause = ((Item_Clause)Array__fetch1(item_clauses, item_clauses_index));
                        switch (item_clause->kind) {
                            case Item_Clause_Kind___item:
                                (void)String__string_append(buffer, (t__0 = String__form(((String)"\033extern %k% %s%__%s%;/*D3*/\n")), t__1 = String__f(define_name), t__2 = String__f(define_name), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), String__f(((item_clause->kind == Item_Clause_Kind___item) ? item_clause->kind__union.item : (Item)System__variant_object_fail((String)"\17Declaration.ezc", 1809))->name->value))));
                                break;
                        }
                        item_clauses_index = (item_clauses_index+1);
                    }
                    break;
                case Define_Clause_Kind___enumeration_prefix:
                    enumeration_prefix = ((define_clause->kind == Define_Clause_Kind___enumeration_prefix) ? define_clause->kind__union.enumeration_prefix : (Enumeration_Prefix_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1812));
                    define_datas = enumeration_prefix->define_datas;
                    define_datas_size = Array__size_get(define_datas);
                    define_datas_index = 0;
                    while ((define_datas_index < define_datas_size)) {
                        define_data = ((Define_Data)Array__fetch1(define_datas, define_datas_index));
                        new_name = define_data->new_name;
                        (void)String__string_append(buffer, (t__3 = String__form(((String)"\045extern Unsigned Unsigned__%s%;/*D4*/\n")), String__divide((t__3), String__f(new_name))));
                        (void)String__string_append(buffer, (t__4 = String__form(((String)"\033extern %s% %s%__%s%;/*D5*/\n")), t__5 = String__f(define_name), t__6 = String__f(define_name), String__divide(String__remainder(String__remainder((t__4), t__5), t__6), String__f(new_name))));
                        define_datas_index = (define_datas_index+1);
                    }
                    break;
            }
            index = (index+1);
        }
        (void)String__string_append(buffer, (t__7 = String__form(((String)"\035extern %cb% %s%__null;/*D6*/\n")), t__8 = Type__f(define_type), String__divide(String__remainder((t__7), t__8), String__f(define_name))));
        (void)String__string_append(buffer, (t__9 = String__form(((String)"\056extern String %s%__string_convert(%k%);/*D7*/\n")), t__10 = String__f(define_name), String__divide(String__remainder((t__9), t__10), String__f(define_name))));
        (void)String__string_append(buffer, (t__11 = String__form(((String)"\043extern void %s%__erase(%k%);/*D8*/\n")), t__12 = String__f(define_name), String__divide(String__remainder((t__11), t__12), String__f(define_name))));
    } else {

        index = 0;
        while ((index < size)) {
            define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
            switch (define_clause->kind) {
                case Define_Clause_Kind___variant:
                    variant = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1846));
                    kind_name = variant->kind_name->value;
                    kind_type = variant->kind_type;
                    kind_type_base = Type__base_name(kind_type);
                    field_clauses = variant->field_clauses;
                    field_clauses_size = Array__size_get(field_clauses);
                    field_clauses_index = 0;
                    while ((field_clauses_index < field_clauses_size)) {
                        field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                        switch (field_clause->kind) {
                            case Field_Clause_Kind___field:
                                field_name = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1858))->name->value;
                                (void)String__string_append(buffer, (t__13 = String__form(((String)"\033extern %k% %s%__%s%;/*D9*/\n")), t__14 = String__f(kind_type_base), t__15 = String__f(kind_type_base), String__divide(String__remainder(String__remainder((t__13), t__14), t__15), String__f(field_name))));
                                break;
                        }
                        field_clauses_index = (field_clauses_index+1);
                    }
                    break;
            }
            index = (index+1);
        }
        /* # Variant/ Record: */
        (void)String__string_append(buffer, (t__16 = String__form(((String)"\035extern %s% %s%__null;/*D10*/\n")), t__17 = String__f(define_name), String__divide(String__remainder((t__16), t__17), String__f(define_name))));
        (void)String__string_append(buffer, (t__18 = String__form(((String)"\042extern %s% %s%__new(void);/*D11*/\n")), t__19 = String__f(define_name), String__divide(String__remainder((t__18), t__19), String__f(define_name))));
        (void)String__string_append(buffer, (t__20 = String__form(((String)"\044extern void %s%__erase(%s%);/*D12*/\n")), t__21 = String__f(define_name), String__divide(String__remainder((t__20), t__21), String__f(define_name))));
    }
}

void Define_Declaration__prefix_scan(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Enumeration_Prefix_Clause enumeration_prefix;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___enumeration_prefix:
                enumeration_prefix = ((define_clause->kind == Define_Clause_Kind___enumeration_prefix) ? define_clause->kind__union.enumeration_prefix : (Enumeration_Prefix_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1895));
                (void)Array__append(compiler->enumeration_prefixes, ((void *)(enumeration_prefix)));
                break;
        }
        index = (index+1);
    }
}

void Define_Declaration__generate_emit(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    Type define_type;
    String define_name;
    Logical null_external_needed;
    Logical new_needed;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Enumeration_Clause enumeration;
    Array item_clauses;
    Unsigned item_clauses_size;
    Unsigned item_clauses_index;
    Item_Clause item_clause;
    Item item;
    String item_name;
    Variant_Clause variant;
    Type kind_type;
    String kind_name;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    Field field;
    Type field_type;
    String field_name;
    Enumeration_Prefix_Clause enumeration_prefix;
    Array define_datas;
    Unsigned define_datas_size;
    Unsigned define_datas_index;
    Define_Data define_data;
    String new_name;
    String value;
    Define_Data define_data_next;
    Generate_Clause generate;
    Comma_Separated generate_names;
    Generate_Name generate_name;
    String name;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    String t__35;
    String t__36;
    String t__37;
    String t__38;
    String t__39;
    String t__40;
    String t__41;
    String t__42;
    String t__43;
    String t__44;
    String t__45;
    String t__46;
    String t__47;
    String t__48;
    String t__49;
    String t__50;
    String t__51;
    String t__52;
    String t__53;
    String t__54;
    String t__55;
    String t__56;
    String t__57;
    String t__58;
    String t__59;
    String t__60;
    String t__61;
    String t__62;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 1909);
    }
    define_type = define->type;
    define_name = Type__base_name(define_type);
    null_external_needed = Logical__true;
    new_needed = Logical__true;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___end_of_line:
            case Define_Clause_Kind___note:
            case Define_Clause_Kind___error:
            case Define_Clause_Kind___registers:
            case Define_Clause_Kind___record_import:
                /* do_nothing */
                break;
            case Define_Clause_Kind___base_type:
                /* do_nothing */
                break;
            case Define_Clause_Kind___enumeration:
                enumeration = ((define_clause->kind == Define_Clause_Kind___enumeration) ? define_clause->kind__union.enumeration : (Enumeration_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1928));
                item_clauses = enumeration->item_clauses;
                item_clauses_size = Array__size_get(item_clauses);
                item_clauses_index = 0;
                while ((item_clauses_index < item_clauses_size)) {
                    item_clause = ((Item_Clause)Array__fetch1(item_clauses, item_clauses_index));
                    switch (item_clause->kind) {
                        case Item_Clause_Kind___item:
                            item = ((item_clause->kind == Item_Clause_Kind___item) ? item_clause->kind__union.item : (Item)System__variant_object_fail((String)"\17Declaration.ezc", 1936));
                            item_name = item->name->value;
                            (void)String__string_append(buffer, (t__0 = String__form(((String)"\031external %s%@%s% %s%\t#D8\n")), t__1 = String__f(item_name), t__2 = String__f(define_name), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), String__f(define_name))));
                            break;
                    }
                    item_clauses_index = (item_clauses_index+1);
                }
                /* # Now generate the string convert routine: */
                (void)String__string_append(buffer, (t__3 = String__form(((String)"\033routine string_convert@%t%\n")), String__divide((t__3), Type__f(define_type))));
                (void)String__string_append(buffer, (t__4 = String__form(((String)"\022    takes %l% %t%\n")), t__5 = String__f(define_name), String__divide(String__remainder((t__4), t__5), Type__f(define_type))));
                (void)String__string_append(buffer, ((String)"\024    returns String\n\n"));
                /* # Now generate {string_convert} routine: */
                (void)String__string_append(buffer, (t__6 = String__form(((String)"\017    switch %l%\n")), String__divide((t__6), String__f(define_name))));
                item_clauses_index = 0;
                while ((item_clauses_index < item_clauses_size)) {
                    item_clause = ((Item_Clause)Array__fetch1(item_clauses, item_clauses_index));
                    switch (item_clause->kind) {
                        case Item_Clause_Kind___item:
                            item = ((item_clause->kind == Item_Clause_Kind___item) ? item_clause->kind__union.item : (Item)System__variant_object_fail((String)"\17Declaration.ezc", 1959));
                            item_name = item->name->value;
                            (void)String__string_append(buffer, (t__7 = String__form(((String)"\017      case %l%\n")), String__divide((t__7), String__f(item_name))));
                            (void)String__string_append(buffer, (t__8 = String__form(((String)"\014\treturn %v%\n")), String__divide((t__8), String__f(item_name))));
                            break;
                    }
                    item_clauses_index = (item_clauses_index+1);
                }
                (void)String__string_append(buffer, ((String)"\017    return \"\"\n\n"));
                break;
            case Define_Clause_Kind___record:
                /* do_nothing */
                break;
            case Define_Clause_Kind___external:
                null_external_needed = Logical__false;
                new_needed = Logical__false;
                break;
            case Define_Clause_Kind___generate:
                /* do_nothing */
                break;
            case Define_Clause_Kind___simple:
                (void)String__string_append(buffer, (t__9 = String__form(((String)"\046external null@%t% = \"%c%__null\"\t#D13\n\n")), t__10 = Type__f(define_type), String__divide(String__remainder((t__9), t__10), Type__f(define_type))));
                null_external_needed = Logical__false;
                break;
            case Define_Clause_Kind___simple_numeric:
                /* do_nothing */
                break;
            case Define_Clause_Kind___variant:
                variant = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 1982));
                kind_type = variant->kind_type;
                kind_name = Type__base_name(kind_type);
                /* # Generate enumeration: */
                (void)String__string_append(buffer, (t__11 = String__form(((String)"\013define %t%\n")), String__divide((t__11), Type__f(kind_type))));
                (void)String__string_append(buffer, ((String)"\020    enumeration\n"));
                /* # Generate the enumeration names: */
                field_clauses = variant->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 1998));
                            (void)String__string_append(buffer, (t__12 = String__form(((String)"\005\t%s%\n")), String__divide((t__12), String__f(field->name->value))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                (void)String__string_append(buffer, ((String)"\001\n"));
                /* # Now do it again for externals: */
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 2010));
                            field_type = field->type;
                            (void)String__string_append(buffer, (t__13 = String__form(((String)"\031external %s%@%t% %t%\t#D9\n")), t__14 = String__f(field->name->value), t__15 = Type__f(kind_type), String__divide(String__remainder(String__remainder((t__13), t__14), t__15), Type__f(kind_type))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                (void)String__string_append(buffer, ((String)"\001\n"));
                /* # Now generate the string convert routine: */
                (void)String__string_append(buffer, (t__16 = String__form(((String)"\033routine string_convert@%t%\n")), String__divide((t__16), Type__f(kind_type))));
                (void)String__string_append(buffer, (t__17 = String__form(((String)"\022    takes %l% %t%\n")), t__18 = String__f(kind_name), String__divide(String__remainder((t__17), t__18), Type__f(kind_type))));
                (void)String__string_append(buffer, ((String)"\024    returns String\n\n"));
                (void)String__string_append(buffer, (t__19 = String__form(((String)"\017    switch %l%\n")), String__divide((t__19), String__f(kind_name))));
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 2032));
                            field_name = field->name->value;
                            (void)String__string_append(buffer, (t__20 = String__form(((String)"\017      case %l%\n")), String__divide((t__20), String__f(field_name))));
                            (void)String__string_append(buffer, (t__21 = String__form(((String)"\014\treturn %v%\n")), String__divide((t__21), String__f(field_name))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                (void)String__string_append(buffer, ((String)"\017    return \"\"\n\n"));
                break;
            case Define_Clause_Kind___enumeration_prefix:
                enumeration_prefix = ((define_clause->kind == Define_Clause_Kind___enumeration_prefix) ? define_clause->kind__union.enumeration_prefix : (Enumeration_Prefix_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 2042));
                define_datas = enumeration_prefix->define_datas;
                define_datas_size = Array__size_get(define_datas);
                if ((define_datas_size != 0)) {

                    (void)String__string_append(buffer, (t__22 = String__form(((String)"\022routine value@%s%\n")), String__divide((t__22), String__f(define_name))));
                    (void)String__string_append(buffer, (t__23 = String__form(((String)"\022    takes %l% %s%\n")), t__24 = String__f(define_name), String__divide(String__remainder((t__23), t__24), String__f(define_name))));
                    (void)String__string_append(buffer, ((String)"\026    returns Unsigned\n\n"));
                    (void)String__string_append(buffer, (t__25 = String__form(((String)"\042    # Return the value of {%l%}.\n\n")), String__divide((t__25), String__f(define_name))));
                    (void)String__string_append(buffer, ((String)"\020    value :@= 0\n"));
                    (void)String__string_append(buffer, (t__26 = String__form(((String)"\017    switch %l%\n")), String__divide((t__26), String__f(define_name))));
                    define_datas_index = 0;
                    while ((define_datas_index < define_datas_size)) {
                        define_data = ((Define_Data)Array__fetch1(define_datas, define_datas_index));
                        new_name = define_data->new_name;
                        value = define_data->value;
                        (void)String__string_append(buffer, (t__27 = String__form(((String)"\017      case %s%\n")), String__divide((t__27), String__f(new_name))));
                        define_datas_index = (define_datas_index+1);
                        (void)String__string_append(buffer, (t__28 = String__form(((String)"\016\tvalue := %s%\n")), String__divide((t__28), String__f(value))));
                    }
                    (void)String__string_append(buffer, ((String)"\022    return value\n\n"));
                    /* # Generate string routine: */
                    (void)String__string_append(buffer, (t__29 = String__form(((String)"\023routine string@%s%\n")), String__divide((t__29), String__f(define_name))));
                    (void)String__string_append(buffer, (t__30 = String__form(((String)"\022    takes %l% %s%\n")), t__31 = String__f(define_name), String__divide(String__remainder((t__30), t__31), String__f(define_name))));
                    (void)String__string_append(buffer, ((String)"\024    returns String\n\n"));
                    (void)String__string_append(buffer, (t__32 = String__form(((String)"\044    # Return the string for {%l%}.\n\n")), String__divide((t__32), String__f(define_name))));
                    (void)String__string_append(buffer, ((String)"\022    result :@= \"\"\n"));
                    (void)String__string_append(buffer, (t__33 = String__form(((String)"\017    switch %l%\n")), String__divide((t__33), String__f(define_name))));
                    define_datas_index = 0;
                    while ((define_datas_index < define_datas_size)) {
                        define_data = ((Define_Data)Array__fetch1(define_datas, define_datas_index));
                        new_name = define_data->new_name;
                        value = define_data->value;
                        (void)String__string_append(buffer, (t__34 = String__form(((String)"\017      case %s%\n")), String__divide((t__34), String__f(new_name))));
                        define_datas_index = (define_datas_index+1);
                        (void)String__string_append(buffer, (t__35 = String__form(((String)"\017\tresult := %v%\n")), String__divide((t__35), String__f(new_name))));
                    }
                    (void)String__string_append(buffer, ((String)"\023    return result\n\n"));
                    /* # Generate unsigned routine: */
                    (void)String__string_append(buffer, (t__36 = String__form(((String)"\025routine unsigned@%s%\n")), String__divide((t__36), String__f(define_name))));
                    (void)String__string_append(buffer, (t__37 = String__form(((String)"\022    takes %l% %s%\n")), t__38 = String__f(define_name), String__divide(String__remainder((t__37), t__38), String__f(define_name))));
                    (void)String__string_append(buffer, ((String)"\026    returns Unsigned\n\n"));
                    (void)String__string_append(buffer, (t__39 = String__form(((String)"\044    # Return the ordinal of {%l%}.\n\n")), String__divide((t__39), String__f(define_name))));
                    (void)String__string_append(buffer, ((String)"\021    result :@= 0\n"));
                    (void)String__string_append(buffer, (t__40 = String__form(((String)"\017    switch %l%\n")), String__divide((t__40), String__f(define_name))));
                    define_datas_index = 0;
                    while ((define_datas_index < define_datas_size)) {
                        define_data = ((Define_Data)Array__fetch1(define_datas, define_datas_index));
                        new_name = define_data->new_name;
                        value = define_data->value;
                        (void)String__string_append(buffer, (t__41 = String__form(((String)"\017      case %s%\n")), String__divide((t__41), String__f(new_name))));
                        (void)String__string_append(buffer, (t__42 = String__form(((String)"\017\tresult := %s%\n")), String__divide((t__42), Unsigned__f(define_datas_index))));
                        define_datas_index = (define_datas_index+1);
                    }
                    (void)String__string_append(buffer, ((String)"\023    return result\n\n"));
                    /* # Generate next routine: */
                    (void)String__string_append(buffer, (t__43 = String__form(((String)"\021routine next@%s%\n")), String__divide((t__43), String__f(define_name))));
                    (void)String__string_append(buffer, (t__44 = String__form(((String)"\022    takes %l% %s%\n")), t__45 = String__f(define_name), String__divide(String__remainder((t__44), t__45), String__f(define_name))));
                    (void)String__string_append(buffer, (t__46 = String__form(((String)"\020    returns %s%\n")), String__divide((t__46), String__f(define_name))));
                    (void)String__string_append(buffer, (t__47 = String__form(((String)"\042    # Return the value of {%l%}.\n\n")), String__divide((t__47), String__f(define_name))));
                    (void)String__string_append(buffer, (t__48 = String__form(((String)"\023    result :@= %l%\n")), String__divide((t__48), String__f(define_name))));
                    (void)String__string_append(buffer, (t__49 = String__form(((String)"\017    switch %l%\n")), String__divide((t__49), String__f(define_name))));
                    define_datas_index = 0;
                    while ((define_datas_index < define_datas_size)) {
                        define_data = ((Define_Data)Array__fetch1(define_datas, define_datas_index));
                        define_data_next = ((Define_Data)Array__fetch1(define_datas, (((define_datas_index+1))%define_datas_size)));
                        new_name = define_data->new_name;
                        value = define_data->value;
                        (void)String__string_append(buffer, (t__50 = String__form(((String)"\017      case %s%\n")), String__divide((t__50), String__f(new_name))));
                        define_datas_index = (define_datas_index+1);
                        (void)String__string_append(buffer, (t__51 = String__form(((String)"\023\tresult := %s%@%s%\n")), t__52 = String__f(define_data_next->new_name), String__divide(String__remainder((t__51), t__52), String__f(define_name))));
                    }
                    (void)String__string_append(buffer, ((String)"\023    return result\n\n"));
                    define_datas_index = 0;
                    while ((define_datas_index < define_datas_size)) {
                        define_data = ((Define_Data)Array__fetch1(define_datas, define_datas_index));
                        new_name = define_data->new_name;
                        (void)String__string_append(buffer, (t__53 = String__form(((String)"\032external %s%@%s% %s%\t#D10\n")), t__54 = String__f(new_name), t__55 = String__f(define_name), String__divide(String__remainder(String__remainder((t__53), t__54), t__55), String__f(define_name))));
                        (void)String__string_append(buffer, (t__56 = String__form(((String)"\044external %s%@Unsigned Unsigned\t#D11\n")), String__divide((t__56), String__f(new_name))));
                        define_datas_index = (define_datas_index+1);
                    }
                }
                break;
        }
        index = (index+1);
    }
    generate = Define_Declaration__generate(define);
    if ((generate != Generate_Clause__null)) {
        generate_names = generate->names;
        size = Comma_Separated__size_get(generate_names);
        index = 0;
        while ((index < size)) {
            generate_name = ((Generate_Name)Comma_Separated__fetch1(generate_names, index));
            name = generate_name->name->value;
            if (String__equal(name, ((String)"\005parse"))) {
                (void)Define_Declaration__parse_generate(define, buffer, compiler);
            } else if (String__equal(name, ((String)"\010traverse"))) {
                (void)Define_Declaration__traverse_generate(define, buffer, compiler);
            } else {
                (void)Compiler__log(compiler, generate_name->name, (t__57 = String__form(((String)"\042Unrecognized %qv% generate keyword")), String__divide((t__57), String__f(name))));
            }
            index = (index+1);
        }
    }
    if (null_external_needed) {
        (void)String__string_append(buffer, (t__58 = String__form(((String)"\033external null@%t% %s%\t#D1\n\n")), t__59 = String__f(define_name), String__divide(String__remainder((t__58), t__59), String__f(define_name))));
    }
    if (new_needed) {
        (void)String__string_append(buffer, (t__60 = String__form(((String)"\020routine new@%t%\n")), String__divide((t__60), Type__f(define_type))));
        (void)String__string_append(buffer, ((String)"\022    takes_nothing\n"));
        (void)String__string_append(buffer, (t__61 = String__form(((String)"\020    returns %t%\n")), String__divide((t__61), Type__f(define_type))));
        (void)String__string_append(buffer, (t__62 = String__form(((String)"\027    external %s%__new\n\n")), String__divide((t__62), String__f(Type__base_name(define_type)))));
    }
}

void Define_Declaration__parse_generate(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_name;
    String locals;
    String code1;
    String code2;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    Field field;
    String field_name;
    Type field_type;
    String field_type_base;
    Logical is_array;
    Field_Clause next_field_clause;
    String next_field_name;
    Field next_field;
    Type sub_type;
    String enum_name;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    String t__17;
    String t__18;
    String t__19;
    String t__20;
    String t__21;
    String t__22;
    String t__23;
    String t__24;
    String t__25;
    String t__26;
    String t__27;
    String t__28;
    String t__29;
    String t__30;
    String t__31;
    String t__32;
    String t__33;
    String t__34;
    temporary = compiler->temporary;
    define_type = define->type;
    define_name = Type__base_name(define_type);
    locals = String__new();
    code1 = String__new();
    code2 = String__new();
    (void)String__string_append(buffer, (t__0 = String__form(((String)"\022routine parse@%s%\n")), String__divide((t__0), String__f(define_name))));
    (void)String__buffer_append(((String)"\030    takes parser Parser\n"), buffer);
    (void)String__string_append(buffer, (t__1 = String__form(((String)"\021    returns %s%\n\n")), String__divide((t__1), String__f(define_name))));
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___record:
                field_clauses = ((define_clause->kind == Define_Clause_Kind___record) ? define_clause->kind__union.record : (Record_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 2250))->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                (void)String__string_append(code2, (t__2 = String__form(((String)"\026    %l% :@= new@%t%()\n")), t__3 = String__f(define_name), String__divide(String__remainder((t__2), t__3), Type__f(define_type))));
                (void)String__buffer_append(((String)"\033    index :@= parser.index\n"), code1);
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 2264));
                            field_name = field->name->value;
                            field_type = field->type;
                            field_type_base = Type__base_name(field_type);
                            is_array = Logical__false;
                            (void)String__string_append(code1, (t__4 = String__form(((String)"\022    %s% :@= parse@")), String__divide((t__4), String__f(field_name))));
                            switch (field_type->kind) {
                                case Type_Kind___parameterized:

                                    next_field_clause = ((Field_Clause)Array__fetch1(field_clauses, (field_clauses_index+1)));
                                    next_field_name = ((String)"\000");
                                    switch (next_field_clause->kind) {
                                        case Field_Clause_Kind___field:
                                            next_field = ((next_field_clause->kind == Field_Clause_Kind___field) ? next_field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 2282));
                                            next_field_name = next_field->name->value;
                                            break;
                                    }
                                    sub_type = ((Type)Comma_Separated__fetch1(((field_type->kind == Type_Kind___parameterized) ? field_type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\17Declaration.ezc", 2285))->sub_types, 0));
                                    (void)String__string_append(code1, (t__5 = String__form(((String)"\055%t%(parser, parse@%t%, null@%t%, %s%@Lexeme)\n")), t__6 = Type__f(field_type), t__7 = Type__f(sub_type), t__8 = Type__f(sub_type), String__divide(String__remainder(String__remainder(String__remainder((t__5), t__6), t__7), t__8), String__f(next_field_name))));
                                    is_array = Logical__true;
                                    break;
                                case Type_Kind___simple:
                                    if (String__equal(field_type_base, ((String)"\005Token"))) {

                                        if (Lexeme__is_lexeme_string(field_name)) {
                                            (void)String__string_append(code1, (t__9 = String__form(((String)"\032Token(parser, %s%@Lexeme)\n")), String__divide((t__9), String__f(field_name))));
                                        } else {
                                            (void)String__string_append(code1, ((String)"\035Token(parser, symbol@Lexeme)\n"));
                                        }
                                    } else if (String__equal(field_type_base, ((String)"\007Keyword"))) {

                                        (void)String__string_append(code1, (t__10 = String__form(((String)"\026Keyword(parser, %qv%)\n")), String__divide((t__10), String__f(field_name))));
                                    } else {

                                        (void)String__string_append(code1, (t__11 = String__form(((String)"\014%t%(parser)\n")), String__divide((t__11), Type__f(field_type))));
                                    }
                                    break;
                                case Type_Kind___routine:
                                    (void)Compiler__log(compiler, field->name, (t__12 = String__form(((String)"\041parse routine for %t% not allowed")), String__divide((t__12), Type__f(field_type))));
                                    break;
                            }
                            if (is_array) {

                                (void)String__string_append(code1, (t__13 = String__form(((String)"\024    if %s%.size = 0\n")), String__divide((t__13), String__f(field_name))));
                            } else {

                                (void)String__string_append(code1, (t__14 = String__form(((String)"\027    if %s% == null@%t%\n")), t__15 = String__f(field_name), String__divide(String__remainder((t__14), t__15), Type__f(field_type))));
                            }
                            (void)String__string_append(code1, ((String)"\027\tparser.index := index\n"));
                            (void)String__string_append(code1, (t__16 = String__form(((String)"\022\treturn null@%t%\n\n")), String__divide((t__16), Type__f(define_type))));
                            (void)String__string_append(code2, (t__17 = String__form(((String)"\023    %l%.%s% := %s%\n")), t__18 = String__f(define_name), t__19 = String__f(field_name), String__divide(String__remainder(String__remainder((t__17), t__18), t__19), String__f(field_name))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                (void)String__string_append(code2, (t__20 = String__form(((String)"\020    return %l%\n\n")), String__divide((t__20), String__f(define_name))));
                goto break__1;
                break;
            case Define_Clause_Kind___variant:
                field_clauses = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 2339))->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                (void)String__string_append(code1, (t__21 = String__form(((String)"\026    %l% :@= new@%t%()\n")), t__22 = String__f(define_name), String__divide(String__remainder((t__21), t__22), Type__f(define_type))));
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 2349));
                            field_name = field->name->value;
                            field_type = field->type;
                            field_type_base = Type__base_name(field_type);
                            if (String__equal(field_type_base, ((String)"\005Token"))) {
                                enum_name = ((String)"\006symbol");
                                if (Lexeme__is_lexeme_string(field_name)) {
                                    enum_name = field_name;
                                }
                                (void)String__string_append(code1, (t__23 = String__form(((String)"\052    %s% :@= parse@%t%(parser, %s%@Lexeme)\n")), t__24 = String__f(field_name), t__25 = Type__f(field_type), String__divide(String__remainder(String__remainder((t__23), t__24), t__25), String__f(enum_name))));
                            } else {
                                (void)String__string_append(code1, (t__26 = String__form(((String)"\036    %s% :@= parse@%t%(parser)\n")), t__27 = String__f(field_name), String__divide(String__remainder((t__26), t__27), Type__f(field_type))));
                            }
                            (void)String__string_append(code1, (t__28 = String__form(((String)"\030    if %s% !== null@%t%\n")), t__29 = String__f(field_name), String__divide(String__remainder((t__28), t__29), Type__f(field_type))));
                            (void)String__string_append(code1, (t__30 = String__form(((String)"\020\t%l%.%s% := %s%\n")), t__31 = String__f(define_name), t__32 = String__f(field_name), String__divide(String__remainder(String__remainder((t__30), t__31), t__32), String__f(field_name))));
                            (void)String__string_append(code1, (t__33 = String__form(((String)"\015\treturn %l%\n\n")), String__divide((t__33), String__f(define_name))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                /* # A variant end, just return {Null}": */
                (void)String__string_append(code2, (t__34 = String__form(((String)"\025    return null@%t%\n\n")), String__divide((t__34), Type__f(define_type))));
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    (void)String__buffer_append(locals, buffer);
    (void)String__buffer_append(((String)"\001\n"), buffer);
    (void)String__buffer_append(code1, buffer);
    (void)String__buffer_append(code2, buffer);
}

void Define_Declaration__traverse_generate(
  Define_Declaration define,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Type define_type;
    String define_name;
    String locals;
    String code1;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    Array field_clauses;
    Unsigned field_clauses_size;
    Unsigned field_clauses_index;
    Field_Clause field_clause;
    Field field;
    String field_name;
    Type field_type;
    Parameterized_Type parameterized_type;
    Variant_Clause variant;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    String t__8;
    String t__9;
    String t__10;
    String t__11;
    String t__12;
    String t__13;
    String t__14;
    String t__15;
    String t__16;
    temporary = compiler->temporary;
    define_type = define->type;
    define_name = Type__base_name(define_type);
    locals = String__new();
    code1 = String__new();
    (void)String__string_append(buffer, (t__0 = String__form(((String)"\025routine traverse@%s%\n")), String__divide((t__0), String__f(define_name))));
    (void)String__string_append(buffer, (t__1 = String__form(((String)"\022    takes %l% %t%\n")), t__2 = String__f(define_name), String__divide(String__remainder((t__1), t__2), Type__f(define_type))));
    (void)String__buffer_append(((String)"\036    takes traverser Traverser\n"), buffer);
    (void)String__buffer_append(((String)"\025    returns_nothing\n\n"), buffer);
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___record:
                field_clauses = ((define_clause->kind == Define_Clause_Kind___record) ? define_clause->kind__union.record : (Record_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 2423))->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 2430));
                            field_name = field->name->value;
                            field_type = field->type;
                            switch (field_type->kind) {
                                case Type_Kind___simple:
                                    (void)String__string_append(code1, (t__3 = String__form(((String)"\052    call traverse@%t%(%l%.%s%, traverser)\n")), t__4 = Type__f(field_type), t__5 = String__f(define_name), String__divide(String__remainder(String__remainder((t__3), t__4), t__5), String__f(field_name))));
                                    break;
                                case Type_Kind___parameterized:
                                    parameterized_type = ((field_type->kind == Type_Kind___parameterized) ? field_type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\17Declaration.ezc", 2440));
                                    (void)String__string_append(code1, (t__6 = String__form(((String)"\070    call traverse@%t%(%l%.%s%, traverser, traverse@%t%)\n")), t__7 = Type__f(field_type), t__8 = String__f(define_name), t__9 = String__f(field_name), String__divide(String__remainder(String__remainder(String__remainder((t__6), t__7), t__8), t__9), Type__f(((Type)Comma_Separated__fetch1(parameterized_type->sub_types, 0))))));
                                    break;
                                case Type_Kind___routine:
                                    (void)Compiler__log(compiler, field->name, (t__10 = String__form(((String)"\042Traverse of type (%t%) not allowed")), String__divide((t__10), Type__f(field_type))));
                                    break;
                            }
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                goto break__1;
                break;
            case Define_Clause_Kind___variant:
                variant = ((define_clause->kind == Define_Clause_Kind___variant) ? define_clause->kind__union.variant : (Variant_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 2452));
                (void)String__string_append(code1, (t__11 = String__form(((String)"\023    switch %l%.%s%\n")), t__12 = String__f(define_name), String__divide(String__remainder((t__11), t__12), String__f(variant->kind_name->value))));
                field_clauses = variant->field_clauses;
                field_clauses_size = Array__size_get(field_clauses);
                field_clauses_index = 0;
                while ((field_clauses_index < field_clauses_size)) {
                    field_clause = ((Field_Clause)Array__fetch1(field_clauses, field_clauses_index));
                    switch (field_clause->kind) {
                        case Field_Clause_Kind___field:
                            field = ((field_clause->kind == Field_Clause_Kind___field) ? field_clause->kind__union.field : (Field)System__variant_object_fail((String)"\17Declaration.ezc", 2463));
                            field_name = field->name->value;
                            field_type = field->type;
                            (void)String__string_append(code1, (t__13 = String__form(((String)"\017      case %s%\n")), String__divide((t__13), String__f(field_name))));
                            (void)String__string_append(code1, (t__14 = String__form(((String)"\047\tcall traverse@%t%(%l%.%s%, traverser)\n")), t__15 = Type__f(field->type), t__16 = String__f(define_name), String__divide(String__remainder(String__remainder((t__14), t__15), t__16), String__f(field_name))));
                            break;
                    }
                    field_clauses_index = (field_clauses_index+1);
                }
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    (void)String__buffer_append(locals, buffer);
    (void)String__buffer_append(((String)"\001\n"), buffer);
    (void)String__buffer_append(code1, buffer);
    (void)String__buffer_append(((String)"\001\n"), buffer);
}

Generate_Clause Define_Declaration__generate(
  Define_Declaration define)
{
    Generate_Clause result;
    Array define_clauses;
    Unsigned size;
    Unsigned index;
    Define_Clause define_clause;
    result = Generate_Clause__null;
    define_clauses = define->define_clauses;
    size = Array__size_get(define_clauses);
    index = 0;
    while ((index < size)) {
        define_clause = ((Define_Clause)Array__fetch1(define_clauses, index));
        switch (define_clause->kind) {
            case Define_Clause_Kind___generate:
                result = ((define_clause->kind == Define_Clause_Kind___generate) ? define_clause->kind__union.generate : (Generate_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 2496));
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

/* # {Defines_Prefix_Declaration} routines: */
void Defines_Prefix_Declaration__visit(
  Defines_Prefix_Declaration defines_prefix,
  String buffer,
  Compiler compiler)
{
    switch (compiler->phase) {
        case Phase___prefix_scan:

            (void)Array__append(compiler->defines_prefixes, ((void *)(defines_prefix)));
            break;
    }
}

/* # {Easy_C_Declaration} routines: */
void Easy_C_Declaration__visit(
  Easy_C_Declaration easy_c,
  String buffer,
  Compiler compiler)
{
    /* do_nothing */;
}

/* # {External_Declaration} routines: */
Logical External_Declaration__equal(
  External_Declaration external_declaration1,
  External_Declaration external_declaration2)
{
    Logical result;
    result = 0;
    result = (Typed_Name__equal(external_declaration1->typed_name, external_declaration2->typed_name)&&Type__equal(external_declaration1->type, external_declaration2->type));
    return result;
}

void External_Declaration__visit(
  External_Declaration external,
  String buffer,
  Compiler compiler)
{
    Logical trace;
    Typed_Name typed_name;
    String external_name;
    Type external_type;
    String external_type_base;
    Type type;
    String temporary;
    Typed_Name_Object typed_name_object;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    trace = Logical__false;
    if (trace) {
        (void)String__d((t__1 = String__form(((String)"\046=>visit@External_Declaration(*,*,%s%)\n")), String__divide((t__1), Phase__f(compiler->phase))));
    }
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 2564);
    }
    typed_name = external->typed_name;
    external_name = typed_name->name->value;
    external_type = typed_name->type;
    external_type_base = Type__base_name(external_type);
    type = external->type;
    temporary = compiler->temporary;
    switch (compiler->phase) {
        case Phase___h_externs_emit:
            (void)String__string_append(buffer, (t__2 = String__form(((String)"\036extern %cb% %s%__%s%;;/*D13*/\n")), t__3 = Type__f(type), t__4 = String__f(external_type_base), String__divide(String__remainder(String__remainder((t__2), t__3), t__4), String__f(external_name))));
            break;
        case Phase___ezh_scan:
            switch (external_type->kind) {
                case Type_Kind___simple:
                    typed_name_object = Typed_Name_Object__new();
                    typed_name_object->kind = Typed_Name_Object_Kind___external; typed_name_object->kind__union.external = external;
                    (void)Compiler__typed_name_insert(compiler, typed_name, typed_name_object, typed_name->name, ((String)"\032visit@External_Declaration"));
                    break;
                default:
                    (void)Compiler__log(compiler, typed_name->name, (t__5 = String__form(((String)"\064external declaration requires a simple type, not %t%")), String__divide((t__5), Type__f(external_type))));
                    break;
            }
            break;
        case Phase___ezh_emit:
            (void)External_Declaration__traverse(external, compiler->traverser);
            break;
    }
    if (trace) {
        (void)String__d((t__7 = String__form(((String)"\046<=visit@External_Declaration(*,*,%s%)\n")), String__divide((t__7), Phase__f(compiler->phase))));
    }
}

void External_Named_Declaration__visit(
  External_Named_Declaration external_named,
  String buffer,
  Compiler compiler)
{
    Typed_Name typed_name;
    String external_name;
    Type external_type;
    String external_type_base;
    String temporary;
    Typed_Name_Object typed_name_object;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 2607);
    }
    typed_name = external_named->typed_name;
    external_name = typed_name->name->value;
    external_type = typed_name->type;
    external_type_base = Type__base_name(external_type);
    temporary = compiler->temporary;
    switch (compiler->phase) {
        case Phase___h_externs_emit:
            (void)String__string_append(buffer, (t__0 = String__form(((String)"\036extern %cb% %cb%__%s%;/*D14*/\n")), t__1 = Type__f(external_type), t__2 = Type__f(external_type), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), String__f(external_name))));
            break;
        case Phase___ezh_scan:
            switch (external_type->kind) {
                case Type_Kind___simple:
                    typed_name_object = Typed_Name_Object__new();
                    typed_name_object->kind = Typed_Name_Object_Kind___external_named; typed_name_object->kind__union.external_named = external_named;
                    (void)Compiler__typed_name_insert(compiler, typed_name, typed_name_object, typed_name->name, ((String)"\032visit@External_Declaration"));
                    break;
                default:
                    (void)Compiler__log(compiler, typed_name->name, (t__3 = String__form(((String)"\064external declaration requires a simple type, not %t%")), String__divide((t__3), Type__f(external_type))));
                    break;
            }
            break;
        case Phase___ezh_emit:
            (void)External_Named_Declaration__traverse(external_named, compiler->traverser);
            break;
    }
}

/* # {External_Named_Declaration} routines: */
Logical External_Named_Declaration__equal(
  External_Named_Declaration external_named_declaration1,
  External_Named_Declaration external_named_declaration2)
{
    Logical result;
    result = 0;
    result = (Typed_Name__equal(external_named_declaration1->typed_name, external_named_declaration2->typed_name)&&Token__equal(external_named_declaration1->string, external_named_declaration2->string));
    return result;
}

/* # {Global_Declaration} routines: */
Logical Global_Declaration__equal(
  Global_Declaration global_declaration1,
  Global_Declaration global_declaration2)
{
    Logical result;
    result = 0;
    result = (Typed_Name__equal(global_declaration1->typed_name, global_declaration2->typed_name)&&Type__equal(global_declaration1->type, global_declaration2->type));
    return result;
}

void Global_Declaration__visit(
  Global_Declaration global,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Typed_Name typed_name;
    String global_name;
    Type global_type;
    String global_type_base;
    Type type;
    String type_base;
    Typed_Name_Object typed_name_object;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 2678);
    }
    temporary = compiler->temporary;
    typed_name = global->typed_name;
    global_name = typed_name->name->value;
    global_type = typed_name->type;
    global_type_base = Type__base_name(global_type);
    type = global->type;
    type_base = Type__base_name(type);
    switch (compiler->phase) {
        case Phase___h_externs_emit:
            (void)String__string_append(buffer, (t__0 = String__form(((String)"\016%k% %s%__%s%;\n")), t__1 = String__f(type_base), t__2 = String__f(global_type_base), String__divide(String__remainder(String__remainder((t__0), t__1), t__2), String__f(global_name))));
            break;
        case Phase___ezh_scan:
            switch (global_type->kind) {
                case Type_Kind___simple:
                    typed_name_object = Typed_Name_Object__new();
                    typed_name_object->kind = Typed_Name_Object_Kind___global; typed_name_object->kind__union.global = global;
                    (void)Compiler__typed_name_insert(compiler, typed_name, typed_name_object, typed_name->name, ((String)"\030visit@Global_Declaration"));
                    break;
                default:
                    (void)Compiler__log(compiler, typed_name->name, (t__3 = String__form(((String)"\062global declaration requires a simple type, not %t%")), String__divide((t__3), Type__f(global_type))));
                    break;
            }
            break;
        case Phase___ezh_emit:
            (void)Global_Declaration__traverse(global, compiler->traverser);
            break;
    }
}

/* # {Global_Library_Declaration} routines: */
void Global_Library_Declaration__visit(
  Global_Library_Declaration global_library,
  String buffer,
  Compiler compiler)
{
    Token global_library_name;
    Source source;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 2720);
    }
    switch (compiler->phase) {
        case Phase___c_emit:
        case Phase___ezh_emit:
        case Phase___link_emit:
        case Phase___h_includes_emit:
            (void)Declaration__library_visit(Library_Declaration__null, Interface_Declaration__null, global_library, global_library->name->value, buffer, compiler);
            break;
        case Phase___source_find:

            global_library_name = global_library->name;
            source = compiler->source;
            (void)Array__append(source->global_libraries, ((void *)(global_library)));
            (void)Compiler__source_register(compiler, global_library_name->value, global_library_name);
            /* #assert 0f */
            /* #call append@(compiler.global_libraries, global_library) */
            /* #assert 0f */
            break;
        case Phase___c_defines_emit:
        case Phase___ezh_scan:
        case Phase___generate_emit:
        case Phase___h_externs_emit:
        case Phase___h_structs_emit:
        case Phase___h_typedefs_emit:
        case Phase___link_scan:
        case Phase___prefix_scan:
            /* do_nothing */
            break;
    }
}

/* # {Include_String_Declaration} routines: */
void Include_String_Declaration__visit(
  Include_String_Declaration include_string,
  String buffer,
  Compiler compiler)
{
    String temporary;
    String include_name;
    String upper_include_name;
    Unsigned size;
    Unsigned index;
    Character character;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 2753);
    }
    temporary = compiler->temporary;
    include_name = Token__string_convert(include_string->string);
    switch (compiler->phase) {
        case Phase___prefix_scan:
            (void)Array__append(compiler->includes, ((void *)(include_string)));
            break;
        case Phase___c_emit:
            (void)String__string_append(buffer, (t__0 = String__form(((String)"\025#include \"%s%\"/*D3*/\n")), String__divide((t__0), String__f(include_name))));
            break;
        case Phase___h_includes_emit:
            upper_include_name = String__new();
            (void)String__upper_case_append(upper_include_name, include_name);
            size = String__size_get(upper_include_name);
            index = 0;
            while ((index < size)) {
                character = String__fetch1(upper_include_name, index);
                if ((!Character__is_lower_case(character)&&!Character__is_upper_case(character)&&!Character__is_decimal_digit(character)&&(character != ((Character)'_')))) {
                    String__store1(upper_include_name, index, ((Character)'_'));
                }
                index = (index+1);
            }
            (void)String__string_append(buffer, (t__1 = String__form(((String)"\025#ifndef %s%_INCLUDED\n")), String__divide((t__1), String__f(upper_include_name))));
            (void)String__string_append(buffer, (t__2 = String__form(((String)"\025#include \"%s%\"/*D4*/\n")), String__divide((t__2), String__f(include_name))));
            (void)String__string_append(buffer, (t__3 = String__form(((String)"\032#endif /* %s%_INCLUDED */\n")), String__divide((t__3), String__f(upper_include_name))));
            break;
    }
}

/* # {Interface_Declaration} routines: */
void Interface_Declaration__visit(
  Interface_Declaration interface,
  String buffer,
  Compiler compiler)
{
    Token interface_name;
    Source source;
    switch (compiler->phase) {
        case Phase___c_emit:
        case Phase___ezh_emit:
        case Phase___link_emit:
        case Phase___h_includes_emit:
            (void)Declaration__library_visit(Library_Declaration__null, interface, Global_Library_Declaration__null, interface->name->value, buffer, compiler);
            break;
        case Phase___source_find:

            interface_name = interface->name;
            source = compiler->source;
            (void)Array__append(source->interfaces, ((void *)(interface)));
            (void)Compiler__source_register(compiler, interface_name->value, interface_name);
            break;
        case Phase___c_defines_emit:
        case Phase___ezh_scan:
        case Phase___generate_emit:
        case Phase___h_externs_emit:
        case Phase___h_structs_emit:
        case Phase___h_typedefs_emit:
        case Phase___link_scan:
        case Phase___prefix_scan:
            /* do_nothing */
            break;
    }
}

/* # {Libary_Declaration} routines: */
void Library_Declaration__visit(
  Library_Declaration library,
  String buffer,
  Compiler compiler)
{
    Source source;
    Token library_name;
    switch (compiler->phase) {
        case Phase___c_emit:
        case Phase___ezh_emit:
        case Phase___link_emit:
        case Phase___h_includes_emit:
            (void)Declaration__library_visit(library, Interface_Declaration__null, Global_Library_Declaration__null, library->name->value, buffer, compiler);
            break;
        case Phase___source_find:

            source = compiler->source;
            (void)Array__append(source->libraries, ((void *)(library)));
            library_name = library->name;
            (void)Compiler__source_register(compiler, library_name->value, library_name);
            break;
        case Phase___c_defines_emit:
        case Phase___ezh_scan:
        case Phase___generate_emit:
        case Phase___h_externs_emit:
        case Phase___h_structs_emit:
        case Phase___h_typedefs_emit:
        case Phase___link_scan:
        case Phase___prefix_scan:
            /* do_nothing */
            break;
    }
}

/* # {Load_Declaration} routines: */
void Load_Declaration__visit(
  Load_Declaration load,
  String buffer,
  Compiler compiler)
{
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 2850);
    }
    switch (compiler->phase) {
        case Phase___link_scan:
            (void)Array__append(compiler->loads, ((void *)(Token__string_convert(load->string))));
            break;
    }
}

/* # {Note} routines: */
void Note__visit(
  Note note,
  String buffer,
  Compiler compiler)
{
    String temporary;
    String t__0;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 2868);
    }
    temporary = compiler->temporary;
    switch (compiler->phase) {
        case Phase___ezh_emit:
            (void)Note__traverse(note, compiler->traverser);
            break;
        case Phase___c_emit:
            (void)Compiler__pad_append(compiler, buffer);
            (void)String__string_append(buffer, (t__0 = String__form(((String)"\012/* %s% */\n")), String__divide((t__0), String__f(note->comment->value))));
            break;
    }
}

/* # {Root} stuff: */
void Root__visit(
  Root root,
  String buffer,
  Compiler compiler,
  Phase phase)
{
    Logical trace;
    String temporary;
    Phase previous_phase;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    trace = Logical__false;
    temporary = compiler->temporary;
    if (trace) {
        (void)String__put((t__1 = String__form(((String)"\033=>visit@Root(*, *, *, %p%)\n")), String__divide((t__1), Phase__f(phase))), Out_Stream__error);
    }
    previous_phase = compiler->phase;
    compiler->phase = phase;
    (void)Array__visit(root->declarations, buffer, compiler, ((void (*)(void *, String, Compiler))(Declaration__visit)));
    if (trace) {
        (void)String__put((t__4 = String__form(((String)"\051<=visit@Root(*, buffer.size=%d%, *, %p%)\n")), t__5 = Unsigned__f(String__size_get(buffer)), String__divide(String__remainder((t__4), t__5), Phase__f(phase))), Out_Stream__error);
    }
    compiler->phase = previous_phase;
}

/* # {Routine_Clause} routines: */
String Routine_Clause__f(
  Routine_Clause routine_clause)
{
    String value;
    Traverser traverser;
    value = Format__field_next();
    traverser = Traverser__create(value, Array__new());
    (void)Routine_Clause__traverse(routine_clause, traverser);
    return value;
}

void Routine_Clause__format(
  Routine_Clause routine_clause,
  String buffer)
{
    Unsigned anchor;
    Unsigned size;
    Unsigned index;
    Character character;
    Traverser traverser;
    anchor = String__format_begin(buffer);
    size = String__size_get(buffer);
    index = (anchor+1);
    character = ((Character)' ');
    while (((index < size)&&(character != ((Character)'%')))) {
        character = String__fetch1(buffer, index);
        index = (index+1);
    }
    traverser = Traverser__create(buffer, Array__new());
    (void)Routine_Clause__traverse(routine_clause, traverser);
    (void)String__format_end(buffer, anchor);
}

void Routine_Clause__visit(
  Routine_Clause routine_clause,
  String buffer,
  Compiler compiler)
{
    Logical previous_tracing;
    Unsigned line_number;
    String temporary;
    Logical trace;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 2951);
    }
    previous_tracing = compiler->tracing;
    line_number = Token__line_number_get(Routine_Clause__location_get(routine_clause));
    compiler->tracing = (line_number == compiler->trace_line);
    temporary = compiler->temporary;
    trace = Logical__false;
    if (trace) {
        (void)String__put((t__3 = String__form(((String)"\061=>visit@Routine_Clause(): line:%d% trace:%l%\n%r%\n")), t__4 = Unsigned__f(line_number), t__5 = Logical__f(compiler->tracing), String__divide(String__remainder(String__remainder((t__3), t__4), t__5), Routine_Clause__f(routine_clause))), Out_Stream__error);
    }
    switch (routine_clause->kind) {
        case Routine_Clause_Kind___assert:
            (void)Assert_Statement__visit(((routine_clause->kind == Routine_Clause_Kind___assert) ? routine_clause->kind__union.assert : (Assert_Statement)System__variant_object_fail((String)"\17Declaration.ezc", 2968)), buffer, compiler);
            break;
        case Routine_Clause_Kind___c_array_access:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___call:
            (void)Call_Statement__visit(((routine_clause->kind == Routine_Clause_Kind___call) ? routine_clause->kind__union.call : (Call_Statement)System__variant_object_fail((String)"\17Declaration.ezc", 2972)), buffer, compiler);
            break;
        case Routine_Clause_Kind___do_nothing:
            (void)Compiler__pad_append(compiler, buffer);
            (void)String__buffer_append(((String)"\022/* do_nothing */;\n"), buffer);
            break;
        case Routine_Clause_Kind___end_of_line:

            /* do_nothing */
            break;
        case Routine_Clause_Kind___external:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___fail:
            (void)Compiler__pad_append(compiler, buffer);
            (void)String__buffer_append(((String)"\016/* fail() */;\n"), buffer);
            break;
        case Routine_Clause_Kind___if:
            (void)If_Statement__visit(((routine_clause->kind == Routine_Clause_Kind___if) ? routine_clause->kind__union.if___k : (If_Statement)System__variant_object_fail((String)"\17Declaration.ezc", 2985)), buffer, compiler);
            break;
        case Routine_Clause_Kind___interrupt:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___local:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___note:

            break;
        case Routine_Clause_Kind___return:
            (void)Return_Statement__visit(((routine_clause->kind == Routine_Clause_Kind___return) ? routine_clause->kind__union.return___k : (Return_Statement)System__variant_object_fail((String)"\17Declaration.ezc", 2993)), buffer, compiler);
            break;
        case Routine_Clause_Kind___returns:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___returns_nothing:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___set:
            (void)Set_Statement__visit(((routine_clause->kind == Routine_Clause_Kind___set) ? routine_clause->kind__union.set : (Set_Statement)System__variant_object_fail((String)"\17Declaration.ezc", 2999)), buffer, compiler);
            break;
        case Routine_Clause_Kind___scalar_cast:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___switch:
            (void)Switch_Statement__visit(((routine_clause->kind == Routine_Clause_Kind___switch) ? routine_clause->kind__union.switch___k : (Switch_Statement)System__variant_object_fail((String)"\17Declaration.ezc", 3003)), buffer, compiler);
            break;
        case Routine_Clause_Kind___take:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___take_import:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___takes_nothing:
            /* do_nothing */
            break;
        case Routine_Clause_Kind___while:
            (void)While_Statement__visit(((routine_clause->kind == Routine_Clause_Kind___while) ? routine_clause->kind__union.while___k : (While_Statement)System__variant_object_fail((String)"\17Declaration.ezc", 3011)), buffer, compiler);
            break;
        case Routine_Clause_Kind___error:
            /* do_nothing */
            break;
    }
    compiler->tracing = previous_tracing;
    if (trace) {
        (void)String__put(((String)"\031<=visit@Routine_Clause()\n"), Out_Stream__error);
    }
}

/* # {Require_Declaration} routines: */
Logical Routine_Declaration__c_array_access(
  Routine_Declaration routine)
{
    Logical result;
    Array routine_clauses;
    Unsigned size;
    Unsigned index;
    Routine_Clause routine_clause;
    result = Logical__false;
    routine_clauses = routine->routine_clauses;
    size = Array__size_get(routine_clauses);
    index = 0;
    while ((index < size)) {
        routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, index));
        switch (routine_clause->kind) {
            case Routine_Clause_Kind___c_array_access:
                result = Logical__true;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

void Require_Declaration__visit(
  Require_Declaration require,
  String buffer,
  Compiler compiler)
{
    String require_name;
    Options options;
    Array require_bases;
    Unsigned size;
    Unsigned index;
    require_name = require->name->value;
    switch (compiler->phase) {
        case Phase___h_includes_emit:

            options = compiler->options;
            require_bases = options->require_bases;
            size = Array__size_get(require_bases);
            index = 0;
            while ((index < size)) {
                if (String__equal(((String)Array__fetch1(require_bases, index)), require_name)) {
                    break;
                }
                index = (index+1);
            }
            if ((index >= size)) {
                (void)Array__append(require_bases, ((void *)(require_name)));
            }
            break;
    }
}

/* # {Routine_Declaration} routines: */
void Routine_Declaration__c_emit(
  Routine_Declaration routine,
  String buffer,
  Compiler compiler)
{
    String temporary;
    Typed_Name typed_name;
    Logical trace;
    String routine_name;
    Type routine_type;
    String routine_type_base;
    Logical c_array_access;
    String interrupt;
    Type scalar_cast;
    String external;
    Type return_type;
    String c_return_type;
    Array take_clauses;
    Array variables;
    Array temporaries;
    Unsigned size;
    Unsigned index;
    String c_type;
    Routine_Clause take_clause;
    String take_name;
    Type take_type;
    Take_Clause take;
    Take_Import_Clause take_import;
    Array routine_clauses;
    Routine_Clause routine_clause;
    Local_Clause local;
    String local_name;
    Type local_type;
    String code_buffer;
    Variable variable;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    compiler->label_count = 0;
    temporary = compiler->temporary;
    typed_name = routine->typed_name;
    trace = Logical__false;
    if (trace) {
        (void)String__put((t__1 = String__form(((String)"\016=>c_emit(%t%)\n")), String__divide((t__1), Typed_Name__f(typed_name))), Out_Stream__error);
    }
    routine_name = typed_name->name->value;
    routine_type = typed_name->type;
    routine_type_base = Type__base_name(routine_type);
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 3094);
    }
    c_array_access = Routine_Declaration__c_array_access(routine);
    interrupt = Routine_Declaration__interrupt(routine);
    scalar_cast = Routine_Declaration__scalar_cast(routine);
    external = Routine_Declaration__external(routine);
    if (((external == String__null)&&(scalar_cast == Type__null)&&!c_array_access)) {
        return_type = Routine_Declaration__return_type(routine);
        c_return_type = Type__c_type(return_type, routine_type, ((String)"\000"));
        take_clauses = Routine_Declaration__take_clauses_extract(routine);
        variables = compiler->variables;
        temporaries = compiler->temporaries;
        (void)Array__trim(variables, 0);
        (void)Array__trim(temporaries, 0);
        (void)Compiler__undefs_append(compiler, buffer);
        if ((interrupt == String__null)) {
            (void)String__buffer_append(c_return_type, buffer);
            (void)String__buffer_append(((String)"\001 "), buffer);
            /* # Deal with -M option: */
            if ((compiler->options->plain_main&&String__equal(routine_name, ((String)"\004main"))&&Type__equal(routine_type, compiler->type_easy_c))) {
                (void)String__buffer_append(((String)"\004main"), buffer);
            } else {
                (void)String__buffer_append(routine_type_base, buffer);
                (void)String__buffer_append(((String)"\002__"), buffer);
                (void)String__buffer_append(routine_name, buffer);
            }
            size = Array__size_get(take_clauses);
            if ((size == 0)) {
                (void)String__buffer_append(((String)"\007(void)\n"), buffer);
            } else {
                (void)String__buffer_append(((String)"\002(\n"), buffer);
                index = 0;
                while ((index < size)) {
                    (void)String__buffer_append(((String)"\002  "), buffer);
                    c_type = String__null;
                    take_clause = ((Routine_Clause)Array__fetch1(take_clauses, index));
                    take_name = String__null;
                    take_type = Type__null;
                    switch (take_clause->kind) {
                        case Routine_Clause_Kind___take:
                            take = ((take_clause->kind == Routine_Clause_Kind___take) ? take_clause->kind__union.take : (Take_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3138));
                            take_name = take->name->value;
                            take_type = take->type;
                            c_type = Type__c_type(take_type, routine_type, take_name);
                            break;
                        case Routine_Clause_Kind___take_import:
                            take_import = ((take_clause->kind == Routine_Clause_Kind___take_import) ? take_clause->kind__union.take_import : (Take_Import_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3143));
                            take_name = take_import->name->value;
                            take_type = take_import->type;
                            c_type = Token__string_convert(take_import->string);
                            break;
                    }
                    (void)String__buffer_append(c_type, buffer);
                    (void)Compiler__variable_insert(compiler, take_name, take_type, Logical__true);
                    index = (index+1);
                    if ((index == size)) {
                        (void)String__buffer_append(((String)"\002)\n"), buffer);
                    } else {
                        (void)String__buffer_append(((String)"\002,\n"), buffer);
                    }
                }
            }
        } else {
            (void)String__string_append(buffer, (t__2 = String__form(((String)"\011ISR(%s%)\n")), String__divide((t__2), String__f(interrupt))));
        }
        (void)String__buffer_append(((String)"\002{\n"), buffer);
        /* # Create all of the local variables: */
        routine_clauses = routine->routine_clauses;
        size = Array__size_get(routine_clauses);
        index = 0;
        while ((index < size)) {
            routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, index));
            switch (routine_clause->kind) {
                case Routine_Clause_Kind___local:
                    local = ((routine_clause->kind == Routine_Clause_Kind___local) ? routine_clause->kind__union.local : (Local_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3171));
                    local_name = local->name->value;
                    local_type = local->type;
                    (void)Compiler__variable_insert(compiler, local_name, local_type, Logical__false);
                    break;
            }
            index = (index+1);
        }
        /* # Generate the procedure code: */
        code_buffer = String__new();
        (void)Compiler__level_begin(compiler);
        (void)Array__visit(routine->routine_clauses, code_buffer, compiler, ((void (*)(void *, String, Compiler))(Routine_Clause__visit)));
        (void)Compiler__level_end(compiler);
        if ((return_type != Type__null)) {

            /* # a return statement (or Fail) statement: */
            index = 0;
            while ((index < size)) {
                routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, (size-1-index)));
                switch (routine_clause->kind) {
                    case Routine_Clause_Kind___end_of_line:
                    case Routine_Clause_Kind___note:
                        /* do_nothing */
                        break;
                    case Routine_Clause_Kind___return:
                    case Routine_Clause_Kind___fail:
                        goto break__1;
                        break;
                    default:
                        (void)Compiler__log(compiler, routine->typed_name->at_sign, (t__3 = String__form(((String)"\057%t% returns %t% but does not end in return/fail")), t__4 = Typed_Name__f(routine->typed_name), String__divide(String__remainder((t__3), t__4), Type__f(return_type))));
                        goto break__1;
                        break;
                }
                index = (index+1);
            }
            break__1:;
        }
        /* # Now output all of the variables: */
        size = Array__size_get(variables);
        index = 0;
        while ((index < size)) {
            variable = ((Variable)Array__fetch1(variables, index));
            if ((variable->level != 0)) {


                (void)String__buffer_append(((String)"\004    "), buffer);
                c_type = Type__c_type(variable->type, routine_type, variable->name);
                (void)String__buffer_append(c_type, buffer);
                (void)String__buffer_append(((String)"\002;\n"), buffer);
            }
            index = (index+1);
        }
        size = Array__size_get(temporaries);
        index = 0;
        while ((index < size)) {
            variable = ((Variable)Array__fetch1(temporaries, index));
            (void)String__buffer_append(((String)"\004    "), buffer);
            c_type = Type__c_type(variable->type, routine_type, variable->name);
            (void)String__buffer_append(c_type, buffer);
            (void)String__buffer_append(((String)"\002;\n"), buffer);
            index = (index+1);
        }
        (void)String__buffer_append(code_buffer, buffer);
        (void)String__buffer_append(((String)"\003}\n\n"), buffer);
        (void)Compiler__variables_clear(compiler);
    }
    if (trace) {
        (void)String__put((t__6 = String__form(((String)"\016<=c_emit(%t%)\n")), String__divide((t__6), Typed_Name__f(typed_name))), Out_Stream__error);
    }
}

Logical Routine_Declaration__compatible(
  Routine_Declaration routine1,
  Routine_Declaration routine2)
{
    Array routine_clauses1;
    Array routine_clauses2;
    External_Routine_Clause external1;
    Unsigned size;
    Unsigned index;
    Routine_Clause routine_clause;
    External_Routine_Clause external2;
    Type prototype1;
    Type prototype2;
    Logical result;
    routine_clauses1 = routine1->routine_clauses;
    routine_clauses2 = routine2->routine_clauses;
    external1 = External_Routine_Clause__null;
    size = Array__size_get(routine_clauses1);
    index = 0;
    while ((index < size)) {
        routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses1, index));
        switch (routine_clause->kind) {
            case Routine_Clause_Kind___external:
                external1 = ((routine_clause->kind == Routine_Clause_Kind___external) ? routine_clause->kind__union.external : (External_Routine_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3256));
                break;
        }
        index = (index+1);
    }
    external2 = External_Routine_Clause__null;
    size = Array__size_get(routine_clauses2);
    index = 0;
    while ((index < size)) {
        routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses2, index));
        switch (routine_clause->kind) {
            case Routine_Clause_Kind___external:
                external2 = ((routine_clause->kind == Routine_Clause_Kind___external) ? routine_clause->kind__union.external : (External_Routine_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3266));
                break;
        }
        index = (index+1);
    }
    prototype1 = Routine_Declaration__prototype_extract(routine1);
    prototype2 = Routine_Declaration__prototype_extract(routine2);
    result = 0;
    if ((Typed_Name__equal(routine1->typed_name, routine2->typed_name)&&Type__equal(prototype1, prototype2))) {

        if ((external1 == External_Routine_Clause__null)) {
            if ((external2 == External_Routine_Clause__null)) {

            } else {
                result = 1;
            }
        } else {
            if ((external2 == External_Routine_Clause__null)) {
                result = 1;
            } else {

                result = Token__equal(external1->name, external2->name);
            }
        }
    }
    return result;
}

String Routine_Declaration__external(
  Routine_Declaration routine)
{
    String result;
    Array routine_clauses;
    Unsigned size;
    Unsigned index;
    Routine_Clause routine_clause;
    result = String__null;
    routine_clauses = routine->routine_clauses;
    size = Array__size_get(routine_clauses);
    index = 0;
    while ((index < size)) {
        routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, index));
        switch (routine_clause->kind) {
            case Routine_Clause_Kind___external:
                result = ((routine_clause->kind == Routine_Clause_Kind___external) ? routine_clause->kind__union.external : (External_Routine_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3305))->name->value;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

void Routine_Declaration__h_externs_emit(
  Routine_Declaration routine,
  String buffer,
  Compiler compiler)
{
    Typed_Name typed_name;
    String routine_name;
    Type routine_type;
    String routine_base_name;
    String external;
    Type return_type;
    String c_return_type;
    Array take_clauses;
    Unsigned size;
    String prefix;
    Unsigned index;
    Routine_Clause take_clause;
    String c_type;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 3320);
    }
    typed_name = routine->typed_name;
    routine_name = typed_name->name->value;
    routine_type = typed_name->type;
    routine_base_name = Type__base_name(routine_type);
    external = Routine_Declaration__external(routine);
    return_type = Routine_Declaration__return_type(routine);
    c_return_type = Type__c_type(return_type, routine_type, ((String)"\000"));
    take_clauses = Routine_Declaration__take_clauses_extract(routine);
    (void)String__buffer_append(((String)"\007extern "), buffer);
    (void)String__buffer_append(c_return_type, buffer);
    (void)String__buffer_append(((String)"\001 "), buffer);
    if ((external == String__null)) {
        (void)String__buffer_append(routine_base_name, buffer);
        (void)String__buffer_append(((String)"\002__"), buffer);
        (void)String__buffer_append(routine_name, buffer);
    } else {
        (void)String__buffer_append(external, buffer);
    }
    (void)String__buffer_append(((String)"\001("), buffer);
    size = Array__size_get(take_clauses);
    if ((size == 0)) {
        (void)String__buffer_append(((String)"\004void"), buffer);
    } else {
        prefix = ((String)"\000");
        index = 0;
        while ((index < size)) {
            (void)String__buffer_append(prefix, buffer);
            prefix = ((String)"\002, ");
            take_clause = ((Routine_Clause)Array__fetch1(take_clauses, index));
            c_type = String__null;
            switch (take_clause->kind) {
                case Routine_Clause_Kind___take:
                    c_type = Type__c_type(((take_clause->kind == Routine_Clause_Kind___take) ? take_clause->kind__union.take : (Take_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3357))->type, routine_type, ((String)"\000"));
                    break;
                case Routine_Clause_Kind___take_import:
                    c_type = Token__string_convert(((take_clause->kind == Routine_Clause_Kind___take_import) ? take_clause->kind__union.take_import : (Take_Import_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3359))->string);
                    break;
            }
            (void)String__buffer_append(c_type, buffer);
            index = (index+1);
        }
    }
    (void)String__buffer_append(((String)"\003);\n"), buffer);
}

Array Routine_Declaration__take_clauses_extract(
  Routine_Declaration routine)
{
    Array take_clauses;
    Array routine_clauses;
    Unsigned size;
    Unsigned index;
    Routine_Clause routine_clause;
    take_clauses = Array__new();
    routine_clauses = routine->routine_clauses;
    size = Array__size_get(routine_clauses);
    index = 0;
    while ((index < size)) {
        routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, index));
        switch (routine_clause->kind) {
            case Routine_Clause_Kind___take:
            case Routine_Clause_Kind___take_import:
                (void)Array__append(take_clauses, ((void *)(routine_clause)));
                break;
        }
        index = (index+1);
    }
    return take_clauses;
}

Type Routine_Declaration__return_type(
  Routine_Declaration routine)
{
    Type type;
    Array routine_clauses;
    Unsigned size;
    Unsigned index;
    Routine_Clause routine_clause;
    Comma_Separated return_types;
    type = Type__null;
    routine_clauses = routine->routine_clauses;
    size = Array__size_get(routine_clauses);
    index = 0;
    while ((index < size)) {
        routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, index));
        switch (routine_clause->kind) {
            case Routine_Clause_Kind___returns:
                return_types = ((routine_clause->kind == Routine_Clause_Kind___returns) ? routine_clause->kind__union.returns : (Returns_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3398))->return_types;
                if (!((Comma_Separated__size_get(return_types) == 1))) {
                    System__assert_fail((String)"\17Declaration.ezc", 3399);
                }
                type = ((Type)Comma_Separated__fetch1(return_types, 0));
                break;
        }
        index = (index+1);
    }
    return type;
}

Type Routine_Declaration__prototype_extract(
  Routine_Declaration routine)
{
    Compiler compiler;
    Messages messages;
    String temporary;
    Typed_Name typed_name;
    Token routine_name;
    Unsigned position;
    File file;
    Logical tracing;
    Routine_Type routine_type;
    Comma_Separated takes_types;
    Comma_Separated return_types;
    Array commas;
    Array sub_types;
    Array routine_clauses;
    Unsigned size;
    Unsigned index;
    Routine_Clause routine_clause;
    Type prototype;
    String t__0;
    String t__1;
    String t__2;
    String t__3;
    String t__4;
    String t__5;
    String t__6;
    String t__7;
    compiler = Compiler__one_and_only();
    messages = compiler->messages;
    temporary = compiler->temporary;
    typed_name = routine->typed_name;
    routine_name = typed_name->name;
    position = routine_name->position;
    file = routine_name->file;
    tracing = compiler->tracing;
    tracing = Logical__false;
    if (tracing) {
        (void)String__put((t__1 = String__form(((String)"\055=>prototype_extract@routine_declaration(%t%)\n")), String__divide((t__1), Typed_Name__f(routine->typed_name))), Out_Stream__error);
    }
    routine_type = Routine_Type__new();
    takes_types = routine_type->takes_types;
    return_types = routine_type->return_types;
    commas = takes_types->commas;
    sub_types = takes_types->sub_types;
    routine_clauses = routine->routine_clauses;
    size = Array__size_get(routine_clauses);
    index = 0;
    while ((index < size)) {
        routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, index));
        switch (routine_clause->kind) {
            case Routine_Clause_Kind___take:
                if ((Comma_Separated__size_get(takes_types) != 0)) {
                    (void)Array__append(commas, ((void *)(Token__create(file, position, Lexeme__comma, ((String)"\001,")))));
                }
                (void)Array__append(sub_types, ((void *)(((routine_clause->kind == Routine_Clause_Kind___take) ? routine_clause->kind__union.take : (Take_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3442))->type)));
                break;
            case Routine_Clause_Kind___take_import:
                if ((Comma_Separated__size_get(takes_types) != 0)) {
                    (void)Array__append(commas, ((void *)(Token__create(file, position, Lexeme__comma, ((String)"\001,")))));
                }
                (void)Array__append(sub_types, ((void *)(((routine_clause->kind == Routine_Clause_Kind___take_import) ? routine_clause->kind__union.take_import : (Take_Import_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3447))->type)));
                break;
            case Routine_Clause_Kind___returns:
                return_types = ((routine_clause->kind == Routine_Clause_Kind___returns) ? routine_clause->kind__union.returns : (Returns_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3449))->return_types;
                break;
        }
        index = (index+1);
    }
    routine_type->open_bracket = Token__create(file, position, Lexeme__open_bracket, ((String)"\001["));
    routine_type->return_types = return_types;
    routine_type->less_than_or_equal = Token__create(file, position, Lexeme__less_than_or_equal, ((String)"\002<="));
    routine_type->takes_types = takes_types;
    routine_type->close_bracket = Token__create(file, position, Lexeme__close_bracket, ((String)"\001]"));
    prototype = Type__new();
    prototype->kind = Type_Kind___routine; prototype->kind__union.routine = routine_type;
    if (tracing) {
        (void)String__put((t__5 = String__form(((String)"\071<=prototype_extract@routine_declaration(%t%, %t%) => %t%\n")), t__6 = Typed_Name__f(routine->typed_name), t__7 = Token__f(routine->end_of_line), String__divide(String__remainder(String__remainder((t__5), t__6), t__7), Type__f(prototype))), Out_Stream__error);
    }
    return prototype;
}

void Routine_Declaration__visit(
  Routine_Declaration routine,
  String buffer,
  Compiler compiler)
{
    Messages messages;
    Traverser traverser;
    Array routine_clauses;
    Unsigned size;
    Unsigned index;
    Routine_Clause routine_clause;
    Logical ok;
    Unsigned end_index;
    Typed_Name_Object typed_name_object;
    Typed_Name typed_name;
    if (!((buffer != String__null))) {
        System__assert_fail((String)"\17Declaration.ezc", 3483);
    }
    messages = compiler->messages;
    compiler->current_routine = routine;
    switch (compiler->phase) {
        case Phase___c_emit:
            (void)Routine_Declaration__c_emit(routine, buffer, compiler);
            break;
        case Phase___h_externs_emit:
            (void)Routine_Declaration__h_externs_emit(routine, buffer, compiler);
            break;
        case Phase___ezh_emit:
            traverser = compiler->traverser;
            (void)Keyword__traverse(routine->routine, traverser);
            (void)Typed_Name__traverse(routine->typed_name, traverser);
            (void)Token__traverse(routine->end_of_line, traverser);
            (void)Token__traverse(routine->open_indent, traverser);
            routine_clauses = routine->routine_clauses;
            size = Array__size_get(routine_clauses);
            index = 0;
            while ((index < size)) {
                routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, index));
                switch (routine_clause->kind) {
                    case Routine_Clause_Kind___c_array_access:
                    case Routine_Clause_Kind___end_of_line:
                    case Routine_Clause_Kind___external:
                    case Routine_Clause_Kind___interrupt:
                    case Routine_Clause_Kind___returns:
                    case Routine_Clause_Kind___returns_nothing:
                    case Routine_Clause_Kind___scalar_cast:
                    case Routine_Clause_Kind___take:
                    case Routine_Clause_Kind___takes_nothing:
                    case Routine_Clause_Kind___take_import:
                        (void)Routine_Clause__traverse(routine_clause, traverser);
                        break;
                    case Routine_Clause_Kind___note:

                        /* # followed by a bare end-of line. */
                        ok = Logical__true;
                        end_index = (index+1);
                        while ((end_index < size)) {
                            switch (((Routine_Clause)Array__fetch1(routine_clauses, end_index))->kind) {
                                case Routine_Clause_Kind___note:

                                    end_index = (end_index+1);
                                    break;
                                case Routine_Clause_Kind___end_of_line:

                                    goto break__1;
                                    break;
                                default:

                                    ok = Logical__false;
                                    goto break__1;
                                    break;
                            }
                        }
                        break__1:;
                        if (ok) {
                            while ((index <= end_index)) {
                                (void)Routine_Clause__traverse(((Routine_Clause)Array__fetch1(routine_clauses, index)), traverser);
                                index = (index+1);
                            }
                        }
                        break;
                    case Routine_Clause_Kind___assert:
                    case Routine_Clause_Kind___call:
                    case Routine_Clause_Kind___do_nothing:
                    case Routine_Clause_Kind___error:
                    case Routine_Clause_Kind___fail:
                    case Routine_Clause_Kind___if:
                    case Routine_Clause_Kind___local:
                    case Routine_Clause_Kind___return:
                    case Routine_Clause_Kind___set:
                    case Routine_Clause_Kind___switch:
                    case Routine_Clause_Kind___while:
                        goto break__2;
                        break;
                }
                index = (index+1);
            }
            break__2:;
            break;
        case Phase___ezh_scan:
            typed_name_object = Typed_Name_Object__new();
            typed_name_object->kind = Typed_Name_Object_Kind___routine; typed_name_object->kind__union.routine = routine;
            typed_name = routine->typed_name;
            (void)Compiler__typed_name_insert(compiler, typed_name, typed_name_object, typed_name->name, ((String)"\031visit@Routine_Declaration"));
            break;
    }
}

String Routine_Declaration__interrupt(
  Routine_Declaration routine)
{
    String result;
    Array routine_clauses;
    Unsigned size;
    Unsigned index;
    Routine_Clause routine_clause;
    result = String__null;
    routine_clauses = routine->routine_clauses;
    size = Array__size_get(routine_clauses);
    index = 0;
    while ((index < size)) {
        routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, index));
        switch (routine_clause->kind) {
            case Routine_Clause_Kind___interrupt:
                result = ((routine_clause->kind == Routine_Clause_Kind___interrupt) ? routine_clause->kind__union.interrupt : (Interrupt_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3561))->name->value;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

Logical Routine_Declaration__is_parameter(
  Routine_Declaration routine,
  Type type)
{
    Logical result;
    Type routine_type;
    Comma_Separated parameters;
    Unsigned size;
    Unsigned index;
    result = Logical__false;
    routine_type = routine->typed_name->type;
    switch (routine_type->kind) {
        case Type_Kind___parameterized:
            parameters = ((routine_type->kind == Type_Kind___parameterized) ? routine_type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\17Declaration.ezc", 3579))->sub_types;
            size = Comma_Separated__size_get(parameters);
            index = 0;
            while ((index < size)) {
                if (Type__equal(((Type)Comma_Separated__fetch1(parameters, index)), type)) {
                    result = Logical__true;
                    break;
                }
                index = (index+1);
            }
            break;
    }
    return result;
}

Logical Routine_Declaration__returns_parameter(
  Routine_Declaration routine)
{
    Logical result;
    Typed_Name typed_name;
    Comma_Separated parameters;
    Type prototype;
    Routine_Type routine_type;
    Comma_Separated return_types;
    Type return_type;
    Unsigned size;
    Unsigned index;
    result = Logical__false;
    typed_name = routine->typed_name;
    switch (typed_name->type->kind) {
        case Type_Kind___parameterized:

            parameters = ((typed_name->type->kind == Type_Kind___parameterized) ? typed_name->type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\17Declaration.ezc", 3608))->sub_types;
            /* # Now get the return types: */
            prototype = Routine_Declaration__prototype_extract(routine);
            switch (prototype->kind) {
                case Type_Kind___routine:
                    routine_type = ((prototype->kind == Type_Kind___routine) ? prototype->kind__union.routine : (Routine_Type)System__variant_object_fail((String)"\17Declaration.ezc", 3614));
                    return_types = routine_type->return_types;
                    if ((Comma_Separated__size_get(return_types) >= 1)) {

                        return_type = ((Type)Comma_Separated__fetch1(return_types, 0));
                        switch (return_type->kind) {
                            case Type_Kind___parameterized:
                                parameters = ((return_type->kind == Type_Kind___parameterized) ? return_type->kind__union.parameterized : (Parameterized_Type)System__variant_object_fail((String)"\17Declaration.ezc", 3622))->sub_types;
                                /* # Now try to match up with a parameter: */
                                size = Comma_Separated__size_get(parameters);
                                index = 0;
                                while ((index < size)) {
                                    if (Type__equal(((Type)Comma_Separated__fetch1(parameters, index)), return_type)) {
                                        result = Logical__true;
                                        break;
                                    }
                                    index = (index+1);
                                }
                                break;
                        }
                    }
                    break;
                default:
                    if (!(Logical__false)) {
                        System__assert_fail((String)"\17Declaration.ezc", 3633);
                    }
                    break;
            }
            break;
    }
    return result;
}

Type Routine_Declaration__scalar_cast(
  Routine_Declaration routine)
{
    Type result;
    Array routine_clauses;
    Unsigned size;
    Unsigned index;
    Routine_Clause routine_clause;
    result = Type__null;
    routine_clauses = routine->routine_clauses;
    size = Array__size_get(routine_clauses);
    index = 0;
    while ((index < size)) {
        routine_clause = ((Routine_Clause)Array__fetch1(routine_clauses, index));
        switch (routine_clause->kind) {
            case Routine_Clause_Kind___scalar_cast:
                result = ((routine_clause->kind == Routine_Clause_Kind___scalar_cast) ? routine_clause->kind__union.scalar_cast : (Scalar_Cast_Clause)System__variant_object_fail((String)"\17Declaration.ezc", 3652))->type;
                goto break__1;
                break;
        }
        index = (index+1);
    }
    break__1:;
    return result;
}

/* # {Typed_Name_Object} routines; */
Logical Typed_Name_Object__equal(
  Typed_Name_Object typed_name_object1,
  Typed_Name_Object typed_name_object2)
{
    Logical result;
    result = 0;
    switch (typed_name_object1->kind) {
        case Typed_Name_Object_Kind___constant:
            switch (typed_name_object2->kind) {
                case Typed_Name_Object_Kind___constant:
                    result = Constant_Declaration__equal(((typed_name_object1->kind == Typed_Name_Object_Kind___constant) ? typed_name_object1->kind__union.constant : (Constant_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3675)), ((typed_name_object2->kind == Typed_Name_Object_Kind___constant) ? typed_name_object2->kind__union.constant : (Constant_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3675)));
                    break;
            }
            break;
        case Typed_Name_Object_Kind___external:
            switch (typed_name_object2->kind) {
                case Typed_Name_Object_Kind___external:
                    result = External_Declaration__equal(((typed_name_object1->kind == Typed_Name_Object_Kind___external) ? typed_name_object1->kind__union.external : (External_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3680)), ((typed_name_object2->kind == Typed_Name_Object_Kind___external) ? typed_name_object2->kind__union.external : (External_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3680)));
                    break;
            }
            break;
        case Typed_Name_Object_Kind___external_named:
            switch (typed_name_object2->kind) {
                case Typed_Name_Object_Kind___external_named:
                    result = External_Named_Declaration__equal(((typed_name_object1->kind == Typed_Name_Object_Kind___external_named) ? typed_name_object1->kind__union.external_named : (External_Named_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3684)), ((typed_name_object2->kind == Typed_Name_Object_Kind___external_named) ? typed_name_object2->kind__union.external_named : (External_Named_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3685)));
                    break;
            }
            break;
        case Typed_Name_Object_Kind___global:
            switch (typed_name_object2->kind) {
                case Typed_Name_Object_Kind___global:
                    result = Global_Declaration__equal(((typed_name_object1->kind == Typed_Name_Object_Kind___global) ? typed_name_object1->kind__union.global : (Global_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3690)), ((typed_name_object2->kind == Typed_Name_Object_Kind___global) ? typed_name_object2->kind__union.global : (Global_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3690)));
                    break;
            }
            break;
        case Typed_Name_Object_Kind___routine:
            switch (typed_name_object2->kind) {
                case Typed_Name_Object_Kind___routine:
                    result = Routine_Declaration__compatible(((typed_name_object1->kind == Typed_Name_Object_Kind___routine) ? typed_name_object1->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3694)), ((typed_name_object2->kind == Typed_Name_Object_Kind___routine) ? typed_name_object2->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3695)));
                    break;
            }
            break;
    }
    return result;
}

void Typed_Name_Object__show(
  Typed_Name_Object typed_name_object,
  String buffer)
{
    if ((typed_name_object == Typed_Name_Object__null)) {
        (void)String__buffer_append(((String)"\026null@Typed_Name_Object"), buffer);
    } else {
        switch (typed_name_object->kind) {
            case Typed_Name_Object_Kind___constant:
                (void)String__buffer_append(((String)"\010constant"), buffer);
                break;
            case Typed_Name_Object_Kind___external:
                (void)String__buffer_append(((String)"\010external"), buffer);
                break;
            case Typed_Name_Object_Kind___external_named:
                (void)String__buffer_append(((String)"\016external_named"), buffer);
                break;
            case Typed_Name_Object_Kind___global:
                (void)String__buffer_append(((String)"\006global"), buffer);
                break;
            case Typed_Name_Object_Kind___routine:
                (void)String__buffer_append(((String)"\007routine"), buffer);
                break;
        }
    }
}

Token Typed_Name_Object__location_get(
  Typed_Name_Object typed_name_object)
{
    Token result;
    result = Token__null;
    switch (typed_name_object->kind) {
        case Typed_Name_Object_Kind___constant:
            result = ((typed_name_object->kind == Typed_Name_Object_Kind___constant) ? typed_name_object->kind__union.constant : (Constant_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3731))->end_of_line;
            break;
        case Typed_Name_Object_Kind___external:
            result = ((typed_name_object->kind == Typed_Name_Object_Kind___external) ? typed_name_object->kind__union.external : (External_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3733))->end_of_line;
            break;
        case Typed_Name_Object_Kind___external_named:
            result = ((typed_name_object->kind == Typed_Name_Object_Kind___external_named) ? typed_name_object->kind__union.external_named : (External_Named_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3735))->end_of_line;
            break;
        case Typed_Name_Object_Kind___global:
            result = ((typed_name_object->kind == Typed_Name_Object_Kind___global) ? typed_name_object->kind__union.global : (Global_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3737))->end_of_line;
            break;
        case Typed_Name_Object_Kind___routine:
            result = ((typed_name_object->kind == Typed_Name_Object_Kind___routine) ? typed_name_object->kind__union.routine : (Routine_Declaration)System__variant_object_fail((String)"\17Declaration.ezc", 3739))->end_of_line;
            break;
    }
    return result;
}


String Typed_Name_Object_Kind__string_convert(
  Typed_Name_Object_Kind typed_name_object_kind)
{
    switch (typed_name_object_kind) {
        case Typed_Name_Object_Kind___constant:
            return ((String)"\010constant");
            break;
        case Typed_Name_Object_Kind___external:
            return ((String)"\010external");
            break;
        case Typed_Name_Object_Kind___external_named:
            return ((String)"\016external_named");
            break;
        case Typed_Name_Object_Kind___global:
            return ((String)"\006global");
            break;
        case Typed_Name_Object_Kind___routine:
            return ((String)"\007routine");
            break;
    }
    return ((String)"\000");
}


/* {Typed_Name_Object} stuff: */

Typed_Name_Object_Kind Typed_Name_Object_Kind__constant = Typed_Name_Object_Kind___constant;
Typed_Name_Object_Kind Typed_Name_Object_Kind__external = Typed_Name_Object_Kind___external;
Typed_Name_Object_Kind Typed_Name_Object_Kind__external_named = Typed_Name_Object_Kind___external_named;
Typed_Name_Object_Kind Typed_Name_Object_Kind__global = Typed_Name_Object_Kind___global;
Typed_Name_Object_Kind Typed_Name_Object_Kind__routine = Typed_Name_Object_Kind___routine;
struct Typed_Name_Object__Struct Typed_Name_Object__Initial = {
};

Typed_Name_Object Typed_Name_Object__null = &Typed_Name_Object__Initial;
void Typed_Name_Object__erase(
  Typed_Name_Object typed_name_object)
{
}

Typed_Name_Object Typed_Name_Object__new(void)
{
    Typed_Name_Object typed_name_object;
    extern void *malloc(size_t);

    typed_name_object = (Typed_Name_Object)malloc(sizeof(*typed_name_object));
    return typed_name_object;
}

void Typed_Name_Object__Initialize(void)
{
    Typed_Name_Object__erase(Typed_Name_Object__null);
}


