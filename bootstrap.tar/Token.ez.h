#ifndef TOKEN_INCLUDED
#define TOKEN_INCLUDED 1

/* Declare all enum's and typedef's first: */
/* h_emit1 */
typedef struct Tokenizer__Struct *Tokenizer;
enum Dispatch__Enum {
    Dispatch___apostrophe,
    Dispatch___amphersand,
    Dispatch___ascii,
    Dispatch___asterisk,
    Dispatch___at_sign,
    Dispatch___back_slash,
    Dispatch___caret,
    Dispatch___carriage_return,
    Dispatch___close_brace,
    Dispatch___close_bracket,
    Dispatch___close_parenthesis,
    Dispatch___colon,
    Dispatch___comma,
    Dispatch___decimal_digit,
    Dispatch___double_quote,
    Dispatch___dollar,
    Dispatch___e,
    Dispatch___equals,
    Dispatch___exclamation_point,
    Dispatch___forward_slash,
    Dispatch___grave_accent,
    Dispatch___greater_than,
    Dispatch___hash,
    Dispatch___hex_letter,
    Dispatch___hyphen,
    Dispatch___illegal,
    Dispatch___latin9,
    Dispatch___less_than,
    Dispatch___letter,
    Dispatch___line_feed,
    Dispatch___open_brace,
    Dispatch___open_bracket,
    Dispatch___open_parenthesis,
    Dispatch___octal_digit,
    Dispatch___percent,
    Dispatch___period,
    Dispatch___plus_sign,
    Dispatch___question_mark,
    Dispatch___semicolon,
    Dispatch___space,
    Dispatch___tab,
    Dispatch___tilde,
    Dispatch___underscore,
    Dispatch___vertical_bar,
    Dispatch___x,
    Dispatch___zero,
};
typedef enum Dispatch__Enum Dispatch;
typedef struct Define_Data__Struct *Define_Data;
typedef struct File__Struct *File;
enum Lexeme__Enum {
    Lexeme___add,
    Lexeme___and,
    Lexeme___assign,
    Lexeme___at_sign,
    Lexeme___character,
    Lexeme___close_brace,
    Lexeme___close_bracket,
    Lexeme___close_indent,
    Lexeme___close_invoke,
    Lexeme___close_parenthesis,
    Lexeme___close_type,
    Lexeme___colon,
    Lexeme___comma,
    Lexeme___comment,
    Lexeme___concatenate,
    Lexeme___conditional_and,
    Lexeme___conditional_or,
    Lexeme___define_assign,
    Lexeme___divide,
    Lexeme___dot,
    Lexeme___end,
    Lexeme___end_of_file,
    Lexeme___end_of_line,
    Lexeme___equals,
    Lexeme___error,
    Lexeme___float_number,
    Lexeme___greater_than,
    Lexeme___greater_than_or_equal,
    Lexeme___identical,
    Lexeme___left_shift,
    Lexeme___less_than,
    Lexeme___less_than_or_equal,
    Lexeme___logical_not,
    Lexeme___number,
    Lexeme___minus,
    Lexeme___multiply,
    Lexeme___negative,
    Lexeme___not,
    Lexeme___not_equal,
    Lexeme___not_identical,
    Lexeme___open_brace,
    Lexeme___open_bracket,
    Lexeme___open_indent,
    Lexeme___open_invoke,
    Lexeme___open_parenthesis,
    Lexeme___open_type,
    Lexeme___or,
    Lexeme___positive,
    Lexeme___question_mark,
    Lexeme___remainder,
    Lexeme___right_shift,
    Lexeme___semicolon,
    Lexeme___set,
    Lexeme___start,
    Lexeme___string,
    Lexeme___symbol,
    Lexeme___type_invoke,
    Lexeme___xor,
};
typedef enum Lexeme__Enum Lexeme;
typedef struct Message__Struct *Message;
typedef struct Messages__Struct *Messages;
typedef struct Token__Struct *Token;
/* h_emit2 */
/* h_emit3 */

/* Include other libraries exactly once: */
#ifndef EASY_C_INCLUDED
#include "Easy_C.ez.h"/*D2*/
#endif /* EASY_C_INCLUDED */
#ifndef COMPILER_INCLUDED
#include "Compiler.ez.h"/*D2*/
#endif /* COMPILER_INCLUDED */
#ifndef PARSE_INCLUDED
#include "Parse.ez.h"/*D2*/
#endif /* PARSE_INCLUDED */

/* Define the structures: */
struct Tokenizer__Struct {
    String buffer;
    String contents;
    Array dispatch_table;
    File file;
    Unsigned index;
    Array indents;
    Messages messages;
    Token previous;
    Array tokens;
    String white_space;
    Array white_spaces;
};
extern struct Tokenizer__Struct Tokenizer__Initial;/*D1*/
struct Define_Data__Struct {
    String old_name;
    String new_name;
    String value;
    String type_name;
};
extern struct Define_Data__Struct Define_Data__Initial;/*D1*/
struct File__Struct {
    Array define_datas;
    String contents;
    String directory;
    String name;
    Array positions;
    Array tokens;
    Root root;
};
extern struct File__Struct File__Initial;/*D1*/
struct Message__Struct {
    Token location;
    String text;
    Unsigned sequence;
};
extern struct Message__Struct Message__Initial;/*D1*/
struct Messages__Struct {
    Array errors;
};
extern struct Messages__Struct Messages__Initial;/*D1*/
struct Token__Struct {
    File file;
    Lexeme lexeme;
    Unsigned position;
    String value;
    String white_space;
};
extern struct Token__Struct Token__Initial;/*D1*/

/* Declare the routine prototypes: */
extern Tokenizer Tokenizer__null;/*D10*/
extern Tokenizer Tokenizer__new(void);/*D11*/
extern void Tokenizer__erase(Tokenizer);/*D12*/
extern Dispatch Dispatch__apostrophe;/*D3*/
extern Dispatch Dispatch__amphersand;/*D3*/
extern Dispatch Dispatch__ascii;/*D3*/
extern Dispatch Dispatch__asterisk;/*D3*/
extern Dispatch Dispatch__at_sign;/*D3*/
extern Dispatch Dispatch__back_slash;/*D3*/
extern Dispatch Dispatch__caret;/*D3*/
extern Dispatch Dispatch__carriage_return;/*D3*/
extern Dispatch Dispatch__close_brace;/*D3*/
extern Dispatch Dispatch__close_bracket;/*D3*/
extern Dispatch Dispatch__close_parenthesis;/*D3*/
extern Dispatch Dispatch__colon;/*D3*/
extern Dispatch Dispatch__comma;/*D3*/
extern Dispatch Dispatch__decimal_digit;/*D3*/
extern Dispatch Dispatch__double_quote;/*D3*/
extern Dispatch Dispatch__dollar;/*D3*/
extern Dispatch Dispatch__e;/*D3*/
extern Dispatch Dispatch__equals;/*D3*/
extern Dispatch Dispatch__exclamation_point;/*D3*/
extern Dispatch Dispatch__forward_slash;/*D3*/
extern Dispatch Dispatch__grave_accent;/*D3*/
extern Dispatch Dispatch__greater_than;/*D3*/
extern Dispatch Dispatch__hash;/*D3*/
extern Dispatch Dispatch__hex_letter;/*D3*/
extern Dispatch Dispatch__hyphen;/*D3*/
extern Dispatch Dispatch__illegal;/*D3*/
extern Dispatch Dispatch__latin9;/*D3*/
extern Dispatch Dispatch__less_than;/*D3*/
extern Dispatch Dispatch__letter;/*D3*/
extern Dispatch Dispatch__line_feed;/*D3*/
extern Dispatch Dispatch__open_brace;/*D3*/
extern Dispatch Dispatch__open_bracket;/*D3*/
extern Dispatch Dispatch__open_parenthesis;/*D3*/
extern Dispatch Dispatch__octal_digit;/*D3*/
extern Dispatch Dispatch__percent;/*D3*/
extern Dispatch Dispatch__period;/*D3*/
extern Dispatch Dispatch__plus_sign;/*D3*/
extern Dispatch Dispatch__question_mark;/*D3*/
extern Dispatch Dispatch__semicolon;/*D3*/
extern Dispatch Dispatch__space;/*D3*/
extern Dispatch Dispatch__tab;/*D3*/
extern Dispatch Dispatch__tilde;/*D3*/
extern Dispatch Dispatch__underscore;/*D3*/
extern Dispatch Dispatch__vertical_bar;/*D3*/
extern Dispatch Dispatch__x;/*D3*/
extern Dispatch Dispatch__zero;/*D3*/
extern Dispatch Dispatch__null;/*D6*/
extern String Dispatch__string_convert(Dispatch);/*D7*/
extern void Dispatch__erase(Dispatch);/*D8*/
extern Define_Data Define_Data__null;/*D10*/
extern Define_Data Define_Data__new(void);/*D11*/
extern void Define_Data__erase(Define_Data);/*D12*/
extern File File__null;/*D10*/
extern File File__new(void);/*D11*/
extern void File__erase(File);/*D12*/
extern Lexeme Lexeme__add;/*D3*/
extern Lexeme Lexeme__and;/*D3*/
extern Lexeme Lexeme__assign;/*D3*/
extern Lexeme Lexeme__at_sign;/*D3*/
extern Lexeme Lexeme__character;/*D3*/
extern Lexeme Lexeme__close_brace;/*D3*/
extern Lexeme Lexeme__close_bracket;/*D3*/
extern Lexeme Lexeme__close_indent;/*D3*/
extern Lexeme Lexeme__close_invoke;/*D3*/
extern Lexeme Lexeme__close_parenthesis;/*D3*/
extern Lexeme Lexeme__close_type;/*D3*/
extern Lexeme Lexeme__colon;/*D3*/
extern Lexeme Lexeme__comma;/*D3*/
extern Lexeme Lexeme__comment;/*D3*/
extern Lexeme Lexeme__concatenate;/*D3*/
extern Lexeme Lexeme__conditional_and;/*D3*/
extern Lexeme Lexeme__conditional_or;/*D3*/
extern Lexeme Lexeme__define_assign;/*D3*/
extern Lexeme Lexeme__divide;/*D3*/
extern Lexeme Lexeme__dot;/*D3*/
extern Lexeme Lexeme__end;/*D3*/
extern Lexeme Lexeme__end_of_file;/*D3*/
extern Lexeme Lexeme__end_of_line;/*D3*/
extern Lexeme Lexeme__equals;/*D3*/
extern Lexeme Lexeme__error;/*D3*/
extern Lexeme Lexeme__float_number;/*D3*/
extern Lexeme Lexeme__greater_than;/*D3*/
extern Lexeme Lexeme__greater_than_or_equal;/*D3*/
extern Lexeme Lexeme__identical;/*D3*/
extern Lexeme Lexeme__left_shift;/*D3*/
extern Lexeme Lexeme__less_than;/*D3*/
extern Lexeme Lexeme__less_than_or_equal;/*D3*/
extern Lexeme Lexeme__logical_not;/*D3*/
extern Lexeme Lexeme__number;/*D3*/
extern Lexeme Lexeme__minus;/*D3*/
extern Lexeme Lexeme__multiply;/*D3*/
extern Lexeme Lexeme__negative;/*D3*/
extern Lexeme Lexeme__not;/*D3*/
extern Lexeme Lexeme__not_equal;/*D3*/
extern Lexeme Lexeme__not_identical;/*D3*/
extern Lexeme Lexeme__open_brace;/*D3*/
extern Lexeme Lexeme__open_bracket;/*D3*/
extern Lexeme Lexeme__open_indent;/*D3*/
extern Lexeme Lexeme__open_invoke;/*D3*/
extern Lexeme Lexeme__open_parenthesis;/*D3*/
extern Lexeme Lexeme__open_type;/*D3*/
extern Lexeme Lexeme__or;/*D3*/
extern Lexeme Lexeme__positive;/*D3*/
extern Lexeme Lexeme__question_mark;/*D3*/
extern Lexeme Lexeme__remainder;/*D3*/
extern Lexeme Lexeme__right_shift;/*D3*/
extern Lexeme Lexeme__semicolon;/*D3*/
extern Lexeme Lexeme__set;/*D3*/
extern Lexeme Lexeme__start;/*D3*/
extern Lexeme Lexeme__string;/*D3*/
extern Lexeme Lexeme__symbol;/*D3*/
extern Lexeme Lexeme__type_invoke;/*D3*/
extern Lexeme Lexeme__xor;/*D3*/
extern Lexeme Lexeme__null;/*D6*/
extern String Lexeme__string_convert(Lexeme);/*D7*/
extern void Lexeme__erase(Lexeme);/*D8*/
extern Message Message__null;/*D10*/
extern Message Message__new(void);/*D11*/
extern void Message__erase(Message);/*D12*/
extern Messages Messages__null;/*D10*/
extern Messages Messages__new(void);/*D11*/
extern void Messages__erase(Messages);/*D12*/
extern Token Token__null;/*D10*/
extern Token Token__new(void);/*D11*/
extern void Token__erase(Token);/*D12*/
extern void Array__buffer_append(Array, String, void (*)(void *, String));
extern String Dispatch__f(Dispatch);
extern Logical File__check(File, Array);
extern File File__create(String, String, Array);
extern Unsigned File__line_number(File, Unsigned);
extern Logical Lexeme__is_lexeme_string(String);
extern File File__read(String, String, String, Compiler);
extern void File__show(File, String);
extern String Lexeme__f(Lexeme);
extern void Lexeme__format(Lexeme, String);
extern Logical Lexeme__is_continuation(Lexeme);
extern void Message__buffer_append(Message, String);
extern Integer Message__compare(Message, Message);
extern Message Message__create(Token, String, Unsigned);
extern Messages Messages__create(Out_Stream);
extern Logical Messages__dump(Messages, Out_Stream);
extern void Messages__log(Messages, Token, String);
extern void Messages__log2(Messages, Token, Token, String);
extern Unsigned Messages__size_get(Messages);
extern void Token__buffer_append(Token, String);
extern Token Token__create(File, Unsigned, Lexeme, String);
extern Integer Token__compare(Token, Token);
extern Logical Token__equal(Token, Token);
extern Unsigned Token__hash(Token);
extern String Token__f(Token);
extern Unsigned Token__line_number_get(Token);
extern String Token__source_name_get(Token);
extern String Token__string_convert(Token);
extern void Token__string_gap_insert(Token, String);
extern Tokenizer Tokenizer__create(Messages);
extern void Tokenizer__dispatch_range(Tokenizer, Character, Character, Dispatch);
extern void Tokenizer__finish(Tokenizer);
extern Token Tokenizer__next(Tokenizer);
extern void Tokenizer__start(Tokenizer, File);
extern void Tokenizer__store1(Tokenizer, Character, Dispatch);
extern void Tokenizer__tokenize(Tokenizer, File);
extern Tokenizer Tokenizer__null;;/*D13*/
extern Tokenizer Tokenizer__new(void);
extern Dispatch Dispatch__apostrophe;;/*D13*/
extern Dispatch Dispatch__amphersand;;/*D13*/
extern Dispatch Dispatch__ascii;;/*D13*/
extern Dispatch Dispatch__asterisk;;/*D13*/
extern Dispatch Dispatch__at_sign;;/*D13*/
extern Dispatch Dispatch__back_slash;;/*D13*/
extern Dispatch Dispatch__caret;;/*D13*/
extern Dispatch Dispatch__carriage_return;;/*D13*/
extern Dispatch Dispatch__close_brace;;/*D13*/
extern Dispatch Dispatch__close_bracket;;/*D13*/
extern Dispatch Dispatch__close_parenthesis;;/*D13*/
extern Dispatch Dispatch__colon;;/*D13*/
extern Dispatch Dispatch__comma;;/*D13*/
extern Dispatch Dispatch__decimal_digit;;/*D13*/
extern Dispatch Dispatch__double_quote;;/*D13*/
extern Dispatch Dispatch__dollar;;/*D13*/
extern Dispatch Dispatch__e;;/*D13*/
extern Dispatch Dispatch__equals;;/*D13*/
extern Dispatch Dispatch__exclamation_point;;/*D13*/
extern Dispatch Dispatch__forward_slash;;/*D13*/
extern Dispatch Dispatch__grave_accent;;/*D13*/
extern Dispatch Dispatch__greater_than;;/*D13*/
extern Dispatch Dispatch__hash;;/*D13*/
extern Dispatch Dispatch__hex_letter;;/*D13*/
extern Dispatch Dispatch__hyphen;;/*D13*/
extern Dispatch Dispatch__illegal;;/*D13*/
extern Dispatch Dispatch__latin9;;/*D13*/
extern Dispatch Dispatch__less_than;;/*D13*/
extern Dispatch Dispatch__letter;;/*D13*/
extern Dispatch Dispatch__line_feed;;/*D13*/
extern Dispatch Dispatch__open_brace;;/*D13*/
extern Dispatch Dispatch__open_bracket;;/*D13*/
extern Dispatch Dispatch__open_parenthesis;;/*D13*/
extern Dispatch Dispatch__octal_digit;;/*D13*/
extern Dispatch Dispatch__percent;;/*D13*/
extern Dispatch Dispatch__period;;/*D13*/
extern Dispatch Dispatch__plus_sign;;/*D13*/
extern Dispatch Dispatch__question_mark;;/*D13*/
extern Dispatch Dispatch__semicolon;;/*D13*/
extern Dispatch Dispatch__space;;/*D13*/
extern Dispatch Dispatch__tab;;/*D13*/
extern Dispatch Dispatch__tilde;;/*D13*/
extern Dispatch Dispatch__underscore;;/*D13*/
extern Dispatch Dispatch__vertical_bar;;/*D13*/
extern Dispatch Dispatch__x;;/*D13*/
extern Dispatch Dispatch__zero;;/*D13*/
extern String Dispatch__string_convert(Dispatch);
extern Dispatch Dispatch__null;;/*D13*/
extern Dispatch Dispatch__new(void);
extern Define_Data Define_Data__null;;/*D13*/
extern Define_Data Define_Data__new(void);
extern File File__null;;/*D13*/
extern File File__new(void);
extern Lexeme Lexeme__add;;/*D13*/
extern Lexeme Lexeme__and;;/*D13*/
extern Lexeme Lexeme__assign;;/*D13*/
extern Lexeme Lexeme__at_sign;;/*D13*/
extern Lexeme Lexeme__character;;/*D13*/
extern Lexeme Lexeme__close_brace;;/*D13*/
extern Lexeme Lexeme__close_bracket;;/*D13*/
extern Lexeme Lexeme__close_indent;;/*D13*/
extern Lexeme Lexeme__close_invoke;;/*D13*/
extern Lexeme Lexeme__close_parenthesis;;/*D13*/
extern Lexeme Lexeme__close_type;;/*D13*/
extern Lexeme Lexeme__colon;;/*D13*/
extern Lexeme Lexeme__comma;;/*D13*/
extern Lexeme Lexeme__comment;;/*D13*/
extern Lexeme Lexeme__concatenate;;/*D13*/
extern Lexeme Lexeme__conditional_and;;/*D13*/
extern Lexeme Lexeme__conditional_or;;/*D13*/
extern Lexeme Lexeme__define_assign;;/*D13*/
extern Lexeme Lexeme__divide;;/*D13*/
extern Lexeme Lexeme__dot;;/*D13*/
extern Lexeme Lexeme__end;;/*D13*/
extern Lexeme Lexeme__end_of_file;;/*D13*/
extern Lexeme Lexeme__end_of_line;;/*D13*/
extern Lexeme Lexeme__equals;;/*D13*/
extern Lexeme Lexeme__error;;/*D13*/
extern Lexeme Lexeme__float_number;;/*D13*/
extern Lexeme Lexeme__greater_than;;/*D13*/
extern Lexeme Lexeme__greater_than_or_equal;;/*D13*/
extern Lexeme Lexeme__identical;;/*D13*/
extern Lexeme Lexeme__left_shift;;/*D13*/
extern Lexeme Lexeme__less_than;;/*D13*/
extern Lexeme Lexeme__less_than_or_equal;;/*D13*/
extern Lexeme Lexeme__logical_not;;/*D13*/
extern Lexeme Lexeme__number;;/*D13*/
extern Lexeme Lexeme__minus;;/*D13*/
extern Lexeme Lexeme__multiply;;/*D13*/
extern Lexeme Lexeme__negative;;/*D13*/
extern Lexeme Lexeme__not;;/*D13*/
extern Lexeme Lexeme__not_equal;;/*D13*/
extern Lexeme Lexeme__not_identical;;/*D13*/
extern Lexeme Lexeme__open_brace;;/*D13*/
extern Lexeme Lexeme__open_bracket;;/*D13*/
extern Lexeme Lexeme__open_indent;;/*D13*/
extern Lexeme Lexeme__open_invoke;;/*D13*/
extern Lexeme Lexeme__open_parenthesis;;/*D13*/
extern Lexeme Lexeme__open_type;;/*D13*/
extern Lexeme Lexeme__or;;/*D13*/
extern Lexeme Lexeme__positive;;/*D13*/
extern Lexeme Lexeme__question_mark;;/*D13*/
extern Lexeme Lexeme__remainder;;/*D13*/
extern Lexeme Lexeme__right_shift;;/*D13*/
extern Lexeme Lexeme__semicolon;;/*D13*/
extern Lexeme Lexeme__set;;/*D13*/
extern Lexeme Lexeme__start;;/*D13*/
extern Lexeme Lexeme__string;;/*D13*/
extern Lexeme Lexeme__symbol;;/*D13*/
extern Lexeme Lexeme__type_invoke;;/*D13*/
extern Lexeme Lexeme__xor;;/*D13*/
extern String Lexeme__string_convert(Lexeme);
extern Lexeme Lexeme__null;;/*D13*/
extern Lexeme Lexeme__new(void);
extern Message Message__null;;/*D13*/
extern Message Message__new(void);
extern Messages Messages__null;;/*D13*/
extern Messages Messages__new(void);
extern Token Token__null;;/*D13*/
extern Token Token__new(void);

/* Declare extracted #define values: */
extern Unsigned Unsigned__unix_errno_2big;
extern Unsigned Unsigned__unix_errno_acces;
extern Unsigned Unsigned__unix_errno_addrinuse;
extern Unsigned Unsigned__unix_errno_addrnotavail;
extern Unsigned Unsigned__unix_errno_adv;
extern Unsigned Unsigned__unix_errno_afnosupport;
extern Unsigned Unsigned__unix_errno_again;
extern Unsigned Unsigned__unix_errno_already;
extern Unsigned Unsigned__unix_errno_asy_c_included;
extern Unsigned Unsigned__unix_errno_bade;
extern Unsigned Unsigned__unix_errno_badf;
extern Unsigned Unsigned__unix_errno_badfd;
extern Unsigned Unsigned__unix_errno_badmsg;
extern Unsigned Unsigned__unix_errno_badr;
extern Unsigned Unsigned__unix_errno_badrqc;
extern Unsigned Unsigned__unix_errno_badslt;
extern Unsigned Unsigned__unix_errno_bfont;
extern Unsigned Unsigned__unix_errno_busy;
extern Unsigned Unsigned__unix_errno_canceled;
extern Unsigned Unsigned__unix_errno_child;
extern Unsigned Unsigned__unix_errno_chrng;
extern Unsigned Unsigned__unix_errno_comm;
extern Unsigned Unsigned__unix_errno_connaborted;
extern Unsigned Unsigned__unix_errno_connrefused;
extern Unsigned Unsigned__unix_errno_connreset;
extern Unsigned Unsigned__unix_errno_deadlk;
extern Unsigned Unsigned__unix_errno_destaddrreq;
extern Unsigned Unsigned__unix_errno_dom;
extern Unsigned Unsigned__unix_errno_dotdot;
extern Unsigned Unsigned__unix_errno_dquot;
extern Unsigned Unsigned__unix_errno_exist;
extern Unsigned Unsigned__unix_errno_fault;
extern Unsigned Unsigned__unix_errno_fbig;
extern Unsigned Unsigned__unix_errno_hostdown;
extern Unsigned Unsigned__unix_errno_hostunreach;
extern Unsigned Unsigned__unix_errno_hwpoison;
extern Unsigned Unsigned__unix_errno_idrm;
extern Unsigned Unsigned__unix_errno_ilseq;
extern Unsigned Unsigned__unix_errno_inprogress;
extern Unsigned Unsigned__unix_errno_intr;
extern Unsigned Unsigned__unix_errno_inval;
extern Unsigned Unsigned__unix_errno_io;
extern Unsigned Unsigned__unix_errno_isconn;
extern Unsigned Unsigned__unix_errno_isdir;
extern Unsigned Unsigned__unix_errno_isnam;
extern Unsigned Unsigned__unix_errno_keyexpired;
extern Unsigned Unsigned__unix_errno_keyrejected;
extern Unsigned Unsigned__unix_errno_keyrevoked;
extern Unsigned Unsigned__unix_errno_l2hlt;
extern Unsigned Unsigned__unix_errno_l2nsync;
extern Unsigned Unsigned__unix_errno_l3hlt;
extern Unsigned Unsigned__unix_errno_l3rst;
extern Unsigned Unsigned__unix_errno_libacc;
extern Unsigned Unsigned__unix_errno_libbad;
extern Unsigned Unsigned__unix_errno_libexec;
extern Unsigned Unsigned__unix_errno_libmax;
extern Unsigned Unsigned__unix_errno_libscn;
extern Unsigned Unsigned__unix_errno_lnrng;
extern Unsigned Unsigned__unix_errno_loop;
extern Unsigned Unsigned__unix_errno_mediumtype;
extern Unsigned Unsigned__unix_errno_mfile;
extern Unsigned Unsigned__unix_errno_mlink;
extern Unsigned Unsigned__unix_errno_msgsize;
extern Unsigned Unsigned__unix_errno_multihop;
extern Unsigned Unsigned__unix_errno_nametoolong;
extern Unsigned Unsigned__unix_errno_navail;
extern Unsigned Unsigned__unix_errno_netdown;
extern Unsigned Unsigned__unix_errno_netreset;
extern Unsigned Unsigned__unix_errno_netunreach;
extern Unsigned Unsigned__unix_errno_nfile;
extern Unsigned Unsigned__unix_errno_noano;
extern Unsigned Unsigned__unix_errno_nobufs;
extern Unsigned Unsigned__unix_errno_nocsi;
extern Unsigned Unsigned__unix_errno_nodata;
extern Unsigned Unsigned__unix_errno_nodev;
extern Unsigned Unsigned__unix_errno_noent;
extern Unsigned Unsigned__unix_errno_noexec;
extern Unsigned Unsigned__unix_errno_nokey;
extern Unsigned Unsigned__unix_errno_nolck;
extern Unsigned Unsigned__unix_errno_nolink;
extern Unsigned Unsigned__unix_errno_nomedium;
extern Unsigned Unsigned__unix_errno_nomem;
extern Unsigned Unsigned__unix_errno_nomsg;
extern Unsigned Unsigned__unix_errno_nonet;
extern Unsigned Unsigned__unix_errno_nopkg;
extern Unsigned Unsigned__unix_errno_noprotoopt;
extern Unsigned Unsigned__unix_errno_nospc;
extern Unsigned Unsigned__unix_errno_nosr;
extern Unsigned Unsigned__unix_errno_nostr;
extern Unsigned Unsigned__unix_errno_nosys;
extern Unsigned Unsigned__unix_errno_notblk;
extern Unsigned Unsigned__unix_errno_notconn;
extern Unsigned Unsigned__unix_errno_notdir;
extern Unsigned Unsigned__unix_errno_notempty;
extern Unsigned Unsigned__unix_errno_notnam;
extern Unsigned Unsigned__unix_errno_notrecoverable;
extern Unsigned Unsigned__unix_errno_notsock;
extern Unsigned Unsigned__unix_errno_notty;
extern Unsigned Unsigned__unix_errno_notuniq;
extern Unsigned Unsigned__unix_errno_nxio;
extern Unsigned Unsigned__unix_errno_opnotsupp;
extern Unsigned Unsigned__unix_errno_overflow;
extern Unsigned Unsigned__unix_errno_ownerdead;
extern Unsigned Unsigned__unix_errno_perm;
extern Unsigned Unsigned__unix_errno_pfnosupport;
extern Unsigned Unsigned__unix_errno_pipe;
extern Unsigned Unsigned__unix_errno_proto;
extern Unsigned Unsigned__unix_errno_protonosupport;
extern Unsigned Unsigned__unix_errno_prototype;
extern Unsigned Unsigned__unix_errno_range;
extern Unsigned Unsigned__unix_errno_remchg;
extern Unsigned Unsigned__unix_errno_remote;
extern Unsigned Unsigned__unix_errno_remoteio;
extern Unsigned Unsigned__unix_errno_restart;
extern Unsigned Unsigned__unix_errno_rfkill;
extern Unsigned Unsigned__unix_errno_rofs;
extern Unsigned Unsigned__unix_errno_shutdown;
extern Unsigned Unsigned__unix_errno_socktnosupport;
extern Unsigned Unsigned__unix_errno_spipe;
extern Unsigned Unsigned__unix_errno_srch;
extern Unsigned Unsigned__unix_errno_srmnt;
extern Unsigned Unsigned__unix_errno_stale;
extern Unsigned Unsigned__unix_errno_strpipe;
extern Unsigned Unsigned__unix_errno_time;
extern Unsigned Unsigned__unix_errno_timedout;
extern Unsigned Unsigned__unix_errno_toomanyrefs;
extern Unsigned Unsigned__unix_errno_txtbsy;
extern Unsigned Unsigned__unix_errno_uclean;
extern Unsigned Unsigned__unix_errno_unatch;
extern Unsigned Unsigned__unix_errno_users;
extern Unsigned Unsigned__unix_errno_xdev;
extern Unsigned Unsigned__unix_errno_xfull;
extern Unsigned Unsigned__unix_errno_xit_failure;
extern Unsigned Unsigned__unix_errno_xit_success;
extern Unsigned Unsigned__unix_errno_asyc_c_h_included;
extern Integer Integer__unix_file_f_dupfd;
extern Integer Integer__unix_file_f_dupfd_cloexec;
extern Integer Integer__unix_file_f_exlck;
extern Integer Integer__unix_file_f_getfd;
extern Integer Integer__unix_file_f_getfl;
extern Integer Integer__unix_file_f_getlk;
extern Integer Integer__unix_file_f_getlk64;
extern Integer Integer__unix_file_f_getown;
extern Integer Integer__unix_file_f_lock;
extern Integer Integer__unix_file_f_ok;
extern Integer Integer__unix_file_f_rdlck;
extern Integer Integer__unix_file_f_setfd;
extern Integer Integer__unix_file_f_setfl;
extern Integer Integer__unix_file_f_setlk;
extern Integer Integer__unix_file_f_setlk64;
extern Integer Integer__unix_file_f_setlkw;
extern Integer Integer__unix_file_f_setlkw64;
extern Integer Integer__unix_file_f_setown;
extern Integer Integer__unix_file_f_shlck;
extern Integer Integer__unix_file_f_test;
extern Integer Integer__unix_file_f_tlock;
extern Integer Integer__unix_file_f_ulock;
extern Integer Integer__unix_file_f_unlck;
extern Integer Integer__unix_file_f_wrlck;
extern Unsigned Unsigned__unix_file_o_accmode;
extern Unsigned Unsigned__unix_file_o_append;
extern Unsigned Unsigned__unix_file_o_async;
extern Unsigned Unsigned__unix_file_o_cloexec;
extern Unsigned Unsigned__unix_file_o_creat;
extern Unsigned Unsigned__unix_file_o_directory;
extern Unsigned Unsigned__unix_file_o_dsync;
extern Unsigned Unsigned__unix_file_o_excl;
extern Unsigned Unsigned__unix_file_o_noctty;
extern Unsigned Unsigned__unix_file_o_nofollow;
extern Unsigned Unsigned__unix_file_o_nonblock;
extern Unsigned Unsigned__unix_file_o_rdonly;
extern Unsigned Unsigned__unix_file_o_rdwr;
extern Unsigned Unsigned__unix_file_o_sync;
extern Unsigned Unsigned__unix_file_o_trunc;
extern Unsigned Unsigned__unix_file_o_wronly;
#endif /* TOKEN_INCLUDED */
